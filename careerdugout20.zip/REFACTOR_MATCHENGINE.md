# Splitting `MatchEngine.kt` — commit by commit

6,292 lines, 107 functions, one class. The plan below moves every one of them
without changing a single line of football. **The proof that it worked is that
`GateKt` comes back byte-identical after each commit** — a file move that
changes the fingerprint was not a file move.

Do not start this until the gate from `NEXT.md` §0 is green and committed.

---

## The thing to know first: Kotlin has no partial classes

You cannot spread one class over several files. There are three ways out, and
only one of them is provable-by-fingerprint:

| approach | churn | risk |
|---|---|---|
| **A. Extension functions** — `internal fun MatchEngine.newPhase()` in another file | tiny; the body never changes | low |
| B. Collaborator classes — `class PhaseRunner(val m: MatchEngine)` | every field reference gains `m.` | medium |
| C. One class per engine version, sharing an interface | rewrite | high |

**Take A now.** The body of each moved function is copied unchanged; the only
edits are `private fun` → `internal fun MatchEngine.` at the top, and `private`
→ `internal` on the state that function touches. B is a fine destination later,
once the file boundaries have proved themselves — but it edits hundreds of
lines inside function bodies, which is exactly what you cannot do while
claiming nothing moved.

### Two traps that come with `internal`

1. **Name mangling.** Kotlin mangles `internal` *functions* on the JVM
   (`stageCorner$app_debug`). `UiFlow.kt` already survives this — it matches
   `it.name == name || it.name.startsWith("$name\$")` — but check every other
   reflective harness. `StageGate.kt` reads the *field* `stagedUntil`, and
   backing fields are not mangled, so that one is safe.
2. **Extensions do not see `private`.** Anything a moved function touches has
   to widen. Widen the minimum, one function group at a time, and never widen
   something "while you're in there".

---

## Move 0 — the free 850 lines: engine v1 is already dead

`ENGINE_V2 = true` is the shipped default and `ENGINE_V3 = false`, so the whole
v1 path in `update()` sits inside an `else` branch that never runs:

```kotlin
if (ENGINE_V3)      { ... v3Tick(step, minutes) }
else if (ENGINE_V2) { ... v2Tick(step, minutes) }
else {
    if (...) newPhase()          // ← dead under the shipped build
    ...  stepPhase() / resolvePhase()
}
```

That is `newPhase` (265) + `stepPhase` (198) + `resolvePhase` (190) plus
helpers — about **850 lines of the biggest file in the project that the game
never executes.** It is also the direct cause of the failure the v4 comment
describes: `CHANCE_QUALITY` was swept for four rows in `BalanceBig` while dead,
and `Scene.TAKE_ON` reads 0.00 a match because it is only reachable from v1.

Keep it — `docs/ENGINE_V2.md` is right that a control row has saved this project
twice — but keep it **somewhere else, and keep it honest**:

- move v1 to `sim/EngineV1.kt`;
- add `tools/harness/EngineFingerprints.kt` printing the fingerprint of v1, v2
  and v3 on the same seeds, so "the control row still runs" is a measured claim
  rather than a belief;
- put the live engine's name in the first line of every harness's output.

Note also the indentation left behind by that `else {` — the block is at the
wrong depth and the closing brace hangs alone. Straighten it **in its own
commit**, after the move, never during.

---

## Target layout

New files all go in `sim/`, so the existing harness compile line
(`$SRC/sim/*.kt`) and the CI workflow pick them up with no change.

| file | what moves into it | ~lines |
|---|---|---|
| `MatchEngine.kt` | class header, all state, `companion object`, `update()` and the tick helpers it splits into | ~1,000 |
| `EngineV1.kt` | `newPhase`, `stepPhase`, `resolvePhase`, `placeBall`, `moveBallTo`, `takeDelay` | ~560 |
| `EngineV2.kt` | `v2Give`…`v2Tick` (23 functions) | ~700 |
| `EngineV3.kt` | `v3Top`…`v3Move` (13 functions) | ~450 |
| `Shooting.kt` | `attemptShot`, `takePenalty`, `scoreGoal`, `blockerOnLine` | ~380 |
| `SetPieces.kt` | `stageFreeKick`, `stageGoalKick`, `stageThrowIn`, `stageCorner`, `stageKickOff` | ~270 |
| `Movement.kt` | `updateTargets`, `moveTowardTargets`, `lineupTargets`, `celebrationTargets`, `sceneTargets`, `pickChasers`, `assignDefensiveJobs`, `v2PickSupport`, `pressureOn`, `updatePressure`, `lastDefenderX`, `separate` | ~740 |
| `Officials.kt` | `showRef`, `cardRisk`, `card`, `sendOff`, `injure`, `flip`, `flipLater` | ~90 |
| `Presentation.kt` | `say`, `sayRaw`, `buildLine`, `fire`, `poseSeconds`, `sceneSeconds`, `sceneAfter`, `liveScene`, `cue`, `updateCrowd`, `updateDanger`, `holdDanger`, `captureFrame`, `advanceReplay` | ~180 |
| `Bench.kt` | `aiManagerThink`, `aiSubstitutions`, `substitute`, `canUse`, `reshape`, `rebuildShape`, `applyOppPlan`, `refreshRatings`, `buildSide`, `resetShape` | ~210 |
| `MatchClose.kt` | `start`, `pause`, `skipToEnd`, `endMatch`, `commit` | ~110 |

`LivePlayer`, `Ball`, `FeedLine`, `MatchEvent`, `Act`, `Ev`, `Mind`, `Scene`,
`Spoken` (lines 13–256) go to `MatchTypes.kt` first — they are already
independent top-level declarations, so that move is pure cut-and-paste and is
the right commit to practise the loop on.

---

## The loop, per commit

```sh
# 1. cut one group into its new file, unchanged
# 2. private -> internal on exactly what it now touches
# 3. compile + gate
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt tools/harness/shim/ThemeStub.kt \
    tools/harness/Harness.kt tools/harness/UiFlow.kt tools/gate/Gate.kt \
    -include-runtime -d build/gate.jar
java -Djava.awt.headless=true -cp build/gate.jar GateKt      # must PASS
# 4. commit. one group per commit, nothing else in it.
```

Order — easiest first, so the loop is boring before it is load-bearing:

1. `MatchTypes.kt` 2. `Presentation.kt` 3. `Officials.kt` 4. `Bench.kt`
5. `MatchClose.kt` 6. `SetPieces.kt` 7. `Shooting.kt` 8. `EngineV1.kt`
9. `EngineV3.kt` 10. `EngineV2.kt` 11. `Movement.kt`

`Movement.kt` is last because `updateTargets` (237) and `moveTowardTargets`
(197) read more private state than anything else in the class, and by then you
will know exactly how much widening that costs.

---

## Then, and only then: `update()` itself

534 lines. It is not one thing, it is nine, in a fixed order. Split it into
private members of the class — **not** extensions, because these are the
orchestration and they should stay next to the state they sequence:

```kotlin
fun update(dtSeconds: Float) {
    if (finished) return
    val vis = dtSeconds * speed
    if (advanceReplay(vis)) return
    if (tickIntro(vis)) return          // lineupTime, replayDelay
    val step = vis
    val minutes = step / SECONDS_PER_MINUTE
    if (tickHalf(minutes)) return       // half end, added time, kick off
    tickFatigue(minutes)
    val holdForGoal = tickRestarts(minutes)   // pendingSide, set pieces
    tickEngine(step, minutes, holdForGoal)    // v3 / v2 / v1 dispatch
    tickTeam(minutes)                   // ambient, subs, manager
    tickBall(step)                      // flight, spin, arrival, goal
    tickTimers(vis)                     // banners, scenes, ref, celebration
    tickPresentation(step)              // crowd, danger, capture
}
```

**Pass the locals, do not promote them to fields.** `step`, `minutes` and
`holdForGoal` are per-tick values; a field holding one of them is state that
outlives the tick, and `holdForGoal` in particular is documented in the file as
going stale *within* a single tick. Promoting it would reintroduce the goal-in-
midfield bug by hand.

Same loop after each extraction: compile, `GateKt`, commit.

---

## What this is worth

Nothing, on its own — the game plays identically, which is the point. What it
buys is that the next four items in `NEXT.md` stop being expensive: the corner
staging fault lives in `SetPieces.kt` + `Movement.kt` instead of somewhere in
six thousand lines, and the decision-score layer becomes a new file next to
`EngineV2.kt` with a fingerprint diff that means something.
