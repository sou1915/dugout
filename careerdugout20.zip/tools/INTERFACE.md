# BroadcastRenderer — hand-off notes

One file: `BroadcastRenderer.kt`, package `com.dugout.career.ui`.
Drop it in. It has no dependencies beyond `android.graphics` and `kotlin.math`,
no assets, no OpenGL, no state that survives a call.

## What you call

```kotlin
drawBroadcast(
    c: Canvas, w: Float, h: Float,
    players: List<RPlayer>, ball: RBall,
    homeKit: RKit, awayKit: RKit,
    camX: Float, camY: Float, zoom: Float
)
```

Once per frame, onto any Canvas. It paints every pixel it is given (sky, stand,
crowd, grass, markings, goals, figures, ball), so you do not need to clear first.
It clips to `0,0,w,h` and restores the canvas before returning.

`RPlayer`, `RBall` and `RKit` are declared in the same file with exactly the
fields you specified — nothing added, nothing renamed.

## What it needs from you

| Argument | Meaning |
|---|---|
| `w`, `h` | canvas size in pixels. Any aspect ratio. |
| `players` | any length, any order. Sorted internally, back to front. |
| `ball` | `height` is in the same units as `y` (1 unit = 0.68 m). |
| `homeKit` / `awayKit` | `pattern`: 0 solid, 1 vertical stripes, 2 sash, 3 hoops. |
| `camX`, `camY` | the point the camera tracks, in pitch coords. Usually the ball, smoothed by you. |
| `zoom` | 1.0 is the default broadcast framing. 0.2 fits the whole pitch. |

Per-player fields that must be right for the figures to move properly:

- `facing` — radians, `0` = +x, `PI/2` = toward the camera. Used as a real 3D
  body rotation, so a player running across the screen shows their side.
- `speed` — pitch units/second, `0` when still. Drives stride length, forward
  lean and arm swing. Saturates around 7.5 units/s (a sprint).
- `runPhase` — a free-running gait accumulator; advance it by
  `speed * k * dt` (k ≈ 1.4 gives a natural cadence) and let it wrap.
  Do not reset it to 0 when a player stops or the legs will snap.
- `seed` — any stable per-player int. Picks skin tone, hair colour and a ±4.5%
  height variation. Keep it constant for the life of the player.
- `isKeeper` — gets a kit chosen to sit far from *both* outfield kits in RGB
  space, and a wider arm carriage.

## What it does not do

No HUD, no scoreboard, no radar, no menus, no match logic, no input. It does not
read the clock, allocate bitmaps, or cache anything between calls: two calls with
identical arguments produce byte-identical output (this is asserted by the
harness — `warmup: frame2 == frame3 -> true`).

## Camera

Real pinhole projection. World space is metres:
`Xm = x * 1.05`, `Ym = y * 0.68` (increasing toward the camera), `Zm` up. The eye
sits behind the near touchline, above the ground, tilted down by a fixed angle;
screen position *and* scale both fall off as `1/depth`. Panning follows `camX` by
translating the eye and follows `camY` by shifting the principal point, so the
tilt angle — and therefore the measured convergence — never drifts as play moves.

Tunables live in `object BroadcastCamera` (all `@JvmField var`, safe to set at
startup):

| Field | Default | Effect |
|---|---|---|
| `backM` | 101.3 | metres behind the near touchline |
| `heightM` | 42.0 | eye height |
| `tiltDeg` | 22.0 | fixed downward tilt |
| `focalK` | 4.8 | focal length in screen widths at `zoom = 1` |
| `aimBias` | 0.62 | where the tracked point sits vertically, 0..1 |
| `figureScale` | 1.25 | figure size vs true metric height |
| `minLinePx` | 1.7 | floor on painted-line thickness |
| `drawStands` | true | stand, crowd, hoardings, dugouts |
| `drawGoals` | true | goal frames and nets |

The first three set the convergence and are coupled: the far/near touchline ratio
is `(backM + heightM·tan(tilt)) / (68 + backM + heightM·tan(tilt))`. Raising
`heightM` or `tiltDeg` opens the pitch out vertically but pushes the *player*
height ratio up; the defaults sit in the middle of both required windows
(0.636 and 0.667). If you want a punchier, closer camera, cut `backM` — but
re-measure, because the ratios move fast.

`figureScale` is the one deliberate lie: 1.25 draws players 25% larger than
1.80 m, which is what the PS1 originals did so figures read on a 480i panel. It
is uniform, so it cannot affect the far/near ratio. Set it to 1.0 for metric
truth.

## Cost per frame

No allocation in the hot path except a handful of `Paint`/`Path` objects created
once per call. Roughly: 1 grass quad + 26 stripe quads, ~40 marking trapezoids
and arcs, ~2 200 crowd rects (cull with `drawStands = false` if you need the
frames back), ~90 net lines per goal, and ~22 polygons per figure. On a mid-range
phone that is comfortably inside a 16 ms budget at 1080p, and the crowd is the
only thing worth cutting first.

## Verifying a change

`harness/` compiles the renderer against a small Java2D implementation of
`android.graphics` and writes PNGs; `tools/measure.py` and `tools/audit.py`
measure those PNGs and unproject them back to metres. If you touch the camera or
the markings, re-run both and check the numbers in `MEASUREMENTS.txt` — in
particular the two ratios the brief pins down, and the "distance from each
marking pixel to the true 105×68 layout" line, which should stay in centimetres.

```
javac -d build/shim $(find shim -name '*.java')
kotlinc -cp build/shim -d build/classes src/com/dugout/career/ui/BroadcastRenderer.kt harness/*.kt
java -cp build/classes:build/shim:$KOTLIN_HOME/lib/kotlin-stdlib.jar harness.HarnessKt
python3 tools/measure.py && python3 tools/audit.py
```
