import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import java.io.File

/**
 * THE GATE. One program, one exit code.
 *
 * Every harness in tools/ prints and returns 0, so nothing in this project can
 * fail a build. That is the gap this closes. It runs the same fingerprint as
 * ResultFingerprint.kt -- byte for byte the same FNV-1a over the same fields,
 * so the numbers stay comparable with everything already written down -- and
 * then it EXITS NON-ZERO when the answer moved.
 *
 * It is a "did you break it" gate, not a balance gate. 200 matches carries a
 * standard error of about 0.11 goals, so the band below is deliberately wide:
 * it catches an engine that has stopped scoring or started scoring twice, not
 * a tuning drift. Tuning stays with BalanceBig on the nightly job, where 9,120
 * matches make the interval mean something.
 *
 *   java -cp build/gate.jar GateKt              check against the baseline
 *   java -cp build/gate.jar GateKt --record     write the baseline (do this
 *                                               on purpose, and say why in
 *                                               the commit message)
 *
 * WHEN THE FINGERPRINT CHANGES AND YOU MEANT IT: re-record, and put the old
 * and new hash in the commit message with the reason. A re-record with no
 * explanation is the same as having no gate at all.
 */

private const val MATCHES = 200
private const val WORLD_SEED = 20260727L
private const val GOALS_MIN = 2.10
private const val GOALS_MAX = 3.10

private class Run(
    val fingerprint: Long,
    val goals: Double,
    val shots: Double,
    val cards: Double,
    val corners: Double,
    val stalled: Int
)

private fun play(): Run {
    val world = World.build(WORLD_SEED)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    if (league.isEmpty()) error("no league fixtures in the calendar")

    var hash = 1469598103934665603L          // FNV-1a 64, as ResultFingerprint
    fun mix(v: Long) { hash = hash xor v; hash *= 1099511628211L }

    var goals = 0; var shots = 0; var cards = 0; var corners = 0; var stalled = 0

    for (i in 0 until MATCHES) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.speed = 6f
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 200_000) {
            m.update(1f / 30f)
            if (!m.running && !m.finished) m.start()
            m.sound.clear()
        }
        // A match that runs out of guard never reached full time. It is a hang,
        // not a result, and it must fail the build rather than be averaged in.
        if (!m.finished) stalled++

        mix(m.score[0].toLong()); mix(m.score[1].toLong())
        mix(m.shots[0].toLong()); mix(m.shots[1].toLong())
        mix(m.onTarget[0].toLong()); mix(m.onTarget[1].toLong())
        mix((m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]).toLong())
        mix(m.corners[0].toLong()); mix(m.corners[1].toLong())

        goals += m.score[0] + m.score[1]
        shots += m.shots[0] + m.shots[1]
        cards += m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]
        corners += m.corners[0] + m.corners[1]
    }
    val n = MATCHES.toDouble()
    return Run(hash, goals / n, shots / n, cards / n, corners / n, stalled)
}

private fun baselineFile(): File {
    // Runs from the repo root in CI and from anywhere locally.
    val here = File("tools/gate/baseline.properties")
    if (here.exists()) return here
    val up = File("../tools/gate/baseline.properties")
    return if (up.exists()) up else here
}

fun main(args: Array<String>) {
    val record = args.contains("--record")
    val started = System.currentTimeMillis()
    val r = play()
    val seconds = (System.currentTimeMillis() - started) / 1000

    println("=== gate: $MATCHES matches, world $WORLD_SEED, ${seconds}s ===")
    println(String.format("goals %.3f   shots %.2f   cards %.3f   corners %.2f",
        r.goals, r.shots, r.cards, r.corners))
    println(String.format("FINGERPRINT %016x", r.fingerprint))
    println()

    if (record) {
        val f = baselineFile()
        f.parentFile?.mkdirs()
        f.writeText(
            "# Written by Gate.kt --record. Re-record only on purpose, and put\n" +
            "# the old hash, the new hash and the reason in the commit message.\n" +
            String.format("fingerprint=%016x%n", r.fingerprint) +
            String.format("goals=%.4f%n", r.goals) +
            "matches=$MATCHES\n" +
            "seed=$WORLD_SEED\n"
        )
        println("baseline written to ${f.path}")
        return
    }

    val f = baselineFile()
    if (!f.exists()) {
        System.err.println("FAIL: no baseline at ${f.path}. Run with --record once and commit it.")
        kotlin.system.exitProcess(2)
    }
    val props = f.readLines()
        .filter { it.contains('=') && !it.trimStart().startsWith("#") }
        .associate { val k = it.substringBefore('='); k.trim() to it.substringAfter('=').trim() }

    val want = props["fingerprint"] ?: ""
    val got = String.format("%016x", r.fingerprint)

    var failed = false

    if (r.stalled > 0) {
        System.err.println("FAIL: ${r.stalled}/$MATCHES matches never reached full time.")
        failed = true
    }
    if (r.goals < GOALS_MIN || r.goals > GOALS_MAX) {
        System.err.println(String.format(
            "FAIL: goals per game %.3f is outside the sanity band %.2f-%.2f.",
            r.goals, GOALS_MIN, GOALS_MAX))
        failed = true
    }
    if (got != want) {
        System.err.println("RESULTS MOVED: baseline $want, this build $got.")
        System.err.println("  If the change was meant to be cosmetic, it was not: something on")
        System.err.println("  the cosmetic path is freezing a player and feeding the outcome model.")
        System.err.println("  If you meant to change the football, re-record and explain it:")
        System.err.println("    java -cp build/gate.jar GateKt --record")
        failed = true
    }

    if (failed) kotlin.system.exitProcess(1)
    println("PASS: fingerprint matches the baseline, nothing moved.")
}
