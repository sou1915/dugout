import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * Follow one corner, tick by tick, and print what the staging gate is doing.
 *
 * StagingCheck says 3.4 attackers are in the box when a corner is taken. A
 * rendered frame of a corner shows the keeper alone and the radar puts every
 * outfield player at the far end. One of them is lying.
 *
 * The suspicion is the queued path: stageCorner runs when the corner is
 * CONCEDED, but sceneAfter defers the CORNER caption behind whatever live scene
 * is up, so stagedUntil burns down before the scene it is meant to hold ever
 * begins. This prints stagedUntil, sceneTime, the scene, and where the men
 * actually are, so the answer is not a guess.
 */
fun main(args: Array<String>) {
    val corners = args.firstOrNull()?.toIntOrNull() ?: 3
    val seed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L

    val staged = MatchEngine::class.java.getDeclaredField("stagedUntil")
    staged.isAccessible = true

    var seen = 0
    var match = 0
    while (seen < corners && match < 8) {
        val m = newEngine(seed + match * 7919L)
        m.replaysEnabled = false
        m.start()
        var wasCorners = 0
        var trace = 0
        var guard = 0
        while (!m.finished && seen < corners && guard++ < 900_000) {
            val before = m.corners[0] + m.corners[1]
            m.update(1f / 36f)
            m.sound.clear()
            val now = m.corners[0] + m.corners[1]
            if (now > before) {
                seen++
                trace = 400          // follow it for about 11 seconds
                println("=== corner ${seen} awarded at ${"%.0f".format(m.clock)} min ===")
                println(String.format("%6s %8s %9s %-12s %12s %6s %11s %10s",
                    "tick", "staged", "sceneT", "scene", "ball", "poss", "home x", "away x"))
            }
            if (trace > 0) {
                trace--
                if (trace % 36 != 0) continue
                val att = if (m.ball.x > 50f) 0 else 1
                val box = m.players.count {
                    it.onPitch && it.pos != Pos.GK && it.side == att &&
                    (if (att == 0) it.x > 83.5f else it.x < 16.5f) && it.y > 21f && it.y < 79f
                }
                val meanX = m.players.filter { it.onPitch && it.side == att && it.pos != Pos.GK }
                    .map { it.x.toDouble() }.average()
                /*
                 * Print BOTH sides and the ball, and the side the engine thinks
                 * is in possession. Inferring the attacking side from ball.x is
                 * unsafe in the first ticks of a corner, because the ball has not
                 * been placed at the flag yet -- so a trace that infers it can
                 * report the defending side walking home and call it a bug.
                 */
                val mx0 = m.players.filter { it.onPitch && it.side == 0 && it.pos != Pos.GK }
                    .map { it.x.toDouble() }.average()
                val mx1 = m.players.filter { it.onPitch && it.side == 1 && it.pos != Pos.GK }
                    .map { it.x.toDouble() }.average()
                println(String.format("%6d %8.2f %9.2f %-12s   ball %5.1f  poss %d   home x %4.0f  away x %4.0f",
                    400 - trace, staged.getFloat(m), m.sceneTime,
                    Scene.LABEL.getOrNull(m.scene) ?: "?", m.ball.x, m.possessionSide, mx0, mx1))
            }
            wasCorners = now
        }
        match++
    }
    println()
    println("staged is the arrangement gate. If it reaches 0 while the scene is")
    println("still up, normal shape has already pulled everybody back out.")
}
