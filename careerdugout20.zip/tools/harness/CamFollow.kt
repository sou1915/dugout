import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView

/**
 * Does the camera actually keep the ball in frame?
 *
 * CamCheck measures how fast the camera pans and how far it lags, but not the
 * thing that matters to somebody watching: whether the ball is on the screen.
 * The close view is about 40 pitch units wide, so anything past 20 units from
 * the camera centre is off the edge of the picture entirely.
 *
 * It also measures jerk — the frame to frame change in pan speed — because the
 * cure for a camera that cannot keep up must not be a camera that snaps.
 */
fun main(args: Array<String>) {
    val seeds = if (args.isNotEmpty()) args.map { it.toLong() } else listOf(20260727L, 5150L)
    for (seed in seeds) {
        val world = World.build(seed)
        val season = Season(world); season.buildCalendar()
        val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
        m.replaysEnabled = false
        m.start()
        val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val v = MatchView(Context(), m)
        m.danger = 1f
        /*
         * Force the close view.
         *
         * Setting danger is not enough off-device. The cut between the board
         * and the broadcast camera is gated on a minimum hold measured in WALL
         * CLOCK time, and a harness renders four thousand frames in a couple of
         * seconds of real time, so the hold never expires and the view sits on
         * the board — where camX is not used at all. A first attempt at this
         * measurement showed the camera moving on 21 frames out of 400 and
         * concluded the pan was broken, when in fact the pan was barely being
         * run. Pin closeUp instead, so this measures the thing it claims to.
         */
        val closeField = MatchView::class.java.getDeclaredField("closeUp")
        closeField.isAccessible = true
        fun pinClose() = closeField.setFloat(v, 1f)
        repeat(60) { pinClose(); v.renderAt(c, 1280, 720) }

        var prev = v.cameraX()
        var prevStep = 0.0
        var lags = DoubleArray(4200)
        var lagN = 0
        var offScreen = 0
        var wayOff = 0
        var jerkSum = 0.0
        var peakPan = 0.0
        var n = 0
        // half the close view in pitch units, from the renderer's own framing
        val halfView = 20.0

        for (i in 0 until 4000) {
            m.update(1f / 36f)
            if (m.finished) break
            m.danger = 1f
            pinClose()
            v.renderAt(c, 1280, 720)
            val now = v.cameraX()
            val step = (now - prev).toDouble()
            prev = now
            if (i > 100) {
                n++
                val lag = Math.abs(m.ball.x - now).toDouble()
                if (lagN < lags.size) lags[lagN++] = lag
                if (lag > halfView) offScreen++
                if (lag > halfView * 1.5) wayOff++
                jerkSum += Math.abs(step - prevStep) * 36 * 36
                val pan = Math.abs(step) * 36
                if (pan > peakPan) peakPan = pan
            }
            prevStep = step
        }
        lags = lags.copyOf(lagN)
        lags.sort()
        val sorted = lags
        fun pct(p: Int): Double = sorted[(sorted.size * p / 100).coerceIn(0, sorted.size - 1)]

        println("seed $seed over $n live frames")
        println(String.format("  lag from camera centre   median %.1f   p90 %.1f   p99 %.1f   max %.1f units",
            pct(50), pct(90), pct(99), sorted.last()))
        println(String.format("  ball off the screen      %.1f%% of frames   (badly off %.1f%%)",
            offScreen * 100.0 / n, wayOff * 100.0 / n))
        println(String.format("  pan speed                peak %.1f units/s", peakPan))
        println(String.format("  jerk                     mean %.1f units/s/s", jerkSum / n))
        println()
    }
    println("the close view spans about 40 units, so a lag over 20 is off screen.")
    println("a real broadcast camera trails the ball but keeps it in frame.")
}
