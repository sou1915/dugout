import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** A signing should put the manager in front of the press, and his answer should land. */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w)
    val club = w.club(w.divisions[0].clubIds.first())!!
    val career = Career(w, s)
    career.start(club.id, "A Manager", "ENG")
    club.balance = 400_000_000L
    club.transferBudget = 300_000_000L
    club.wageBudget = 5_000_000

    // buy someone from another club
    val target = w.clubs.first { it.id != club.id && it.divisionId == 0 }
        .let { o -> w.squadOf(o).maxByOrNull { it.overall() }!! }
    val before = w.squadOf(club).map { it.morale }.average()
    val repBefore = w.managerRep

    val res = career.makeBid(target.id, 90_000_000L, target.wage * 4, 4)
    println("signing: ${res.message}")
    println("press questions waiting: ${career.pressWaiting}")
    val q = career.press.first { !it.answered }
    println()
    println("${q.from}: ${q.text}")
    for ((i, o) in q.options.withIndex()) println("  ${i + 1}. ${o.text}")

    // hype him up
    career.answerPress(q, q.options[0])
    val after = w.squadOf(club).map { it.morale }.average()
    println()
    println(String.format("squad morale   %.1f -> %.1f", before, after))
    println(String.format("his morale     now %.1f", w.player(target.id)!!.morale))
    println("manager rep    $repBefore -> ${w.managerRep}")
    println("questions left ${career.pressWaiting}")

    // and the harder one after a beating
    career.pressOnDefeat(4, "Kelsea Athletic")
    val q2 = career.press.first { !it.answered }
    println()
    println("${q2.from}: ${q2.text}")
    for (o in q2.options) println("  - ${o.text}")
    val m0 = w.squadOf(club).map { it.morale }.average()
    career.answerPress(q2, q2.options[1])          // blame the players
    val m1 = w.squadOf(club).map { it.morale }.average()
    println(String.format("blaming them:  squad morale %.1f -> %.1f, rep now %d", m0, m1, w.managerRep))

    // weekly events keep arriving
    var events = 0
    for (wk in 1..30) { w.week = wk; career.worldPulse() }
    println()
    println("world events after 30 weeks: ${career.worldNews.size}, inbox ${career.inbox.size}")
    for (e in career.worldNews.take(4)) println("  ${e.headline}")
}
