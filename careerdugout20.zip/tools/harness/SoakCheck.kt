import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season
import com.dugout.career.ui.Face

/**
 * A whole career played through, the way the app drives it: days between
 * matches, live matches, season rolls, saves. Nothing has ever run this end to
 * end, and a management game that falls over in season three is no use.
 */
fun main(args: Array<String>) {
    val seasons = args.firstOrNull()?.toIntOrNull() ?: 3
    val ctx = Context()
    val w = World.build(20260727L)
    Face.assignAll(w.players.values)
    val s0 = Season(w); s0.buildCalendar()
    val club = w.club(w.divisions[2].clubIds.first())!!
    val career = Career(w, s0)
    career.start(club.id, "A Manager", "ENG")

    var season = s0
    var matches = 0
    var goals = 0
    var days = 0
    var sacked = false
    val t0 = System.nanoTime()

    for (yr in 1..seasons) {
        var guard = 0
        while (guard++ < 400) {
            val fx = season.nextUserFixture()
            if (fx == null) break
            // walk the days first, as the hub does
            var dayGuard = 0
            while (!career.onMatchDay && dayGuard++ < 10) {
                if (career.advanceDay()) { sacked = true; break }
            }
            if (sacked) break
            days += career.daysBetweenMatches

            val m = MatchEngine(w, season, fx)
            m.replaysEnabled = false
            m.speed = 8f
            m.start()
            var tick = 0
            while (!m.finished && tick++ < 300_000) m.update(1f / 30f)
            if (!m.finished) {
                println("HUNG on ${club.name} week ${fx.week} after $tick ticks")
                return
            }
            // commit() writes the player statistics and applies the result to
            // the table. Without it the fixture is never marked played and the
            // same match comes round for ever; MainActivity calls it right
            // before simWeek and the soak has to do the same.
            m.commit()
            goals += m.score[0] + m.score[1]
            matches++
            season.simWeek(fx.week, fx.id)
            career.resetWeekDays()
        }
        if (sacked) { println("sacked in season $yr"); break }
        // read the table before the roll wipes it
        val playedThisSeason = club.played
        val finishedPos = season.position(club.id)
        season.endSeason()
        season.newSeason()
        season.rolloverPlayers()
        Save.write(ctx, w, season, career)
        val back = Save.read(ctx)
        if (back == null) { println("SAVE FAILED after season $yr"); return }
        println(String.format(
            "season %d done: %2d played, pos %2d, balance %s, squad %d, save %.2f MB",
            yr, playedThisSeason, finishedPos, com.dugout.career.core.Fmt.money(club.balance),
            club.squad.size, java.io.File(ctx.filesDir, "career.sav").length() / 1048576.0
        ))
    }

    val secs = (System.nanoTime() - t0) / 1e9
    println()
    println(String.format("%d live matches, %d goals (%.2f a game), %d days walked, in %.1f s",
        matches, goals, goals.toDouble() / matches, days, secs))
    // integrity after all that
    val names = w.players.values.map { it.full }
    println("duplicate player names after ${seasons} seasons: ${names.size - names.toSet().size}")
    val faces = w.players.values.map { Face.vector(Face.of(it)).joinToString(",") }
    println("duplicate faces: ${faces.size - faces.toSet().size}")
    println("orphan clubs: ${w.clubs.count { w.division(it.divisionId) == null }}")
}
