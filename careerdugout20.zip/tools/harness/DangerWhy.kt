import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season

/** What is actually holding the camera in. Stop guessing. */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val m = MatchEngine(w, s, s.fixtures.first { it.comp == 0 })
    m.start()
    var n = 0
    var box = 0; var third = 0; var mid = 0; var far = 0
    var scenes = 0; var celeb = 0; var replay = 0; var flourish = 0
    var closeFrames = 0
    for (i in 0 until 60000) {
        m.update(1f / 36f)
        n++
        val toGoal = if (m.possessionSide == 0) 100f - m.ball.x else m.ball.x
        when {
            toGoal < 20f -> box++
            toGoal < 30f -> third++
            toGoal < 44f -> mid++
            else -> far++
        }
        if (m.scene == Scene.PENALTY || m.scene == Scene.CORNER || m.scene == Scene.FREEKICK) scenes++
        if (m.celebrationTime > 0f) celeb++
        if (m.replay != null) replay++
        if (m.refCard > 0 || m.woodwork > 0f || m.skill > 0f) flourish++
        if (m.danger >= 0.55f) closeFrames++
        if (m.finished) break
    }
    fun pct(x: Int) = x * 100.0 / n
    println("=== where the ball is ===")
    println(String.format("in the box     %.0f%%", pct(box)))
    println(String.format("final third    %.0f%%", pct(third)))
    println(String.format("middle third   %.0f%%", pct(mid)))
    println(String.format("own half       %.0f%%", pct(far)))
    println()
    println("=== other things that force the close camera ===")
    println(String.format("set piece scenes %.0f%%   celebrations %.0f%%   replays %.0f%%   cards/woodwork/skill %.0f%%",
        pct(scenes), pct(celeb), pct(replay), pct(flourish)))
    println()
    println(String.format("close camera overall %.0f%%", pct(closeFrames)))
}
