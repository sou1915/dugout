import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.broadcastProject

/**
 * How big is a figure in the broadcast view, and how much detail is on it?
 *
 * The player is located with the renderer's own projection and measured inside a
 * tight box around that point. Differencing against a frame with him removed
 * does not work: taking a player off the pitch puts him on the substitutes'
 * bench and changes the HUD name plates, so the difference covers half the frame.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start(); m.danger = 1f; m.shake = 0f
    for (p in m.players) p.onPitch = false
    val far = m.players.first { it.side == 0 && it.pos != 0 }
    val near = m.players.last { it.side == 0 && it.pos != 0 && it.key != far.key }
    far.onPitch = true; far.x = 36f; far.y = 30f
    near.onPitch = true; near.x = 64f; near.y = 72f
    for (p in listOf(far, near)) {
        p.action = Act.RUN; p.speedNow = 0f; p.facing = (Math.PI / 2).toFloat()
    }
    m.ball.holder = null; m.ball.x = 50f; m.ball.y = 50f
    m.refCard = 0; m.banner = null; m.celebrateKey = null

    val a = render(m, 40) { it.followBall = false }
    save(a, "out/figure.png")

    fun grass(rgb: Int): Boolean {
        val r = (rgb shr 16) and 0xFF; val g = (rgb shr 8) and 0xFF; val b = rgb and 0xFF
        return g > r + 10 && g > b + 16 && g in 55..205
    }

    fun measure(px: Float, py: Float, label: String) {
        // the renderer's own camera, at the framing the view settles to
        val pr = broadcastProject(W.toFloat(), H.toFloat(), 50f, 50f, 0.72f, px, py)
        val sx = pr[0].toInt(); val sy = pr[1].toInt()
        val box = (pr[2] * 3.2f).toInt().coerceAtLeast(20)
        var top = -1; var bot = -1; var l = 9999; var r = -1
        val cols = HashSet<Int>()
        for (y in (sy - box * 2).coerceAtLeast(0) until (sy + box / 3).coerceAtMost(H)) {
            for (x in (sx - box).coerceAtLeast(0) until (sx + box).coerceAtMost(W)) {
                val q = a.image.getRGB(x, y) and 0xFFFFFF
                if (grass(q)) continue
                if (top < 0) top = y
                bot = y; if (x < l) l = x; if (x > r) r = x
                cols.add(q)
            }
        }
        println(String.format("%-14s at screen (%4d,%4d)  height %3d px  width %3d px  %4d colours",
            label, sx, sy, bot - top + 1, r - l + 1, cols.size))
    }
    measure(36f, 30f, "far  (y=30)")
    measure(64f, 72f, "near (y=72)")
}
