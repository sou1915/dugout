import com.dugout.career.core.World
import com.dugout.career.ui.Face

/** Faces that would look wrong to anyone who knows what a footballer looks like. */
fun main() {
    val w = World.build(20260727L)
    val players = w.players.values.toList()
    Face.assignAll(players)

    var greyYoung = 0; var baldYoung = 0; var beardBoy = 0
    var bleachOld = 0; var afroBald = 0
    val examples = ArrayList<String>()
    for (p in players) {
        val f = Face.of(p)
        val bad = ArrayList<String>()
        if (f.hair == 9 && p.age <= 24) { greyYoung++; bad.add("grey at ${p.age}") }
        if (f.isBald && p.age <= 21) { baldYoung++; bad.add("shaven at ${p.age}") }
        if (f.beard >= 4 && p.age <= 18) { beardBoy++; bad.add("full beard at ${p.age}") }
        if (f.hair == 8 && p.age >= 34) { bleachOld++; bad.add("bleached at ${p.age}") }
        if (f.style == 4 && f.isBald) { afroBald++; bad.add("afro and bald at once") }
        if (bad.isNotEmpty() && examples.size < 8) {
            examples.add("${p.full.padEnd(24)} ${p.age}  ${bad.joinToString(", ")}")
        }
    }
    println("=== implausible faces among ${players.size} players ===")
    println(String.format("grey haired under 25      %d", greyYoung))
    println(String.format("shaven headed under 22    %d", baldYoung))
    println(String.format("full beard at 18 or under %d", beardBoy))
    println(String.format("bleached at 34 or over    %d", bleachOld))
    println(String.format("afro and bald together    %d", afroBald))
    println()
    for (e in examples) println("   $e")
}
