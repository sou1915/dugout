import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Do moves have a SHAPE now, and does the touchline change it?
 *
 * A phase used to be a shapeless run of passes — no cross, no counter, no ball
 * in behind — which is why the football read as messy however well the numbers
 * behaved, and why there were no scenes: a scene IS a pattern. This counts the
 * mix of patterns a side plays, and then changes its tactics and counts again.
 * If the mix does not move, the dials on the touchline are decoration.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 12
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }

    fun mix(label: String, setup: (com.dugout.career.core.Tactics) -> Unit): DoubleArray {
        val n = IntArray(5)
        for (i in 0 until matches) {
            val m = MatchEngine(world, season, league[i % league.size])
            m.replaysEnabled = false
            setup(m.home.tactics)
            m.start()
            var last = -1; var g = 0
            while (!m.finished && g++ < 300_000) {
                m.update(1f / 36f)
                if (m.finished) break
                if (m.possessionSide == 0 && m.phasePattern != last) {
                    n[m.phasePattern]++; last = m.phasePattern
                }
            }
        }
        val tot = n.sum().toDouble().coerceAtLeast(1.0)
        val pct = DoubleArray(5) { n[it] * 100.0 / tot }
        println(String.format("%-22s %8.0f%% %8.0f%% %8.0f%% %8.0f%% %8.0f%%",
            label, pct[0], pct[1], pct[2], pct[3], pct[4]))
        return pct
    }

    println("=== the shape of a move, $matches matches per setup ===")
    println(String.format("%-22s %9s %9s %9s %9s %9s",
        "tactics", "build-up", "cross", "through", "counter", "long shot"))
    mix("as picked") { }
    mix("Get it wide (direct+wide)") { t -> t.passing = 2; t.width = 2 }
    mix("Through the middle") { t -> t.passing = 0; t.width = 0 }
    mix("Counter-attack") { t -> t.counter = true; t.passing = 2 }
    mix("Patient build-up") { t -> t.passing = 0; t.tempo = 0; t.counter = false }
    println()
    println("if these rows are the same, the touchline is decoration.")
}
