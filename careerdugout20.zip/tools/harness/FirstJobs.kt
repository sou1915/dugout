import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/**
 * How much is actually ON the "start from nothing" screen.
 *
 * The owner reports the first screen of a new career as mostly empty, with the
 * only content crammed at the bottom. The screen is a header panel, a list of
 * clubs who would have you, and two buttons. If that list is short or empty
 * the screen has almost nothing in it, and no amount of layout work on the
 * panels will fix that -- so measure the list before touching the layout.
 */
fun main() {
    for (seed in listOf(20260727L, 5150L, 99001L, 777333L)) {
        val w = World.build(seed)
        val s = Season(w)
        w.managerName = "A Manager"; w.managerNation = "ENG"
        w.userClubId = -1
        w.managerRep = w.profile.ageInfo.startingRep
        val car = Career(w, s)
        val v = car.vacancies()
        println("seed $seed  rep ${w.managerRep}  vacancies ${v.size}  approached ${v.count { it.approached }}")
        for (j in v.take(4)) println("      ${j.clubName} (${j.divisionName}, rep ${j.reputation})")
    }
}
