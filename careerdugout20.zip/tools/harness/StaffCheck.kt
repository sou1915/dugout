import android.content.Context
import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** Does the backroom actually change anything? */
fun main() {
    val w = World.build(20260727L)
    println("=== who works here ===")
    val top = w.club(w.divisions[0].clubIds.first())!!
    val bottom = w.club(w.divisions[4].clubIds.last())!!
    for (c in listOf(top, bottom)) {
        println("${c.name}  (reputation ${c.reputation})")
        for (st in c.staff) {
            println(String.format("   %-20s %-24s %2d  %s  %s",
                st.roleName, st.name, st.quality, "*".repeat(st.stars), Fmt.wage(st.wage)))
        }
        println(String.format("   backroom wage bill %s a week", Fmt.wage(Backroom.wageBill(c.staff))))
        println()
    }

    println("=== what good staff are worth ===")
    println(String.format("%-24s %10s %10s %10s %10s",
        "backroom", "coaching", "injuries", "youth", "scout err"))
    for (q in intArrayOf(30, 50, 70, 90)) {
        val fake = arrayListOf(
            Staff(1, "A", StaffRole.COACH, q, 0), Staff(2, "B", StaffRole.COACH, q, 0),
            Staff(3, "C", StaffRole.PHYSIO, q, 0), Staff(4, "D", StaffRole.SCOUT, q, 0),
            Staff(5, "E", StaffRole.YOUTH, q, 0)
        )
        println(String.format("all rated %-14d %9.2fx %9.2fx %9.2fx %8d pts",
            q, Backroom.coachingFactor(fake), Backroom.physioFactor(fake),
            Backroom.youthFactor(fake), Backroom.scoutError(fake)))
    }

    // the same teenager under a poor and a strong staff
    println()
    println("=== the same 17 year old, two clubs ===")
    for (q in intArrayOf(32, 88)) {
        val w2 = World.build(20260727L)
        val s2 = Season(w2); s2.buildCalendar()
        val c2 = w2.club(w2.divisions[0].clubIds.first())!!
        c2.staff.forEach { it.quality = q }
        val car = Career(w2, s2)
        car.start(c2.id, "A Manager", "ENG")
        val p = w2.squadOf(c2).filter { it.age <= 19 }
            .maxByOrNull { it.potential - it.overall() } ?: continue
        val start = p.overall()
        var weeks = 0
        while (p.overall() < p.potential && weeks < 500) {
            w2.week = (weeks % 38) + 1; p.minutes += 70; car.applyTraining(); weeks++
        }
        println(String.format("staff rated %2d: %d -> %d took %d weeks", q, start, p.potential, weeks))
    }

    // and it survives a save
    val ctx = Context()
    val s3 = Season(w); s3.buildCalendar()
    val car3 = Career(w, s3); car3.start(top.id, "M", "ENG")
    val before = top.staff.joinToString { "${it.name}:${it.quality}" }
    Save.write(ctx, w, s3, car3)
    val back = Save.read(ctx)!!
    val after = back.world.club(top.id)!!.staff.joinToString { "${it.name}:${it.quality}" }
    println()
    println("=== what a report tells you ===")
    reportDemo()
    println()
    println("staff survive a save: ${before == after} (${back.world.club(top.id)!!.staff.size} people)")
}

/** What a report actually tells you, under different chief scouts. */
fun reportDemo() {
    for (q in intArrayOf(30, 55, 80, 95)) {
        val w = World.build(20260727L)
        val s = Season(w); s.buildCalendar()
        val c = w.club(w.divisions[0].clubIds.first())!!
        c.staff.filter { it.role == StaffRole.SCOUT }.forEach { it.quality = q }
        c.balance = 5_000_000L
        val car = Career(w, s); car.start(c.id, "M", "ENG")
        val rep = car.scoutMission(-1, false)
        val lines = rep.found.take(3).joinToString("   ") { p ->
            "${p.overall()} reads ${car.reportedOverall(p)}"
        }
        println(String.format("scout %2d (+/-%d):  %s", q, Backroom.scoutError(c.staff), lines))
    }
}
