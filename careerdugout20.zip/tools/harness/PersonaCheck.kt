import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Does the word on the player screen actually mean anything now? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val club = w.club(w.divisions[0].clubIds.first())!!
    val career = Career(w, s)
    career.start(club.id, "A Manager", "ENG")

    println("=== the same 66-rated teenager, ten different characters ===")
    println(String.format("%-15s %6s %6s %6s %8s %7s  %s",
        "personality", "start", "1 szn", "ceil", "wage", "weeks", "scout note"))
    for (name in PERSONALITIES) {
        val w2 = World.build(20260727L)
        val s2 = Season(w2); s2.buildCalendar()
        val c2 = w2.club(w2.divisions[0].clubIds.first())!!
        val car2 = Career(w2, s2)
        car2.start(c2.id, "A Manager", "ENG")
        val p = w2.squadOf(c2).filter { it.age <= 20 }
            .maxByOrNull { it.potential - it.overall() } ?: continue
        p.personality = name
        val start = p.overall()
        val wage0 = p.expectedWage()
        val ceiling = p.potential
        // everyone reaches his ceiling eventually; what differs is how long,
        // so measure the weeks taken rather than the end point
        var weeks = 0
        var afterOne = start
        while (p.overall() < ceiling && weeks < 400) {
            w2.week = (weeks % 38) + 1
            p.minutes += 70
            car2.applyTraining()
            weeks++
            if (weeks == 38) { s2.rolloverPlayers(); afterOne = p.overall() }
        }
        val fx = Personalities.of(name)
        println(String.format("%-15s %6d %6d %6d %8s %7d  %s",
            name, start, afterOne, ceiling, Fmt.wage(wage0), weeks, fx.note))
    }

    println()
    println("=== how hard they take a bad week ===")
    println(String.format("%-15s %8s %8s", "personality", "praised", "criticised"))
    for (name in arrayOf("Temperamental", "Resolute", "Determined", "Fickle")) {
        val p = w.squadOf(club).first()
        p.personality = name
        p.morale = 70.0; p.shiftMorale(10.0); val up = p.morale
        p.morale = 70.0; p.shiftMorale(-10.0); val dn = p.morale
        println(String.format("%-15s %8.1f %8.1f", name, up, dn))
    }
}
