import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Where is the ball at the instant a goal is awarded?
 *
 * ReplayCheck only ever looks at the first goal of the first seed, so it can
 * pass while a whole class of goals is still being given in midfield. This
 * walks many matches and records, for every goal, the ball position and flight
 * state at the tick the score changed. A goal given properly has the ball on a
 * goal line (x near 1 or 99); anything else is the bug.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 60
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val league = s.fixtures.filter { it.comp == 0 }

    var total = 0
    var bad = 0
    val badX = ArrayList<Float>()
    // how far from the nearest goal line, bucketed
    val buckets = IntArray(11)

    for (i in 0 until matches) {
        val m = MatchEngine(w, s, league[i % league.size])
        m.speed = 6f
        m.replaysEnabled = true
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            val before = m.score[0] + m.score[1]
            m.update(1f / 36f)
            if (!m.running && !m.finished) m.start()
            m.sound.clear()
            val after = m.score[0] + m.score[1]
            if (after > before) {
                total++
                val x = m.ball.x
                val dist = minOf(Math.abs(x - 100f), Math.abs(x - 0f))
                buckets[minOf(10, (dist / 2f).toInt())]++
                if (dist > 6f) {
                    bad++
                    if (badX.size < 25) badX.add(x)
                }
            }
        }
    }

    println("goals inspected            $total over $matches matches")
    println("given away from a goal line $bad  (${String.format("%.1f", bad * 100.0 / total)}%)")
    println()
    println("distance from nearest goal line at the moment the goal was given:")
    for (b in 0 until 11) {
        if (buckets[b] == 0) continue
        val lab = if (b == 10) ">=20" else "${b * 2}-${b * 2 + 2}"
        println(String.format("  %5s units  %4d  %s", lab, buckets[b],
            "#".repeat(minOf(60, buckets[b] * 60 / maxOf(1, total)))))
    }
    if (badX.isNotEmpty()) {
        println()
        println("sample bad ball x: " + badX.joinToString(", ") { String.format("%.1f", it) })
    }
}
