import com.dugout.career.core.Names
import com.dugout.career.core.flagOf

/** Flags are computed now, not written out, so check they are real. */
fun main() {
    var bad = 0
    for (n in Names.ALL_NATIONS) {
        val f = n.flag
        val cps = f.codePoints().toArray()
        val ok = (cps.size == 2 && cps.all { it in 0x1F1E6..0x1F1FF }) ||
                 (cps.size == 1 && cps[0] == 0x1F3F4)   // the home nations fallback
        if (!ok) { bad++; if (bad < 10) println("BAD ${n.code} ${cps.joinToString{ "U+%X".format(it) }}") }
    }
    println("nations: ${Names.ALL_NATIONS.size}, malformed flags: $bad")
    println("with a league: ${Names.NATIONS.size}, without: ${Names.EXTRA_NATIONS.size}")
    println("sample: ESP=" + Names.byCode("ESP").flag.codePoints().toArray().joinToString{ "U+%X".format(it) })
    println("sample: JPN=" + flagOf("JP").codePoints().toArray().joinToString{ "U+%X".format(it) })
    println("name capacity across league nations: ${Names.capacity}")
}
