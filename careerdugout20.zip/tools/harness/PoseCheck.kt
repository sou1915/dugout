import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.ui.RAct
import com.dugout.career.ui.RBall
import com.dugout.career.ui.RKit
import com.dugout.career.ui.RPlayer
import com.dugout.career.ui.drawBroadcast
import java.io.File
import javax.imageio.ImageIO

/**
 * Does the figure actually change shape when he does something?
 *
 * The engine has always set an action on every player — sliding in, the keeper
 * going down, arms up after a goal, rising to a cross — and RPlayer had no
 * field to carry it, so the renderer drew all of them running. This renders one
 * man alone, once per action, and measures his silhouette.
 *
 * Measured against the running figure, so "the pose is drawn" is a difference
 * in the picture rather than an assertion that the code was called. A dive must
 * come out much wider than tall; a man flat out must be the flattest thing on
 * the pitch; a celebration must be the tallest.
 */
private const val PW = 900
private const val PH = 560

private class Shape(val w: Int, val h: Int, val px: Int)

private fun silhouette(b: Bitmap, bg: Bitmap): Shape {
    var minX = Int.MAX_VALUE; var maxX = Int.MIN_VALUE
    var minY = Int.MAX_VALUE; var maxY = Int.MIN_VALUE
    var n = 0
    for (y in 0 until PH) for (x in 0 until PW) {
        // the pitch has mown stripes, so a fixed background colour will not do:
        // difference against the SAME scene with nobody in it
        if (b.image.getRGB(x, y) == bg.image.getRGB(x, y)) continue
        n++
        if (x < minX) minX = x; if (x > maxX) maxX = x
        if (y < minY) minY = y; if (y > maxY) maxY = y
    }
    if (n == 0) return Shape(0, 0, 0)
    return Shape(maxX - minX + 1, maxY - minY + 1, n)
}

private fun renderOne(action: Int, actionTime: Float): Bitmap {
    val bmp = Bitmap.createBitmap(PW, PH, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val men = if (action < 0) emptyList() else listOf(
        RPlayer(
            x = 50f, y = 50f, facing = 0.5f, speed = 4f, runPhase = 1.1f,
            side = 0, isKeeper = action == RAct.DIVE, shirt = 9, seed = 4242,
            action = action, actionTime = actionTime
        )
    )
    // the ball parked off to one side so it cannot contaminate the silhouette
    val ball = RBall(12f, 12f, 0f, 0f)
    drawBroadcast(c, PW.toFloat(), PH.toFloat(), men, ball,
        RKit(0xFFD32F2F.toInt(), 0xFFFFFFFF.toInt(), 0),
        RKit(0xFF1976D2.toInt(), 0xFFFFFFFF.toInt(), 0),
        50f, 43f, 0.72f)
    return bmp
}

fun main(args: Array<String>) {
    val write = args.contains("png")
    val empty = renderOne(-1, 0f)
    val names = mapOf(
        RAct.RUN to "run", RAct.TACKLE to "tackle", RAct.SHOOT to "shoot",
        RAct.DIVE to "dive (keeper)", RAct.CELEBRATE to "celebrate",
        RAct.DRIBBLE to "dribble", RAct.DOWN to "on the floor", RAct.HEADER to "header"
    )

    val runShape = silhouette(renderOne(RAct.RUN, 0f), empty)
    println("=== the figure, one man alone, silhouette in pixels ===")
    println(String.format("%-16s %6s %6s %8s %10s %12s",
        "action", "width", "height", "pixels", "w/h", "vs running"))
    for (a in listOf(RAct.RUN, RAct.TACKLE, RAct.SHOOT, RAct.DIVE,
                     RAct.CELEBRATE, RAct.DRIBBLE, RAct.DOWN, RAct.HEADER)) {
        val b = renderOne(a, 2.0f)
        val s = silhouette(b, empty)
        if (write) {
            File("out").mkdirs()
            ImageIO.write(b.image, "png", File("out/pose_${names[a]!!.replace(" ", "_")}.png"))
        }
        // how many pixels differ from the running figure: zero means the action
        // reached the renderer and changed nothing
        var diff = 0
        val rb = renderOne(RAct.RUN, 0f)
        for (y in 0 until PH) for (x in 0 until PW)
            if (b.image.getRGB(x, y) != rb.image.getRGB(x, y)) diff++
        println(String.format("%-16s %6d %6d %8d %10.2f %12d",
            names[a], s.w, s.h, s.px, s.w.toFloat() / maxOf(1, s.h), diff))
    }
    println()
    println(String.format("running figure is %d x %d for reference", runShape.w, runShape.h))
    println("a dive should be far wider than tall, a man on the floor flatter still,")
    println("and a celebration taller than a run. Zero in the last column means the")
    println("pose never reached the picture.")
}
