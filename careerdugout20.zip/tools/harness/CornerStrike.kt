import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * AUDIT HARNESS -- when does the corner actually LEAVE THE FLAG, and who is in
 * the box at that instant?
 *
 * StagingCheck measures the box at the tick the CORNER CAPTION expires, on the
 * stated assumption that "the tick the corner scene ends is the tick it gets
 * delivered". The delivery is in fact booked by shootAfterScene at
 * `clock + 0.60` MATCH MINUTES, while the caption and the staging hold are in
 * REAL seconds. The two instants are not the same and do not even scale
 * together: the caption is fixed in real time, the delivery moves with the
 * 1x/2x/4x control.
 *
 * The delivery is detected from the ball leaving the flag, which is exact --
 * cornerFlagX/Y are public and stageCorner places the ball on them.
 */
private class Probe(val name: String, val speed: Float) {
    var attAtStrike = 0.0; var defAtStrike = 0.0; var lag = 0.0; var n = 0L
    var lagBuckets = LongArray(8)
    var attAtCaption = 0.0; var capLag = 0.0; var capN = 0L
    var gkOff = 0.0; var gkN = 0L
    var neverLeft = 0L

    fun boxCount(m: MatchEngine, att: Int, side: Int) = m.players.count {
        it.onPitch && it.pos != Pos.GK && it.side == side &&
            (if (att == 0) it.x > 83.5f else it.x < 16.5f) && it.y > 21f && it.y < 79f
    }

    fun run(matches: Int) {
        for (i in 0 until matches) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false
            m.speed = speed
            m.start()
            val dt = 1f / 36f
            var prevCorners = intArrayOf(m.corners[0], m.corners[1])
            var pendingAtt = -1
            var spotted = false
            var flagX = 0f; var flagY = 0f
            var awardedAt = 0.0
            var elapsed = 0.0
            var wasCorner = false
            var guard = 0
            while (!m.finished && guard++ < 900_000) {
                m.update(dt)
                m.sound.clear()
                elapsed += dt.toDouble()

                for (s in 0..1) if (m.corners[s] > prevCorners[s]) {
                    if (pendingAtt >= 0) neverLeft++
                    pendingAtt = s
                    spotted = false
                    flagX = m.cornerFlagX; flagY = m.cornerFlagY
                    awardedAt = elapsed
                }
                prevCorners = intArrayOf(m.corners[0], m.corners[1])

                if (pendingAtt >= 0) {
                    val gk = m.players.firstOrNull {
                        it.onPitch && it.pos == Pos.GK && it.side != pendingAtt
                    }
                    if (gk != null) {
                        val goalX = if (pendingAtt == 0) 100f else 0f
                        gkOff += Math.hypot(((goalX - gk.x) * 1.05).toDouble(),
                            ((50f - gk.y) * 0.68).toDouble())
                        gkN++
                    }
                    // placeBall ROLLS the ball to the flag over a few tenths, so
                    // it starts this window far away. Wait for it to arrive
                    // before watching it leave, or every corner reads as
                    // delivered on the tick it was awarded.
                    val away = Math.hypot((m.ball.x - flagX).toDouble(), (m.ball.y - flagY).toDouble())
                    if (!spotted && away < 3.0) spotted = true
                    if (spotted && away > 8.0) {
                        attAtStrike += boxCount(m, pendingAtt, pendingAtt)
                        defAtStrike += boxCount(m, pendingAtt, 1 - pendingAtt)
                        val l = elapsed - awardedAt
                        lag += l; n++
                        lagBuckets[Math.min(7, (l / 1.0).toInt())]++
                        pendingAtt = -1
                        spotted = false
                    }
                }

                val nowCorner = m.sceneTime > 0f && m.scene == Scene.CORNER
                if (wasCorner && !nowCorner) {
                    val att = if (m.ball.x > 50f) 0 else 1
                    attAtCaption += boxCount(m, att, att)
                    capLag += elapsed - awardedAt
                    capN++
                }
                wasCorner = nowCorner
            }
        }
    }

    fun report() {
        println(String.format("%-10s %9.2f %11.2f %11.2f  |  %9.2f %11.2f  | %8.1f",
            name,
            lag / maxOf(1L, n), attAtStrike / maxOf(1L, n), defAtStrike / maxOf(1L, n),
            capLag / maxOf(1L, capN), attAtCaption / maxOf(1L, capN),
            gkOff / maxOf(1L, gkN)))
    }

    fun histogram() {
        print("  $name delivery lag, seconds:  ")
        for (b in 0 until 8) print(String.format("%d-%ds:%d  ", b, b + 1, lagBuckets[b]))
        println()
    }
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    println("=== when does a corner leave the flag, and who is there? ($matches matches each) ===")
    println("CORNER_SECONDS = ${MatchEngine.CORNER_SECONDS} real s (staging hold " +
        "${MatchEngine.CORNER_SECONDS + 1.6f} real s)")
    println("delivery booked at clock + 0.60 MATCH MINUTES = " +
        "${0.60 * MatchEngine.SECONDS_PER_MINUTE} real s at 1x")
    println()
    println(String.format("%-10s %9s %11s %11s  |  %9s %11s  | %8s",
        "", "delivery", "att in box", "def in box", "caption", "att in box", "GK off"))
    println(String.format("%-10s %9s %11s %11s  |  %9s %11s  | %8s",
        "", "lag s", "AT STRIKE", "AT STRIKE", "ends at s", "THEN", "line m"))
    val probes = listOf(1f, 2f, 4f).map { Probe("speed ${it.toInt()}x", it) }
    for (p in probes) { p.run(matches); p.report() }
    println()
    for (p in probes) p.histogram()
    println()
    println("AT STRIKE is what the viewer sees the corner delivered into.")
    println("'caption/THEN' is the instant StagingCheck samples -- seconds after")
    println("the ball has already gone.")
}
