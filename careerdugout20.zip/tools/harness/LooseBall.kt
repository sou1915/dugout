import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How long the ball spends bouncing around with nobody on it. Raising the loft
 * to five metres may have left it pinging about the pitch untouched.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var frames = 0
    var loose = 0
    var looseAir = 0
    var run = 0
    var longestRun = 0
    var bounces = 0
    var nearSum = 0.0; var nearN = 0; var farFrames = 0
    var wasDown = true
    for (i in 0 until 9000) {
        m.update(dt)
        if (i < 200) continue
        frames++
        val held = m.ball.holder != null
        if (!held) {
            loose++
            val near = m.players.filter { it.onPitch }.minOfOrNull { q ->
                Math.hypot(((q.x - m.ball.x) * 1.05), ((q.y - m.ball.y) * 0.68))
            } ?: 0.0
            nearSum += near; nearN++
            if (near > 6.0) farFrames++
            run++
            if (run > longestRun) longestRun = run
            if (m.ball.height > 0.05f) looseAir++
        } else run = 0
        // a bounce: was on the grass, now rising
        val down = m.ball.height <= 0.02f
        if (wasDown && m.ball.height > 0.15f && m.ball.t >= 1f) bounces++
        wasDown = down
        if (m.finished) break
    }
    println("=== the loose ball ===")
    println(String.format("nobody on the ball        %.0f%% of the match", loose * 100.0 / frames))
    println(String.format("loose and in the air      %.0f%% of the match", looseAir * 100.0 / frames))
    println(String.format("longest unbroken spell    %.1f seconds", longestRun / 36.0))
    println(String.format("bounces off the turf      %d in a match", bounces))
    println(String.format("when loose, nearest man   %.1f m away on average", nearSum / nearN))
    println(String.format("loose and nobody within 6 m  %.0f%% of the match", farFrames * 100.0 / frames))
    println()
    println("in a real match somebody is on the ball almost all the time;")
    println("a loose ball is gathered within a second or two.")
}
