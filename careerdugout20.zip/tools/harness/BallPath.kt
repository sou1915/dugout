import com.dugout.career.sim.MatchEngine
import kotlin.math.abs
import kotlin.math.atan2

/**
 * Does the ball's PATH bend, or does it fly straight?
 *
 * BallJump measures the ball appearing somewhere else — a teleport, a jump in
 * POSITION. Making the ball advance itself fixed that by construction and the
 * report from the device did not change: "the ball flies on the pitch, it
 * changes path suddenly".
 *
 * That is a different fault and nothing here has ever measured it. A ball whose
 * position is continuous can still turn a corner in mid-air, because the ball
 * steers toward an aim point that other systems move under it. Position stays
 * smooth; DIRECTION does not. On screen that is a ball flying one way and then
 * bending another for no reason, which is exactly what is being described.
 *
 * So this measures the turn: the angle between the ball's travel this frame and
 * its travel last frame, while it is in the air and moving fast enough for a
 * direction to mean anything. A struck ball bends a few degrees a second from
 * spin. Anything past about fifteen degrees IN ONE FRAME is a kink no football
 * makes.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    when (args.getOrNull(1)) {
        "off" -> { MatchEngine.BALL_AGENT = false; MatchEngine.WAIT_FOR_BALL = false }
        "nowait" -> MatchEngine.WAIT_FOR_BALL = false
    }
    println("ball advances itself ${if (MatchEngine.BALL_AGENT) "ON" else "off"}, " +
            "waits to be struck ${if (MatchEngine.WAIT_FOR_BALL) "ON" else "off"}")

    val turns = ArrayList<Double>()
    var kinks = 0L      // over 15 degrees in one frame
    var hard = 0L       // over 45 degrees: the ball visibly changes its mind
    var reversals = 0L  // over 120 degrees: it turns round
    var frames = 0L
    var flights = 0L
    var flightsWithKink = 0L
    var kinkSpeed = 0.0
    var causeRestruck = 0L; var causeHolder = 0L; var causeBigAim = 0L
    var causeAimDrift = 0L; var causeNone = 0L
    val samples = ArrayList<String>()

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var px = m.ball.x; var py = m.ball.y
        var lastAng = Double.NaN
        var lastStep = 0.0
        var ptx = m.ball.toX; var pty = m.ball.toY
        var pHolder = m.ball.holder
        var pt = m.ball.t
        var wasFlying = false
        var thisFlightKinked = false
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            val flying = m.ball.t < 1f
            if (flying && !wasFlying) { flights++; thisFlightKinked = false; lastAng = Double.NaN; lastStep = 0.0 }
            if (!flying && wasFlying && thisFlightKinked) flightsWithKink++
            wasFlying = flying

            val dToX = Math.hypot(((m.ball.toX - ptx) * 1.05).toDouble(),
                                  ((m.ball.toY - pty) * 0.68).toDouble())
            val holderChanged = m.ball.holder != pHolder
            val restruck = m.ball.t < pt
            ptx = m.ball.toX; pty = m.ball.toY; pHolder = m.ball.holder; pt = m.ball.t
            val dxm = (m.ball.x - px) * 1.05
            val dym = (m.ball.y - py) * 0.68
            px = m.ball.x; py = m.ball.y
            if (!flying) { lastAng = Double.NaN; continue }
            val step = Math.hypot(dxm, dym)
            /*
             * A turn only counts when the ball is genuinely travelling. Reversing
             * through 180 degrees on a six-centimetre step is invisible on a
             * screen and is just the last tick of a flight settling; counting it
             * turns a harmless dribble of arithmetic into an alarming number.
             * At 8 m/s a frame is 22 cm, which is the slowest a moving ball
             * looks like a moving ball.
             */
            if (step < 8.0 / 36.0) { lastAng = Double.NaN; lastStep = 0.0; continue }
            val ang = atan2(dym, dxm)
            if (!lastAng.isNaN() && lastStep >= 8.0 / 36.0) {
                var d = ang - lastAng
                while (d > Math.PI) d -= Math.PI * 2
                while (d < -Math.PI) d += Math.PI * 2
                val deg = Math.toDegrees(abs(d))
                turns.add(deg)
                frames++
                if (deg > 15.0) {
                    kinks++; thisFlightKinked = true
                    kinkSpeed += (step + lastStep) * 0.5 * 36.0
                    when {
                        restruck -> causeRestruck++
                        holderChanged -> causeHolder++
                        dToX > 1.0 -> causeBigAim++
                        dToX > 0.05 -> causeAimDrift++
                        else -> causeNone++
                    }
                    if (deg > 120.0 && samples.size < 12)
                        samples.add(String.format(
                            "  %6.1f deg  t=%.2f  aim moved %5.2f m  holder changed %-5s  restruck %s",
                            deg, m.ball.t, dToX, holderChanged, restruck))
                }
                if (deg > 45.0) hard++
                if (deg > 120.0) reversals++
            }
            lastAng = ang
            lastStep = step
        }
    }

    turns.sort()
    fun q(f: Double) = if (turns.isEmpty()) 0.0 else turns[(turns.size * f).toInt().coerceAtMost(turns.size - 1)]
    println()
    println("=== how sharply does the ball turn in the air? ($matches matches) ===")
    println("$frames frames of real flight, $flights separate flights")
    println(String.format("  median turn per frame        %6.2f deg", q(0.5)))
    println(String.format("  p99                          %6.2f deg", q(0.99)))
    println(String.format("  worst                        %6.2f deg", if (turns.isEmpty()) 0.0 else turns.last()))
    println(String.format("  over 15 deg in one frame     %6d  (%.1f a match)", kinks, kinks.toDouble() / matches))
    println(String.format("  over 45 deg                  %6d  (%.1f a match)", hard, hard.toDouble() / matches))
    println(String.format("  over 120 deg, it turns round %6d  (%.1f a match)", reversals, reversals.toDouble() / matches))
    println(String.format("  flights containing a kink    %6d  (%.0f%% of flights)",
        flightsWithKink, 100.0 * flightsWithKink / maxOf(1L, flights)))
    println(String.format("  mean ball speed AT a kink    %6.1f m/s", kinkSpeed / maxOf(1L, kinks)))
    println()
    println("  what was happening at the kink:")
    println(String.format("    the ball was struck again        %6d (%.0f%%)", causeRestruck, 100.0*causeRestruck/maxOf(1L,kinks)))
    println(String.format("    the receiver changed             %6d (%.0f%%)", causeHolder, 100.0*causeHolder/maxOf(1L,kinks)))
    println(String.format("    the aim point moved over 1 m     %6d (%.0f%%)", causeBigAim, 100.0*causeBigAim/maxOf(1L,kinks)))
    println(String.format("    the aim point drifted            %6d (%.0f%%)", causeAimDrift, 100.0*causeAimDrift/maxOf(1L,kinks)))
    println(String.format("    nothing changed at all           %6d (%.0f%%)", causeNone, 100.0*causeNone/maxOf(1L,kinks)))
    println()
    println("  a few of the reversals:")
    samples.forEach { println(it) }
    println()
    println("a struck ball bends a few degrees a second from spin. A kink of")
    println("fifteen degrees inside one frame is the ball changing its mind.")
}
