import com.dugout.career.core.World
import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Stride length: how far a man travels for the gait phase he burns. If this is
 * much larger than a real stride the legs are cycling too slowly for the speed
 * and he skates across the grass.
 *
 * PASS GEOMETRY USED TO BE MEASURED HERE AND THE FIGURE WAS WRONG. It spotted
 * a delivery with `!wasFlying && ball.t < 1f`, which needs a frame with the
 * ball at rest between two passes, and this engine rarely has one: a phase
 * steps on a match-minute timer while the ball flies in real seconds, so the
 * next pass is struck while the last is still travelling. That test saw 14% of
 * the passes played, weighted toward the opening ball of a move, and reported
 * a mean of 19.6 m against a real 18 — reassuringly close, and untrue. It is
 * 24.6 m. Passes now live in PassAudit.kt, which counts them when the engine
 * counts them. This file kept the stride, which was never in doubt, and now
 * runs it over many players and many matches instead of one man in one match.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L

    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var strideTotal = 0.0
    var phaseTotal = 0.0
    var samples = 0

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        val lastPos = HashMap<String, Pair<Float, Float>>()
        val lastPhase = HashMap<String, Float>()
        var i = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            for (p in m.players) if (p.onPitch) {
                lastPos[p.key] = Pair(p.x, p.y); lastPhase[p.key] = p.runPhase
            }
            m.update(dt)
            if (m.finished) break
            i++
            if (i < 200) continue
            for (p in m.players) {
                if (!p.onPitch || p.pos == Pos.GK) continue
                val prev = lastPos[p.key] ?: continue
                val ph0 = lastPhase[p.key] ?: continue
                val dph = p.runPhase - ph0
                if (dph <= 0.0001f) continue
                val dd = Math.hypot(((p.x - prev.first) * 1.05).toDouble(),
                                    ((p.y - prev.second) * 0.68).toDouble())
                // a restart teleports him; that is not a stride
                if (dd > 1.0) continue
                strideTotal += dd
                phaseTotal += dph.toDouble()
                samples++
            }
        }
    }

    // one full gait cycle is 2*PI of `gait`, and gait = runPhase * 0.52
    val cycleRunPhase = (2 * Math.PI) / 0.52
    val metresPerRunPhase = strideTotal / phaseTotal
    println("=== stride: $matches matches, $samples samples ===")
    println(String.format("one full leg cycle covers %.2f m", cycleRunPhase * metresPerRunPhase))
    println("a running stride cycle (left then right) is about 3.0-4.0 m;")
    println("if this is far larger the legs are cycling too slowly and he skates")
}
