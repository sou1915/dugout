import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Mind
import com.dugout.career.sim.Season

/**
 * DOES THE MAN A PASS IS AIMED AT GO AND MEET IT?
 *
 * The owner's idea: every player should carry his own state -- he should KNOW
 * he has the ball the moment he gets it, and know when he is waiting for a
 * pass -- rather than twenty two figures reading one global description of the
 * match. Until now `v2PassTo` existed and only the ENGINE read it, so the
 * intended receiver walked into his formation slot while a ball was played at
 * him and the delivery had to chase him.
 *
 * Two things measured here, both per pass:
 *
 *   closing   how much of the gap to where the ball is going he closes while it
 *             is in the air. Negative means he moved AWAY from a ball aimed at
 *             him, which is the incorrect movement being complained about.
 *   met       share of passes where he is within 3 m of the arrival point when
 *             the ball gets there.
 *
 * And the time on the ball, which used to be one number belonging to the match
 * and is now each man's own.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 10
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var passes = 0
    var closedSum = 0.0
    var met = 0
    var awayFromIt = 0
    var thinkSum = 0.0
    var thinkN = 0
    val mindTime = DoubleArray(5)
    var frames = 0.0

    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var watching: String? = null
        var startGap = 0.0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt); m.sound.clear()
            if (m.finished) break
            frames += dt
            for (p in m.players) {
                if (!p.onPitch) continue
                mindTime[p.mind.coerceIn(0, 4)] += dt
                if (p.mind == Mind.ON_BALL && p.thinkLeft > 0f) { thinkSum += p.thinkLeft; thinkN++ }
            }
            // a new man is expecting a pass: start watching him
            val exp = m.players.firstOrNull { it.onPitch && it.mind == Mind.EXPECTING }
            if (exp != null && exp.key != watching && m.ball.t < 1f) {
                watching = exp.key
                // to the BALL, not to its aim point: the aim point is re-led
                // toward the receiver every tick, so measuring against it
                // compares two different things and reads as nonsense.
                startGap = Math.hypot(((exp.x - m.ball.x) * 1.05).toDouble(),
                    ((exp.y - m.ball.y) * 0.68).toDouble())
            }
            // the ball has arrived: how did he do?
            if (watching != null && m.ball.t >= 1f) {
                val p = m.players.firstOrNull { it.key == watching }
                if (p != null && startGap > 0.5) {
                    val endGap = Math.hypot(((p.x - m.ball.x) * 1.05).toDouble(),
                        ((p.y - m.ball.y) * 0.68).toDouble())
                    passes++
                    closedSum += startGap - endGap
                    if (endGap < 3.0) met++
                    if (endGap > startGap) awayFromIt++
                }
                watching = null
            }
        }
    }

    println("=== the man a pass is aimed at, over $matches matches ===")
    println()
    println("passes watched                 $passes")
    if (passes > 0) {
        println(String.format("gap he closed while it flew    %.2f m", closedSum / passes))
        println(String.format("he MET it (within 3 m)         %.1f%%", 100.0 * met / passes))
        println(String.format("he moved AWAY from it          %.1f%%", 100.0 * awayFromIt / passes))
    }
    println()
    if (thinkN > 0)
        println(String.format("mean think left on the ball    %.2f s", thinkSum / thinkN))
    println()
    println("share of a man's time in each state:")
    for (i in 0..4)
        println(String.format("  %-14s %6.1f%%", Mind.LABEL[i], 100.0 * mindTime[i] / (frames * 22)))
}
