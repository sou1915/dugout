import com.dugout.career.core.World
import com.dugout.career.sim.Comp
import com.dugout.career.sim.Season

/** Can a career actually be run outside England? */
fun main() {
    val world = World.build(20260727L)

    println("=== playable countries ===")
    val countries = world.playableCountries()
    println(countries.joinToString(", ") + "   (${countries.size} total)")
    println()

    // take a job in Spain
    world.playerCountry = "ESP"
    val pyramid = world.pyramidOf("ESP")
    println("=== Spanish pyramid ===")
    for (d in pyramid) println(String.format("  tier %d  %-34s %2d clubs", d.tier, d.name, d.clubIds.size))

    val season = Season(world)
    season.buildCalendar()
    println()
    for (d in pyramid) {
        val fx = season.fixtures.filter { it.divisionId == d.id }
        val weeks = fx.map { it.week }.distinct().size
        val perClub = fx.count { it.homeId == d.clubIds[0] || it.awayId == d.clubIds[0] }
        println(String.format("  %-34s %4d fixtures over %2d rounds, %d games each",
            d.name, fx.size, weeks, perClub))
    }
    val home = season.fixtures.count { it.comp == Comp.LEAGUE && (world.division(it.divisionId)?.isHome ?: false) }
    val abroad = season.fixtures.count { it.comp == Comp.LEAGUE && !(world.division(it.divisionId)?.isHome ?: true) }
    println()
    println("league fixtures: $home at home, $abroad in Spain, ${home + abroad} total")

    // play the whole Spanish season out and read the table
    val top = pyramid[0]
    val rng = com.dugout.career.core.Rng(99L)
    for (wk in 1..40) {
        world.week = wk
        season.simWeek(wk, -1)
    }
    println()
    println("=== ${top.name} final table (top 6) ===")
    val tbl = season.table(top.id)
    for (i in 0 until minOf(6, tbl.size)) {
        val c = tbl[i]
        println(String.format("%2d  %-24s %2d pts  %+3d gd", i + 1, c.name, c.points, c.goalDiff))
    }
    val played = season.fixtures.count { it.divisionId == top.id && it.played }
    val total = season.fixtures.count { it.divisionId == top.id }
    println()
    println("$played of $total fixtures played in the top flight")

    val rep = season.endSeason()
    println("promoted ${rep.promoted.size}, relegated ${rep.relegated.size} across both pyramids")
    val spanishMoves = (rep.promoted + rep.relegated).count { world.division(it.divisionId)?.country == "ESP" }
    println("of which $spanishMoves were Spanish clubs")
}
