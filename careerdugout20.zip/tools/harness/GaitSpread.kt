import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How a match is actually spent. A real footballer walks for most of it, jogs a
 * good deal, runs sometimes and sprints rarely. If everyone sits in one band the
 * pitch looks mechanical however correct the average is.
 */
fun main(args: Array<String>) {
    // Several matches. One match is a single set of twenty two men with one
    // set of stamina and one game state, which is not a sample of anything.
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    val last = HashMap<String, Pair<Float, Float>>()
    // metres per second bands
    var still = 0; var walk = 0; var jog = 0; var run = 0; var sprint = 0
    var n = 0
    var celebrationFrames = 0
    for (match in 0 until matches) {
    val m = MatchEngine(world, season, league[match % league.size])
    m.replaysEnabled = false
    m.start()
    last.clear()
    for (i in 0 until 9000) {
        for (p in m.players) if (p.onPitch) last[p.key] = Pair(p.x, p.y)
        m.update(dt)
        if (i < 200) continue
        // A celebration is not match play, and the 15/45/25/12/3 this is
        // compared against is a figure for play. Players sprint to mob a
        // scorer — they should — and counting those six seconds a goal in with
        // the rest pushed sprinting from 3.3% to 6.2% without anything about
        // the football having changed. Counted separately below.
        if (m.celebrationTime > 0f) { celebrationFrames++; continue }
        for (p in m.players) {
            if (!p.onPitch || p.pos == Pos.GK) continue
            val prev = last[p.key] ?: continue
            val dx = (p.x - prev.first) * 1.05
            val dy = (p.y - prev.second) * 0.68
            val mps = Math.sqrt(dx * dx + dy * dy) / dt
            if (mps > 30) continue
            n++
            when {
                mps < 0.4 -> still++
                mps < 2.0 -> walk++
                mps < 4.0 -> jog++
                mps < 6.0 -> run++
                else -> sprint++
            }
        }
        if (m.finished) break
    }
    }
    fun pct(x: Int) = x * 100.0 / n
    println("=== how the outfield players spend a match ===")
    println(String.format("standing      %5.1f%%   (real football is around 15)", pct(still)))
    println(String.format("walking       %5.1f%%   (around 45)", pct(walk)))
    println(String.format("jogging       %5.1f%%   (around 25)", pct(jog)))
    println(String.format("running       %5.1f%%   (around 12)", pct(run)))
    println(String.format("sprinting     %5.1f%%   (around 3)", pct(sprint)))
    println()
    println(String.format("%d matches, %d samples; %d frames skipped as celebration",
        matches, n, celebrationFrames))
}
