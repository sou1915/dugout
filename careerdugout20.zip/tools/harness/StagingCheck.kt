import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * When a set piece is TAKEN, has anybody got there yet?
 *
 * READ THIS BEFORE TRUSTING THE NUMBERS BELOW.
 *
 * This harness samples on the tick the CORNER CAPTION expires, on the
 * assumption -- stated in the loop as "the tick the corner scene ends is the
 * tick it gets delivered" -- that the caption ending and the ball being struck
 * are the same event. They were not. The delivery was booked by shootAfterScene
 * at clock + 0.60 MATCH MINUTES while the caption ran CORNER_SECONDS REAL
 * seconds, so the ball left the flag 2.4 s after the corner was awarded at 1x
 * and the caption expired at 8 s. Every "in the box when it is taken" figure
 * this printed was measured five or six seconds after the ball had gone, and
 * the corner-hold sweep it justified was tuning a number nothing read.
 *
 * SET_PIECE_TAKE now derives the delivery from the hold, so the two instants
 * are within a second of each other and this harness is roughly honest again.
 * SetPieceSweep measures the delivery instant exactly, by watching the ball
 * leave the flag; prefer it.
 *
 * stageCorner sends every attacker to the penalty area and every defender in
 * behind them, and then the scene lasts 1.3 seconds. A player covers about four
 * units in that time and the box is thirty units away, so the staging is set,
 * nobody arrives, the scene ends and they all scatter back to their formation
 * slots before the ball is delivered.
 *
 * That is why the scenes still read as missing after they were given captions:
 * the caption is drawn, and behind it nothing has happened yet. A scene is the
 * arrangement, not the label on it.
 *
 * Measures, at the moment the scene ENDS -- which is when the ball is actually
 * played -- how many men have reached where they were sent.
 */
private fun run(matches: Int, cornerSecs: Float, fkSecs: Float): String {
    MatchEngine.CORNER_SECONDS = cornerSecs
    MatchEngine.FREEKICK_SECONDS = fkSecs
    var cornerAtt = 0.0; var cornerDef = 0.0; var cornerN = 0L
    var arrived = 0.0; var arrivedN = 0L
    var goals = 0L

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var was = Scene.NONE
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(1f / 36f)
            m.sound.clear()
            val now = if (m.sceneTime > 0f) m.scene else Scene.NONE
            // the tick the corner scene ends is the tick it gets delivered
            if (was == Scene.CORNER && now != Scene.CORNER) {
                val att = if (m.ball.x > 50f) 0 else 1
                val box = m.players.filter {
                    it.onPitch && it.pos != Pos.GK &&
                    (if (att == 0) it.x > 83.5f else it.x < 16.5f) && it.y > 21f && it.y < 79f
                }
                cornerAtt += box.count { it.side == att }
                cornerDef += box.count { it.side != att }
                cornerN++
            }
            if (was != Scene.NONE && now != was && (was == Scene.CORNER || was == Scene.FREEKICK)) {
                // how close is each man to the place he was sent, in metres
                val on = m.players.filter { it.onPitch && it.pos != Pos.GK }
                arrived += on.count {
                    Math.hypot(((it.targetX - it.x) * 1.05).toDouble(),
                               ((it.targetY - it.y) * 0.68).toDouble()) < 4.0
                }.toDouble() / on.size
                arrivedN++
            }
            was = now
        }
        goals += m.score[0] + m.score[1]
    }
    return String.format("%-8.1f %-9.1f %11.2f %11.2f %13.0f%% %10.2f",
        cornerSecs, fkSecs,
        cornerAtt / maxOf(1L, cornerN), cornerDef / maxOf(1L, cornerN),
        100.0 * arrived / maxOf(1L, arrivedN), goals.toDouble() / matches)
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 12
    println("=== has anybody arrived when the set piece is taken? ($matches matches each) ===")
    println(String.format("%-8s %-9s %11s %11s %14s %10s",
        "corner s", "free-kick", "attackers", "defenders", "in position", "goals"))
    println(run(matches, 1.3f, 2.0f))
    for (c in listOf(6.0f, 8.0f, 10.0f)) println(run(matches, c, c * 0.55f))
    MatchEngine.CORNER_SECONDS = 1.3f
    MatchEngine.FREEKICK_SECONDS = 2.0f
    println()
    println("a real corner has five or six attackers and eight defenders in the")
    println("area when it is swung in. 'in position' is the share of outfield men")
    println("who have reached where the staging sent them.")
}
