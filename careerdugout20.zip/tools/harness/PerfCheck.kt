import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView

/** What a frame costs, and what the engine costs, per rendered frame. */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start()
    for (i in 0 until 600) m.update(1f / 36f)

    val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(Context(), m)

    fun bench(label: String, warm: Int, runs: Int, body: () -> Unit): Double {
        repeat(warm) { body() }
        val t0 = System.nanoTime()
        repeat(runs) { body() }
        val ms = (System.nanoTime() - t0) / 1e6 / runs
        println(String.format("%-34s %6.2f ms/frame   %5.0f fps headroom", label, ms, 1000.0 / ms))
        return ms
    }

    // board view: danger low
    m.danger = 0f
    repeat(60) { v.renderAt(c, 1280, 720) }
    val board = bench("board view (whole pitch)", 30, 200) { v.renderAt(c, 1280, 720) }

    // broadcast view: danger high, camera settled
    m.danger = 1f
    repeat(60) { v.renderAt(c, 1280, 720) }
    val close = bench("broadcast view (perspective)", 30, 200) { v.renderAt(c, 1280, 720) }

    // where the time goes
    com.dugout.career.ui.BroadcastCamera.drawStands = false
    repeat(60) { v.renderAt(c, 1280, 720) }
    val noStands = bench("  without stands and crowd", 30, 200) { v.renderAt(c, 1280, 720) }
    com.dugout.career.ui.BroadcastCamera.drawGoals = false
    repeat(30) { v.renderAt(c, 1280, 720) }
    val noGoals = bench("  without goals either", 30, 200) { v.renderAt(c, 1280, 720) }
    com.dugout.career.ui.BroadcastCamera.drawStands = true
    com.dugout.career.ui.BroadcastCamera.drawGoals = true
    println()
    println(String.format("crowd and stands cost %.2f ms, goals %.2f ms, the rest %.2f ms",
        close - noStands, noStands - noGoals, noGoals))
    println()

    // engine alone
    /*
     * Restart the match when it ends.
     *
     * update() returns immediately once `finished` is set, so benching four
     * thousand plain calls was timing a no-op for most of them and reporting an
     * engine faster than it is. Same family of bug as the whistle checks that
     * were missing from StickCheck and CamCheck: a harness that keeps calling
     * into a finished match measures nothing.
     */
    val eng = bench("engine update", 200, 4000) {
        if (m.finished) { m.start() }
        m.update(1f / 36f)
    }

    println()
    println(String.format("worst case together: %.2f ms, which is %.0f fps",
        close + eng, 1000.0 / (close + eng)))
    println("a phone is perhaps three to four times slower than this desktop,")
    println("so divide the headroom accordingly. 30 fps needs the total under 33 ms.")
}
