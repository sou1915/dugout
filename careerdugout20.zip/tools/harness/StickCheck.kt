import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How close the ball actually sits to whoever is supposed to have it, and how
 * often it is off the ground. A ball that looks like a drone is one that hangs
 * a body width away from the man in possession.
 */
fun main(args: Array<String>) {
    /*
     * Many matches, not one.
     *
     * A single match yields under two hundred frames where somebody actually
     * has the ball at his feet — most of the time it is loose or travelling —
     * so the mean distance off one match moves by a tenth of a metre from
     * nothing at all. The figure in the README was quoted off that sample.
     */
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    var held = 0
    var sumD = 0.0
    var worst = 0.0
    var air = 0
    var airHeld = 0
    var total = 0
    for (match in 0 until matches) {
    val m = MatchEngine(world, season, league[match % league.size])
    m.replaysEnabled = false
    m.start()
    for (i in 0 until 8000) {
        m.update(dt)
        /*
         * Stop at the final whistle, before anything else.
         *
         * This check used to sit at the BOTTOM of the loop, after three
         * `continue`s. Any frame where the ball was loose or in flight jumped
         * over it, so if the match ended on one of those — which it usually
         * does — the loop never broke and went on counting four thousand
         * frames of a frozen, finished match. That is where "airborne 59% of
         * the match" came from: the true figure is 17%, and BallCheck had been
         * saying so all along. It also fed every one of those frozen frames
         * into the mean distance from the man in possession.
         */
        if (m.finished) break
        if (i < 200) continue
        total++
        if (m.ball.height > 0.05f) air++
        val h = m.ball.holder ?: continue
        if (m.ball.t < 1f) continue                 // still in flight to him
        val p = m.players.firstOrNull { it.key == h } ?: continue
        val dx = (m.ball.x - p.x) * 1.05
        val dy = (m.ball.y - p.y) * 0.68
        val d = Math.sqrt(dx * dx + dy * dy)
        held++; sumD += d
        if (d > worst) worst = d
        if (m.ball.height > 0.05f) airHeld++
    }
    }
    println("=== ball against the man in possession, $matches matches ===")
    println(String.format("mean distance from his body   %.2f m", sumD / held))
    println(String.format("worst                         %.2f m", worst))
    println(String.format("airborne while held           %.0f%%", airHeld * 100.0 / held))
    println()
    println(String.format("airborne overall              %.0f%% of the match", air * 100.0 / total))
    println()
    println("a ball at a player's feet is within about 0.6 m of him")
}
