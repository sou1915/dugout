import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Is a far side player drawn smaller than a near one?
 *
 * Both are put on the pitch at once, in different halves, and each measured in
 * his own half of the frame. Toggling a player off the pitch does not work as a
 * control: he reappears on the substitutes bench and the difference picks him
 * up there instead.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start(); m.danger = 1f; m.shake = 0f
    for (p in m.players) p.onPitch = false

    val far = m.players.first { it.side == 0 && it.pos != 0 }
    val near = m.players.last { it.side == 0 && it.pos != 0 && it.key != far.key }
    far.onPitch = true; far.x = 36f; far.y = 37f
    near.onPitch = true; near.x = 64f; near.y = 65f
    for (p in listOf(far, near)) {
        p.action = Act.RUN; p.speedNow = 0f; p.facing = (Math.PI / 2).toFloat()
    }
    m.ball.holder = null; m.ball.x = 50f; m.ball.y = 50f
    m.refCard = 0; m.banner = null; m.celebrateKey = null

    val withBoth = render(m, 40) { it.followBall = false }
    save(withBoth, "out/depth.png")
    far.onPitch = false; near.onPitch = false
    val empty = render(m, 40) { it.followBall = false }
    far.onPitch = true; near.onPitch = true

    fun heightIn(xFrom: Int, xTo: Int): Int {
        var top = -1; var bot = -1
        for (y in 0 until H) {
            for (x in xFrom until xTo) {
                val q = withBoth.image.getRGB(x, y); val r = empty.image.getRGB(x, y)
                if (maxOf(Math.abs(((q shr 16) and 0xFF) - ((r shr 16) and 0xFF)),
                        Math.abs(((q shr 8) and 0xFF) - ((r shr 8) and 0xFF)),
                        Math.abs((q and 0xFF) - (r and 0xFF))) > 24) {
                    if (top < 0) top = y
                    bot = y
                }
            }
        }
        return if (top < 0) 0 else bot - top + 1
    }

    // the bench sits at the very top of the frame, so measure below it
    val farH = heightIn(0, W / 2)
    val nearH = heightIn(W / 2, W)
    println("=== figure height against depth ===")
    println(String.format("far side  (y=37)  %4d px", farH))
    println(String.format("near side (y=65)  %4d px", nearH))
    println(String.format("near is %.2fx the far figure", nearH.toDouble() / farH))
    println("a broadcast camera gives roughly 1.5 to 1.8")
}
