import com.dugout.career.core.World

/** How international the squads actually are. */
fun main() {
    val w = World.build(20260727L)
    println(String.format("nations represented across the world: %d",
        w.players.values.map { it.nation }.distinct().size))
    println()
    println(String.format("%-26s %4s %10s %s", "club", "rep", "foreign", "example nations"))
    val sample = listOf(
        w.divisions[0].clubIds.first(), w.divisions[0].clubIds.last(),
        w.divisions[4].clubIds.first(), w.divisions[4].clubIds.last()
    )
    for (id in sample) {
        val c = w.club(id) ?: continue
        val sq = w.squadOf(c)
        val foreign = sq.count { it.nation != "ENG" }
        val nats = sq.map { it.nation }.filter { it != "ENG" }.distinct().take(5)
        println(String.format("%-26s %4d %9.0f%% %s",
            c.name, c.reputation, foreign * 100.0 / sq.size, nats.joinToString(", ")))
    }
}
