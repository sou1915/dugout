import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- do the players pile up on each other?
 *
 * The owner reports men tangling and bunching into one spot. An earlier check
 * measured SPREAD (mean distance from a side's own centroid) at 18-19 m and I
 * concluded there was no clumping problem. That was the wrong measurement:
 * spread says how stretched a SIDE is, and says nothing about two men standing
 * on the same blade of grass.
 *
 * separate() enforces minGap = 1.15 PITCH UNITS. One x-unit is 1.05 m and one
 * y-unit is 0.68 m, so along y that is 0.78 m -- not the "metre and a half" the
 * comment claims. Two sprites that close are drawn on top of each other. And it
 * is a single pass, so a genuine pile of eight or ten men cannot resolve.
 *
 * Measured here, per frame of open play:
 *   OVERLAP   pairs of men closer than 1.5 m
 *   PILE      the most men found inside a 5 m circle
 *   BASE      how far a man drifts from the station his formation gives him
 */
private class Row(val label: String, val v2: Boolean) {
    var frames = 0L
    var overlaps = 0L
    var pileSum = 0.0
    var pileMax = 0
    var baseSum = 0.0; var baseN = 0L
    var near15 = 0.0; var shapeSum = 0.0

    fun run(n: Int) {
        MatchEngine.ENGINE_V2 = v2; MatchEngine.ENGINE_V3 = false
        val dt = 1f / 36f
        for (i in 0 until n) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false; m.start()
            var g = 0
            while (!m.finished && g++ < 900_000) {
                m.update(dt); m.sound.clear()
                if (g % 9 != 0) continue
                val on = m.players.filter { it.onPitch && it.pos != Pos.GK }
                if (on.size < 4) continue
                frames++
                var pairs = 0
                for (a in on.indices) for (b in a + 1 until on.size) {
                    val d = Math.hypot(((on[a].x - on[b].x) * 1.05).toDouble(),
                        ((on[a].y - on[b].y) * 0.68).toDouble())
                    if (d < 1.5) pairs++
                }
                overlaps += pairs
                var best = 0
                for (p in on) {
                    val c = on.count {
                        Math.hypot(((it.x - p.x) * 1.05).toDouble(),
                            ((it.y - p.y) * 0.68).toDouble()) < 5.0
                    }
                    if (c > best) best = c
                }
                pileSum += best
                if (best > pileMax) pileMax = best
                for (p in on) {
                    baseSum += Math.hypot(((p.x - p.baseX) * 1.05).toDouble(),
                        ((p.y - p.baseY) * 0.68).toDouble())
                    baseN++
                }
                // how many men are inside fifteen metres of the ball. Real
                // football is four to six; if it is ten or more, everybody is
                // chasing the same ball and the formation means nothing.
                near15 += on.count {
                    Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(),
                        ((it.y - m.ball.y) * 0.68).toDouble()) < 15.0
                }
                // SHAPE: residual after taking out the side's own slide, i.e.
                // how much the formation is DEFORMED rather than moved. This
                // is the honest "does he hold his slot" figure -- the block is
                // supposed to slide with the ball, it is not supposed to melt.
                for (side in 0..1) {
                    val men = on.filter { it.side == side }
                    if (men.size < 4) continue
                    val ox = men.map { (it.x - it.baseX).toDouble() }.average()
                    val oy = men.map { (it.y - it.baseY).toDouble() }.average()
                    shapeSum += men.map {
                        Math.hypot(((it.x - it.baseX - ox) * 1.05),
                            ((it.y - it.baseY - oy) * 0.68))
                    }.average() / 2.0
                }
            }
        }
        MatchEngine.ENGINE_V2 = true
    }

    fun print() {
        println(String.format("%-4s %12.2f %12.2f %10d %12.1f %11.1f %11.1f",
            label, overlaps.toDouble() / maxOf(1L, frames),
            pileSum / maxOf(1L, frames), pileMax, baseSum / maxOf(1L, baseN),
            near15 / maxOf(1L, frames), shapeSum / maxOf(1L, frames)))
    }
}

fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 5
    println("=== do the players pile up? ($n matches each) ===")
    println(String.format("%-4s %12s %12s %10s %12s %11s %11s",
        "", "overlapping", "biggest", "worst", "drift from", "men within", "shape"))
    println(String.format("%-4s %12s %12s %10s %12s %11s %11s",
        "", "pairs/frame", "pile (5 m)", "pile", "station m", "15 m of ball", "deform m"))
    Row("v1", false).also { it.run(n) }.print()
    Row("v2", true).also { it.run(n) }.print()
    println()
    println("Real football: two outfielders inside 1.5 m of each other is a duel,")
    println("so a fraction of a pair per frame. Six or more inside a 5 m circle")
    println("only happens in a box at a corner. Men within 15 m of the ball:")
    println("real football is four to six. Shape deform is the residual after")
    println("the side's own slide is removed -- a block that holds its shape")
    println("reads under about 8 m however far up the pitch it has moved.")
    println()
    println("CAUTION ON THE DEFORM FIGURE. It is measured against the RAW")
    println("formation baseX/baseY, and updateTargets deliberately compacts the")
    println("shape to SHAPE_COMPACT = 0.62 of its drawn spread. A striker drawn")
    println("at x=76 is intentionally stationed near 65, which this counts as")
    println("eleven metres of deformation before anything has gone wrong. So a")
    println("high number here does NOT by itself prove the shape is melting.")
    println("Separate the intended compaction from the real scatter before")
    println("changing any code on the strength of it.")
}
