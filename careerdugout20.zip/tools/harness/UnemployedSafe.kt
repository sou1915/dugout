import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/**
 * Everything the out of work screen touches, with no club present. Any of these
 * reaching for userClub without checking is a crash on the device.
 */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w)
    val car = Career(w, s)
    w.managerName = "A Manager"
    w.userClubId = -1
    w.managerRep = 22

    var ok = 0; var failed = 0
    fun step(name: String, body: () -> Unit) {
        try { body(); ok++; println("  ok    $name") }
        catch (e: Throwable) { failed++; println("  CRASH $name  ${e::class.simpleName}: ${e.message}") }
    }

    println("=== with no club ===")
    step("world.unemployed") { require(w.unemployed) }
    step("vacancies()") { car.vacancies() }
    step("record.summary()") { w.record.summary() }
    step("unemployedWeek()") { car.unemployedWeek() }
    step("squadRating on a random club") { w.squadRating(w.clubs.first()) }
    step("news and inbox") { car.news.size; car.inbox.size }
    step("take a job then check the record") {
        val v = car.vacancies().first()
        car.takeJob(v.clubId)
        require(!w.unemployed)
        require(w.record.spells.isNotEmpty())
    }
    step("leave it again") {
        car.leaveJob(sacked = true)
        require(w.unemployed)
    }
    println()
    println("$ok passed, $failed crashed")
}
