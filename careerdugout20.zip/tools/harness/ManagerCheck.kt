import android.content.Context
import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** Do the setup choices actually change the career? */
fun newCareer(age: Int, school: Int, phil: Int, manner: Int): Triple<World, Season, Career> {
    val w = World.build(20260727L)
    w.profile.ageBand = age; w.profile.school = school
    w.profile.philosophy = phil; w.profile.manner = manner
    val s = Season(w); s.buildCalendar()
    val c = w.club(w.divisions[0].clubIds.first())!!
    val car = Career(w, s)
    car.start(c.id, "A Manager", "ENG")
    return Triple(w, s, car)
}

fun main() {
    println("=== the day you walk in ===")
    println(String.format("%-14s %6s   %s", "age", "rep", "set up as"))
    for (a in 0..2) {
        val (w, _, _) = newCareer(a, 1, 1, 1)
        val c = w.userClub!!
        println(String.format("%-14s %6d   %s",
            ManagerAges.of(a).label, w.managerRep, Presets.nameFor(c.tactics)))
    }

    println()
    println("=== your school of play, and how fast a squad learns it ===")
    for (sc in 0..4) {
        val (w, _, _) = newCareer(1, sc, 1, 1)
        val c = w.userClub!!
        val own = Presets.nameFor(c.tactics)
        val info = ManagerSchools.of(sc)
        // pick a preset that is genuinely outside this school
        val alien = Presets.ALL.map { it.name }
            .first { it !in info.homeGround }
        println(String.format("%-15s starts as %-16s own ideas %.2fx, %s %.2fx",
            info.label, own, info.affinity(own), alien, info.affinity(alien)))
    }

    println()
    println("=== squad building: the same teenager, three managers ===")
    for (ph in 0..2) {
        val (w, s, car) = newCareer(1, 0, ph, 1)
        val c = w.userClub!!
        val p = w.squadOf(c).filter { it.age <= 18 }
            .maxByOrNull { it.potential - it.overall() } ?: continue
        val start = p.overall()
        // everyone gets there in the end; the difference is how long it takes
        var weeks = 0
        while (p.overall() < p.potential && weeks < 500) {
            w.week = (weeks % 38) + 1; p.minutes += 70; car.applyTraining(); weeks++
            if (weeks % 38 == 0) s.rolloverPlayers()
        }
        println(String.format("%-18s %d to his %d ceiling in %3d weeks   veterans %.2fx   scouts %+d yrs",
            ManagerPhilosophies.of(ph).label, start, p.potential, weeks,
            ManagerPhilosophies.of(ph).veteranHold, ManagerPhilosophies.of(ph).scoutAgeBias))
    }

    println()
    println("=== how the dressing room takes it ===")
    println(String.format("%-24s %8s %10s", "manner", "praised", "criticised"))
    for (mn in 0..2) {
        val (w, _, car) = newCareer(1, 0, 1, mn)
        val p = w.squadOf(w.userClub!!).first()
        p.personality = "Professional"
        p.morale = 70.0; car.tell(p, 10.0); val up = p.morale
        p.morale = 70.0; car.tell(p, -10.0); val dn = p.morale
        println(String.format("%-24s %8.1f %10.1f", ManagerManners.of(mn).label, up, dn))
    }

    // and it survives a save
    val (w, s, car) = newCareer(0, 2, 0, 2)
    val ctx = Context()
    Save.write(ctx, w, s, car)
    val back = Save.read(ctx)!!
    val bp = back.world.profile
    println()
    println("profile survives a save: age ${bp.ageBand}, school ${bp.school}, " +
            "philosophy ${bp.philosophy}, manner ${bp.manner}")
    println("appointed: ${back.world.profile.summary()}")
}
