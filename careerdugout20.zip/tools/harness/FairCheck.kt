import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * The manager's own matches are played by the live engine; everybody else's are
 * quick-simmed. If the two disagree, the club you manage is systematically
 * better or worse off than the league around it, whatever you do.
 */
fun main() {
    var liveP = 0; var liveGF = 0; var liveGA = 0; var liveW = 0; var liveD = 0
    var quickP = 0; var quickGF = 0; var quickGA = 0; var quickW = 0; var quickD = 0

    for (seed in 0 until 120) {
        val w = World.build(9000L + seed)
        val s = Season(w); s.buildCalendar()
        // the same fixture, resolved both ways
        val fx = s.fixtures.first { it.comp == 0 }

        val m = MatchEngine(w, s, fx)
        m.replaysEnabled = false; m.speed = 8f
        m.start()
        var t = 0
        while (!m.finished && t++ < 300_000) m.update(1f / 30f)
        liveGF += m.score[0]; liveGA += m.score[1]; liveP++
        if (m.score[0] > m.score[1]) liveW++ else if (m.score[0] == m.score[1]) liveD++

        // and the quick path on a fresh world so nothing is carried over
        val w2 = World.build(9000L + seed)
        val s2 = Season(w2); s2.buildCalendar()
        val fx2 = s2.fixtures.first { it.comp == 0 }
        val res = s2.quickSimPublic(fx2)
        quickGF += res.first; quickGA += res.second; quickP++
        if (res.first > res.second) quickW++ else if (res.first == res.second) quickD++
    }

    fun pts(w2: Int, d: Int) = w2 * 3 + d
    println("=== the same 120 fixtures, resolved both ways ===")
    println(String.format("%-22s %7s %7s %8s %8s", "path", "for", "against", "wins", "points"))
    println(String.format("%-22s %7.2f %7.2f %7.0f%% %8d", "live engine",
        liveGF.toDouble() / liveP, liveGA.toDouble() / liveP, liveW * 100.0 / liveP, pts(liveW, liveD)))
    println(String.format("%-22s %7.2f %7.2f %7.0f%% %8d", "quick simulation",
        quickGF.toDouble() / quickP, quickGA.toDouble() / quickP, quickW * 100.0 / quickP, pts(quickW, quickD)))
    println()
    val gap = pts(liveW, liveD) - pts(quickW, quickD)
    println(String.format("points difference over 120 matches: %+d", gap))
    println(String.format("over a 38 game season that is worth %+.1f points", gap * 38.0 / 120.0))
}
