import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How tightly the scoring side bunches up while it celebrates.
 *
 * Reported from the device: "after scoring a goal they united in one place on
 * the pitch". The engine fans the mates out on a ring around the scorer, so
 * this measures whether the ring survives contact with the movement code.
 *
 * Measured in METRES, not pitch units — a unit is 1.05 m along the pitch and
 * only 0.68 m across it, so a ring that looks round in units is a flat ellipse
 * on the grass, and a radius quoted in units flatters the spread by half on the
 * short axis.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    // the real game shows a replay after every goal, and update() returns early
    // while one is running, so the celebration the player watches is not the one
    // a replays-off harness measures
    val replays = args.getOrNull(1) != "noreplay"
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var goals = 0
    val closest = ArrayList<Double>()
    val spread = ArrayList<Double>()
    val bounding = ArrayList<Double>()
    var framesInsideTwoMetres = 0
    var framesSampled = 0
    // spread against how far into the celebration we are, because the mob
    // converges over several seconds and an average across the whole window
    // hides the state it settles into — which is the state a player sees
    val bySecond = Array(7) { ArrayList<Double>() }
    val closestBySecond = Array(7) { ArrayList<Double>() }

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = replays
        m.start()
        var guard = 0
        var celebrating = false
        // celebrateSide is private, so the scoring side is taken from which
        // score went up. Watching for a CELEBRATE action instead only finds the
        // first 2.4 seconds, while the men are still running in, and reports
        // the converging phase as though it were the huddle.
        var prevH = 0; var prevA = 0
        var side = -1
        var startedAt = 0f
        while (!m.finished && guard++ < 300_000) {
            m.update(dt)
            if (m.finished) break
            if (m.score[0] > prevH) { side = 0; startedAt = m.celebrationTime }
            if (m.score[1] > prevA) { side = 1; startedAt = m.celebrationTime }
            prevH = m.score[0]; prevA = m.score[1]

            val on = m.celebrationTime > 0f
            if (on && !celebrating) goals++
            celebrating = on
            if (!on || side < 0) continue

            val mob = m.players.filter { it.onPitch && it.side == side && it.pos != Pos.GK }
            if (mob.size < 5) continue

            framesSampled++
            val elapsed = (startedAt - m.celebrationTime).coerceAtLeast(0f)
            var minD = 1e9
            for (i in mob.indices) for (j in i + 1 until mob.size) {
                val dx = (mob[i].x - mob[j].x) * 1.05
                val dy = (mob[i].y - mob[j].y) * 0.68
                val d = Math.sqrt(dx * dx + dy * dy)
                if (d < minD) minD = d
            }
            val cx = mob.map { it.x }.average()
            val cy = mob.map { it.y }.average()
            val dists = mob.map {
                val dx = (it.x - cx) * 1.05
                val dy = (it.y - cy) * 0.68
                Math.sqrt(dx * dx + dy * dy)
            }
            closest.add(minD)
            spread.add(dists.average())
            bounding.add(dists.max())
            if (dists.max() < 2.0) framesInsideTwoMetres++
            val bucket = elapsed.toInt().coerceIn(0, 6)
            bySecond[bucket].add(dists.average())
            closestBySecond[bucket].add(minD)
        }
    }

    if (framesSampled == 0) { println("no celebrations sampled"); return }
    println("=== the mob after a goal: $matches matches, $goals goals, $framesSampled frames," +
        " replays ${if (replays) "on (as the game runs)" else "off"} ===")
    println(String.format("closest two men          %.2f m on average, %.2f m at worst",
        closest.average(), closest.min()))
    println(String.format("mean distance from the centre of the huddle  %.2f m", spread.average()))
    println(String.format("furthest man from that centre               %.2f m on average", bounding.average()))
    println(String.format("frames with the whole mob inside a 2 m circle  %d  (%.0f%%)",
        framesInsideTwoMetres, framesInsideTwoMetres * 100.0 / framesSampled))
    println()
    println("how it changes as the celebration runs:")
    println(String.format("  %-10s %14s %14s", "second", "mean spread", "closest pair"))
    for (s in 0..6) {
        if (bySecond[s].isEmpty()) continue
        println(String.format("  %-10d %11.2f m %11.2f m", s,
            bySecond[s].average(), closestBySecond[s].average()))
    }
    println()
    println("real football: the scorer peels away and is caught by two or three")
    println("men; the rest arrive spread over ten or fifteen metres. Nobody stands")
    println("closer than about a metre, because they are solid bodies.")
}
