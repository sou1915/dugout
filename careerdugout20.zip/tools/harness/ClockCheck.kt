import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import kotlin.math.abs
import kotlin.math.atan2

/**
 * Can the ball be given enough real time to behave, without changing the game?
 *
 * The ball flies in real seconds and the match clock is compressed, and the two
 * disagree by about three to one: a move gives each pass 0.38 s and the pass
 * needs 1.26. The engine hid it by striking the ball again in mid-air, which is
 * "the ball moves suddenly without a player touching it".
 *
 * Waiting for the ball is the fix, and on its own it cost 1.7 goals a game
 * because every move took three times as long. The claim this harness tests is
 * that SECONDS_PER_MINUTE buys the ball its time for free -- that the NUMBER of
 * moves in a match is fixed by phaseDuration in match minutes and does not care
 * how long a match minute lasts in real seconds.
 *
 * If that is right, the goals column stays flat while the kinks column falls,
 * and the only cost is how long a match takes to watch.
 */
private fun measure(secsPerMin: Double, wait: Boolean, matches: Int, scale: Double = 1.0): String {
    MatchEngine.SECONDS_PER_MINUTE = secsPerMin
    MatchEngine.WAIT_FOR_BALL = wait
    MatchEngine.PHASE_SCALE = scale
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val lg = s.fixtures.filter { it.comp == 0 }

    var goals = 0L; var shots = 0L; var passes = 0L
    var kinks = 0L; var flights = 0L; var kinkedFlights = 0L
    var realSeconds = 0.0

    for (i in 0 until matches) {
        val m = MatchEngine(w, s, lg[i % lg.size])
        m.replaysEnabled = false
        m.start()
        var px = m.ball.x; var py = m.ball.y
        var lastAng = Double.NaN; var lastStep = 0.0
        var wasFlying = false; var kinked = false
        var frames = 0L
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(1f / 36f)
            m.sound.clear()
            frames++
            val flying = m.ball.t < 1f
            if (flying && !wasFlying) { flights++; kinked = false; lastAng = Double.NaN; lastStep = 0.0 }
            if (!flying && wasFlying && kinked) kinkedFlights++
            wasFlying = flying
            val dxm = (m.ball.x - px) * 1.05; val dym = (m.ball.y - py) * 0.68
            px = m.ball.x; py = m.ball.y
            if (!flying) { lastAng = Double.NaN; lastStep = 0.0; continue }
            val step = Math.hypot(dxm, dym)
            if (step < 8.0 / 36.0) { lastAng = Double.NaN; lastStep = 0.0; continue }
            val ang = atan2(dym, dxm)
            if (!lastAng.isNaN() && lastStep >= 8.0 / 36.0) {
                var d = ang - lastAng
                while (d > Math.PI) d -= Math.PI * 2
                while (d < -Math.PI) d += Math.PI * 2
                if (Math.toDegrees(abs(d)) > 15.0) { kinks++; kinked = true }
            }
            lastAng = ang; lastStep = step
        }
        goals += m.score[0] + m.score[1]
        shots += m.shots[0] + m.shots[1]
        passes += m.passesTotal[0] + m.passesTotal[1]
        realSeconds += frames / 36.0
    }

    val mm = matches.toDouble()
    return String.format("%-6.2f %-6.2f %-7s %7.2f %9.1f %9.1f %9.1f %11.0f%% %9.1f",
        secsPerMin, scale, if (wait) "waits" else "no",
        goals / mm, shots / mm, passes / mm, kinks / mm,
        100.0 * kinkedFlights / maxOf(1L, flights), realSeconds / mm)
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    println("=== can the ball be given time without changing the game? ($matches matches each) ===")
    println(String.format("%-6s %-6s %-7s %7s %9s %9s %9s %12s %9s",
        "s/min", "scale", "ball", "goals", "shots", "passes", "kinks", "flights kinked", "watch"))
    // what ships today, then the clock opened up and the move shortened to put
    // the number of chances back
    println(measure(1.15, false, matches))
    for (sc in listOf(1.0, 0.85, 0.75, 0.65, 0.55)) println(measure(4.0, true, matches, sc))
    MatchEngine.SECONDS_PER_MINUTE = 1.15
    MatchEngine.WAIT_FOR_BALL = false
    MatchEngine.PHASE_SCALE = 1.0
    println()
    println("goals must stay in 2.5-2.7. 'watch' is how many real seconds a match")
    println("takes at 1x; there is a 1x/2x/4x control, so 4x that is the slowest")
    println("a player would ever sit through.")
}
