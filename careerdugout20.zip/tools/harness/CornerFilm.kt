import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.Pos
import com.dugout.career.sim.Scene
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * LOOK AT A CORNER, AND MEASURE HOW IT IS TAKEN.
 *
 * The owner reports that corners are played wrongly. Everything about a corner
 * so far has been measured at ONE instant -- StagingCheck at the delivery,
 * SceneAudit at a swept sample point -- and an instant cannot show a routine.
 * This films the whole thing, from the moment the scene is set to a couple of
 * seconds after the ball is struck, and prints beside each frame:
 *
 *   taker      how far the nearest attacker is from the corner arc
 *   in box     attackers and defenders inside the penalty area
 *   ball       where it is and whether it is in the air
 *
 * A corner that reads "taker 14 m" for its whole hold is one where nobody ever
 * walked over to take it.
 */
fun main(args: Array<String>) {
    val seed = args.firstOrNull()?.toLongOrNull() ?: 20260727L
    val m = newEngine(seed)
    m.replaysEnabled = false
    m.start()

    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(android.content.Context(), m)
    val closeField = MatchView::class.java.getDeclaredField("closeUp")
    closeField.isAccessible = true
    File("out/corner").mkdirs()

    println("=== the first corner, frame by frame ===")
    println(String.format("%-5s %-6s %-11s %-9s %-24s %s",
        "file", "min", "scene", "taker m", "ball", "in the box (att/def)"))

    var taken = 0
    var guard = 0
    var seen = false
    var after = 0
    while (!m.finished && guard++ < 300_000 && taken < 60) {
        m.update(1f / 36f); m.sound.clear()
        if (m.finished) break
        val isCorner = m.scene == Scene.CORNER && m.sceneTime > 0f
        if (!isCorner && !seen) continue
        if (isCorner) seen = true else after++
        if (after > 130) break            // two and a half seconds past the delivery
        // one frame in four, so a nine-second corner is about eighty frames
        if (guard % 9 != 0) continue

        closeField.setFloat(v, 1f)
        v.renderAt(c, W, H)
        taken++
        stampFrame(c, W.toFloat(), H.toFloat())
        ImageIO.write(bmp.image, "png", File(String.format("out/corner/%02d.png", taken)))

        // which end, and therefore which corner arc
        val nearGoal = if (m.ball.x > 50f) 100f else 0f
        val att = if (nearGoal > 50f) 0 else 1
        val arcX = nearGoal
        val arcY = if (m.ball.y < 50f) 0f else 100f
        val takerD = m.players.filter { it.onPitch && it.side == att }
            .minOfOrNull {
                Math.hypot(((it.x - arcX) * 1.05).toDouble(), ((it.y - arcY) * 0.68).toDouble())
            } ?: -1.0
        fun inBox(side: Int) = m.players.count {
            it.onPitch && it.side == side && it.pos != Pos.GK &&
                (if (nearGoal > 50f) it.x > 83f else it.x < 17f) &&
                it.y > 21f && it.y < 79f
        }
        // are the attackers walking into the box, or standing still?
        val outfield = m.players.filter { it.onPitch && it.side == att && it.pos != Pos.GK }
        val toTarget = outfield.map {
            Math.hypot(((it.targetX - it.x) * 1.05).toDouble(), ((it.targetY - it.y) * 0.68).toDouble())
        }
        val meanGap = if (toTarget.isEmpty()) 0.0 else toTarget.average()
        val moving = outfield.count { it.speedNow > 0.5f }
        println(String.format("%-5d %-6.1f %-11s %8.1f  %-24s %d / %d   gap %4.1f m, moving %d/%d",
            taken, m.clock, Scene.LABEL[m.scene].ifEmpty { "open play" }, takerD,
            String.format("(%.1f,%.1f) h%.1f", m.ball.x, m.ball.y, m.ball.height),
            inBox(att), inBox(1 - att), meanGap, moving, outfield.size))
    }
    println()
    println("written to out/corner/. A real corner: the taker is ON the arc, five")
    println("or six attackers and seven or eight defenders are in the box, and the")
    println("delivery goes into the six yard box or is worked short.")
}
