import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.ui.Face
import com.dugout.career.ui.drawFace
import java.io.File
import javax.imageio.ImageIO

/** Are the faces actually varied, and do age and nation show? */
fun main() {
    val w = World.build(20260727L)
    val players = w.players.values.toList()
    Face.assignAll(players)

    val combos = HashSet<String>()
    val styles = IntArray(Face.STYLES)
    val beards = IntArray(Face.BEARDS)
    val jaws = IntArray(Face.JAWS)
    val skins = IntArray(9)
    var grey = 0; var bald = 0
    for (p in players) {
        val f = Face.of(p)
        combos.add("${f.skin}-${f.hair}-${f.style}-${f.brow}-${f.eye}-${f.nose}-${f.mouth}-${f.beard}-${f.jaw}-${f.ears}")
        styles[f.style]++; beards[f.beard]++; jaws[f.jaw]++; skins[f.skin]++
        if (f.hair == 9) grey++
        if (f.isBald) bald++
    }
    println("=== ${players.size} players ===")
    println("distinct faces: ${combos.size}  (${combos.size * 100 / players.size}% unique)")
    println()
    println("hair style spread  " + styles.joinToString(" ") { it.toString().padStart(5) })
    println("beard spread       " + beards.joinToString(" ") { it.toString().padStart(5) })
    println("jaw spread         " + jaws.joinToString(" ") { it.toString().padStart(5) })
    println("skin spread        " + skins.joinToString(" ") { it.toString().padStart(5) })
    println()
    println(String.format("grey haired %.1f%%   shaven headed %.1f%%",
        grey * 100.0 / players.size, bald * 100.0 / players.size))

    // does age show?
    println()
    println(String.format("%-14s %8s %8s %9s", "age band", "grey", "bald", "no beard"))
    for ((lo, hi) in listOf(16 to 20, 21 to 25, 26 to 30, 31 to 40)) {
        val band = players.filter { it.age in lo..hi }
        if (band.isEmpty()) continue
        val g = band.count { Face.of(it).hair == 9 }
        val b = band.count { Face.of(it).isBald }
        val nb = band.count { Face.of(it).beard == 0 }
        println(String.format("%-14s %7.1f%% %7.1f%% %8.1f%%", "$lo-$hi",
            g * 100.0 / band.size, b * 100.0 / band.size, nb * 100.0 / band.size))
    }

    // does nation show?
    println()
    println(String.format("%-8s %s", "nation", "mean skin index (0 lightest, 8 darkest)"))
    for (nat in listOf("SWE", "ENG", "ESP", "BRA", "MAR")) {
        val band = players.filter { it.nation == nat }
        if (band.isEmpty()) continue
        println(String.format("%-8s %.2f  over %d players", nat,
            band.sumOf { Face.of(it).skin }.toDouble() / band.size, band.size))
    }

    // a contact sheet
    val cols = 12; val rows = 8; val cell = 110
    val bmp = Bitmap.createBitmap(cols * cell, rows * cell, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val bg = android.graphics.Paint()
    bg.color = 0xFF16140F.toInt()
    c.drawRect(0f, 0f, (cols * cell).toFloat(), (rows * cell).toFloat(), bg)
    val pick = players.shuffled(java.util.Random(7)).take(cols * rows)
    for ((i, p) in pick.withIndex()) {
        val x = (i % cols) * cell + cell / 2f
        val y = (i / cols) * cell + cell * 0.52f
        drawFace(c, x, y, cell * 0.95f, Face.of(p))
    }
    File("out").mkdirs()
    ImageIO.write(bmp.image, "png", File("out/faces.png"))
    println()
    println("contact sheet written: out/faces.png")
}
