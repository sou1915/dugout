import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Does the dressing room have a pecking order, and does mood actually spread? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val c = w.club(w.divisions[0].clubIds.first())!!
    val car = Career(w, s); car.start(c.id, "A Manager", "ENG")
    val squad = w.squadOf(c)
    val avg = car.squadAverage(c)

    println("=== who carries weight ===")
    println(String.format("%-24s %4s %4s %5s %-14s %s", "player", "age", "ovr", "infl", "standing", "why"))
    for (p in squad.sortedByDescending { DressingRoom.influence(it, avg, c.tactics.captain) }.take(6)) {
        val inf = DressingRoom.influence(p, avg, c.tactics.captain)
        val why = buildString {
            if (p.hasTrait(Traits.LEADER)) append("leader ")
            if (p.id == c.tactics.captain) append("captain ")
            if (p.cApps > 150) append("${p.cApps} apps ")
            append(p.personality.lowercase())
        }
        println(String.format("%-24s %4d %4d %5d %-14s %s",
            p.full, p.age, p.overall(), inf, Standing.LABEL[DressingRoom.standingOf(inf)], why))
    }
    println()
    val tail = squad.sortedBy { DressingRoom.influence(it, avg, c.tactics.captain) }.first()
    println(String.format("lowest: %s, %d years old, influence %d (%s)",
        tail.full, tail.age, DressingRoom.influence(tail, avg, c.tactics.captain),
        Standing.LABEL[DressingRoom.standingOf(DressingRoom.influence(tail, avg, c.tactics.captain))]))

    // one unhappy senior man against one unhappy reserve
    println()
    println("=== mood spreads from the top, not the bottom ===")
    for (target in listOf("senior", "reserve")) {
        val w2 = World.build(20260727L)
        val s2 = Season(w2); s2.buildCalendar()
        val c2 = w2.club(w2.divisions[0].clubIds.first())!!
        val car2 = Career(w2, s2); car2.start(c2.id, "A Manager", "ENG")
        val sq = w2.squadOf(c2)
        val a2 = car2.squadAverage(c2)
        for (p in sq) p.morale = 70.0
        val victim =
            if (target == "senior") sq.maxByOrNull { DressingRoom.influence(it, a2, c2.tactics.captain) }!!
            else sq.minByOrNull { DressingRoom.influence(it, a2, c2.tactics.captain) }!!
        victim.morale = 12.0
        val m = w2.profile.mannerInfo
        repeat(6) { DressingRoom.settle(sq, a2, c2.tactics.captain, m.praise, m.criticism) }
        val rest = sq.filter { it.id != victim.id }.map { it.morale }.average()
        println(String.format("one unhappy %-8s (influence %2d): the rest sit at %.1f after six weeks",
            target, DressingRoom.influence(victim, a2, c2.tactics.captain), rest))
    }

    // and what selling one costs
    println()
    println("=== what losing him does to the group ===")
    for (p in squad.sortedByDescending { DressingRoom.influence(it, avg, c.tactics.captain) }
        .filterIndexed { i, _ -> i == 0 || i == 12 || i == squad.size - 1 }) {
        val inf = DressingRoom.influence(p, avg, c.tactics.captain)
        println(String.format("%-24s %-14s costs the room %.1f morale",
            p.full, Standing.LABEL[DressingRoom.standingOf(inf)],
            DressingRoom.departureCost(p, avg, c.tactics.captain)))
    }
}
