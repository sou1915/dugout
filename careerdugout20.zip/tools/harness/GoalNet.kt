import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season
import kotlin.math.abs

/**
 * DOES THE BALL GO IN THE NET, AND DOES THE GAME RESTART FROM THE CENTRE?
 *
 * Two things the owner reported and that no existing harness could see.
 *
 * 1. The replay is captured the instant a goal is awarded, and a goal was
 *    awarded when the ball reached x = 99 or 1 -- the goal LINE. So the last
 *    frame of every goal replay had the ball sitting on the line, never in the
 *    net, and half the time not even between the posts, because the aim was
 *    50 +/- 8 units against a goal 5.4 units wide either side of centre.
 *
 * 2. Nothing restarted from the centre spot. Scene.KICK_OFF fired once, at the
 *    opening whistle. Every goal after that just handed possession over
 *    wherever the celebration had left everybody standing.
 *
 * This measures both: where the ball is when the goal is given, and how many
 * kick-offs a match actually contains against how many goals were scored.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var goals = 0
    var inNet = 0
    var betweenPosts = 0
    var kickOffs = 0
    var kickOffAfterGoal = 0
    var worstX = 0f
    var worstY = 0f
    // how far into his own half each side is when the restart is finally taken
    var restartsMeasured = 0
    var strayMen = 0

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var wasScore = 0
        var wasScene = Scene.NONE
        var goalPending = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt)
            if (m.finished) break
            val now = m.score[0] + m.score[1]
            if (now != wasScore) {
                goals++
                goalPending++
                // the goal has just been given; the ball is where the replay's
                // last frame will show it
                val bx = m.ball.x
                val by = m.ball.y
                val past = if (bx > 50f) bx - 100f else -bx
                if (past > 0.5f) inNet++ else {
                    if (abs(past) > abs(worstX)) worstX = past
                }
                if (abs(by - 50f) <= 5.4f) betweenPosts++
                else if (abs(by - 50f) > abs(worstY - 50f)) worstY = by
                wasScore = now
            }
            if (m.scene == Scene.KICK_OFF && wasScene != Scene.KICK_OFF) {
                kickOffs++
                if (goalPending > 0) {
                    kickOffAfterGoal++
                    goalPending--
                    // count the men on the wrong side of halfway
                    restartsMeasured++
                    for (p in m.players) {
                        if (!p.onPitch) continue
                        val wrong = if (p.side == 0) p.targetX > 50.5f else p.targetX < 49.5f
                        if (wrong) strayMen++
                    }
                }
            }
            wasScene = m.scene
        }
    }

    fun pct(a: Int, b: Int) = if (b == 0) "-" else String.format("%.1f%%", 100.0 * a / b)
    println("=== goals and the restart, over $matches matches ===")
    println()
    println("goals scored                 $goals")
    println("ball past the line           ${pct(inNet, goals)}   (was 0%: it stopped ON the line)")
    println("ball between the posts       ${pct(betweenPosts, goals)}   (goal is 5.4 units either side)")
    println("worst short of the line      ${String.format("%.2f", worstX)} units")
    println("worst outside the posts      ${String.format("%.2f", worstY - 50f)} units off centre")
    println()
    println("kick-off scenes              ${String.format("%.2f", kickOffs.toDouble() / matches)} a match")
    println("  expected                   ${String.format("%.2f", 1.0 + goals.toDouble() / matches)}  (one to start, one a goal)")
    println("after a goal                 $kickOffAfterGoal of $goals goals")
    println("men in the wrong half        ${if (restartsMeasured == 0) "-" else
        String.format("%.2f", strayMen.toDouble() / restartsMeasured)} of 22")
}
