import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Does the replay actually contain the goal? And where does the ball go when one
 * is scored — does it cross the line and reach the net, or stop short?
 *
 * This used to stop at the very first goal of the very first seed and report on
 * that one alone. It passed while roughly seven goals in ten were being awarded
 * in midfield, because the first goal of seed 3000 happened to be a clean one.
 * It now walks many matches and passes only if every goal it saw was given at a
 * goal line with a replay that reaches it.
 *
 * The attacking end is taken from where the ball actually finished, not from
 * the score: sides change ends at half time, so a home goal in the second half
 * is scored at x=0 and a score-based guess calls it a failure.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 60

    var goals = 0
    var badPlace = 0
    var badReplay = 0
    var noReplay = 0
    var worstPlace = 0f
    var worstReplay = 0f
    var firstFailure: String? = null

    for (seed in 0 until matches) {
        val w = World.build(3000L + seed / 6)
        val s = Season(w); s.buildCalendar()
        val league = s.fixtures.filter { it.comp == 0 }
        val m = MatchEngine(w, s, league[seed % league.size])
        m.speed = 6f
        m.start()

        var awaitingReplay = false
        var goalX = 0f
        var goalTick = -1
        var guard = 0

        while (!m.finished && guard++ < 300_000) {
            val before = m.score[0] + m.score[1]
            m.update(1f / 36f)
            if (!m.running && !m.finished) m.start()
            m.sound.clear()
            if (m.score[0] + m.score[1] > before) {
                goals++
                goalX = m.ball.x
                goalTick = guard
                val line = if (goalX > 50f) 100f else 0f
                val off = Math.abs(goalX - line)
                if (off > worstPlace) worstPlace = off
                if (off > 3f) {
                    badPlace++
                    if (firstFailure == null) firstFailure =
                        String.format("goal awarded with the ball on x=%.1f, %.1f from the line", goalX, off)
                }
                awaitingReplay = true
            }
            val rp = m.replay
            if (awaitingReplay && rp != null) {
                awaitingReplay = false
                val line = if (goalX > 50f) 100f else 0f
                val closest = rp.map { Math.abs(it.ballX - line) }.minOrNull() ?: 99f
                if (closest > worstReplay) worstReplay = closest
                if (closest > 3f) {
                    badReplay++
                    if (firstFailure == null) firstFailure =
                        String.format("replay stops %.1f units short of the line", closest)
                }
            }
            // the replay is armed a few seconds after the goal; if it never
            // appears within a generous window that is a failure of its own
            if (awaitingReplay && guard - goalTick > 4000) {
                awaitingReplay = false
                noReplay++
                if (firstFailure == null) firstFailure = "no replay was ever produced for a goal"
            }
        }
    }

    println("matches                   $matches")
    println("goals inspected           $goals")
    println(String.format("worst goal placement      %.1f units from the goal line", worstPlace))
    println(String.format("worst replay approach     %.1f units from the goal line", worstReplay))
    println("goals given off the line  $badPlace")
    println("replays stopping short    $badReplay")
    println("goals with no replay      $noReplay")
    println()
    if (badPlace + badReplay + noReplay == 0) println("PASS")
    else println("FAIL: $firstFailure")
}
