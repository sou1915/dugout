import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Where the ball's impossible speeds come from.
 *
 * BallCheck over one match reported a peak of 41.8 m/s, which sits neatly
 * against MAX_BALL_MPS 26 times LAUNCH_RATIO 1.55 = 40.3, so it read as the
 * model working. Over 40 matches the peak is 181 m/s and the average match
 * has a fastest frame of 58. Something moves the ball outside its own flight
 * model, and one match was too small to see it.
 *
 * This classifies every frame above the modelled ceiling.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    val ceiling = MatchEngine.MAX_BALL_MPS * MatchEngine.LAUNCH_RATIO

    var frames = 0
    var over = 0
    var inFlightTargetMoved = 0
    var inFlightTargetStill = 0
    var notInFlight = 0
    var worst = 0.0
    var worstWhy = ""

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var px = m.ball.x; var py = m.ball.y
        var ptx = m.ball.toX; var pty = m.ball.toY
        var i = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            val wasFlying = m.ball.t < 1f
            m.update(dt)
            if (m.finished) break
            i++
            val dx = (m.ball.x - px) * 1.05
            val dy = (m.ball.y - py) * 0.68
            val mps = Math.sqrt(dx * dx + dy * dy) / dt
            // did the aim point move while the ball was on its way?
            val targetShift = Math.hypot(((m.ball.toX - ptx) * 1.05).toDouble(),
                                         ((m.ball.toY - pty) * 0.68).toDouble())
            val flying = m.ball.t < 1f
            val newFlight = !wasFlying && flying
            px = m.ball.x; py = m.ball.y
            ptx = m.ball.toX; pty = m.ball.toY
            if (i < 200) continue
            frames++
            // a fresh delivery legitimately starts from wherever the ball was
            if (newFlight) continue
            if (mps <= ceiling) continue
            over++
            when {
                !flying -> notInFlight++
                targetShift > 0.5 -> inFlightTargetMoved++
                else -> inFlightTargetStill++
            }
            if (mps > worst) {
                worst = mps
                worstWhy = String.format(
                    "t=%.2f dur=%.2f loft=%.1f curve=%.2f targetShift=%.1f m flying=%b",
                    m.ball.t, m.ball.duration, m.ball.loft, m.ball.curve, targetShift, flying)
            }
        }
    }

    println("=== ball speeds above the modelled ceiling: $matches matches ===")
    println(String.format("modelled ceiling            %.1f m/s  (MAX_BALL_MPS %.0f x LAUNCH_RATIO %.2f)",
        ceiling, MatchEngine.MAX_BALL_MPS, MatchEngine.LAUNCH_RATIO))
    println(String.format("frames measured             %d", frames))
    println(String.format("frames over the ceiling     %d  (%.2f%%)", over, over * 100.0 / frames))
    println()
    println(String.format("  in flight, aim point moved   %d  (%.0f%% of them)",
        inFlightTargetMoved, inFlightTargetMoved * 100.0 / Math.max(1, over)))
    println(String.format("  in flight, aim point still   %d  (%.0f%%)",
        inFlightTargetStill, inFlightTargetStill * 100.0 / Math.max(1, over)))
    println(String.format("  not in flight                %d  (%.0f%%)",
        notInFlight, notInFlight * 100.0 / Math.max(1, over)))
    println()
    println(String.format("worst frame %.1f m/s: %s", worst, worstWhy))
}
