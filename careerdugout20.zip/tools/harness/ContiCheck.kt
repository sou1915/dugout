import com.dugout.career.core.World
import com.dugout.career.sim.Season

/**
 * Who actually gets into the Continental Cup.
 *
 * Qualifiers were taken with `.take(8)` off an ordered list of first divisions.
 * At sixteen countries that was already arbitrary; at sixty it means the same
 * eight countries qualify every season of every career, and the other forty
 * four league nations are decoration. This prints which countries get in and
 * whether that changes when the world does.
 */
fun main(args: Array<String>) {
    val seeds = if (args.isNotEmpty()) args.map { it.toLong() }
    else listOf(20260727L, 5150L, 99001L)

    // Also walk a few home countries, because the tournament is meant to be
    // the manager's own continent and a check that only ever runs from England
    // cannot see that.
    val countries = listOf("ENG", "BRA", "JPN", "MAR", "AUS", "MEX")
    for (seed in seeds) {
        val w = World.build(seed)
        val s = Season(w)
        s.buildCalendar()
        val entrants = s.conti.rounds.first().ties
            .flatMap { listOf(it.homeId, it.awayId) }
            .mapNotNull { w.club(it) }

        // Foreign clubs have a divisionId too, so "has a division" does not
        // mean English; the division's own country is the only honest source.
        val byCountry = entrants.groupingBy { c ->
            w.division(c.divisionId)?.country ?: "??"
        }.eachCount()

        println("seed $seed: ${entrants.size} entrants from ${byCountry.size} countries")
        println("   " + byCountry.entries.sortedByDescending { it.value }
            .joinToString(", ") { "${it.key} x${it.value}" })
        val reps = entrants.map { it.reputation }
        println(String.format("   reputation %d..%d, mean %.1f",
            reps.min(), reps.max(), reps.average()))
        println()
    }

    println("=== the same season from different home countries ===")
    for (code in countries) {
        val w2 = World.build(20260727L)
        w2.playerCountry = code
        val s2 = Season(w2)
        s2.buildCalendar()
        val ent = s2.conti.rounds.first().ties
            .flatMap { listOf(it.homeId, it.awayId) }
            .mapNotNull { w2.club(it) }
        val by = ent.groupingBy { w2.division(it.divisionId)?.country ?: "??" }.eachCount()
        println(String.format("%-4s (%-13s) %2d entrants: %s", code,
            com.dugout.career.core.continentOf(code), ent.size,
            by.entries.sortedByDescending { it.value }.joinToString(", ") { "${it.key} x${it.value}" }))
    }
    println()

    println("=== a whole season of the tournament ===")
    for (code in listOf("ENG", "BRA", "AUS")) playThrough(code)
    println()

    // How many countries could plausibly send somebody?
    val w = World.build(20260727L)
    val tops = w.foreignLeagues.filter { it.tier == 1 }
    println("first divisions in the world: ${tops.size} (plus England)")
    println("of which can now reach the tournament: see the country lists above")
}

/**
 * The bracket has to survive being played. Sixteen entrants means eight ties,
 * then four, two, one — a malformed field would either crash the round
 * advance or quietly leave the cup unfinished at the end of the season.
 */
fun playThrough(code: String) {
    val w = World.build(20260727L)
    w.playerCountry = code
    val s = Season(w)
    s.buildCalendar()
    for (wk in 1..46) { w.week = wk; s.simWeek(wk, -1) }
    val rounds = s.conti.rounds
    println(String.format("%-4s rounds %d: %s | finished %s | winner %s", code,
        rounds.size, rounds.joinToString(" -> ") { it.name + "(" + it.ties.size + ")" },
        s.conti.finished,
        s.conti.rounds.lastOrNull()?.ties?.firstOrNull()?.let { t ->
            w.club(if (t.homeGoals >= t.awayGoals) t.homeId else t.awayId)?.name
        } ?: "-"))
}
