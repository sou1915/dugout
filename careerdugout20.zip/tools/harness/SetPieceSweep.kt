import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- the three set-piece changes, each against a control row.
 *
 * Reports what the viewer sees (men in the box at the instant the ball leaves
 * the flag, keeper's distance from his own goal, seconds the pitch stays frozen
 * after the delivery) alongside what it costs (goals per game, match length),
 * so a picture fix that quietly moved the balance cannot hide.
 *
 * Goals per game is roughly Poisson with mean 2.6, so the standard error is
 * sqrt(2.6/n): at 240 matches that is 0.10, or +/-0.21 at 95%. Do not read a
 * trend smaller than that. Rows share seeds, which makes the comparison paired
 * and rather tighter than the unpaired figure suggests, but not by enough to
 * argue about a tenth of a goal.
 */
private class Row(val label: String) {
    var attBox = 0.0; var defBox = 0.0; var lag = 0.0; var n = 0L
    var frozenAfter = 0.0
    var gkOff = 0.0; var gkN = 0L
    var goals = 0L; var corners = 0L; var matches = 0L
    var realSeconds = 0.0

    fun run(matches: Int, speed: Float) {
        for (i in 0 until matches) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false
            m.speed = speed
            m.start()
            val dt = 1f / 36f
            var fx = 0f; var fy = 0f
            var prevCorners = intArrayOf(m.corners[0], m.corners[1])
            var spotted = false; var watching = false
            var elapsed = 0.0
            var guard = 0
            while (!m.finished && guard++ < 900_000) {
                m.update(dt)
                m.sound.clear()
                elapsed += dt.toDouble()
                /*
                 * Detect the award from corners[], not from the flag moving.
                 * cornerFlagX/Y take exactly four values, so two corners in a
                 * row at the same flag look identical and the second is missed
                 * -- which read the control row's delivery lag as 7.59 s when
                 * CornerStrike, watching corners[], measures 2.38 s.
                 */
                var awarded = false
                for (sIdx in 0..1) if (m.corners[sIdx] > prevCorners[sIdx]) awarded = true
                prevCorners = intArrayOf(m.corners[0], m.corners[1])
                if (awarded) {
                    fx = m.cornerFlagX; fy = m.cornerFlagY
                    spotted = false; watching = true
                    awardedAt = elapsed
                }
                if (watching) {
                    val att = if (fx > 50f) 0 else 1
                    val gk = m.players.firstOrNull {
                        it.onPitch && it.pos == Pos.GK && it.side != att
                    }
                    if (gk != null) {
                        val goalX = if (att == 0) 100f else 0f
                        gkOff += Math.hypot(((goalX - gk.x) * 1.05).toDouble(),
                            ((50f - gk.y) * 0.68).toDouble())
                        gkN++
                    }
                    val away = Math.hypot((m.ball.x - fx).toDouble(), (m.ball.y - fy).toDouble())
                    if (!spotted && away < 3.0) spotted = true
                    if (spotted && away > 8.0) {
                        attBox += m.players.count {
                            it.onPitch && it.pos != Pos.GK && it.side == att &&
                                (if (att == 0) it.x > 83.5f else it.x < 16.5f) &&
                                it.y > 21f && it.y < 79f
                        }
                        defBox += m.players.count {
                            it.onPitch && it.pos != Pos.GK && it.side != att &&
                                (if (att == 0) it.x > 83.5f else it.x < 16.5f) &&
                                it.y > 21f && it.y < 79f
                        }
                        frozenAfter += gateOf(m).toDouble()
                        lag += elapsed - awardedAt
                        n++
                        watching = false; spotted = false
                    }
                }
            }
            goals += m.score[0] + m.score[1]
            corners += m.corners[0] + m.corners[1]
            realSeconds += elapsed
            this.matches++
        }
    }

    private var awardedAt = 0.0

    fun print() {
        println(String.format("%-26s %7.2f %9.2f %9.2f %10.2f %8.1f %8.2f %9.0f",
            label,
            lag / maxOf(1L, n), attBox / maxOf(1L, n), defBox / maxOf(1L, n),
            frozenAfter / maxOf(1L, n), gkOff / maxOf(1L, gkN),
            goals.toDouble() / maxOf(1L, matches), realSeconds / maxOf(1L, matches)))
    }
}

private val gateField = MatchEngine::class.java.getDeclaredField("stagedUntil")
    .also { it.isAccessible = true }

private fun gateOf(m: MatchEngine) = gateField.getFloat(m)

private fun set(timing: Boolean, release: Boolean, keeper: Boolean, hold: Float) {
    MatchEngine.SET_PIECE_TIMING = timing
    MatchEngine.RELEASE_STAGING = release
    MatchEngine.KEEPER_ON_LINE = keeper
    MatchEngine.CORNER_SECONDS = hold
}

fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 60
    val speed = args.getOrNull(1)?.toFloatOrNull() ?: 1f

    println("=== set-piece changes, each against the control ($n matches, speed ${speed}x) ===")
    println(String.format("%-26s %7s %9s %9s %10s %8s %8s %9s",
        "", "deliver", "att box", "def box", "frozen", "GK off", "goals", "match"))
    println(String.format("%-26s %7s %9s %9s %10s %8s %8s %9s",
        "", "lag s", "AT BALL", "AT BALL", "after s", "line m", "per gm", "real s"))

    val rows = listOf(
        Triple("control (all off, hold 8)", listOf(false, false, false), 8.0f),
        Triple("+ timing only", listOf(true, false, false), 8.0f),
        Triple("+ release only", listOf(false, true, false), 8.0f),
        Triple("+ keeper only", listOf(false, false, true), 8.0f),
        Triple("ALL ON, hold 5.0", listOf(true, true, true), 5.0f),
        Triple("ALL ON, hold 6.5", listOf(true, true, true), 6.5f),
        Triple("ALL ON, hold 8.0", listOf(true, true, true), 8.0f)
    )
    for ((label, flags, hold) in rows) {
        set(flags[0], flags[1], flags[2], hold)
        val r = Row(label)
        r.run(n, speed)
        r.print()
    }
    set(true, true, true, 8.0f)
    println()
    println("'deliver lag' is real seconds from the corner being awarded to the")
    println("ball leaving the flag. 'frozen after' is how long updateTargets keeps")
    println("returning early once the ball has gone -- every man held in his")
    println("corner position while play has restarted. SE on goals at $n matches")
    println(String.format("is %.3f, so ignore anything under %.2f.",
        Math.sqrt(2.6 / n), 2 * Math.sqrt(2.6 / n)))
}
