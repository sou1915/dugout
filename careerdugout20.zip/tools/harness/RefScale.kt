import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Does the referee stand the same height as a player at the same depth? */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start(); m.danger = 1f; m.shake = 0f
    for (p in m.players) p.onPitch = false
    val pl = m.players.first { it.side == 0 && it.pos != Pos.GK }
    pl.onPitch = true; pl.action = Act.RUN; pl.speedNow = 0f
    pl.x = 44f; pl.y = 50f; pl.facing = (Math.PI / 2).toFloat()
    m.ball.holder = null; m.ball.x = 10f; m.ball.y = 10f
    m.banner = null; m.celebrateKey = null

    // referee at the same depth, other side of the frame
    m.refX = 56f; m.refY = 50f
    m.refCard = 1
    val withBoth = render(m, 40) { it.followBall = false }
    save(withBoth, "out/refscale.png")
    // Measure by colour in the one frame. Diffing against a frame with the
    // player removed does not work: taking him off the pitch puts him on the
    // substitutes bench and the difference picks him up there instead.
    fun extentOf(x0: Int, x1: Int, test: (Int, Int, Int) -> Boolean): Int {
        var top = -1; var bot = -1
        for (y in 0 until H) for (x in x0 until x1) {
            val c = withBoth.image.getRGB(x, y)
            if (test((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF)) {
                if (top < 0) top = y
                bot = y
            }
        }
        return if (top < 0) 0 else bot - top + 1
    }

    val kit = m.home.primary
    val kr = (kit shr 16) and 0xFF; val kg = (kit shr 8) and 0xFF; val kb = kit and 0xFF
    val playerH = extentOf(0, W / 2) { r, g, b ->
        Math.abs(r - kr) < 40 && Math.abs(g - kg) < 40 && Math.abs(b - kb) < 40
    }
    // the referee is the only near black figure on the grass
    val refH = extentOf(W / 2, W) { r, g, b -> r < 46 && g < 50 && b < 58 }

    println("=== same depth, side by side ===")
    println("player  $playerH px")
    println("referee $refH px")
    println(String.format("referee is %.2fx the player", refH.toDouble() / playerH))
}
