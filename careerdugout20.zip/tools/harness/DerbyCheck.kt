import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Rivalries, and whether a derby is actually different.
 *
 * Two things have to be true. The map has to be sane — everybody has a few
 * rivals rather than none or twenty, same-town clubs always hate each other,
 * and the same world always produces the same list. And the fixture has to
 * feel different without being easier: a derby should be fuller, louder and
 * more bad tempered, and it should NOT quietly hand the home side a goal.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 200
    val w = World.build(20260727L)

    println("=== the map ===")
    val counts = w.clubs.map { w.rivalsFor(it.id).size }
    val none = counts.count { it == 0 }
    println(String.format("clubs %d, mean rivals %.2f, most %d, none at all %d (%.0f%%)",
        w.clubs.size, counts.average(), counts.max(), none, none * 100.0 / w.clubs.size))

    // same-town clubs must always be rivals: that is the one hard rule
    var townPairs = 0; var townMissed = 0
    val byTown = w.clubs.groupBy { it.city }
    for ((_, here) in byTown) {
        if (here.size < 2) continue
        for (i in here.indices) for (j in i + 1 until here.size) {
            townPairs++
            if (!w.areRivals(here[i].id, here[j].id)) townMissed++
        }
    }
    println("same-town pairs $townPairs, of which not rivals $townMissed  " +
            (if (townMissed == 0) "ok" else "FAIL"))

    // symmetry: if a is b's rival, b is a's
    var asym = 0
    for (c in w.clubs) for (r in w.rivalsFor(c.id)) if (!w.areRivals(r.id, c.id)) asym++
    println("one-sided rivalries $asym  " + (if (asym == 0) "ok" else "FAIL"))

    // stable across builds of the same seed
    val w2 = World.build(20260727L)
    val same = w.clubs.all { c ->
        w.rivalsFor(c.id).map { it.id }.toSet() == w2.rivalsFor(c.id).map { it.id }.toSet()
    }
    val w3 = World.build(5150L)
    val differs = w3.clubs.count { c -> w3.rivalsFor(c.id).size != w.rivalsFor(c.id).size }
    println("same seed gives the same rivalries: $same, another seed differs at $differs clubs")

    println()
    println("=== a user club's derbies ===")
    val club = w.club(w.divisions[0].clubIds.first())!!
    println("${club.name} of ${club.city}:")
    for (r in w.rivalsFor(club.id)) {
        println(String.format("   %-28s %-16s rep %d   %s", r.name, r.city, r.reputation,
            w.derbyName(club.id, r.id)))
    }

    println()
    println("=== what a derby actually changes ===")
    val season = Season(w); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    var dN = 0; var oN = 0
    var dAtt = 0L; var oAtt = 0L
    var dCards = 0; var oCards = 0
    var dGoals = 0; var oGoals = 0
    var dHome = 0; var oHome = 0
    for (i in 0 until matches) {
        val f = league[i % league.size]
        val m = MatchEngine(w, season, f)
        m.replaysEnabled = false
        m.speed = 6f
        m.start()
        val derby = m.isDerby
        var guard = 0
        while (!m.finished && guard++ < 300_000) { m.update(1f / 36f); m.sound.clear() }
        val cards = m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]
        val goals = m.score[0] + m.score[1]
        if (derby) {
            dN++; dAtt += m.attendance; dCards += cards; dGoals += goals
            if (m.score[0] > m.score[1]) dHome++
        } else {
            oN++; oAtt += m.attendance; oCards += cards; oGoals += goals
            if (m.score[0] > m.score[1]) oHome++
        }
    }
    if (dN == 0) { println("no derbies in the sample"); return }
    println(String.format("%-10s %5s %10s %8s %8s %8s", "", "games", "crowd", "cards", "goals", "home w"))
    println(String.format("%-10s %5d %10d %8.2f %8.2f %7.0f%%", "derby", dN, dAtt / dN,
        dCards.toDouble() / dN, dGoals.toDouble() / dN, dHome * 100.0 / dN))
    println(String.format("%-10s %5d %10d %8.2f %8.2f %7.0f%%", "ordinary", oN, oAtt / oN,
        oCards.toDouble() / oN, oGoals.toDouble() / oN, oHome * 100.0 / oN))
    println()
    println("a derby should be fuller, more bad tempered, and no easier to win.")

    /*
     * What a derby costs and pays OUTSIDE the ninety minutes. Until now the
     * answer was nothing at all: the result went through applyResult exactly
     * like any other, so a rivalry was a caption on the hub screen. The room
     * and the board now feel one and a half times an ordinary result.
     *
     * Measured by playing the same result into applyResult twice, once as a
     * derby and once not, from an identical starting state, so the difference
     * is the mechanic and nothing else.
     */
    println()
    println("=== what a derby changes off the pitch ===")
    println(String.format("%-12s %12s %12s %12s", "result", "club morale", "player mor.", "board conf."))
    for (label in listOf("win 2-0", "draw 1-1", "lose 0-2")) {
        val (hg, ag) = when (label) {
            "win 2-0" -> 2 to 0
            "draw 1-1" -> 1 to 1
            else -> 0 to 2
        }
        val out = StringBuilder(String.format("%-12s", label))
        for (derby in listOf(false, true)) {
            // a clean world each time, so nothing carries over between runs
            val w2 = World.build(20260727L)
            val s2 = Season(w2); s2.buildCalendar()
            // a fixture whose home side is the user, and which is or is not a
            // derby as required
            val fx = s2.fixtures.firstOrNull {
                it.comp == 0 && w2.areRivals(it.homeId, it.awayId) == derby
            } ?: continue
            val club = w2.club(fx.homeId) ?: continue
            club.isUser = true
            val squad = w2.squadOf(club)
            val m0 = club.morale
            val p0 = squad.map { it.morale }.average()
            val b0 = club.boardConfidence
            s2.applyResult(fx, hg, ag)
            val dm = club.morale - m0
            val dp = w2.squadOf(club).map { it.morale }.average() - p0
            val db = club.boardConfidence - b0
            out.append(String.format("  %+5.1f %+5.1f %+4d %s", dm, dp, db,
                if (derby) "(derby)" else "(ordinary)"))
        }
        println(out.toString())
    }
    println()
    println("the derby row should move further than the ordinary one, and losing")
    println("one should cost the board's confidence where an ordinary loss does not")
}
