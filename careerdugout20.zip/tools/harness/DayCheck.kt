import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Three presses of continue between matches, each with something to read. */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val club = w.club(w.divisions[0].clubIds.first())!!
    val career = Career(w, s)
    career.start(club.id, "A Manager", "ENG")
    career.resetWeekDays()

    println("=== a week between two matches ===")
    var presses = 0
    val startWeek = w.week
    while (!career.onMatchDay && presses < 8) {
        val label = career.dayLabel()
        career.advanceDay()
        presses++
        val b = career.briefing()
        val fresh = career.news.take(3).map { it.text }
        println()
        println("press $presses  ($label)")
        for (t in fresh) println("   \u00B7 $t")
        println("   briefing items: ${b.size}")
    }
    println()
    println("after $presses presses: ${career.dayLabel()}, week $startWeek -> ${w.week}")
    println("next fixture is ${if (s.nextUserFixture() != null) "ready" else "none"}")
}
