import com.dugout.career.sim.MatchEngine
import com.dugout.career.ui.MatchView
import com.dugout.career.ui.lastBallSX
import com.dugout.career.ui.lastBallSY
import android.graphics.Bitmap
import android.graphics.Canvas

/**
 * AUDIT HARNESS -- does the bottom-centre radar sit on top of the football?
 *
 * The radar was originally centred along the bottom edge, was 22% of the width,
 * and covered the ball in every frame of a live match. It was moved to the
 * top-right corner for that reason, and the pixel-art reference puts it back.
 * "The reference does it" is not evidence that it works here: this measures how
 * often the ball actually falls behind it, which is the thing that broke.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 4
    var frames = 0L
    var behind = 0L
    var behindPlate = 0L
    val dt = 1f / 36f
    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val v = MatchView(android.content.Context(), m)
        var g = 0
        while (!m.finished && g++ < 900_000) {
            m.update(dt); m.sound.clear()
            // render every twelfth frame: the camera needs to be eased, and a
            // full-render sweep of a match does not finish
            if (g % 12 != 0) continue
            v.renderAt(c, W, H)
            val bx = lastBallSX
            val by = lastBallSY
            if (bx < 0f) continue
            frames++
            val pad = H * 0.026f
            val rw = W * 0.15f; val rh = rw * 0.64f
            val x0 = (W - rw) / 2f; val y0 = H - pad * 0.5f - rh
            if (bx in x0..(x0 + rw) && by in y0..(y0 + rh)) behind++
            val boxH = H * 0.076f
            val plateW = W * 0.26f
            val pt = H - pad - boxH
            if (by > pt && (bx < pad + plateW || bx > W - pad - plateW)) behindPlate++
        }
    }
    println("=== is the ball hidden behind the HUD? ($matches matches) ===")
    println(String.format("frames sampled              %6d", frames))
    println(String.format("ball behind the RADAR       %6d   %5.2f%%",
        behind, 100.0 * behind / maxOf(1L, frames)))
    println(String.format("ball behind a NAME PLATE    %6d   %5.2f%%",
        behindPlate, 100.0 * behindPlate / maxOf(1L, frames)))
    println()
    println("The original bottom-centre radar covered the ball constantly. If")
    println("either figure is more than about a percent, move it back to the corner.")
}
