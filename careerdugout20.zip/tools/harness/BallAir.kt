import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- how much of the match is the ball IN THE AIR?
 *
 * "The ball keeps flying" is the complaint. PROJECT_STATE records the share of
 * the match spent in the air as having gone from 38% to "normal" without saying
 * what normal measured, so there is no number to check against. This produces
 * one, plus where the height is coming from:
 *
 *   loft is set per delivery. 0 is along the floor. Anything at or above 3.0
 *   is treated as an aerial ball and HEADED on arrival, so the loft
 *   distribution and the header count are the same fact seen twice.
 *
 * A real match: the ball is off the ground for roughly 25-30% of playing time,
 * and most of that is one high ball, not every pass floating.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 15
    val dt = 1f / 36f
    var frames = 0L
    var airborne = 0L
    var high = 0L
    var heightSum = 0.0
    var maxH = 0.0
    var inFlight = 0L
    var atFeet = 0L
    var loose = 0L
    var flightLen = 0.0

    // loft as struck, sampled once per delivery
    var deliveries = 0L
    val loftBuckets = LongArray(6)   // 0, <2, <4, <6, <8, 8+
    var loftSum = 0.0

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var lastT = 1f
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()
            frames++
            val h = m.ball.height.toDouble()
            heightSum += h
            if (h > maxH) maxH = h
            if (h > 0.4) airborne++
            if (h > 1.8) high++
            if (m.ball.t < 1f) inFlight++
            else if (m.ball.holder != null) atFeet++
            else loose++

            // a new delivery started this tick
            if (m.ball.t < 1f && lastT >= 1f) {
                deliveries++
                flightLen += m.ball.duration.toDouble()
                val l = m.ball.loft.toDouble()
                loftSum += l
                val b = when {
                    l < 0.01 -> 0
                    l < 2.0 -> 1
                    l < 4.0 -> 2
                    l < 6.0 -> 3
                    l < 8.0 -> 4
                    else -> 5
                }
                loftBuckets[b]++
            }
            lastT = m.ball.t
        }
    }

    println("=== how much of the match is the ball in the air? ($matches matches) ===")
    println()
    println(String.format("ball off the ground (>0.4 m)   %6.1f%% of all frames",
        100.0 * airborne / maxOf(1L, frames)))
    println(String.format("ball above head height (>1.8 m) %5.1f%% of all frames",
        100.0 * high / maxOf(1L, frames)))
    println(String.format("mean ball height               %6.2f m", heightSum / maxOf(1L, frames)))
    println(String.format("highest it ever got            %6.2f m", maxH))
    println()
    println(String.format("BALL IN FLIGHT                 %6.1f%% of all frames  <- struck, travelling",
        100.0 * inFlight / maxOf(1L, frames)))
    println(String.format("  at a man's feet              %6.1f%%", 100.0 * atFeet / maxOf(1L, frames)))
    println(String.format("  loose, rolling               %6.1f%%", 100.0 * loose / maxOf(1L, frames)))
    println(String.format("mean flight duration           %6.2f s", flightLen / maxOf(1L, deliveries)))
    println()
    println(String.format("deliveries per match           %6.1f", deliveries.toDouble() / matches))
    println(String.format("mean loft as struck            %6.2f", loftSum / maxOf(1L, deliveries)))
    println()
    println("loft as struck, share of deliveries:")
    val names = listOf("along the floor", "under 2", "2 to 4", "4 to 6", "6 to 8", "8 and over")
    for (b in 0 until 6) {
        println(String.format("  %-16s %6.1f%%   %s", names[b],
            100.0 * loftBuckets[b] / maxOf(1L, deliveries),
            if (b >= 2) "<- headed on arrival (loft >= 3.0)" else ""))
    }
    println()
    println("Every delivery at loft 3.0 or more is HEADED by whoever it reaches.")
    println("If that share is large, the match is played in the air, and the")
    println("header count and 'the ball keeps flying' are the same finding.")
}
