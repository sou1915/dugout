import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView

/** How fast the camera actually moves, in pitch units and screen widths a second. */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start()
    val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(Context(), m)
    m.danger = 1f
    repeat(60) { v.renderAt(c, 1280, 720) }

    var prev = v.cameraX()
    var sum = 0.0; var peak = 0.0; var n = 0
    var lagSum = 0.0
    /*
     * Stop at the final whistle.
     *
     * This ran a fixed four thousand frames with no check on m.finished, so
     * once the match ended it went on measuring a frozen ball for thousands of
     * frames. Those frames have a stationary camera and a stationary ball, so
     * they dragged the mean pan speed down towards zero and pinned the lag at
     * whatever the last live frame happened to be: it reported a camera that
     * barely moved and sat twenty units off the ball, neither of which was
     * true of the live match. Same shape of bug as the one in StickCheck.
     */
    var live = 0
    for (i in 0 until 4000) {
        m.update(1f / 36f)
        if (m.finished) break
        live++
        m.danger = 1f
        v.renderAt(c, 1280, 720)
        val now = v.cameraX()
        val dps = Math.abs(now - prev) * 36.0        // pitch units per second
        prev = now
        if (i > 100) {
            sum += dps; n++
            if (dps > peak) peak = dps
            lagSum += Math.abs(m.ball.x - now)
        }
    }
    println("=== camera in the close view ===")
    println(String.format("mean pan speed   %.2f pitch units per second", sum / n))
    println(String.format("fastest          %.2f units per second", peak))
    println(String.format("mean lag behind the ball  %.1f units", lagSum / n))
    println(String.format("live frames measured      %d", live))
    println()
    // a unit is 1.05 m along the pitch; the close view shows about this much
    println("for scale: the close view spans roughly 40 units across the screen,")
    println("so 40 units a second means the whole view sweeps past in one second.")
    println("a broadcast camera pans a good deal slower and lags the ball.")
}
