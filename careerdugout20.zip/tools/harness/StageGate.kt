import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * AUDIT HARNESS -- is the staging gate actually open while a corner is on screen?
 *
 * The rendered corner shows an empty box while the radar shows the players
 * still standing in their formation slots, which is what updateTargets produces
 * when `stagedUntil` has already run out: the early return at the top of the
 * tactical block is skipped and every man is re-pointed at his station.
 *
 * `stagedUntil` is private, so this reads it by reflection. Reported per corner:
 * the gate's value on the tick the CORNER caption first appears, and whether it
 * survives to the delivery.
 */
private val gateField = MatchEngine::class.java.getDeclaredField("stagedUntil")
    .also { it.isAccessible = true }

private fun gate(m: MatchEngine) = gateField.getFloat(m)

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20

    var capN = 0L
    var gateOpenAtCaption = 0L
    var gateAtCaption = 0.0
    var emptyBoxAtCaption = 0L
    var attAtCaption = 0.0
    // the whole caption window
    var windowN = 0L
    var gateShutDuring = 0L
    var frozenAfter = 0.0
    var frozenN = 0L

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val dt = 1f / 36f
        var wasCorner = false
        var sawGateShut = false
        var spotted = false
        var watching = false
        var fx = 0f; var fy = 0f
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()
            val nowCorner = m.sceneTime > 0f && m.scene == Scene.CORNER
            if (m.cornerFlagX != fx || m.cornerFlagY != fy) {
                fx = m.cornerFlagX; fy = m.cornerFlagY; spotted = false; watching = true
            }
            if (watching) {
                val away = Math.hypot((m.ball.x - fx).toDouble(), (m.ball.y - fy).toDouble())
                if (!spotted && away < 3.0) spotted = true
                if (spotted && away > 8.0) {
                    // the ball has gone; how much staging hold is left?
                    frozenAfter += gate(m).toDouble(); frozenN++
                    watching = false; spotted = false
                }
            }
            if (nowCorner && !wasCorner) {
                // caption just came up
                capN++
                val g = gate(m)
                gateAtCaption += g
                if (g > 0f) gateOpenAtCaption++
                val att = if (m.cornerFlagX > 50f) 0 else 1
                val box = m.players.count {
                    it.onPitch && it.pos != Pos.GK && it.side == att &&
                        (if (att == 0) it.x > 83.5f else it.x < 16.5f) && it.y > 21f && it.y < 79f
                }
                attAtCaption += box
                if (box == 0) emptyBoxAtCaption++
                sawGateShut = false
            }
            if (nowCorner && gate(m) <= 0f) sawGateShut = true
            if (wasCorner && !nowCorner) {
                windowN++
                if (sawGateShut) gateShutDuring++
            }
            wasCorner = nowCorner
        }
    }

    println("=== is the staging gate open while the CORNER caption is up? ($matches matches) ===")
    println("stagedUntil is set to CORNER_SECONDS + 1.6 = ${MatchEngine.CORNER_SECONDS + 1.6f} s")
    println("the caption runs for CORNER_SECONDS = ${MatchEngine.CORNER_SECONDS} s")
    println()
    println(String.format("corner captions shown            %6d", capN))
    println(String.format("  gate OPEN when caption appears %6d   %5.1f%%",
        gateOpenAtCaption, 100.0 * gateOpenAtCaption / maxOf(1L, capN)))
    println(String.format("  mean stagedUntil then          %6.2f s", gateAtCaption / maxOf(1L, capN)))
    println(String.format("  attackers in box then          %6.2f", attAtCaption / maxOf(1L, capN)))
    println(String.format("  EMPTY box when caption appears %6d   %5.1f%%",
        emptyBoxAtCaption, 100.0 * emptyBoxAtCaption / maxOf(1L, capN)))
    println(String.format("  gate SHUTS before the caption does %6d / %d   %5.1f%%",
        gateShutDuring, windowN, 100.0 * gateShutDuring / maxOf(1L, windowN)))
    println()
    println(String.format("AFTER the ball leaves the flag the gate stays open %6.2f s",
        frozenAfter / maxOf(1L, frozenN)))
    println("   -- and updateTargets returns early for all of it, so every man")
    println("      holds his corner position while play has already restarted.")
}
