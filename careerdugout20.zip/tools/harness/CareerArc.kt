import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Save
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Start with nothing, take a job, move on. Does the record follow? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val car = Career(w, s)
    w.managerName = "A Manager"

    println("=== out of work ===")
    println("unemployed: ${w.unemployed},  reputation ${w.managerRep}")
    var v = car.vacancies()
    println("jobs he could get: ${v.size}")
    for (j in v.take(4)) {
        println(String.format("   %-26s %-24s rep %2d  %s",
            j.clubName, j.divisionName, j.reputation,
            if (j.approached) "they approached him" else "he would have to apply"))
    }

    // take the best one going
    val first = v.lastOrNull() ?: return
    car.takeJob(first.clubId)
    println()
    println("=== takes the ${first.clubName} job ===")
    println("unemployed now: ${w.unemployed},  club ${w.userClub?.name}")
    println("spells on record: ${w.record.spells.size}")

    // play a season
    for (wk in 1..38) { w.week = wk; s.simWeek(wk, -1) }
    w.record.current?.let {
        it.played = 38; it.won = 20; it.drawn = 9; it.lost = 9
        it.honours.add("Promoted, season ${w.season}")
    }
    w.managerRep = 55
    w.season++

    println()
    println("=== reputation grows, better jobs appear ===")
    v = car.vacancies()
    println("jobs now: ${v.size}, best is ${v.firstOrNull()?.clubName} (rep ${v.firstOrNull()?.reputation})")

    // move to a bigger club
    val better = v.firstOrNull { it.clubId != first.clubId }
    if (better != null) {
        car.takeJob(better.clubId)
        println("moves to ${better.clubName}")
    }

    // and gets sacked
    car.leaveJob(sacked = true)
    println()
    println("=== dismissed ===")
    println("unemployed: ${w.unemployed},  reputation ${w.managerRep}")

    // and it has to survive a save
    val ctx = Context()
    Save.write(ctx, w, s, car)
    val back = Save.read(ctx)!!
    println()
    println(String.format("record survives a save: %d spells -> %d, honours %d -> %d",
        w.record.spells.size, back.world.record.spells.size,
        w.record.totalHonours, back.world.record.totalHonours))
    println(String.format("still unemployed after load: %s", back.world.unemployed))

    println()
    println("=== the CV ===")
    println(w.record.summary())
    for (sp in w.record.spells) {
        println(String.format("   %-24s %-22s P%-4d W%-4d %s",
            sp.clubName, sp.years(w.season), sp.played, sp.won, sp.endingLabel))
        for (h in sp.honours) println("      $h")
    }
}
