import com.dugout.career.core.Rng
import com.dugout.career.core.World

/** Are the badges actually varied, or do they all come out the same? */
fun main() {
    val w = World.build(20260727L)
    val combos = HashMap<String, Int>()
    val shapes = IntArray(8)
    val devices = IntArray(7)
    val charges = IntArray(4)
    for (c in w.clubs) {
        val r = Rng(c.crestSeed.toLong())
        val s = r.i(0, 7); val d = r.i(0, 6); val ch = r.i(0, 3)
        shapes[s]++; devices[d]++; charges[ch]++
        combos["$s-$d-$ch"] = (combos["$s-$d-$ch"] ?: 0) + 1
    }
    println("=== ${w.clubs.size} clubs ===")
    println("distinct shape/device/charge combinations: ${combos.size} of 224 possible")
    println()
    println("shape spread   " + shapes.joinToString(" ") { it.toString().padStart(4) })
    println("device spread  " + devices.joinToString(" ") { it.toString().padStart(4) })
    println("charge spread  " + charges.joinToString(" ") { it.toString().padStart(4) })
    println()
    val top = combos.entries.sortedByDescending { it.value }.take(5)
    println("commonest combinations:")
    for ((k, v) in top) println("  $k used by $v clubs")
    println()
    println("if one shape or device dominates, the seeds are correlated")
}
