import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How the ball is drawn: its size against a man, and whether its shadow parts
 * from it when it is in the air. The shadow separating is the only cue that
 * tells you a ball is off the ground at all.
 */
fun main() {
    fun frame(height: Float, withBall: Boolean): android.graphics.Bitmap {
        val world = World.build(20260727L)
        val season = Season(world); season.buildCalendar()
        val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
        m.start(); m.danger = 1f; m.shake = 0f
        for (p in m.players) p.onPitch = false
        val pl = m.players.first { it.side == 0 && it.pos != Pos.GK }
        pl.onPitch = true; pl.action = Act.RUN; pl.speedNow = 0f
        pl.x = 38f; pl.y = 50f; pl.facing = (Math.PI / 2).toFloat()
        m.ball.holder = null
        m.ball.x = if (withBall) 60f else 500f
        m.ball.y = 50f
        m.ball.height = height
        m.ball.t = 1f
        m.refCard = 0; m.banner = null; m.celebrateKey = null
        return render(m, 40) { it.followBall = false }
    }

    // ball alone: difference between a frame with it and one without
    fun ballBox(height: Float): IntArray {
        val a = frame(height, true)
        val b = frame(height, false)
        var top = -1; var bot = -1; var left = -1; var right = -1
        for (y in 0 until H) for (x in W / 2 until W) {
            val p = a.image.getRGB(x, y); val q = b.image.getRGB(x, y)
            if (maxOf(Math.abs(((p shr 16) and 0xFF) - ((q shr 16) and 0xFF)),
                    Math.abs(((p shr 8) and 0xFF) - ((q shr 8) and 0xFF)),
                    Math.abs((p and 0xFF) - (q and 0xFF))) > 20) {
                if (top < 0) top = y
                bot = y
                if (left < 0 || x < left) left = x
                if (x > right) right = x
            }
        }
        return intArrayOf(left, top, right, bot)
    }

    println("=== the ball as drawn ===")
    println(String.format("%-16s %8s %9s %s", "height", "width", "vertical", "note"))
    for (h in floatArrayOf(0f, 1f, 2.5f, 4f)) {
        val b = ballBox(h)
        val w = b[2] - b[0] + 1
        val v = b[3] - b[1] + 1
        val note = if (v > w * 1.6f) "ball and shadow apart" else "one blob"
        println(String.format("%-16s %6d px %7d px  %s",
            String.format("%.1f units", h), w, v, note))
    }
}
