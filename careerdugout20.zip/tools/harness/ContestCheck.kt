import com.dugout.career.core.Pos
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- is the ball ever CONTESTED in open play?
 *
 * Every measurement in this project so far has asked where men stand. This asks
 * whether they ever touch the ball, which is a different question and the one
 * behind "it lacks something".
 *
 * In a phase-based engine the move is a pre-built sequence of team mates and
 * the outcome is rolled before the ball moves, so a defender has no way to take
 * it: blockerOnLine finds a man standing in the passing lane and the passer
 * simply CLIPS IT OVER HIM. The pass always arrives. Possession only ever
 * changes at the end of a phase, on a roll made before any of it was drawn.
 *
 * Counted per match, over open play only (no set piece on screen):
 *
 *   CLOSE      seconds an opponent spends within 2 m of the ball
 *   LANE       passes with an opponent standing in the line, which are the
 *              passes that get clipped over him
 *   TOUCH      defensive interventions that actually happen: a slide, a man
 *              put on the floor
 *
 * The ratio of the first two to the third is the size of the hole.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    var closeSeconds = 0.0
    var openSeconds = 0.0
    var laneFrames = 0L
    var flightFrames = 0L
    var slides = 0L
    var downs = 0L
    var carrierPressedSeconds = 0.0
    var carrierSeconds = 0.0
    var nearestToBall = 0.0
    var samples = 0L

    val dt = 1f / 36f
    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var wasAct = HashMap<String, Int>()
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()
            // open play only
            if (m.sceneTime > 0f && m.scene != 0 && m.scene != 10 &&
                m.scene != 11 && m.scene != 12 && m.scene != 13) continue
            openSeconds += dt.toDouble()

            val att = m.possessionSide
            val opp = m.players.filter { it.onPitch && it.side != att && it.pos != Pos.GK }
            val dNear = opp.minOfOrNull {
                Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(),
                    ((it.y - m.ball.y) * 0.68).toDouble())
            } ?: 99.0
            nearestToBall += dNear; samples++
            if (dNear < 2.0) closeSeconds += dt.toDouble()

            // the man on the ball, and whether an opponent is on him
            val holder = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
            if (holder != null && holder.pos != Pos.GK) {
                carrierSeconds += dt.toDouble()
                val dh = opp.minOfOrNull {
                    Math.hypot(((it.x - holder.x) * 1.05).toDouble(),
                        ((it.y - holder.y) * 0.68).toDouble())
                } ?: 99.0
                if (dh < 2.0) carrierPressedSeconds += dt.toDouble()
            }

            // in flight, with an opponent inside a metre of where it is going
            if (m.ball.t < 1f) {
                flightFrames++
                if (dNear < 1.5) laneFrames++
            }

            // interventions that actually happened
            for (p in m.players) {
                if (!p.onPitch) continue
                val prev = wasAct[p.key] ?: Act.RUN
                if (prev != p.action) {
                    if (p.action == Act.TACKLE) slides++
                    if (p.action == Act.DOWN) downs++
                }
                wasAct[p.key] = p.action
            }
        }
    }

    fun per(x: Double) = x / matches
    println("=== is the ball ever contested in open play? ($matches matches) ===")
    println()
    println(String.format("open play per match              %8.1f s", per(openSeconds)))
    println(String.format("nearest opponent to the ball     %8.2f m  (mean)",
        nearestToBall / maxOf(1L, samples)))
    println()
    println(String.format("an opponent within 2 m of BALL   %8.1f s per match   %4.1f%% of open play",
        per(closeSeconds), 100.0 * closeSeconds / maxOf(1.0, openSeconds)))
    println(String.format("an opponent within 2 m of the"))
    println(String.format("  man actually carrying it       %8.1f s per match   %4.1f%% of carry time",
        per(carrierPressedSeconds),
        100.0 * carrierPressedSeconds / maxOf(1.0, carrierSeconds)))
    println(String.format("ball in flight within 1.5 m of"))
    println(String.format("  an opponent                    %8.1f%% of flight frames",
        100.0 * laneFrames / maxOf(1L, flightFrames)))
    println()
    println(String.format("DEFENSIVE INTERVENTIONS"))
    println(String.format("  slide tackles                  %8.2f per match", per(slides.toDouble())))
    println(String.format("  men put on the floor           %8.2f per match", per(downs.toDouble())))
    println(String.format("  interceptions                  %8.2f per match   <- none exist", 0.0))
    println(String.format("  blocked passes                 %8.2f per match   <- none exist", 0.0))
    println(String.format("  deflections                    %8.2f per match   <- none exist", 0.0))
    println()
    println("A real match has roughly 20 tackles, 45 interceptions and 15 blocked")
    println("passes. Here a defender in the passing lane is clipped over, every")
    println("time, and possession only changes on a roll made before the ball")
    println("moved. Twenty two men are on the pitch and eleven of them can never")
    println("touch the ball.")
}
