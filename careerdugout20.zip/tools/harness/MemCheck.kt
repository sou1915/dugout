import com.dugout.career.core.World
import com.dugout.career.sim.Season

/** What the world costs in memory. A phone will not give an app much. */
fun main() {
    val rt = Runtime.getRuntime()
    fun used(): Long {
        System.gc(); Thread.sleep(120); System.gc(); Thread.sleep(120)
        return rt.totalMemory() - rt.freeMemory()
    }
    fun mb(b: Long) = b / 1048576.0

    val base = used()
    val w = World.build(20260727L)
    val afterWorld = used()
    com.dugout.career.ui.Face.assignAll(w.players.values)
    val afterFaces = used()
    val s = Season(w)
    s.buildCalendar()
    val afterFixtures = used()

    println("=== memory ===")
    println(String.format("world (%d clubs, %d players)  %6.1f MB",
        w.clubs.size, w.players.size, mb(afterWorld - base)))
    println(String.format("face registry                  %6.1f MB", mb(afterFaces - afterWorld)))
    println(String.format("fixtures (%d)                %6.1f MB",
        s.fixtures.size, mb(afterFixtures - afterFaces)))
    println(String.format("total                          %6.1f MB", mb(afterFixtures - base)))
    println()
    println("An Android app is commonly given 128 to 256 MB before it is killed,")
    println("and the UI, bitmaps and the renderer all come out of the same budget.")
}
