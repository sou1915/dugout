import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season

/**
 * How often anything actually HAPPENS in a match.
 *
 * Posing the figures is worth nothing if the engine never sets the pose. This
 * counts every transition into each action and each scene, per match, so
 * "there is no tackling scene" can be answered with a number rather than an
 * opinion. Real-match reference figures are in the output.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 30
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    val actNames = mapOf(
        Act.TACKLE to "tackle (sliding in)", Act.SHOOT to "shot struck",
        Act.DIVE to "keeper diving", Act.CELEBRATE to "celebrating",
        Act.DRIBBLE to "taking a man on", Act.DOWN to "down injured",
        Act.HEADER to "header"
    )
    val sceneNames = mapOf(
        Scene.CORNER to "corner", Scene.PENALTY to "penalty",
        Scene.FREEKICK to "free kick", Scene.THROW_IN to "throw-in",
        Scene.GOAL_KICK to "goal kick", Scene.KICK_OFF to "kick off",
        Scene.SUBSTITUTION to "substitution"
    )
    val actCount = HashMap<Int, Int>()
    val sceneCount = HashMap<Int, Int>()
    var cards = 0
    var goals = 0
    var woodwork = 0
    var skills = 0

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        val wasAct = HashMap<String, Int>()
        var wasScene = Scene.NONE
        var wasCard = 0
        var wasWood = 0f
        var wasSkill = 0f
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt)
            if (m.finished) break
            for (p in m.players) {
                if (!p.onPitch) continue
                val prev = wasAct[p.key] ?: Act.RUN
                if (p.action != prev && p.action != Act.RUN)
                    actCount[p.action] = (actCount[p.action] ?: 0) + 1
                wasAct[p.key] = p.action
            }
            if (m.scene != wasScene && m.scene != Scene.NONE)
                sceneCount[m.scene] = (sceneCount[m.scene] ?: 0) + 1
            wasScene = m.scene
            if (m.refCard > 0 && wasCard == 0) cards++
            wasCard = m.refCard
            if (m.woodwork > 0f && wasWood <= 0f) woodwork++
            wasWood = m.woodwork
            if (m.skill > 0f && wasSkill <= 0f) skills++
            wasSkill = m.skill
        }
        goals += m.score[0] + m.score[1]
    }

    val n = matches.toDouble()
    println("=== what happens in a match, averaged over $matches ===")
    println()
    println(String.format("%-24s %10s   %s", "player action", "per match", "real football"))
    val realAct = mapOf(
        Act.TACKLE to "~20 tackles, maybe 6 sliding",
        Act.SHOOT to "~25 shots",
        Act.DIVE to "~6 saves needing a dive",
        Act.CELEBRATE to "one a goal",
        Act.DRIBBLE to "~40 take-ons attempted",
        Act.DOWN to "~3 stoppages",
        Act.HEADER to "~40 headers"
    )
    for ((a, label) in actNames)
        println(String.format("%-24s %10.1f   %s", label, (actCount[a] ?: 0) / n, realAct[a] ?: ""))
    println()
    println(String.format("%-24s %10s   %s", "scene", "per match", "real football"))
    val realScene = mapOf(
        Scene.CORNER to "~10", Scene.PENALTY to "~0.25", Scene.FREEKICK to "~28 fouls",
        Scene.THROW_IN to "~40", Scene.GOAL_KICK to "~14", Scene.KICK_OFF to "~4",
        Scene.SUBSTITUTION to "~6"
    )
    for ((s, label) in sceneNames)
        println(String.format("%-24s %10.1f   %s", label, (sceneCount[s] ?: 0) / n, realScene[s] ?: ""))
    println()
    println(String.format("%-24s %10.2f   ~4 bookings", "cards shown", cards / n))
    println(String.format("%-24s %10.2f   ~0.5", "off the woodwork", woodwork / n))
    println(String.format("%-24s %10.2f", "named skill moves", skills / n))
    println(String.format("%-24s %10.2f", "goals", goals / n))
    println()
    println("a zero here is a thing the player will never see, however well it is drawn.")
}
