import com.dugout.career.core.Personalities
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/**
 * Do individual conversations behave like conversations?
 *
 * The thing being tested is not that the code runs. It is that a talk can go
 * badly. A talk that always helps is a button that adds morale, and it would
 * make the whole dressing room system pointless — any unrest could simply be
 * clicked away. So this measures the success rate by personality, checks it
 * varies, and checks that a promise made and not kept costs more than the
 * promise gained.
 */
private fun setup(seed: Long): Triple<World, Season, Career> {
    val w = World.build(seed)
    val club = w.club(w.divisions[0].clubIds.first())!!
    club.isUser = true
    w.userClubId = club.id
    val s = Season(w); s.buildCalendar()
    return Triple(w, s, Career(w, s))
}

fun main() {
    println("=== how each talk lands, by personality ===")
    println("(1000 players each, morale set low so they have something to be unhappy about)")
    println()
    val personalities = listOf("Professional", "Ambitious", "Determined", "Loyal",
        "Temperamental", "Casual", "Model Citizen", "Fickle", "Resolute", "Spirited")

    print(String.format("%-15s", "personality"))
    for (t in Career.Talk.entries) print(String.format("%12s", t.name.take(9)))
    println()

    for (person in personalities) {
        print(String.format("%-15s", person))
        for (talk in Career.Talk.entries) {
            val (w, s, career) = setup(20260727L)
            val club = w.userClub!!
            var good = 0; var n = 0; var net = 0.0
            // walk many players through the same talk, one week each so the
            // "one talk per man per week" guard does not swallow them
            for ((i, id) in w.players.keys.take(1200).withIndex()) {
                val p = w.player(id) ?: continue
                p.clubId = club.id
                p.personality = person
                p.morale = 38.0
                w.week = i + 1
                val r = career.talkTo(p, talk) ?: continue
                n++
                if (r.wentWell) good++
                net += r.moraleAfter - r.moraleBefore
            }
            print(String.format("%9d%% %+.0f", good * 100 / maxOf(1, n), net / maxOf(1, n)))
        }
        println()
    }

    println()
    println("=== a promise kept against a promise broken ===")
    run {
        val (w, _, career) = setup(20260727L)
        val club = w.userClub!!
        // One talk per man per week is enforced, so walk down the squad until
        // a promise lands rather than asking the same player twice.
        var made: Career.TalkResult? = null
        for (p in w.squadOf(club)) {
            p.morale = 40.0
            val r = career.talkTo(p, Career.Talk.PROMISE) ?: continue
            if (r.wentWell) { made = r; break }
        }
        if (made == null) { println("no promise landed across the whole squad"); return@run }
        val p = made.player
        val afterPromise = p.morale
        println(String.format("%s: promise made, morale %.1f, promises open %d",
            p.last, afterPromise, career.promises.size))

        // keep it: he gets his starts
        p.apps += 6
        w.week = 1
        career.advanceWeek()
        println(String.format("kept    -> morale %.1f (%+.1f), open %d, broken %d",
            p.morale, p.morale - afterPromise, career.promises.size, p.brokenPromises))

        // now make another and give him nothing
        p.morale = 60.0
        var second: Career.TalkResult? = null
        for (attempt in 0 until 30) {
            career.advanceWeek()
            val r = career.talkTo(p, Career.Talk.PROMISE) ?: continue
            if (r.wentWell) { second = r; break }
        }
        if (second == null) { println("second promise never landed"); return@run }
        val afterSecond = p.morale
        val appsAt = p.apps
        for (wk in 1..11) career.advanceWeek()
        println(String.format("broken  -> morale %.1f (%+.1f), open %d, broken %d, starts made %d",
            p.morale, p.morale - afterSecond, career.promises.size, p.brokenPromises,
            p.apps - appsAt))
    }

    println("=== one talk per player per week ===")
    run {
        val (w, s, career) = setup(20260727L)
        val p = w.squadOf(w.userClub!!).first()
        val a = career.talkTo(p, Career.Talk.ENCOURAGE)
        val b = career.talkTo(p, Career.Talk.ENCOURAGE)
        println("first talk ${if (a != null) "allowed" else "refused"}, " +
                "second the same week ${if (b == null) "refused" else "ALLOWED - wrong"}")
        w.week++
        for (wk in 1..1) career.advanceWeek()
        val c = career.talkTo(p, Career.Talk.ENCOURAGE)
        println("next week ${if (c != null) "allowed again" else "REFUSED - wrong"}")
    }
}
