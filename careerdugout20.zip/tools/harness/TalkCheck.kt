import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** How much does the commentator actually say, and how loud is it? */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 8
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    var lines = 0; var big = 0; var secs = 0.0
    val sample = ArrayList<String>()
    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false; m.start()
        var g = 0
        while (!m.finished && g++ < 300_000) {
            m.update(1f / 36f); m.sound.clear(); secs += 1.0 / 36.0
            for (sp in m.spoken) {
                lines++
                if (sp.weight >= 0.6f) big++
                if (sample.size < 14 && sp.weight >= 0.4f) sample.add(sp.text)
            }
            m.spoken.clear()
        }
    }
    println(String.format("lines a match        %.1f", lines.toDouble() / matches))
    println(String.format("one every            %.1f seconds", secs / lines))
    println(String.format("of those, big ones   %.1f a match", big.toDouble() / matches))
    println()
    for (t in sample) println("  \"" + t + "\"")
}
