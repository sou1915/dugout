import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * How often is somebody on the floor, and how often is it two men at once?
 *
 * Reported from the device: "when the players pass they slide at the same time".
 * There is no PASS pose in the engine at all — a passer stays in RUN — so
 * whatever is being seen is a genuine slide happening at or near the moment of
 * a pass, and possibly more than one at a time. act() caps the pitch at two men
 * on the floor, which permits exactly the doubled-up slide being described.
 *
 * A real match has 15-20 tackles, of which only about 4-6 are slides, and two
 * men going to ground together is a rarity. This counts:
 *
 *   - how many separate slides and falls a match
 *   - how much of the match has anybody on the floor
 *   - how much has TWO on the floor
 *   - how many slides begin within a moment of a pass being struck
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    args.getOrNull(1)?.toDoubleOrNull()?.let { MatchEngine.SLIDE_REACH_M = it }
    println("slide reach ${MatchEngine.SLIDE_REACH_M} m")
    var slides = 0L
    var falls = 0L
    var framesAny = 0L
    var framesTwo = 0L
    var frames = 0L
    var nearPass = 0L
    var passes = 0L
    var whileFlying = 0L
    var reach = 0.0

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val was = HashMap<String, Int>()
        var sincePass = 999
        var lastT = m.ball.t
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            frames++
            // a pass leaving the boot resets the flight, so t drops
            if (m.ball.t < lastT) { sincePass = 0; passes++ } else sincePass++
            lastT = m.ball.t

            var onFloor = 0
            for (p in m.players) {
                if (!p.onPitch) continue
                val a = p.action
                val down = a == 1 || a == 6      // Act.TACKLE, Act.DOWN
                if (down) onFloor++
                val prev = was[p.key] ?: 0
                if (down && prev != a) {
                    if (a == 1) slides++ else falls++
                    /*
                     * "In the air" is not a safe test. resolvePhase fires the
                     * tackle and restarts the ball in the SAME tick, so by the
                     * time a harness looks, t is always back to 0 and the answer
                     * is always 100% -- which says nothing.
                     *
                     * How far the ball is from the man going to ground does not
                     * depend on that ordering. A tackle is made at the ball; a
                     * man sliding at a ball twenty metres away is sliding at
                     * nothing, and that is what looks absurd on a screen.
                     */
                    val d = Math.hypot(((m.ball.x - p.x) * 1.05).toDouble(),
                                       ((m.ball.y - p.y) * 0.68).toDouble())
                    reach += d
                    if (d > 5.0) whileFlying++
                    // within a third of a second of the ball being struck
                    if (sincePass <= 12) nearPass++
                }
                was[p.key] = a
            }
            if (onFloor >= 1) framesAny++
            if (onFloor >= 2) framesTwo++
        }
    }

    val mm = matches.toDouble()
    println("=== men on the floor, $matches matches ===")
    println(String.format("  slides                        %6.1f a match   (real: 4-6)", slides / mm))
    println(String.format("  falls and fouls               %6.1f a match", falls / mm))
    println(String.format("  starting within 1/3 s of a pass %5.1f a match   (%.0f%% of them)",
        nearPass / mm, 100.0 * nearPass / maxOf(1L, slides + falls)))
    println(String.format("  mean distance to the ball when he goes down %.1f m", reach / maxOf(1L, slides + falls)))
    println(String.format("  going down over 5 m from the ball  %.1f a match (%.0f%% of them)",
        whileFlying / mm, 100.0 * whileFlying / maxOf(1L, slides + falls)))
    println(String.format("  any man on the floor          %6.1f%% of the match", 100.0 * framesAny / frames))
    println(String.format("  TWO men on the floor          %6.1f%% of the match   (real: rare)", 100.0 * framesTwo / frames))
    println(String.format("  passes struck                 %6.1f a match", passes / mm))
    println()
    println("two men going to ground together is a rarity in football. If the")
    println("'two at once' figure is anything but tiny, that is what is being")
    println("seen from the touchline.")
}
