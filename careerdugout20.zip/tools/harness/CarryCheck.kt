import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * Is the ball at the feet of the man who has it?
 *
 * Rendered frames showed the ball drawn several metres away from the player the
 * engine named as its holder. The engine interpolates `ball.x/y` along a pass
 * while the ball is in flight, but once it has arrived (`ball.t >= 1`) nothing
 * moves it again until the next pass leaves. The carrier keeps running and the
 * ball sits on the grass where it landed, so on the screen a man dribbles away
 * from the ball and then a pass fires out of an empty patch of turf.
 *
 * That is the whole of "ball movement is illogical" in one line of missing code.
 * This measures how far apart they get, in metres.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    var n = 0L
    val gaps = ArrayList<Double>()
    var worst = 0.0
    var over2 = 0L
    var over5 = 0L

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            val k = m.ball.holder ?: continue
            if (m.ball.t < 1f) continue          // still in flight, not a carry
            val p = m.players.firstOrNull { it.key == k && it.onPitch } ?: continue
            if (p.pos == Pos.GK) continue        // in his hands, different rules
            val d = Math.hypot(((p.x - m.ball.x) * 1.05).toDouble(),
                               ((p.y - m.ball.y) * 0.68).toDouble())
            gaps.add(d); n++
            if (d > worst) worst = d
            if (d > 2.0) over2++
            if (d > 5.0) over5++
        }
    }

    gaps.sort()
    fun q(f: Double) = if (gaps.isEmpty()) 0.0 else gaps[(gaps.size * f).toInt().coerceAtMost(gaps.size - 1)]
    println("=== how far is the ball from the man carrying it? ===")
    println("$matches matches, $n carrying frames")
    println(String.format("  median %5.2f m", q(0.5)))
    println(String.format("  p90    %5.2f m", q(0.9)))
    println(String.format("  p99    %5.2f m", q(0.99)))
    println(String.format("  worst  %5.2f m", worst))
    println(String.format("  over 2 m  %5.1f%% of carrying frames", 100.0 * over2 / maxOf(1, n)))
    println(String.format("  over 5 m  %5.1f%% of carrying frames", 100.0 * over5 / maxOf(1, n)))
    println()
    println("a man in possession has the ball inside about a metre. Anything past")
    println("two metres is visibly not his, and past five it is a different phase")
    println("of play happening in another part of the pitch.")
}
