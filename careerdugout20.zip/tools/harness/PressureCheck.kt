import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Does the ball go to the man in space?
 *
 * The receiver of every pass was whoever stood nearest a geometric aim point,
 * with no regard for whether a defender was on his shoulder. The pressure layer
 * charges a marked man extra apparent distance, so a free man slightly further
 * away becomes the better pass -- "space first, player second".
 *
 * The thing to measure is not pressure itself but whether the ball ARRIVES
 * anywhere better. Two numbers say it:
 *
 *   - how pressed the receiver is at the moment the pass is played
 *   - how often the receiver is the MOST pressed of the available options
 *
 * Sweeps the weight, since too much of it makes a side pass sideways to whoever
 * is loneliest and never play forward. Pass length and shot count guard that.
 */
private fun run(matches: Int, on: Boolean, weight: Float): String {
    MatchEngine.PRESSURE = on
    MatchEngine.PRESSURE_WEIGHT = weight
    var recvPressure = 0.0
    var teamPressure = 0.0
    var n = 0L
    var passLen = 0.0
    var passN = 0L
    var shots = 0L
    var goals = 0L
    var worstChoice = 0L

    val w = World.build(20260727L)
    val se = Season(w); se.buildCalendar()
    val lg = se.fixtures.filter { it.comp == 0 }
    for (i in 0 until matches) {
        val m = MatchEngine(w, se, lg[i % lg.size])
        m.replaysEnabled = false
        m.start()
        var lastT = m.ball.t
        var lastHolder = m.ball.holder
        var fromX = m.ball.x; var fromY = m.ball.y
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            val px = m.ball.x; val py = m.ball.y
            m.update(1f / 36f)
            m.sound.clear()
            // a fresh strike with a new holder is a pass being played
            if (m.ball.t < lastT && m.ball.holder != null && m.ball.holder != lastHolder) {
                val recv = m.players.firstOrNull { it.key == m.ball.holder && it.onPitch }
                if (recv != null && recv.pos != Pos.GK) {
                    val mates = m.players.filter {
                        it.onPitch && it.side == recv.side && it.pos != Pos.GK && it.key != recv.key
                    }
                    if (mates.isNotEmpty()) {
                        recvPressure += recv.pressure
                        teamPressure += mates.map { it.pressure.toDouble() }.average()
                        if (recv.pressure >= mates.maxOf { it.pressure }) worstChoice++
                        n++
                    }
                }
                passLen += Math.hypot(((m.ball.toX - fromX) * 1.05).toDouble(),
                                      ((m.ball.toY - fromY) * 0.68).toDouble())
                passN++
                fromX = px; fromY = py
            }
            lastT = m.ball.t
            lastHolder = m.ball.holder
        }
        shots += m.shots[0] + m.shots[1]
        goals += m.score[0] + m.score[1]
    }
    val mm = matches.toDouble()
    return String.format("%-8s %-8.1f %11.3f %13.3f %12.1f%% %10.1f m %8.1f %8.2f",
        if (on) "on" else "off", weight,
        recvPressure / maxOf(1L, n), teamPressure / maxOf(1L, n),
        100.0 * worstChoice / maxOf(1L, n),
        passLen / maxOf(1L, passN), shots / mm, goals / mm)
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    println("=== does the ball go to the man in space? ($matches matches each) ===")
    println(String.format("%-8s %-8s %11s %13s %13s %12s %8s %8s",
        "pressure", "weight", "receiver", "team average", "worst choice", "pass", "shots", "goals"))
    println(run(matches, false, 0f))
    for (w in listOf(6f, 12f, 20f)) println(run(matches, true, w))
    MatchEngine.PRESSURE = true
    MatchEngine.PRESSURE_WEIGHT = 12f
    println()
    println("'receiver' is how pressed the man receiving the ball is, 0 to 1, against")
    println("the team average beside it: below it means the ball is finding space.")
    println("'worst choice' is how often the ball went to the MOST marked man on")
    println("the pitch, which no side would ever choose on purpose.")
}
