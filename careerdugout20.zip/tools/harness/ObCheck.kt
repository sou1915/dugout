import com.dugout.career.core.World
import com.dugout.career.sim.*

/** Does the off-ball layer run a match at all, and what are the men doing? */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 6
    for (on in listOf(false, true)) {
        OffBall.ENABLED = on
        val world = World.build(20260727L)
        val season = Season(world); season.buildCalendar()
        val league = season.fixtures.filter { it.comp == 0 }
        var goals = 0; var hung = 0; var mid = 0.0; var n = 0.0
        val jobs = LongArray(OffBall.Job.COUNT)
        val t0 = System.nanoTime()
        for (i in 0 until matches) {
            OffBall.reset()
            val m = MatchEngine(world, season, league[i % league.size])
            m.replaysEnabled = false; m.start()
            var g = 0
            while (!m.finished && g++ < 300_000) {
                m.update(1f / 36f); m.sound.clear()
                if (g % 20 == 0) {
                    val out = m.players.filter { it.onPitch && it.pos != com.dugout.career.core.Pos.GK }
                    for (p in out) jobs[p.job.coerceIn(0, OffBall.Job.COUNT - 1)]++
                    mid += out.count { it.y > 40f && it.y < 60f }.toDouble() / out.size; n++
                }
            }
            if (!m.finished) hung++
            goals += m.score[0] + m.score[1]
        }
        val cpu = (System.nanoTime() - t0) / 1e9 / matches
        println(if (on) "=== OFF-BALL ON ===" else "=== OFF-BALL OFF ===")
        println(String.format("  goals %.2f   hung %d   in middle fifth %.1f%%   cpu %.2fs/match",
            goals.toDouble() / matches, hung, 100.0 * mid / n, cpu))
        if (on) {
            val tot = jobs.sum().toDouble()
            for (j in 0 until OffBall.Job.COUNT)
                if (jobs[j] > 0) println(String.format("    %-14s %5.1f%%",
                    OffBall.Job.LABEL[j], 100.0 * jobs[j] / tot))
        }
    }
}
