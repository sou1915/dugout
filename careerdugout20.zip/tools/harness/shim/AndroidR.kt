@file:Suppress("unused", "ClassName")

package android

/** Only the handful of framework attribute ids the button states use. */
object R {
    object attr {
        const val state_enabled = 16842910
        const val state_pressed = 16842919
        const val state_selected = 16842913
        const val state_focused = 16842908
    }
    object color {
        const val transparent = 17170445
    }
}
