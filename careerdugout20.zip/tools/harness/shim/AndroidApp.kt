@file:Suppress("unused", "UNUSED_PARAMETER")

package android.app

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.Window

open class Activity : Context() {
    open fun onCreate(savedInstanceState: Bundle?) {}
    open fun onPause() {}
    open fun onResume() {}
    open fun onDestroy() {}
    open fun onStop() {}
    open fun onStart() {}
    open fun onBackPressed() {}
    open fun setContentView(v: View?) {}
    open fun finish() {}
    fun runOnUiThread(r: Runnable) = r.run()
    val window: Window = Window()
}
