@file:Suppress("unused", "UNUSED_PARAMETER")

package android.media

class AudioAttributes private constructor() {
    companion object {
        const val USAGE_GAME = 14
        const val USAGE_MEDIA = 1
        const val CONTENT_TYPE_SONIFICATION = 4
        const val CONTENT_TYPE_MUSIC = 2
    }
    class Builder {
        fun setUsage(u: Int): Builder = this
        fun setContentType(t: Int): Builder = this
        fun build(): AudioAttributes = AudioAttributes()
    }
}

class AudioFormat private constructor() {
    companion object {
        const val ENCODING_PCM_16BIT = 2
        const val CHANNEL_OUT_STEREO = 12
        const val CHANNEL_OUT_MONO = 4
    }
    class Builder {
        fun setEncoding(e: Int): Builder = this
        fun setSampleRate(r: Int): Builder = this
        fun setChannelMask(m: Int): Builder = this
        fun build(): AudioFormat = AudioFormat()
    }
}

object AudioManager {
    const val STREAM_MUSIC = 3
}

/** Accepts writes and discards them; the harness never makes a sound. */
class AudioTrack private constructor() {
    companion object {
        const val MODE_STREAM = 1
        const val MODE_STATIC = 0
        fun getMinBufferSize(rate: Int, channels: Int, encoding: Int): Int = 4096
    }
    class Builder {
        fun setAudioAttributes(a: AudioAttributes): Builder = this
        fun setAudioFormat(f: AudioFormat): Builder = this
        fun setBufferSizeInBytes(n: Int): Builder = this
        fun setTransferMode(m: Int): Builder = this
        fun build(): AudioTrack = AudioTrack()
    }
    fun play() {}
    fun pause() {}
    fun stop() {}
    fun flush() {}
    fun release() {}
    fun write(data: ShortArray, offset: Int, size: Int): Int = size
}
