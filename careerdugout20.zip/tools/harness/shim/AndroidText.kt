@file:Suppress("unused")

package android.text

object InputType {
    const val TYPE_CLASS_TEXT = 1
    const val TYPE_TEXT_FLAG_CAP_WORDS = 8192
    const val TYPE_CLASS_NUMBER = 2
    const val TYPE_TEXT_VARIATION_PERSON_NAME = 96
}

object TextUtils {
    enum class TruncateAt { START, MIDDLE, END, MARQUEE }
}
