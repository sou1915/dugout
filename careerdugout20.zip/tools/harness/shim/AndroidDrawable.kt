@file:Suppress("unused", "UNUSED_PARAMETER")

package android.graphics.drawable

open class Drawable {
    open fun setBounds(l: Int, t: Int, r: Int, b: Int) {}
    open var alpha: Int = 255
}

open class ColorDrawable(var color: Int = 0) : Drawable()

open class GradientDrawable(
    var orientation: Orientation = Orientation.TOP_BOTTOM,
    var colors: IntArray? = null
) : Drawable() {
    enum class Orientation { TOP_BOTTOM, LEFT_RIGHT, BL_TR, BR_TL, BOTTOM_TOP, RIGHT_LEFT, TR_BL, TL_BR }
    companion object {
        const val RECTANGLE = 0
        const val OVAL = 1
        const val LINE = 2
        const val RING = 3
    }
    var shape: Int = RECTANGLE
    var cornerRadius: Float = 0f
    var cornerRadii: FloatArray? = null
    fun setColor(c: Int) {}
    fun setStroke(width: Int, color: Int) {}
    fun setSize(w: Int, h: Int) {}
}

open class StateListDrawable : Drawable() {
    fun addState(stateSet: IntArray, drawable: Drawable?) {}
}

open class LayerDrawable(layers: Array<Drawable?>) : Drawable()
