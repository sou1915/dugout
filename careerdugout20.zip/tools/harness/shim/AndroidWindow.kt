@file:Suppress("unused", "UNUSED_PARAMETER")

package android.view

class Window {
    val decorView: View = View(null)
    fun addFlags(f: Int) {}
    fun clearFlags(f: Int) {}
    fun setStatusBarColor(c: Int) {}
    fun setNavigationBarColor(c: Int) {}
}

object WindowManager {
    object LayoutParams {
        const val FLAG_KEEP_SCREEN_ON = 128
        const val FLAG_FULLSCREEN = 1024
    }
}
