@file:Suppress("unused")

package android.content

/**
 * The renderer only holds a Context, but Save writes through one, so the shim
 * gives it a real directory to work in and the save round trip can be tested
 * off the device.
 */
open class Resources {
    val displayMetrics = android.util.DisplayMetrics()
}

open class Context(dir: java.io.File? = null) {
    val resources = Resources()
    val filesDir: java.io.File =
        dir ?: java.io.File(System.getProperty("java.io.tmpdir"), "dugout-save").apply { mkdirs() }
}
