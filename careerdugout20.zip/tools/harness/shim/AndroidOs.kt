@file:Suppress("unused", "UNUSED_PARAMETER")

package android.os

open class Bundle

class Looper {
    companion object {
        private val main = Looper()
        fun getMainLooper(): Looper = main
    }
}

/** Runs nothing; the harness only needs the calls to type check. */
class Handler(looper: Looper? = null) {
    fun post(r: Runnable): Boolean = true
    fun postDelayed(r: Runnable, delayMillis: Long): Boolean = true
    fun removeCallbacks(r: Runnable) {}
    fun removeCallbacksAndMessages(token: Any?) {}
}
