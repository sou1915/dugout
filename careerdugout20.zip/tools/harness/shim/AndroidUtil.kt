@file:Suppress("unused")

package android.util

object TypedValue {
    const val COMPLEX_UNIT_PX = 0
    const val COMPLEX_UNIT_DIP = 1
    const val COMPLEX_UNIT_SP = 2

    fun applyDimension(unit: Int, value: Float, metrics: DisplayMetrics): Float =
        when (unit) {
            COMPLEX_UNIT_DIP -> value * metrics.density
            COMPLEX_UNIT_SP -> value * metrics.scaledDensity
            else -> value
        }
}

class DisplayMetrics {
    @JvmField var density: Float = 2.75f
    @JvmField var scaledDensity: Float = 2.75f
    @JvmField var widthPixels: Int = 2340
    @JvmField var heightPixels: Int = 1080
}
