@file:Suppress("unused", "UNUSED_PARAMETER", "MemberVisibilityCanBePrivate")

package android.widget

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup

open class FrameLayout(context: Context?) : ViewGroup(context) {
    open class LayoutParams(w: Int, h: Int) : ViewGroup.LayoutParams(w, h) {
        @JvmField var gravity: Int = 0
    }
}

open class LinearLayout(context: Context?) : ViewGroup(context) {
    companion object {
        const val HORIZONTAL = 0
        const val VERTICAL = 1
        const val SHOW_DIVIDER_MIDDLE = 2
    }
    var orientation: Int = HORIZONTAL
    var gravity: Int = 0
    var weightSum: Float = 0f
    var dividerDrawable: Drawable? = null
    var showDividers: Int = 0

    open class LayoutParams : ViewGroup.LayoutParams {
        @JvmField var weight: Float = 0f
        @JvmField var gravity: Int = -1
        constructor(w: Int, h: Int) : super(w, h)
        constructor(w: Int, h: Int, weight: Float) : super(w, h) { this.weight = weight }
    }
}

open class ScrollView(context: Context?) : FrameLayout(context) {
    var isFillViewport: Boolean = false
    fun fullScroll(direction: Int) {}
    fun smoothScrollTo(x: Int, y: Int) {}
    fun scrollTo2(x: Int, y: Int) {}
}

open class HorizontalScrollView(context: Context?) : FrameLayout(context) {
    var isFillViewport: Boolean = false
    fun fullScroll(direction: Int) {}
    fun smoothScrollTo(x: Int, y: Int) {}
}

open class TextView(context: Context?) : View(context) {
    // Both spellings: the real widget is a Java class, so Kotlin callers can
    // use `tv.text = x` and `tv.setText(x)` interchangeably. A plain Kotlin
    // property only offers the first, so the accessors are renamed on the JVM
    // side and the familiar methods added back by hand.
    @get:JvmName("textProp") @set:JvmName("textProp")
    var text: CharSequence? = ""
    fun setText(s: CharSequence?) { text = s }
    fun getText(): CharSequence? = text
    @get:JvmName("textSizeProp") @set:JvmName("textSizeProp")
    var textSize: Float = 14f
    fun setTextSize(size: Float) { textSize = size }
    fun getTextSize(): Float = textSize
    var typeface: Typeface? = null
    var gravity: Int = 0
    var maxLines: Int = Int.MAX_VALUE
    var minWidth: Int = 0
    var minHeight: Int = 0
    var maxWidth: Int = Int.MAX_VALUE
    var minLines: Int = 0
    var letterSpacing: Float = 0f
    var isAllCaps: Boolean = false
    var includeFontPadding: Boolean = true
    var ellipsize: TextUtils.TruncateAt? = null
    @get:JvmName("singleLineProp") @set:JvmName("singleLineProp")
    var isSingleLine: Boolean = false
    fun setSingleLine(v: Boolean) { isSingleLine = v }

    fun setTextColor(c: Int) {}
    fun setTextSize(unit: Int, size: Float) { textSize = size }
    fun setTypeface(tf: Typeface?, style: Int = 0) { typeface = tf }
    fun setLineSpacing(add: Float, mult: Float) {}
    fun setCompoundDrawables(l: Drawable?, t: Drawable?, r: Drawable?, b: Drawable?) {}
    fun setShadowLayer(radius: Float, dx: Float, dy: Float, color: Int) {}
}

open class EditText(context: Context?) : TextView(context) {
    @get:JvmName("hintProp") @set:JvmName("hintProp")
    var hint: CharSequence? = ""
    fun setHint(s: CharSequence?) { hint = s }
    fun getHint(): CharSequence? = hint
    var inputType: Int = 0
    fun setSelection(index: Int) {}
    fun setHintTextColor(c: Int) {}
}

open class Button(context: Context?) : TextView(context)
open class ImageView(context: Context?) : View(context) {
    fun setImageDrawable(d: Drawable?) {}
}
