package com.dugout.career.ui

import android.graphics.Typeface

/**
 * The real Theme.kt pulls in the whole Android widget stack. The renderer only
 * reads two things from it, so the off-device harness supplies just those.
 */
object Theme {
    val DISPLAY: Typeface = Typeface.DEFAULT_BOLD
    val RED: Int = 0xFFF87171.toInt()
}
