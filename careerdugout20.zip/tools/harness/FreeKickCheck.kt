import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Do the three free kick routines lead to different matches? */
fun main() {
    val labels = arrayOf("Shoot on sight", "Direct (default)", "Cross into the box")
    println(String.format("%-24s %8s %9s %8s", "routine", "goals", "shots", "on target"))
    for (r in 0..2) {
        var gf = 0; var sh = 0; var ot = 0; var n = 0
        for (seed in 0 until 320) {
            val w = World.build(9000L + seed)
            val s = Season(w); s.buildCalendar()
            val fx = s.fixtures.first { it.comp == 0 }
            w.club(fx.homeId)!!.tactics.freeKickRoutine = r
            val m = MatchEngine(w, s, fx)
            m.replaysEnabled = false
            m.speed = 6f
            m.start()
            var guard = 0
            while (!m.finished && guard++ < 200_000) m.update(1f / 36f)
            gf += m.score[0]; sh += m.shots[0]; ot += m.onTarget[0]; n++
        }
        println(String.format("%-24s %8.2f %9.2f %8.2f", labels[r],
            gf.toDouble() / n, sh.toDouble() / n, ot.toDouble() / n))
    }
}
