import com.dugout.career.core.CONTINENTS
import com.dugout.career.core.CONTINENT_OF
import com.dugout.career.core.FOREIGN_CODES
import com.dugout.career.core.LEAGUE_NAMES
import com.dugout.career.core.Names
import com.dugout.career.core.World
import com.dugout.career.core.clubsPerLeagueOf
import com.dugout.career.core.continentOf
import com.dugout.career.core.tiersOf

/**
 * The club picker groups by continent and then by country. A country missing
 * from CONTINENT_OF does not fail, it silently defaults to Europe, so the only
 * way to know the map is complete is to check it. Same for LEAGUE_NAMES: a
 * country without an entry gets divisions called First, Second and Third.
 */
fun main() {
    val w = World.build(20260727L)
    val playable = w.playableCountries()
    println("playable countries: ${playable.size}")

    val missingCont = playable.filterNot { CONTINENT_OF.containsKey(it) }
    val missingNames = FOREIGN_CODES.filterNot { LEAGUE_NAMES.containsKey(it) }
    val missingNation = playable.filter { code -> Names.byCode(code).code != code }
    println("no continent mapping : ${missingCont.ifEmpty { listOf("none") }}")
    println("no league names      : ${missingNames.ifEmpty { listOf("none") }}")
    println("no name pool         : ${missingNation.ifEmpty { listOf("none") }}")

    var clubs = 100
    println()
    for (cont in CONTINENTS) {
        val here = playable.filter { continentOf(it) == cont }
        if (here.isEmpty()) { println("$cont: EMPTY - it would not appear in the picker"); continue }
        println(String.format("%-15s %2d countries", cont, here.size))
        for (code in here) {
            if (code == "ENG") continue
            clubs += tiersOf(code) * clubsPerLeagueOf(code)
            val d = w.pyramidOf(code)
            val bad = d.size != tiersOf(code) ||
                    d.any { (w.division(it.id)?.clubIds?.size ?: 0) != clubsPerLeagueOf(code) }
            println(String.format("    %-4s %-26s %d x %-2d  %s%s",
                code, Names.byCode(code).label, tiersOf(code), clubsPerLeagueOf(code),
                Names.byCode(code).flag, if (bad) "   MISMATCH" else ""))
        }
    }
    println()
    println("clubs implied by the shape table: $clubs, world has ${w.clubs.size}")
}
