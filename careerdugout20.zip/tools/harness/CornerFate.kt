import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * AUDIT HARNESS -- what happens to a corner after it is awarded?
 *
 * There are two places a corner is awarded. resolvePhase's OUT_CORNER stages it
 * and books the delivery through shootAfterScene. attemptShot's save path also
 * increments corners[att] and calls stageCorner -- and then hands possession to
 * the side that CONCEDED, with flipLater(def, 0.5). Nothing ever delivers it.
 *
 * Classifies every corner in a match as
 *   TAKEN     the awarding side registered a shot before losing the ball
 *   ABANDONED possession went to the other side with no shot struck
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    var taken = 0L; var abandoned = 0L
    var abandonedBallAtFlag = 0L
    var capShown = 0L

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val dt = 1f / 36f
        var prevShots = intArrayOf(m.shots[0], m.shots[1])
        var prevCorners = intArrayOf(m.corners[0], m.corners[1])
        var pendingAtt = -1
        var wasCorner = false
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()

            // a new corner supersedes any still-unresolved one
            for (s in 0..1) if (m.corners[s] > prevCorners[s]) {
                if (pendingAtt >= 0) abandoned++
                pendingAtt = s
            }
            prevCorners = intArrayOf(m.corners[0], m.corners[1])

            if (pendingAtt >= 0) {
                if (m.shots[pendingAtt] > prevShots[pendingAtt]) {
                    taken++
                    pendingAtt = -1
                } else if (m.possessionSide != pendingAtt && m.ball.holder != null) {
                    // the other side is on the ball and no corner was ever struck
                    abandoned++
                    val goalX = if (pendingAtt == 0) 100f else 0f
                    if (Math.abs(m.ball.x - goalX) < 12f &&
                        (m.ball.y < 12f || m.ball.y > 88f)) abandonedBallAtFlag++
                    pendingAtt = -1
                }
            }
            prevShots = intArrayOf(m.shots[0], m.shots[1])

            val nowCorner = m.sceneTime > 0f && m.scene == Scene.CORNER
            if (nowCorner && !wasCorner) capShown++
            wasCorner = nowCorner
        }
    }
    val n = taken + abandoned
    println("=== the fate of a corner ($matches matches) ===")
    println(String.format("corners awarded      %6.2f per match", n.toDouble() / matches))
    println(String.format("  taken (a shot)     %6.2f per match   %5.1f%%",
        taken.toDouble() / matches, 100.0 * taken / maxOf(1L, n)))
    println(String.format("  ABANDONED          %6.2f per match   %5.1f%%",
        abandoned.toDouble() / matches, 100.0 * abandoned / maxOf(1L, n)))
    println(String.format("    of those, ball still at the flag when the other side took over: %d",
        abandonedBallAtFlag))
    println(String.format("CORNER caption shown %6.2f per match", capShown.toDouble() / matches))
    println()
    println("An abandoned corner is staged, captioned CORNER, has the ball placed")
    println("on the flag -- and is then played out by the side that conceded it.")
}
