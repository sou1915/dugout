import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season

/**
 * CAN THE MANAGER SEE HIS OWN CORNER INSTRUCTION?
 *
 * The corner routine used to choose who the ball was aimed at and what the
 * chance was worth, and move nobody: four settings, one arrangement. So the
 * only honest test of engine v4's "a set piece is a play" is whether the four
 * routines and the three commitment settings put men in DIFFERENT PLACES.
 *
 * Sampled at the instant the delivery is struck, over both sides:
 *   box      men inside the penalty area
 *   near     men within 8 m of the near post
 *   far      men within 8 m of the far post
 *   short    men within 12 m of the corner flag
 *   edge     men just outside the area
 *   back     men still in their own half
 */
private fun measure(routine: Int, men: Int, matches: Int): DoubleArray {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    val acc = DoubleArray(6)
    var n = 0
    for (i in 0 until matches) {
        val fx = league[i % league.size]
        world.club(fx.homeId)?.tactics?.let { it.cornerRoutine = routine; it.cornerMen = men }
        world.club(fx.awayId)?.tactics?.let { it.cornerRoutine = routine; it.cornerMen = men }
        val m = MatchEngine(world, season, fx)
        m.replaysEnabled = false
        m.start()
        var wasCorner = false
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt); m.sound.clear()
            if (m.finished) break
            val corner = m.scene == Scene.CORNER && m.sceneTime > 0f
            // the frame the corner ends is the frame it is delivered
            if (wasCorner && !corner) {
                val goalX = if (m.cornerFlagX > 50f) 100f else 0f
                val att = if (goalX > 50f) 0 else 1
                val toMid = if (m.cornerFlagY < 50f) 1f else -1f
                val nearY = 50f - toMid * 4.6f
                val farY = 50f + toMid * 4.6f
                val on = m.players.filter { it.onPitch && it.side == att && it.pos != Pos.GK }
                fun md(px: Float, py: Float, qx: Float, qy: Float) =
                    Math.hypot(((px - qx) * 1.05).toDouble(), ((py - qy) * 0.68).toDouble())
                acc[0] += on.count {
                    (if (goalX > 50f) it.x > 83f else it.x < 17f) && it.y > 21f && it.y < 79f }
                acc[1] += on.count { md(it.x, it.y, goalX, nearY) < 8.0 }
                acc[2] += on.count { md(it.x, it.y, goalX, farY) < 8.0 }
                acc[3] += on.count { md(it.x, it.y, m.cornerFlagX, m.cornerFlagY) < 12.0 }
                acc[4] += on.count {
                    val d = Math.abs(it.x - goalX) * 1.05
                    d > 17.0 && d < 26.0 }
                acc[5] += on.count { if (goalX > 50f) it.x < 50f else it.x > 50f }
                n++
            }
            wasCorner = corner
        }
    }
    if (n == 0) return acc
    for (i in acc.indices) acc[i] /= n
    return acc
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 6
    val routines = arrayOf("near post", "far post", "work it short", "edge of the box")
    println("=== where the attacking side stands when the corner is struck ===")
    println("    $matches matches per row, both sides set the same way")
    println()
    println(String.format("  %-18s %6s %6s %6s %6s %6s %6s",
        "routine", "box", "near", "far", "short", "edge", "back"))
    // Tactics.cornerRoutine is 0 near, 1 far, 2 short, 3 edge
    for (r in 0..3) {
        val a = measure(r, 1, matches)
        println(String.format("  %-18s %6.1f %6.1f %6.1f %6.1f %6.1f %6.1f",
            routines[r], a[0], a[1], a[2], a[3], a[4], a[5]))
    }
    println()
    println(String.format("  %-18s %6s %6s %6s %6s %6s %6s",
        "men up", "box", "near", "far", "short", "edge", "back"))
    for ((i, label) in arrayOf("keep men back", "normal", "everyone up").withIndex()) {
        val a = measure(1, i, matches)
        println(String.format("  %-18s %6.1f %6.1f %6.1f %6.1f %6.1f %6.1f",
            label, a[0], a[1], a[2], a[3], a[4], a[5]))
    }
    println()
    println("Four identical rows would mean the manager cannot see his own")
    println("instruction, which is what this measured before engine v4.")
}
