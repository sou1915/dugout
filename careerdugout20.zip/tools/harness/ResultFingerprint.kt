import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * A checksum of what the simulation DECIDED, so a change meant to be purely
 * cosmetic can be proved to be purely cosmetic.
 *
 * Aggregate balance is too blunt for this. Goals per game has a standard error
 * of 0.03 even at 9,000 matches, so a change that quietly moved one result in
 * fifty would hide inside it. This prints a hash of every score, every shot
 * count and every card in a run: if a change is really only on the cosmetic
 * stream, the hash must come back BYTE IDENTICAL, not merely similar.
 *
 * Why that is a meaningful test here: the engine has two random streams. `rng`
 * decides outcomes, `sfxRng` decides presentation. Drawing from sfxRng cannot
 * disturb rng. But POSITIONS feed the outcome model — nextMan picks the next
 * man in a move by distance, so whoever is standing nearby ends up shooting —
 * which means any cosmetic act that stops a player moving (TACKLE, DOWN and
 * DIVE all do) leaks into the result after all. This harness is what tells the
 * difference between the two kinds of "cosmetic".
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 200
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L
    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }

    var hash = 1469598103934665603L          // FNV-1a 64
    fun mix(v: Long) {
        hash = hash xor v
        hash *= 1099511628211L
    }

    var goals = 0; var shots = 0; var cards = 0; var corners = 0
    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.speed = 6f
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 200_000) {
            m.update(1f / 30f)
            if (!m.running && !m.finished) m.start()
            m.sound.clear()
        }
        mix(m.score[0].toLong()); mix(m.score[1].toLong())
        mix(m.shots[0].toLong()); mix(m.shots[1].toLong())
        mix(m.onTarget[0].toLong()); mix(m.onTarget[1].toLong())
        mix((m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]).toLong())
        mix(m.corners[0].toLong()); mix(m.corners[1].toLong())
        goals += m.score[0] + m.score[1]
        shots += m.shots[0] + m.shots[1]
        cards += m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]
        corners += m.corners[0] + m.corners[1]
    }
    val n = matches.toDouble()
    println("=== result fingerprint: $matches matches, world $worldSeed ===")
    println(String.format("goals %.3f   shots %.2f   cards %.3f   corners %.2f",
        goals / n, shots / n, cards / n, corners / n))
    println(String.format("FINGERPRINT %016x", hash))
    println()
    println("a change on the cosmetic stream alone must leave this identical.")
}
