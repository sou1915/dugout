import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * LOOK AT A CROSS.
 *
 * MatchFilm samples every Nth frame of a match, which almost never lands on the
 * moment that matters. Player Jobs exist for one picture: a ball swung into the
 * area with bodies attacking it. This waits for a CROSS pattern to reach the
 * final third and photographs THAT, so the claim "jobs put men in the box" can
 * be looked at instead of only counted.
 *
 * Set the third argument to "nojobs" for the before picture.
 *
 *   java -cp build/cross.jar CrossFilmKt [shots] [seed] [nojobs]
 */
fun main(args: Array<String>) {
    val want = args.firstOrNull()?.toIntOrNull() ?: 6
    val seed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L
    val jobs = args.getOrNull(2) != "nojobs"
    MatchEngine.JOBS = jobs
    val tag = if (jobs) "jobs" else "nojobs"

    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val closeField = MatchView::class.java.getDeclaredField("closeUp")
    closeField.isAccessible = true

    File("out/cross").mkdirs()
    println("=== crosses reaching the final third ($tag) ===")
    println(String.format("%-16s %-6s %-14s %s", "file", "min", "ball", "who is in the area"))

    var taken = 0
    var match = 0
    while (taken < want && match < 40) {
        val m = newEngine(seed + match * 7919L)
        m.replaysEnabled = false
        m.start()
        val v = MatchView(android.content.Context(), m)
        var guard = 0
        var cooldown = 0
        while (!m.finished && taken < want && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            // The camera eases toward the ball a little on every render, so it
            // MUST be rendered every frame. Capturing only at the interesting
            // moment leaves the camera wherever it started and photographs the
            // halfway line while the ball is in the corner — which is exactly
            // what the first version of this harness did, and it looked like a
            // camera bug rather than a harness bug.
            closeField.setFloat(v, 1f)
            v.renderAt(c, W, H)
            if (cooldown > 0) { cooldown--; continue }
            if (m.phasePattern != MatchEngine.PAT_CROSS) continue
            // the ball has to have actually got there
            val inFinal = m.ball.x > 78f || m.ball.x < 22f
            if (!inFinal) continue

            taken++
            cooldown = 900   // don't photograph the same cross twenty times
            val name = String.format("out/cross/%s-%02d.png", tag, taken)
            stampFrame(c, W.toFloat(), H.toFloat())
            ImageIO.write(bmp.image, "png", File(name))

            val toLeft = m.ball.x < 50f
            val att = if (toLeft) 1 else 0
            val boxMen = m.players.filter {
                it.onPitch && it.pos != Pos.GK &&
                (if (toLeft) it.x < 16.5f else it.x > 83.5f) && it.y > 21f && it.y < 79f
            }
            fun meanX(s: Int) = m.players.filter { it.onPitch && it.side == s && it.pos != Pos.GK }
                .map { it.x }.average()
            println(String.format(
                "%-16s %-6.0f %-14s box %d att %d def | poss %d, att side %d | mean x  home %.0f away %.0f",
                name.substringAfterLast('/'), m.clock,
                String.format("(%.0f,%.0f)", m.ball.x, m.ball.y),
                boxMen.count { it.side == att }, boxMen.count { it.side != att },
                m.possessionSide, att, meanX(0), meanX(1)))
        }
        match++
    }
    MatchEngine.JOBS = true
    println()
    println("written to out/cross/. A cross with nobody attacking it is the bug.")
}
