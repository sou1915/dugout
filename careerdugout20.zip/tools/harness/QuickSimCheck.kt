import com.dugout.career.core.Rng
import com.dugout.career.core.World
import com.dugout.career.sim.Season

/** The quick simulation's own distribution, as the reference the live engine should meet. */
fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 4000
    val world = World.build(20260727L)
    val season = Season(world)
    season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val rng = Rng(12345L)
    var g = 0; var h = 0; var d = 0; var a = 0
    for (i in 0 until n) {
        val r = season.quickSim(league[i % league.size], rng)
        g += r.homeGoals + r.awayGoals
        when {
            r.homeGoals > r.awayGoals -> h++
            r.homeGoals == r.awayGoals -> d++
            else -> a++
        }
    }
    val nn = n.toDouble()
    println(String.format("quickSim over %d matches:", n))
    println(String.format("  goals per game  %.2f", g / nn))
    println(String.format("  home %.1f%%  draw %.1f%%  away %.1f%%", h*100/nn, d*100/nn, a*100/nn))
}
