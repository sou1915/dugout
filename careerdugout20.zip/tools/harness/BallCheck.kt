import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Ball speed and flight height in real units, to compare against a real match.
 *
 * This ran ONE match. Its figures — 21.4 m/s mean, 41.8 peak, 5.0 m high,
 * airborne 17-18% — were quoted in the brief as if they were properties of the
 * game. A single match is a few thousand frames of one fixture between two
 * particular sides, and the peak especially is an extreme value that moves a
 * long way match to match. It now runs 40 and prints how many.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L

    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var sum = 0.0; var n = 0; var peak = 0.0
    var airborne = 0; var total = 0
    var maxH = 0.0
    val peaksPerMatch = ArrayList<Double>()
    val heightsPerMatch = ArrayList<Double>()

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var px = m.ball.x; var py = m.ball.y
        var pfx = m.ball.fromX; var pfy = m.ball.fromY
        var pt = m.ball.t
        var matchPeak = 0.0; var matchHigh = 0.0
        var i = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt)
            if (m.finished) break
            val dx = (m.ball.x - px) * 1.05
            val dy = (m.ball.y - py) * 0.68
            val mps = Math.sqrt(dx * dx + dy * dy) / dt
            // A restart repositions the ball, and the old filter — "not in
            // flight and moving faster than 25" — missed every reposition that
            // had a new delivery struck in the SAME update, which is most of
            // them: the ball off the woodwork is placed on the frame, then the
            // goal kick is rolled out, and the frame reads as 3,000 m/s of
            // flight. That is where a peak of 181 m/s came from against a
            // flight model that cannot exceed 40.3. A frame is only a flight
            // frame if it is the SAME flight as the one before it: same origin,
            // and t moved forward.
            val sameFlight = m.ball.fromX == pfx && m.ball.fromY == pfy && m.ball.t > pt
            px = m.ball.x; py = m.ball.y
            pfx = m.ball.fromX; pfy = m.ball.fromY
            pt = m.ball.t
            i++
            if (i <= 200) continue
            // the share of the match the ball spends off the grass is about
            // every frame of it, flight or not
            total++
            if (m.ball.height > 0.05f) {
                airborne++
                // height is in pitch units on the short axis
                val h = m.ball.height * 0.68
                if (h > maxH) maxH = h
                if (h > matchHigh) matchHigh = h
            }
            // speed, though, is only meaningful while it is travelling
            if (sameFlight && mps > 0.4) {
                sum += mps; n++
                if (mps > peak) peak = mps
                if (mps > matchPeak) matchPeak = mps
            }
        }
        peaksPerMatch.add(matchPeak)
        heightsPerMatch.add(matchHigh)
    }

    println("=== ball: $matches matches, $total frames after warm-up ===")
    println(String.format("mean speed while moving   %.1f m/s   (%d moving frames)", sum / n, n))
    println(String.format("fastest in any match      %.1f m/s", peak))
    println(String.format("fastest in a match        %.1f m/s on average, %.1f at the quietest",
        peaksPerMatch.average(), peaksPerMatch.min()))
    println(String.format("highest off the turf      %.1f m  (per match: %.1f m on average)",
        maxH, heightsPerMatch.average()))
    println(String.format("share of time airborne    %.0f%%", airborne * 100.0 / total))
    println()
    println("real football: a firm pass is 15-25 m/s, a hard shot 25-35 m/s,")
    println("and the ball is on the grass for most of a match.")
}
