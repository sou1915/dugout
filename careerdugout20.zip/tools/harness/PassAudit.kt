import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Pass geometry, measured against the engine's own pass counter.
 *
 * WHY THIS EXISTS. `PassCheck` and `PassBig` both spotted a new delivery with
 * the edge test `!wasFlying && ball.t < 1f`: the ball was not in flight last
 * frame and is in flight now. That test needs a frame with the ball at rest
 * BETWEEN two passes, and in this engine there usually is not one. A phase
 * steps on a match-minute timer while the ball flies in real seconds, so the
 * next pass is struck while the last one is still travelling and the edge
 * never appears. Measured here: the engine strikes 192 passes a match and the
 * edge test saw 14% of them, and what it did see was weighted toward the
 * opening ball of a move, which is struck from a standing restart into space
 * and is one of the longer balls in football. That is where "mean pass 19.6 m
 * against a real 18" came from. The true figure is 24.6 m.
 *
 * This counts a pass when the engine counts one (`passesTotal`) and takes the
 * geometry from `ball.fromX/fromY -> ball.toX/toY`, which moveBallTo has just
 * set, so the origin is exact rather than sampled a frame late.
 *
 * Runs at speed 1. At speed 4 several phase steps land inside one update and
 * the harness cannot see the ones in between; that is reported as `collapsed`
 * rather than quietly dropped.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L
    // finer than the 36 the game renders at only to prove the sample is not
    // biased by the passes that collapse into a single update; the geometry
    // must not move when the tick shrinks
    val fps = args.getOrNull(2)?.toIntOrNull() ?: 36

    var enginePasses = 0
    var seen = 0
    var collapsed = 0
    var oldRule = 0
    var fwd = 0; var side = 0; var back = 0
    val lens = ArrayList<Double>()
    val speeds = ArrayList<Double>()
    var opening = 0
    val openLens = ArrayList<Double>()

    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var prevPasses = 0
        var wasFlying = false
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / fps)
            if (m.finished) break

            val now = m.passesTotal[0] + m.passesTotal[1]
            val struck = now - prevPasses
            prevPasses = now
            if (struck > 0) {
                enginePasses += struck
                // more than one phase step inside a single update: only the last
                // delivery is still on the ball, the rest are already gone
                if (struck > 1) collapsed += struck - 1
                val dx = (m.ball.toX - m.ball.fromX) * 1.05
                val dy = (m.ball.toY - m.ball.fromY) * 0.68
                val len = Math.sqrt(dx * dx + dy * dy)
                seen++
                lens.add(len)
                speeds.add(len / m.ball.duration)
                if (m.phaseStepPublic <= 1) { opening++; openLens.add(len) }
                // forward is toward the goal the side in possession attacks
                val toGoal = if (m.possessionSide == 0) dx else -dx
                when {
                    toGoal > len * 0.35 -> fwd++
                    toGoal < -len * 0.35 -> back++
                    else -> side++
                }
            }
            // the rule the old harnesses used, counted alongside for comparison
            if (!wasFlying && m.ball.t < 1f && m.ball.holder != null) {
                val dx = (m.ball.toX - m.ball.fromX) * 1.05
                val dy = (m.ball.toY - m.ball.fromY) * 0.68
                if (Math.sqrt(dx * dx + dy * dy) > 1.5) oldRule++
            }
            wasFlying = m.ball.t < 1f
        }
    }

    val n = lens.size
    println("=== passes: $matches matches, world seed $worldSeed, $fps fps ===")
    println(String.format("engine struck        %d  (%.0f a match)", enginePasses, enginePasses.toDouble() / matches))
    println(String.format("measured here        %d  (%.0f%% of them)", n, n * 100.0 / enginePasses))
    println(String.format("collapsed into another update  %d", collapsed))
    println(String.format("the old edge test would have seen  %d  (%.0f%% of them)",
        oldRule, oldRule * 100.0 / enginePasses))
    println()
    println(String.format("mean %.1f m   median %.1f m   mean delivery speed %.1f m/s",
        lens.average(), lens.sorted()[n / 2], speeds.average()))
    println(String.format("under 10 m %.0f%%   10-25 m %.0f%%   25-40 m %.0f%%   over 40 m %.0f%%",
        lens.count { it < 10 } * 100.0 / n, lens.count { it in 10.0..25.0 } * 100.0 / n,
        lens.count { it in 25.0..40.0 } * 100.0 / n, lens.count { it > 40 } * 100.0 / n))
    println(String.format("forward %.0f%%   sideways %.0f%%   backward %.0f%%",
        fwd * 100.0 / n, side * 100.0 / n, back * 100.0 / n))
    if (openLens.isNotEmpty())
        println(String.format("opening ball of a move: %d, mean %.1f m  (the rest: %d, mean %.1f m)",
            opening, openLens.average(), n - opening,
            (lens.sum() - openLens.sum()) / Math.max(1, n - opening)))
    println()
    println("real football: mean about 18 m, roughly 45 forward / 35 side / 20 back,")
    println("a firm pass travels 12-20 m/s")
}
