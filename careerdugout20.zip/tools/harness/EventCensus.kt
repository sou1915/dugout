import com.dugout.career.core.World
import com.dugout.career.sim.Ev4
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Ref
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season

/**
 * WALK THE WHOLE TABLE AND PRINT THE ZEROES.
 *
 * This is the gate the event tree exists for. `AliveCensus` counts the dozen
 * things somebody thought to count; this counts **everything a football match
 * contains**, because the list is now written down in one place.
 *
 * The owner has said several times that there is nothing happening in the
 * simulation, and each time it took weeks to turn that into a defect anybody
 * could work on. With this it takes a minute: the rows that read 0.00 are the
 * answer, each one a named job, and the rows that read something are proof that
 * part of the argument is already done.
 *
 * Three defects in this audit were correct code that nothing reached --
 * `v2Defend`, `CHANCE_QUALITY`, the skill moves. Every one of them would have
 * been a zero in this column on the day it was introduced.
 *
 *   java -cp build/h.jar EventCensusKt [matches]
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20

    val bad = Ev4.selfCheck()
    if (bad != "ok") { println("TABLE BROKEN: $bad"); return }

    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    val total = LongArray(Ev4.COUNT)
    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) { m.update(dt); m.sound.clear() }
        for (e in 0 until Ev4.COUNT) total[e] += m.evCount[e]
    }

    val groups = arrayOf(
        "ON THE BALL" to 0, "PASSING" to 13, "SHOOTING" to 22, "GOALKEEPING" to 36,
        "DEFENDING" to 46, "FOULS AND DISCIPLINE" to 56, "SET PIECES" to 67,
        "PHYSICAL AND MANAGEMENT" to 78, "THE MATCH ITSELF" to 86)

    println("=== every event a football match contains, over $matches matches ===")
    println()
    var zeroes = 0
    for (g in groups.indices) {
        val from = groups[g].second
        val to = if (g + 1 < groups.size) groups[g + 1].second else Ev4.COUNT
        println("  ${groups[g].first}")
        for (e in from until to) {
            val per = total[e].toDouble() / matches
            if (per <= 0.0) zeroes++
            val sh = Ev4.SHOWN[e]
            val shows = buildString {
                if (sh.scene != Scene.NONE) append(Scene.LABEL[sh.scene].ifEmpty { "scene" })
                if (sh.pose >= 0) { if (isNotEmpty()) append(" + "); append("pose") }
                if (sh.ref != Ref.NONE) { if (isNotEmpty()) append(" + "); append(Ref.LABEL[sh.ref]) }
                if (isEmpty()) append("-")
            }
            println(String.format("    %-26s %7.2f   %s%s",
                Ev4.NAME[e], per, shows, if (per <= 0.0) "        <- NEVER HAPPENS" else ""))
        }
        println()
    }
    println(String.format("%d of %d events never happen.", zeroes, Ev4.COUNT))
    println()
    println("A zero here is not a bug on its own -- most of these have never been")
    println("written. It is a LIST, and that is the point: every line of it is a")
    println("named job, and none of them costs a byte of assets.")
}
