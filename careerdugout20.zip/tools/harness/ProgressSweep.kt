import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.OffBall
import com.dugout.career.sim.Season

/**
 * WHAT DOES IT COST TO MAKE THE BALL GO FORWARD?
 *
 * `V2_PROGRESS_W` is how much a pass is worth for gaining ground, against a
 * lane term worth 16 for being safe. With the off-ball layer on, EventCensus
 * reads 238 short passes a match, 6 long ones and 6.75 shots: a side that
 * keeps the ball and never goes anywhere, because every man it can see is
 * beside it and safe.
 *
 * The lever has to be swept with the layer BOTH ways, because a value that
 * fixes the layer and wrecks the shipped engine is not a fix.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 6
    println(String.format("  %-6s %-4s %7s %7s %9s %9s",
        "weight", "ob", "goals", "shots", "carry x", "middle"))
    for (w in floatArrayOf(1.15f, 2.2f, 3.4f, 5.0f, 7.5f)) {
        for (ob in booleanArrayOf(false, true)) {
            MatchEngine.V2_PROGRESS_W = w
            OffBall.ENABLED = ob
            val world = World.build(20260727L)
            val season = Season(world); season.buildCalendar()
            val league = season.fixtures.filter { it.comp == 0 }
            var goals = 0; var shots = 0; var carry = 0.0; var cn = 0.0
            var mid = 0.0; var mn = 0.0
            for (i in 0 until matches) {
                OffBall.reset()
                val m = MatchEngine(world, season, league[i % league.size])
                m.replaysEnabled = false; m.start()
                var g = 0
                while (!m.finished && g++ < 300_000) {
                    m.update(1f / 36f); m.sound.clear()
                    if (g % 20 != 0) continue
                    val out = m.players.filter { it.onPitch && it.pos != Pos.GK }
                    if (out.isNotEmpty()) {
                        mid += out.count { it.y > 40f && it.y < 60f }.toDouble() / out.size; mn++
                    }
                    val h = m.ball.holder
                    val c = h?.let { k -> m.players.firstOrNull { it.key == k && it.onPitch } }
                    if (c != null) { carry += (if (c.side == 0) c.x else 100f - c.x).toDouble(); cn++ }
                }
                goals += m.score[0] + m.score[1]
                shots += m.shots[0] + m.shots[1]
            }
            println(String.format("  %-6.2f %-4s %7.2f %7.1f %9.1f %8.1f%%",
                w, if (ob) "on" else "off", goals.toDouble() / matches,
                shots.toDouble() / matches, carry / cn, 100.0 * mid / mn))
        }
    }
    println()
    println("Target: 2.5-2.7 goals, about 24 shots, and the layer ON.")
}
