import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * The old move construction against the new one, on every figure that matters,
 * from the same worlds and the same fixtures.
 *
 * Version 1 builds a move by hopping between whoever is standing near the man
 * on the ball. Version 2 advances the BALL a sampled distance in a sampled
 * direction and then asks who is best placed to receive it. Everything about
 * the outcome — ratings, the outcome roll, chance quality — is identical
 * between them, so any difference here is geometry.
 *
 * Read the whole table at once. Three separate attempts to fix this engine's
 * geometry each fixed one line and broke another, so a version only wins if it
 * wins across the board.
 */
private class Res {
    var games = 0; var goals = 0; var goalsSq = 0.0
    var hw = 0; var dr = 0; var aw = 0; var shots = 0
    val passLen = ArrayList<Double>()
    var fwd = 0; var side = 0; var back = 0
    val shotD = ArrayList<Double>()
    val goalD = ArrayList<Double>()
    var blockSum = 0.0; var shapeN = 0
}

private fun run(v2: Boolean, seeds: List<Long>, seasons: Int, geoMatches: Int): Res {
    MatchEngine.SPATIAL_V2 = v2
    val r = Res()

    // --- results, over many matches, for balance ---
    for (seed in seeds) {
        val world = World.build(seed)
        val season = Season(world); season.buildCalendar()
        val top = world.divisions.first()
        val fx = season.fixtures.filter { it.comp == 0 && it.divisionId == top.id }
        for (week in 0 until seasons) {
            world.week = week
            for (f in fx) {
                val m = MatchEngine(world, season, f)
                m.speed = 6f; m.replaysEnabled = false
                m.start()
                var g = 0
                while (!m.finished && g++ < 200_000) {
                    m.update(1f / 30f)
                    if (!m.running && !m.finished) m.start()
                    m.sound.clear()
                }
                val gg = m.score[0] + m.score[1]
                r.goals += gg; r.goalsSq += (gg * gg).toDouble(); r.games++
                r.shots += m.shots[0] + m.shots[1]
                when {
                    m.score[0] > m.score[1] -> r.hw++
                    m.score[0] == m.score[1] -> r.dr++
                    else -> r.aw++
                }
            }
        }
    }

    // --- geometry, frame by frame, on a smaller sample ---
    val world = World.build(seeds.first())
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    for (i in 0 until geoMatches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var prevPasses = 0
        var lastShot = -1.0
        val prevShots = HashMap<String, Int>()
        for (p in m.players) prevShots[p.key] = p.shots
        var frame = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            val goalsBefore = m.score[0] + m.score[1]
            m.update(1f / 36f)
            if (m.finished) break
            frame++

            val now = m.passesTotal[0] + m.passesTotal[1]
            if (now > prevPasses) {
                prevPasses = now
                val dx = (m.ball.toX - m.ball.fromX) * 1.05
                val dy = (m.ball.toY - m.ball.fromY) * 0.68
                val len = Math.sqrt(dx * dx + dy * dy)
                r.passLen.add(len)
                val toGoal = if (m.possessionSide == 0) dx else -dx
                when {
                    toGoal > len * 0.35 -> r.fwd++
                    toGoal < -len * 0.35 -> r.back++
                    else -> r.side++
                }
            }

            var shooter: com.dugout.career.sim.LivePlayer? = null
            for (p in m.players) {
                val was = prevShots[p.key] ?: 0
                if (p.shots > was) { shooter = p; prevShots[p.key] = p.shots }
            }
            if (shooter != null) {
                val gx = if (shooter.side == 0) 100f else 0f
                val d = Math.hypot(((gx - shooter.x) * 1.05), ((50f - shooter.y) * 0.68))
                r.shotD.add(d); lastShot = d
            }
            if (m.score[0] + m.score[1] > goalsBefore && lastShot >= 0) {
                r.goalD.add(lastShot); lastShot = -1.0
            }

            if (frame > 300 && frame % 12 == 0 && m.celebrationTime <= 0f) {
                for (sd in 0..1) {
                    val on = m.players.filter { it.onPitch && it.side == sd && it.pos != Pos.GK }
                    if (on.size < 8) continue
                    val xs = on.map { it.x }
                    val cx = xs.average()
                    val trimmed = on.sortedBy { Math.abs(it.x - cx) }.dropLast(1).map { it.x }
                    r.blockSum += (trimmed.max() - trimmed.min()) * 1.05
                    r.shapeN++
                }
            }
        }
    }
    return r
}

private fun med(v: List<Double>) = if (v.isEmpty()) 0.0 else v.sorted()[v.size / 2]

fun main(args: Array<String>) {
    val seasons = args.firstOrNull()?.toIntOrNull() ?: 3
    val geo = args.getOrNull(1)?.toIntOrNull() ?: 30
    val seeds = listOf(20260727L, 5150L, 99001L, 777333L)

    val v1 = run(false, seeds, seasons, geo)
    val v2 = run(true, seeds, seasons, geo)
    MatchEngine.SPATIAL_V2 = false

    fun line(label: String, a: String, b: String, real: String) =
        println(String.format("%-26s %14s %14s   %s", label, a, b, real))

    println("=== move construction: walking the players vs walking the ball ===")
    println(String.format("%d matches for results, %d for geometry, seeds %s",
        v1.games, geo, seeds.joinToString(",")))
    println()
    println(String.format("%-26s %14s %14s   %s", "", "v1 (players)", "v2 (ball)", "real football"))
    val n1 = v1.games.toDouble(); val n2 = v2.games.toDouble()
    val m1 = v1.goals / n1; val m2 = v2.goals / n2
    val ci1 = 1.96 * Math.sqrt((v1.goalsSq / n1 - m1 * m1) / n1)
    val ci2 = 1.96 * Math.sqrt((v2.goalsSq / n2 - m2 * m2) / n2)
    line("goals per game", String.format("%.2f±%.2f", m1, ci1), String.format("%.2f±%.2f", m2, ci2), "2.5 - 2.7")
    line("home wins", String.format("%.1f%%", v1.hw * 100 / n1), String.format("%.1f%%", v2.hw * 100 / n2), "~45%")
    line("draws", String.format("%.1f%%", v1.dr * 100 / n1), String.format("%.1f%%", v2.dr * 100 / n2), "~25%")
    line("away wins", String.format("%.1f%%", v1.aw * 100 / n1), String.format("%.1f%%", v2.aw * 100 / n2), "~30%")
    line("shots per game", String.format("%.1f", v1.shots / n1), String.format("%.1f", v2.shots / n2), "~25")
    println()
    line("mean pass", String.format("%.1f m", v1.passLen.average()), String.format("%.1f m", v2.passLen.average()), "~18 m")
    val f1 = v1.fwd + v1.side + v1.back; val f2 = v2.fwd + v2.side + v2.back
    line("forward / side / back",
        String.format("%.0f/%.0f/%.0f", v1.fwd * 100.0 / f1, v1.side * 100.0 / f1, v1.back * 100.0 / f1),
        String.format("%.0f/%.0f/%.0f", v2.fwd * 100.0 / f2, v2.side * 100.0 / f2, v2.back * 100.0 / f2),
        "45/35/20")
    println()
    line("median shot", String.format("%.1f m", med(v1.shotD)), String.format("%.1f m", med(v2.shotD)), "12-25 m")
    line("median goal", String.format("%.1f m", med(v1.goalD)), String.format("%.1f m", med(v2.goalD)), "~11 m")
    line("goals from own half",
        String.format("%.1f%%", v1.goalD.count { it > 52.5 } * 100.0 / Math.max(1, v1.goalD.size)),
        String.format("%.1f%%", v2.goalD.count { it > 52.5 } * 100.0 / Math.max(1, v2.goalD.size)),
        "~0%")
    line("block, back to front",
        String.format("%.1f m", v1.blockSum / v1.shapeN), String.format("%.1f m", v2.blockSum / v2.shapeN), "30-40 m")
    println()
    println("a version only wins if it wins across the board: every previous attempt")
    println("at this fixed one line and broke another.")
}
