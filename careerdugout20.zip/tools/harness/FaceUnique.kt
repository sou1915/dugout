import com.dugout.career.core.World
import com.dugout.career.ui.Face

/**
 * Two questions: does any face repeat, and is any pair of faces so close that
 * they would read as the same man? All pairs, no sampling.
 */
fun main() {
    val w = World.build(20260727L)
    val players = w.players.values.toList()
    val t0 = System.nanoTime()
    Face.assignAll(players)
    val ms = (System.nanoTime() - t0) / 1e6
    println(String.format("faces assigned in %.0f ms", ms))
    val vecs = players.map { Face.vector(Face.of(it)) }
    val n = vecs.size
    println("=== $n players, every pair compared ===")

    val seen = HashMap<String, Int>()
    var dupes = 0
    for (v in vecs) {
        val k = v.joinToString(",")
        val c = (seen[k] ?: 0) + 1
        seen[k] = c
        if (c > 1) dupes++
    }
    println("exact duplicate faces: $dupes")

    // minimum pairwise Hamming distance over the ten features
    val hist = IntArray(11)
    var minD = 99
    var worstA = -1; var worstB = -1
    for (i in 0 until n) {
        val a = vecs[i]
        for (j in i + 1 until n) {
            val b = vecs[j]
            var d = 0
            for (f in 0 until 10) if (a[f] != b[f]) d++
            hist[d]++
            if (d < minD) { minD = d; worstA = i; worstB = j }
        }
    }
    println("closest pair differs in $minD of 10 features")
    println()
    println("how far apart every pair of faces is:")
    for (d in 0..10) if (hist[d] > 0) {
        println(String.format("   %2d features apart : %,12d pairs", d, hist[d]))
    }
    if (worstA >= 0) {
        val pa = players[worstA]; val pb = players[worstB]
        println()
        println("the two most similar men in the game:")
        println("   ${pa.full}, ${pa.age}, ${pa.nation}  ${vecs[worstA].joinToString(",")}")
        println("   ${pb.full}, ${pb.age}, ${pb.nation}  ${vecs[worstB].joinToString(",")}")
    }
}
