import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * BallCheck reports the ball airborne 17% of the match and StickCheck reports
 * 59%. Both test `height > 0.05`, so one of them is wrong and the numbers in
 * the README are built on whichever it is. This counts both ways in a single
 * run and profiles the height itself.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f

    var px = m.ball.x; var py = m.ball.y
    var totalStick = 0; var airStick = 0
    var totalBall = 0; var airBall = 0
    var skippedTeleport = 0; var skippedFast = 0
    // height buckets in pitch units on the short axis
    val buckets = IntArray(12)
    var deadAir = 0; var deadTotal = 0

    for (i in 0 until 8000) {
        m.update(dt)
        val dx = (m.ball.x - px) * 1.05
        val dy = (m.ball.y - py) * 0.68
        val mps = Math.sqrt(dx * dx + dy * dy) / dt
        px = m.ball.x; py = m.ball.y
        if (i <= 200) continue

        // StickCheck's accounting
        totalStick++
        if (m.ball.height > 0.05f) airStick++

        // BallCheck's accounting
        val teleport = m.ball.t >= 1f && mps > 25
        if (mps >= 200) skippedFast++
        else if (teleport) skippedTeleport++
        else {
            totalBall++
            if (m.ball.height > 0.05f) airBall++
        }

        val h = m.ball.height * 0.68
        buckets[minOf(11, (h * 2).toInt())]++

        // is the ball airborne while nothing is in flight? that would be a
        // ball hanging in the air with no journey to explain it
        if (m.ball.t >= 1f) {
            deadTotal++
            if (m.ball.height > 0.05f) deadAir++
        }
        if (m.finished) break
    }

    println("frames after warm-up            $totalStick")
    println(String.format("airborne, StickCheck rule       %d  (%.0f%%)", airStick, airStick * 100.0 / totalStick))
    println(String.format("airborne, BallCheck rule        %d of %d  (%.0f%%)", airBall, totalBall, airBall * 100.0 / totalBall))
    println("frames BallCheck skipped        teleport $skippedTeleport, over 200 m/s $skippedFast")
    println()
    println(String.format("frames with the ball NOT in flight (t>=1): %d, of which airborne %d (%.0f%%)",
        deadTotal, deadAir, deadAir * 100.0 / maxOf(1, deadTotal)))
    println()
    println("ball height distribution (metres above the turf):")
    for (b in buckets.indices) {
        if (buckets[b] == 0) continue
        val lab = if (b == 11) ">=5.5" else String.format("%.1f-%.1f", b * 0.5, b * 0.5 + 0.5)
        println(String.format("  %8s  %5d  %s", lab, buckets[b],
            "#".repeat(minOf(60, buckets[b] * 60 / totalStick))))
    }
}
