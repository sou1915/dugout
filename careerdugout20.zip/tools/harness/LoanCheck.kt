import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season
import android.content.Context

/**
 * Does a loan do the thing it exists to do?
 *
 * The claim being tested is not "the code runs". It is that a young player
 * sent out on loan plays games and develops, and one left in the reserves does
 * not — which is the entire reason the feature was asked for. So this measures
 * appearances and the change in overall for both groups, and checks the
 * bookkeeping cannot leak: two clubs between them must always pay exactly one
 * wage, and no player may end up in two squads or none.
 */
private fun setup(seed: Long): Triple<World, Season, Career> {
    val w = World.build(seed)
    val div = w.divisions[0]
    val club = w.club(div.clubIds.first())!!
    club.isUser = true
    w.userClubId = club.id
    val s = Season(w); s.buildCalendar()
    return Triple(w, s, Career(w, s))
}

private fun audit(w: World): String {
    val problems = ArrayList<String>()
    // every player in exactly one squad
    val counts = HashMap<Int, Int>()
    for (c in w.clubs) for (id in c.squad) counts[id] = (counts[id] ?: 0) + 1
    val twice = counts.count { it.value > 1 }
    val none = w.players.values.count { (counts[it.id] ?: 0) == 0 }
    if (twice > 0) problems.add("$twice players in two squads")
    if (none > 0) problems.add("$none players in no squad")
    // a loaned player must sit in the borrowing club's squad, not the parent's
    for (p in w.players.values) {
        if (!p.onLoan) continue
        val host = w.club(p.clubId)
        val parent = w.club(p.loanFromId)
        if (host == null || !host.squad.contains(p.id)) problems.add("${p.last} not in host squad")
        if (parent != null && parent.squad.contains(p.id)) problems.add("${p.last} still in parent squad")
    }
    // the two clubs together pay exactly one wage
    var paid = 0L; var owed = 0L
    for (c in w.clubs) paid += w.wageBill(c).toLong()
    for (p in w.players.values) if (w.club(p.clubId) != null) owed += p.wage.toLong()
    if (paid != owed) problems.add("wages $paid paid vs $owed owed")
    return if (problems.isEmpty()) "ok" else problems.joinToString("; ")
}

fun main() {
    println("=== a single loan, start to finish ===")
    run {
        val (w, _, career) = setup(20260727L)
        val club = w.userClub!!
        val before = audit(w)
        val squadBefore = club.squad.size
        val wageBefore = w.wageBill(club)

        val p = w.squadOf(club).filter { career.loanEligible(it) }
            .maxByOrNull { it.potential }
        if (p == null) { println("no eligible player"); return@run }
        val suitors = career.loanSuitors(p)
        println("player   ${p.full}, ${p.age}, overall ${p.overall()}, potential ${p.potential}")
        println("suitors  ${suitors.size}: ${suitors.take(3).joinToString { it.name + " (rep " + it.reputation + ")" }}")
        val to = suitors.first()
        val share = career.loanWageOffer(p, to)
        val err = career.loanOut(p, to, 20, share)
        println("loan     ${err ?: "agreed with ${to.name}, they pay $share% of wages"}")
        println("squad    $squadBefore -> ${club.squad.size}")
        println("wages    $wageBefore -> ${w.wageBill(club)}  (saving ${wageBefore - w.wageBill(club)})")
        println("audit    before=$before  after=${audit(w)}")
        println("recall   ${career.recallLoan(p) ?: "allowed"}")
        p.loanLocked = 0
        println("recall   ${career.recallLoan(p) ?: "allowed, he is home"}")
        println("audit    ${audit(w)}")
    }

    println()
    println("=== a season: loaned youngsters against reserve-bound ones ===")
    run {
        val (w, season, career) = setup(20260727L)
        val club = w.userClub!!
        // the young players who would otherwise sit in the reserves
        // the youngest men in the squad, whatever their nominal status: at a
        // top flight club these are the ones who will not get a game
        val kids = w.squadOf(club)
            .filter { it.age <= 21 }
            .sortedByDescending { it.potential }
        if (kids.size < 4) { println("not enough youngsters (${kids.size})"); return@run }
        // half go out, half stay, alternating down the potential order so the
        // two groups start out as alike as the squad allows
        val out = kids.filterIndexed { i, _ -> i % 2 == 0 }
        val stay = kids.filterIndexed { i, _ -> i % 2 == 1 }
        val startOut = out.map { it.overall() }
        val startStay = stay.map { it.overall() }
        for (p in out) {
            val to = career.loanSuitors(p).firstOrNull() ?: continue
            career.loanOut(p, to, 40, career.loanWageOffer(p, to))
        }
        println("sent out ${out.size}, kept back ${stay.size}")

        for (wk in 1..38) {
            w.week = wk
            season.simWeek(wk, -1)
            career.advanceWeek()
        }

        fun report(label: String, group: List<com.dugout.career.core.Player>, start: List<Int>) {
            val apps = group.sumOf { it.apps }
            val gain = group.indices.sumOf { group[it].overall() - start[it] }
            println(String.format("%-10s %2d players  %3d apps (%.1f each)  overall %+.2f each",
                label, group.size, apps, apps.toDouble() / group.size,
                gain.toDouble() / group.size))
        }
        report("on loan", out, startOut)
        report("reserves", stay, startStay)
        println("audit    ${audit(w)}")
    }

    println()
    println("=== does the rest of the world use it ===")
    run {
        val (w, season, career) = setup(20260727L)
        for (wk in 1..38) { w.week = wk; season.simWeek(wk, -1); career.advanceWeek() }
        val live = w.players.values.count { it.onLoan }
        val clubsUsing = w.players.values.filter { it.onLoan }.map { it.loanFromId }.distinct().size
        println("players out on loan after a season: $live, from $clubsUsing different clubs")
        println("audit    ${audit(w)}")
    }

    println()
    println("=== a loan through the save file ===")
    run {
        val ctx = Context()
        val (w, season, career) = setup(20260727L)
        val club = w.userClub!!
        val p = w.squadOf(club).filter { career.loanEligible(it) }
            .maxByOrNull { it.potential }
        if (p == null) { println("no eligible player"); return@run }
        val to = career.loanSuitors(p).first()
        career.loanOut(p, to, 18, career.loanWageOffer(p, to))
        val beforeParentWage = club.loanWageOut
        val beforeHost = p.clubId
        val beforeShare = p.loanWageShare
        val beforeWeeks = p.loanWeeks

        Save.write(ctx, w, season, career)
        val loaded = Save.read(ctx)
        if (loaded == null) { println("save did not come back"); return@run }
        val w2 = loaded.world
        val p2 = w2.player(p.id)!!
        val club2 = w2.userClub!!
        val ok = p2.onLoan && p2.loanFromId == club2.id && p2.clubId == beforeHost &&
                p2.loanWageShare == beforeShare && p2.loanWeeks == beforeWeeks &&
                club2.loanWageOut == beforeParentWage &&
                w2.club(beforeHost)!!.squad.contains(p2.id) &&
                !club2.squad.contains(p2.id)
        println("on loan      ${p2.onLoan}, at ${w2.club(p2.clubId)?.name}")
        println("owner        ${w2.club(p2.loanFromId)?.name}")
        println("weeks/share  ${p2.loanWeeks} / ${p2.loanWageShare}%  (was $beforeWeeks / $beforeShare%)")
        println("parent still owes ${club2.loanWageOut} a week (was $beforeParentWage)")
        println("audit        ${audit(w2)}")
        println(if (ok) "round trip ok" else "ROUND TRIP FAILED")
    }
}
