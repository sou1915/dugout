import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Things that look wrong even when speeds are right: men standing inside each
 * other, and a ball that travels straight through an opponent.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var frames = 0
    var overlapFrames = 0
    var overlapPairs = 0
    var worstOverlap = 99.0
    var passes = 0
    var passesThroughSomeone = 0
    var lofted = 0
    var lastBallT = 1f

    for (i in 0 until 8000) {
        val bx = m.ball.x; val by = m.ball.y
        val tx = m.ball.toX; val ty = m.ball.toY
        val wasFlying = m.ball.t < 1f
        m.update(dt)
        if (i < 200) continue
        frames++

        // men inside each other
        val on = m.players.filter { it.onPitch }
        var any = false
        for (a in on.indices) for (b in a + 1 until on.size) {
            val p = on[a]; val q = on[b]
            val dx = (p.x - q.x) * 1.05; val dy = (p.y - q.y) * 0.68
            val d = Math.sqrt(dx * dx + dy * dy)
            if (d < 0.9) { overlapPairs++; any = true; if (d < worstOverlap) worstOverlap = d }
        }
        if (any) overlapFrames++

        // a pass just started: does its line cross an opponent?
        if (!wasFlying && m.ball.t < 1f) {
            passes++
            val dx = m.ball.toX - bx; val dy = m.ball.toY - by
            val len = Math.hypot(dx.toDouble(), dy.toDouble())
            if (len > 1) {
                val opp = m.players.filter { it.onPitch && it.side != m.possessionSide && it.pos != Pos.GK }
                var blocked = false
                for (o in opp) {
                    // distance from o to the segment
                    // a man marking the receiver is not "in the way": only count
                    // someone genuinely standing in the middle of the line
                    val raw = ((o.x - bx) * dx + (o.y - by) * dy) / (len * len)
                    if (raw < 0.15 || raw > 0.85) continue
                    val t = raw.coerceIn(0.0, 1.0)
                    val cx = bx + dx * t; val cy = by + dy * t
                    val dd = Math.hypot(((o.x - cx) * 1.05).toDouble(), ((o.y - cy) * 0.68).toDouble())
                    if (dd < 1.0) { blocked = true; break }
                }
                // a ball clipped over him is not played through him
                if (blocked && m.ball.loft < 0.8f) passesThroughSomeone++
                if (blocked && m.ball.loft >= 0.8f) lofted++
            }
        }
        lastBallT = m.ball.t
        if (m.finished) break
    }
    println("=== realism ===")
    println(String.format("frames with men inside each other   %.0f%%", overlapFrames * 100.0 / frames))
    println(String.format("average overlapping pairs a frame   %.2f", overlapPairs.toDouble() / frames))
    println(String.format("closest two men ever got            %.2f m", worstOverlap))
    println()
    println(String.format("passes played straight through an opponent  %d of %d  (%.0f%%)",
        passesThroughSomeone, passes, passesThroughSomeone * 100.0 / Math.max(1, passes)))
    println(String.format("clipped over a man in the way                %d", lofted))
    println()
    println("two players cannot be closer than about 0.8 m, and a pass through")
    println("a man standing in the line should be blocked or deflected")
}
