import com.dugout.career.sim.MatchEngine

/** How often does the ball actually cross a line, and which one? */
fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 8
    var touch = 0L; var goalLine = 0L; var maxY = 0f; var minY = 100f
    var yBeyond95 = 0L; var frames = 0L
    val dt = 1f / 36f
    for (i in 0 until n) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false; m.start()
        var wasOut = false
        var g = 0
        while (!m.finished && g++ < 900_000) {
            m.update(dt); m.sound.clear(); frames++
            if (m.ball.y > maxY) maxY = m.ball.y
            if (m.ball.y < minY) minY = m.ball.y
            if (m.ball.y > 95f || m.ball.y < 5f) yBeyond95++
            val out = m.ball.y < 1.2f || m.ball.y > 98.8f
            val outG = m.ball.x < 1.2f || m.ball.x > 98.8f
            if ((out || outG) && !wasOut) { if (out) touch++ else goalLine++ }
            wasOut = out || outG
        }
    }
    println("=== does the ball ever cross a touchline? ($n matches) ===")
    println(String.format("crossed a TOUCHLINE      %6.2f per match", touch.toDouble() / n))
    println(String.format("crossed a GOAL LINE      %6.2f per match", goalLine.toDouble() / n))
    println(String.format("ball y beyond 95 or 5    %6.2f%% of frames", 100.0 * yBeyond95 / frames))
    println(String.format("extreme ball y reached   %6.1f min, %6.1f max", minY, maxY))
    println()
    println("If the ball never reaches y>98.8 the throw-in code cannot fire,")
    println("however often the clearance branch is taken.")
}
