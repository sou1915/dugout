import android.content.Context
import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** Contract clauses: do they lower the wage, cost money, and let rivals in? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val c = w.club(w.divisions[0].clubIds.first())!!
    val car = Career(w, s); car.start(c.id, "A Manager", "ENG")

    val striker = w.squadOf(c).filter { it.pos == Pos.ST }.maxByOrNull { it.overall() }!!
    println("=== ${striker.full}, ${Pos.name(striker.pos)}, ${striker.overall()} rated ===")
    println(String.format("basic demand with no clauses      %s", Fmt.wage(car.renewalDemand(striker))))

    striker.appearanceFee = 4000
    println(String.format("with %s an appearance             %s  (clauses worth %s a week)",
        Fmt.wage(4000), Fmt.wage(car.renewalDemand(striker)), Fmt.wage(striker.clauseValue())))
    striker.goalBonus = 9000
    println(String.format("plus %s a goal                    %s  (clauses worth %s a week)",
        Fmt.wage(9000), Fmt.wage(car.renewalDemand(striker)), Fmt.wage(striker.clauseValue())))
    striker.releaseClause = 25_000_000L
    println(String.format("plus a %s release clause     %s",
        Fmt.money(25_000_000L), Fmt.wage(car.renewalDemand(striker))))

    // a defender values a clean sheet bonus; a striker does not
    println()
    val cb = w.squadOf(c).first { Pos.group(it.pos) == 1 }
    cb.cleanSheetBonus = 5000
    striker.cleanSheetBonus = 5000
    println(String.format("clean sheet bonus is worth %s a week to a defender, %s to a striker",
        Fmt.wage(cb.clauseValue()), Fmt.wage(striker.clauseValue() - 4000 * 62 / 100 - (9000 * 0.42 * 0.62).toInt())))

    // the bill after a match
    println()
    val before = c.balance
    val played = w.squadOf(c).take(11).map { it.id }
    car.payMatchBonuses(played, listOf(striker.id, striker.id), true)
    println(String.format("a win to nil with two from him cost %s in bonuses", Fmt.money(before - c.balance)))

    // rivals and the small print
    println()
    striker.releaseClause = (striker.value() * 0.55).toLong()
    println(String.format("clause set at %s, he is worth %s",
        Fmt.money(striker.releaseClause), Fmt.money(striker.value())))
    var week = 0
    var gone = false
    while (week < 120 && !gone) {
        w.week = (week % 38) + 1
        car.checkReleaseClauses()
        if (striker.clubId != c.id) { gone = true }
        week++
    }
    println(if (gone) "a rival paid it after $week weeks: he now plays for ${w.club(striker.clubId)?.name}"
            else "nobody triggered it in 120 weeks")

    // and the save layout survived being extended
    println()
    val ctx = Context()
    val keeper = w.squadOf(c).first { it.pos == Pos.GK }
    keeper.appearanceFee = 1500; keeper.releaseClause = 4_000_000L
    val traitsBefore = keeper.traits.joinToString(",")
    val persBefore = keeper.personality
    val appsBefore = keeper.cApps
    Save.write(ctx, w, s, car)
    val back = Save.read(ctx)!!
    val k2 = back.world.player(keeper.id)!!
    println("clauses survive:   fee ${k2.appearanceFee}, clause ${Fmt.money(k2.releaseClause)}")
    println("nothing shifted:   traits ${k2.traits.joinToString(",") == traitsBefore}, " +
            "personality ${k2.personality == persBefore}, career apps ${k2.cApps == appsBefore}")
}
