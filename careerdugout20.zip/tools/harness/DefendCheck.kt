import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * When the ball is in your own penalty area, are you defending it?
 *
 * Rendered frames of crosses showed a ball on the goal line at x=99 with the
 * defending side's outfield ten averaging x=58 — standing on the halfway line
 * while their goal was under attack, and NOT ONE defender inside the area. Every
 * cross captured, with jobs and without, reported zero defenders in the box.
 *
 * In real football a ball in your area has eight or nine of your outfield ten
 * goal-side of it. This measures three things at the moment the ball enters an
 * area:
 *
 *   - how many of the defending ten are goal-side of the ball
 *   - how many are inside their own area
 *   - where the defending side's outfield average actually is
 *
 * The side being measured is the one whose goal it is, taken from the geometry
 * of the pitch and not from possession, because a ball in your box is your
 * problem whoever last touched it.
 */
/**
 * Does the defending shape drop as the ball comes at it, or is it fixed?
 *
 * Buckets by how far the ball is from the defending side's own goal line and
 * reports where that side's outfield ten stand, where they are TOLD to stand,
 * and where their deepest man is. If the target moves and the men do not, they
 * cannot cover the ground in time; if the target does not move either, the
 * defensive shape simply is not reacting.
 */
private fun buckets(matches: Int): String {
    val edges = listOf(0f, 12f, 22f, 34f, 50f, 70f, 105f)
    val n = LongArray(edges.size - 1)
    val at = DoubleArray(edges.size - 1)
    val tgt = DoubleArray(edges.size - 1)
    val deep = DoubleArray(edges.size - 1)
    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            if (m.celebrationTime > 0f) continue
            for (def in 0..1) {
                if (m.possessionSide == def) continue      // only the side under attack
                val ballFrom = (if (def == 0) m.ball.x else 100f - m.ball.x) * 1.05f
                var b = edges.indexOfFirst { ballFrom < it } - 1
                if (b < 0) b = edges.size - 2
                val on = m.players.filter { it.onPitch && it.side == def && it.pos != Pos.GK }
                if (on.size < 8) continue
                fun own(v: Float) = (if (def == 0) v else 100f - v) * 1.05f
                at[b] += on.map { own(it.x).toDouble() }.average()
                tgt[b] += on.map { own(it.targetX).toDouble() }.average()
                deep[b] += on.minOf { own(it.x) }.toDouble()
                n[b]++
            }
        }
    }
    val sb = StringBuilder("=== does the defending shape drop as the ball comes? ===\n")
    sb.append(String.format("%-18s %12s %12s %12s%n",
        "ball is", "they stand", "told to be", "deepest man"))
    for (b in n.indices) {
        if (n[b] == 0L) continue
        sb.append(String.format("%-18s %10.0f m %10.0f m %10.0f m%n",
            String.format("%.0f-%.0f m out", edges[b], edges[b + 1]),
            at[b] / n[b], tgt[b] / n[b], deep[b] / n[b]))
    }
    sb.append("\nall distances are from the DEFENDING side's own goal line.\n")
    sb.append("if 'told to be' tracks the ball and 'they stand' does not, the men\n")
    sb.append("cannot cover the ground; if neither moves, the shape is not reacting.\n")
    return sb.toString()
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    // The flags MUST be set before a single match is simulated. The first
    // version of this parsed them further down, after the measurement loop had
    // already run, and printed four identical results for four configurations
    // while the bucket table above it changed -- which is what gave it away.
    when (args.getOrNull(1)) {
        "off" -> { MatchEngine.RECOVER = false; MatchEngine.DEF_JOBS = false }
        "norecover" -> MatchEngine.RECOVER = false
        "nozones" -> MatchEngine.DEF_JOBS = false
    }
    args.getOrNull(2)?.toFloatOrNull()?.let { MatchEngine.DEF_JOB_RANGE = it }
    println("getting back ${if (MatchEngine.RECOVER) "ON" else "off"}, " +
            "zones ${if (MatchEngine.DEF_JOBS) "ON range ${MatchEngine.DEF_JOB_RANGE}" else "off"}")
    println()

    var n = 0L
    var goalSide = 0.0
    var inBox = 0.0
    var meanX = 0.0
    var noneInBox = 0L
    var deepest = 0.0

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()
            if (m.celebrationTime > 0f) continue
            val bx = m.ball.x; val by = m.ball.y
            // side 0 defends x=0 and side 1 defends x=100; the engine never
            // swaps ends, resetShape puts both back on their own side at the
            // interval, so this holds for the whole match
            val def = when {
                bx < 16.5f && by > 21f && by < 79f -> 0
                bx > 83.5f && by > 21f && by < 79f -> 1
                else -> continue
            }
            val on = m.players.filter { it.onPitch && it.side == def && it.pos != Pos.GK }
            if (on.size < 8) continue
            val gs = on.count { if (def == 0) it.x < bx else it.x > bx }
            val ib = on.count {
                (if (def == 0) it.x < 16.5f else it.x > 83.5f) && it.y > 21f && it.y < 79f
            }
            goalSide += gs
            inBox += ib
            if (ib == 0) noneInBox++
            // how far back the deepest outfielder is, as distance from own line
            deepest += on.minOf { if (def == 0) it.x else 100f - it.x }.toDouble()
            meanX += on.map { if (def == 0) it.x else 100f - it.x }.average()
            n++
        }
    }

    println(buckets(matches))
    println("=== the ball is in your box: where is your team? ($matches matches) ===")
    println("$n frames with the ball inside a penalty area")
    println(String.format("  defenders goal-side of the ball   %.2f of 10   (real: 8-9)", goalSide / maxOf(1L, n)))
    println(String.format("  defenders inside their own area   %.2f of 10   (real: 5-7)", inBox / maxOf(1L, n)))
    println(String.format("  nobody in the area at all         %.1f%%       (real: ~never)", 100.0 * noneInBox / maxOf(1L, n)))
    println(String.format("  their outfield average sits at    %.0f m from their own line", meanX / maxOf(1L, n) * 1.05))
    println(String.format("  their DEEPEST outfielder is at    %.0f m from their own line", deepest / maxOf(1L, n) * 1.05))
    println()
    println("A side with the ball in its own six-yard box does not stand on the")
    println("halfway line. If the average is anywhere near 50 m, the defending")
    println("shape is not reacting to danger at all.")
}
