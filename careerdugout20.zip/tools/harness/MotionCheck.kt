import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Smoothness, not speed. A man who changes direction instantly, or stops dead,
 * or a ball that jumps across the pitch between frames, all read as machinery
 * however correct the speeds are.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f

    val lastHeading = HashMap<String, Float>()
    val lastFacing = HashMap<String, Float>()
    val lastPos = HashMap<String, Pair<Float, Float>>()
    var turns = 0; var sharpTurns = 0; var veryySharp = 0
    var facingJumps = 0; var facingSamples = 0
    var stops = 0; var moves = 0
    var ballJumps = 0; var ballFrames = 0; var inScene = 0
    var pb = Pair(m.ball.x, m.ball.y)

    fun norm(a: Float): Float {
        var x = a
        while (x > Math.PI) x -= (Math.PI * 2).toFloat()
        while (x < -Math.PI) x += (Math.PI * 2).toFloat()
        return x
    }

    for (i in 0 until 8000) {
        m.update(dt)
        if (i < 200) continue
        ballFrames++
        val bd = Math.hypot((m.ball.x - pb.first).toDouble(), (m.ball.y - pb.second).toDouble())
        if (bd > 4.0) {
            ballJumps++                        // more than 4 units in 1/36 s
            // a restart legitimately places the ball; anything else is a teleport
            if (m.scene != com.dugout.career.sim.Scene.NONE || m.banner != null) inScene++
        }
        pb = Pair(m.ball.x, m.ball.y)

        for (p in m.players) {
            if (!p.onPitch) continue
            val prev = lastPos[p.key]
            lastPos[p.key] = Pair(p.x, p.y)
            if (prev != null) {
                val dx = p.x - prev.first; val dy = p.y - prev.second
                val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (d > 0.02f) {
                    moves++
                    val h = Math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                    val lh = lastHeading[p.key]
                    if (lh != null) {
                        val turn = Math.abs(norm(h - lh)) * 180f / Math.PI.toFloat()
                        turns++
                        if (turn > 30f) sharpTurns++
                        if (turn > 90f) veryySharp++
                    }
                    lastHeading[p.key] = h
                } else stops++
            }
            val lf = lastFacing[p.key]
            if (lf != null) {
                facingSamples++
                val fd = Math.abs(norm(p.facing - lf)) * 180f / Math.PI.toFloat()
                if (fd > 40f) facingJumps++
            }
            lastFacing[p.key] = p.facing
        }
        if (m.finished) break
    }
    println("=== motion smoothness (per rendered frame) ===")
    println(String.format("heading changes over 30 deg   %.1f%% of moving frames", sharpTurns * 100.0 / turns))
    println(String.format("heading changes over 90 deg   %.2f%% of moving frames", veryySharp * 100.0 / turns))
    println(String.format("facing snaps over 40 deg      %.2f%% of frames", facingJumps * 100.0 / facingSamples))
    println(String.format("frames standing still         %.0f%%", stops * 100.0 / (stops + moves)))
    println(String.format("ball jumps over 4 units       %d in %d frames (%.2f%%)",
        ballJumps, ballFrames, ballJumps * 100.0 / ballFrames))
    println(String.format("  of those, %d were restarts and %d were mid play", inScene, ballJumps - inScene))
    println()
    println("a real player turns a few degrees a frame at speed and cannot reverse instantly")
}
