import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * When the ball is in the penalty area, is anybody there?
 *
 * This is the whole point of Player Jobs, stated as a number. The complaint was
 * that a cross was worked wide, swung in, and NOBODY WAS IN THE BOX, because
 * patterns moved the ball while every player stood in his formation slot. Jobs
 * send men to the near post, the penalty spot and the back post before the ball
 * arrives.
 *
 * Runs the same fixtures twice — jobs off, then jobs on — so the difference is
 * the feature and not the seed. Also reports team shape, because that is the
 * thing jobs are most likely to break: pulling four men forward every phase is
 * exactly how the block got stretched by the random-run version that had to be
 * reverted.
 *
 *   java -cp build/box.jar BoxCheckKt [matches]
 */
private class Tally {
    var boxFrames = 0L
    var attInBox = 0.0
    var defInBox = 0.0
    var emptyBox = 0L
    var blockSum = 0.0
    var blockN = 0L
    var goals = 0L
    var matches = 0L
}

private fun run(matches: Int, jobs: Boolean, seconds: Float = 4.5f): Tally {
    MatchEngine.JOBS = jobs
    MatchEngine.JOB_SECONDS = seconds
    val t = Tally()
    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(1f / 36f)
            m.sound.clear()

            // team shape: how far the attacking outfield ten are spread, as the
            // mean distance of each man from his own side's centre of mass
            val att = if (m.ball.x > 50f) 0 else 1
            val on = m.players.filter { it.onPitch && it.side == att && it.pos != Pos.GK }
            if (on.size >= 8) {
                val cx = on.map { it.x }.average(); val cy = on.map { it.y }.average()
                t.blockSum += on.map {
                    Math.hypot(((it.x - cx) * 1.05), ((it.y - cy) * 0.68))
                }.average()
                t.blockN++
            }

            // is the ball in a penalty area?
            val bx = m.ball.x; val by = m.ball.y
            val inHome = bx < 16.5f && by > 21f && by < 79f
            val inAway = bx > 83.5f && by > 21f && by < 79f
            if (!inHome && !inAway) continue
            val attSide = if (inAway) 0 else 1
            val boxMen = m.players.filter {
                it.onPitch && it.pos != Pos.GK &&
                (if (inHome) it.x < 16.5f else it.x > 83.5f) && it.y > 21f && it.y < 79f
            }
            val a = boxMen.count { it.side == attSide }
            val d = boxMen.count { it.side != attSide }
            t.boxFrames++
            t.attInBox += a
            t.defInBox += d
            if (a == 0) t.emptyBox++
        }
        t.goals += m.score[0] + m.score[1]
        t.matches++
    }
    return t
}

private fun report(name: String, t: Tally) {
    println(String.format("%-10s %8.2f %8.2f %11.1f%% %10.1f m %9.2f",
        name,
        t.attInBox / maxOf(1L, t.boxFrames),
        t.defInBox / maxOf(1L, t.boxFrames),
        100.0 * t.emptyBox / maxOf(1L, t.boxFrames),
        t.blockSum / maxOf(1L, t.blockN),
        t.goals.toDouble() / maxOf(1L, t.matches)))
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 30
    println("=== is anyone in the box when the ball gets there? ($matches matches each) ===")
    println(String.format("%-10s %8s %8s %12s %12s %9s",
        "", "attackers", "defenders", "nobody there", "block", "goals/game"))
    report("jobs off", run(matches, false))
    // Three configs, not a fine sweep. Goals per game over 30 matches carries a
    // standard error of sqrt(2.6/30) = 0.29, so plus and minus 0.58 at 95%: the
    // first version of this table swung 2.27 to 2.73 across durations and every
    // bit of that was sampling noise being read as a trend.
    for (s in listOf(4.5f, 8.0f, 12.0f)) {
        report(String.format("on %.1fs", s), run(matches, true, s))
    }
    MatchEngine.JOBS = true
    MatchEngine.JOB_SECONDS = 4.5f
    println()
    println("real football: three or four attackers arrive in the area for a cross,")
    println("and a delivery reaching an empty box is a rarity, not the norm.")
    println("block here is the mean distance of the attacking outfield ten from")
    println("their own centre of mass — not ShapeCheck's figure, a different")
    println("measure. What matters is that jobs must not push it UP.")
    println("goals/game must stay inside 2.5-2.7; confirm any survivor on")
    println("BalanceBig before believing it.")
}
