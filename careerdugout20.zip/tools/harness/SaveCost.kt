import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/**
 * AUDIT HARNESS -- what does an autosave cost?
 *
 * MainActivity.autosave() calls Save.write on the MAIN THREAD, including from
 * onPause(). The world is 1,236 clubs and 32,136 players serialised into one
 * StringBuilder and written out. Anything over a few hundred milliseconds there
 * is dropped frames at best and an ANR at worst.
 */
fun main() {
    val dir = java.io.File(System.getProperty("java.io.tmpdir"), "dugout-savecost")
    dir.mkdirs()
    val ctx = android.content.Context(dir)

    val t0 = System.nanoTime()
    val world = World.build(20260727L)
    val t1 = System.nanoTime()
    val season = Season(world)
    season.buildCalendar()
    val career = Career(world, season)

    println("=== autosave cost ===")
    println(String.format("world build            %6d ms   (%d clubs, %d players)",
        (t1 - t0) / 1_000_000, world.clubs.size, world.clubs.sumOf { it.squad.size }))

    // first write is cold; report the warm figure too
    val times = ArrayList<Long>()
    repeat(5) {
        val a = System.nanoTime()
        val ok = Save.write(ctx, world, season, career)
        val b = System.nanoTime()
        if (!ok) println("  write FAILED")
        times.add((b - a) / 1_000_000)
    }
    println("Save.write             ${times.joinToString(" / ")} ms   (5 runs)")

    val f = java.io.File(dir, "career.sav")
    println(String.format("save file              %6.2f MB", f.length() / 1048576.0))

    val r0 = System.nanoTime()
    val snap = Save.read(ctx)
    val r1 = System.nanoTime()
    println(String.format("Save.read              %6d ms   %s",
        (r1 - r0) / 1_000_000, if (snap == null) "RETURNED NULL" else "ok"))

    // what a corrupt save does
    f.writeText(f.readText().substring(0, (f.length() / 2).toInt()))
    val bad = Save.read(ctx)
    println("truncated save         ${if (bad == null) "read() returns null -- the career is silently gone" else "loaded"}")
    println()
    println("Anything above ~16 ms on the main thread drops a frame; Android's")
    println("ANR watchdog fires at 5 s, and onPause has a much tighter budget.")
    dir.deleteRecursively()
}
