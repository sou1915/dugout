import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import com.dugout.career.sim.Season

/**
 * HOW LONG IS ANYTHING ACTUALLY ON SCREEN?
 *
 * The owner reports there are no scenes in the match at all -- no dribbles, no
 * free kicks, no tackles, no referee, no penalties, no keeper saves. AliveCensus
 * says otherwise: 4.1 tackles, 26.8 take-ons, 11.0 dives a match. Both can be
 * true, because a COUNT is not a DURATION. A pose that fires four times and
 * lasts six tenths of a second is on screen for two and a half seconds out of a
 * four hundred second match, and a player watching will never once catch it.
 *
 * So this measures seconds, not counts: for each action and each scene, how many
 * seconds of the match it is visible for, and what share of the match that is.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    val actNames = linkedMapOf(
        Act.TACKLE to "a man sliding in", Act.SHOOT to "a shot being struck",
        Act.DIVE to "the keeper diving", Act.DRIBBLE to "somebody taking a man on",
        Act.HEADER to "a header", Act.DOWN to "a man on the floor",
        Act.CELEBRATE to "celebrating")
    val sceneNames = linkedMapOf(
        Scene.CORNER to "CORNER", Scene.PENALTY to "PENALTY", Scene.FREEKICK to "FREE KICK",
        Scene.THROW_IN to "THROW-IN", Scene.GOAL_KICK to "GOAL KICK",
        Scene.KICK_OFF to "KICK OFF", Scene.CARD to "BOOKING",
        Scene.TAKE_ON to "TAKE-ON", Scene.SAVE to "SAVE", Scene.TACKLE to "TACKLE",
        Scene.SHOT to "SHOT", Scene.SUBSTITUTION to "SUBSTITUTION")

    val actSecs = HashMap<Int, Double>()
    val sceneSecs = HashMap<Int, Double>()
    /*
     * The EVENT's own caption, which is the thing the table was written for and
     * which nothing measured until the table was switched on. `Scene.LABEL`
     * names the shape of a stoppage; this names what actually happened, and a
     * row that reads 0.0 here is a row that is still dark whatever its count
     * says.
     */
    val evSecs = HashMap<String, Double>()
    var matchSecs = 0.0
    var anyPose = 0.0
    var refSecs = 0.0

    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt); m.sound.clear()
            if (m.finished) break
            matchSecs += dt
            var posed = false
            for (p in m.players) {
                if (!p.onPitch || p.actionTime <= 0f) continue
                if (p.action == Act.RUN) continue
                actSecs[p.action] = (actSecs[p.action] ?: 0.0) + dt
                posed = true
            }
            if (posed) anyPose += dt
            if (m.scene != Scene.NONE && m.sceneTime > 0f)
                sceneSecs[m.scene] = (sceneSecs[m.scene] ?: 0.0) + dt
            if (m.refCard > 0) refSecs += dt
            if (m.evCaptionTime > 0f && m.evCaption.isNotEmpty())
                evSecs[m.evCaption] = (evSecs[m.evCaption] ?: 0.0) + dt
        }
    }

    val per = matchSecs / matches
    println("=== seconds on screen, averaged over $matches matches ===")
    println()
    println(String.format("a match lasts %.0f seconds of wall clock at 1x", per))
    println()
    println(String.format("  %-30s %8s %8s", "you can see...", "seconds", "of match"))
    for ((k, name) in actNames) {
        val s = (actSecs[k] ?: 0.0) / matches
        println(String.format("  %-30s %8.1f %7.1f%%", name, s, 100.0 * s / per))
    }
    println(String.format("  %-30s %8.1f %7.1f%%", "ANY named pose at all",
        anyPose / matches, 100.0 * (anyPose / matches) / per))
    println(String.format("  %-30s %8.1f %7.1f%%", "the referee showing a card",
        refSecs / matches, 100.0 * (refSecs / matches) / per))
    println()
    println(String.format("  %-30s %8s %8s", "captions", "seconds", "of match"))
    for ((k, name) in sceneNames) {
        val s = (sceneSecs[k] ?: 0.0) / matches
        println(String.format("  %-30s %8.1f %7.1f%%", name, s, 100.0 * s / per))
    }
    println()
    println(String.format("  %-30s %8s %8s", "event captions (the table)", "seconds", "of match"))
    if (evSecs.isEmpty()) println("    nothing -- every row is still dark")
    for ((name, s2) in evSecs.entries.sortedByDescending { it.value })
        println(String.format("  %-30s %8.1f %7.1f%%", name, s2 / matches, 100.0 * (s2 / matches) / per))

    println()
    println("A count is not a duration. Four tackles a match at six tenths of a")
    println("second each is two and a half seconds of a four hundred second game.")
}
