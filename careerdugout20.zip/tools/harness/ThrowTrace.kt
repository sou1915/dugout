import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

private val gateField = MatchEngine::class.java.getDeclaredField("stagedUntil")
    .also { it.isAccessible = true }

/**
 * AUDIT HARNESS -- one throw-in, tick by tick.
 *
 * Prints the ball, the staging gate, the nearest man and the taker's target
 * from the tick the scene is set until a few ticks after it ends, so "the ball
 * is 6 units off the touchline" stops being an average and becomes a sequence.
 */
fun main(args: Array<String>) {
    val want = args.firstOrNull()?.toIntOrNull() ?: 3
    var shown = 0
    var i = 0
    while (shown < want && i < 40) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val dt = 1f / 36f
        var tracing = 0
        var guard = 0
        var t = 0.0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()
            t += dt.toDouble()
            if (m.scene == Scene.THROW_IN && m.sceneTime > 0f && tracing == 0 && shown < want) {
                shown++
                tracing = 1
                println()
                println("--- throw-in ${shown} (match $i, minute ${m.clock.toInt()}) ---")
                println(String.format("%6s %7s %7s %8s %8s %9s %9s %8s",
                    "t s", "ball x", "ball y", "gate", "sceneT", "nearest", "taker d", "holder"))
            }
            if (tracing in 1..70) {
                val near = m.players.filter { it.onPitch }
                    .minByOrNull {
                        Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(),
                            ((it.y - m.ball.y) * 0.68).toDouble())
                    }
                val nd = if (near == null) 99.0 else Math.hypot(
                    ((near.x - m.ball.x) * 1.05).toDouble(),
                    ((near.y - m.ball.y) * 0.68).toDouble())
                val td = if (near == null) 0.0 else Math.hypot(
                    ((near.targetX - near.x) * 1.05).toDouble(),
                    ((near.targetY - near.y) * 0.68).toDouble())
                if (tracing % 4 == 1) {
                    println(String.format("%6.2f %7.1f %7.1f %8.2f %8.2f %9.1f %9.1f %8s",
                        t, m.ball.x, m.ball.y, gateField.getFloat(m), m.sceneTime,
                        nd, td, if (m.ball.holder == null) "-" else "yes"))
                }
                tracing++
            }
        }
        i++
    }
    println()
    println("'gate' is stagedUntil. 'taker d' is how far the man nearest the ball")
    println("still has to travel to reach his target.")
}
