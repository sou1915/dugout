import com.dugout.career.core.Backroom
import com.dugout.career.core.Fmt
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Where the money goes each week, and whether a club can survive on it. */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    println(String.format("%-26s %12s %12s %12s %12s", "club", "player wages", "staff", "sponsor/wk", "net/wk"))
    for (tier in 0..4) {
        val c = w.club(w.divisions[tier].clubIds.first())!!
        val players = w.wageBill(c).toLong()
        val staff = Backroom.wageBill(c.staff).toLong()
        val wages = players + staff
        val ops = (wages * 0.55).toLong() + c.capacity * 1L
        val sponsor = c.sponsor / 38
        val net = sponsor - wages - ops
        println(String.format("%-26s %12s %12s %12s %12s",
            "${w.divisions[tier].shortName}: ${c.name}".take(26),
            Fmt.money(players), Fmt.money(staff), Fmt.money(sponsor), Fmt.money(net)))
    }
    println()
    println("gate receipts and prize money arrive separately; a negative net here")
    println("has to be covered by them or a club bleeds out over a season")

    // what the season actually does to a mid table club
    val c = w.club(w.divisions[2].clubIds.first())!!
    val career = Career(w, s); career.start(c.id, "A Manager", "ENG")
    val start = c.balance
    var low = start
    for (wk in 1..38) {
        w.week = wk
        career.weeklyFinance()
        if (c.balance < low) low = c.balance
    }
    println()
    println(String.format("mid table club over 38 weeks of wages and running costs:"))
    println(String.format("  started %s, finished %s, lowest %s",
        Fmt.money(start), Fmt.money(c.balance), Fmt.money(low)))
}
