import com.dugout.career.sim.MatchEngine

/**
 * SceneAudit against engine v1, so a v1/v2 comparison uses the SAME criteria.
 *
 * Two of SceneAudit's tests were corrected (a booking is not about the ball; a
 * free-kick taker legitimately stands off it). Comparing v2 on the corrected
 * tests against v1 figures recorded under the old ones would be exactly the
 * unfair comparison this harness exists to prevent.
 */
fun main(args: Array<String>) {
    MatchEngine.ENGINE_V2 = false
    println("*** ENGINE_V2 = false (v1) ***")
    val cls = Class.forName("SceneAuditKt")
    cls.getMethod("main", Array<String>::class.java).invoke(null, args)
}
