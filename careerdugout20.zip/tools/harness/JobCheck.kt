import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** Mirrors exactly what the club picker does, for a job outside England. */
fun main() {
    for (code in listOf("GER", "BRA", "ENG")) {
        val w = World.build(20260727L)
        val s = Season(w)
        val pyramid = w.pyramidOf(code)
        val club = w.club(pyramid[0].clubIds.first())!!

        // this is takeJob(): country from the club's division, then start
        w.playerCountry = w.division(club.divisionId)?.country ?: "ENG"
        val career = Career(w, s)
        career.start(club.id, "A Manager", "ENG")

        val mine = s.fixtures.count { it.homeId == club.id || it.awayId == club.id }
        val league = s.fixtures.count { it.divisionId == club.divisionId }
        val next = s.nextUserFixture()
        val opp = next?.let { f ->
            val o = if (f.homeId == club.id) f.awayId else f.homeId
            w.club(o)?.name
        }
        println(String.format("%-4s %-26s %-28s %3d fixtures, league has %3d",
            code, club.name, pyramid[0].name, mine, league))
        println(String.format("     first up: %s   objectives set: %d", opp ?: "none", career.objectives.size))

        // and it survives a save
        val ctx = Context()
        Save.write(ctx, w, s, career)
        val back = Save.read(ctx)
        println(String.format("     reloads as %s, user club %s",
            back?.world?.playerCountry, back?.world?.club(club.id)?.name))
        println()
    }
}
