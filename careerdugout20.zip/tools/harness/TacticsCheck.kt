import com.dugout.career.core.Formations
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Do the tactical controls actually move the numbers the match is decided on? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w)
    val club = w.club(w.divisions[0].clubIds.first())!!
    val career = Career(w, s)
    career.start(club.id, "A Manager", "ENG")
    val t = club.tactics

    fun show(label: String) {
        val r = w.teamRating(club, true)
        println(String.format("%-30s atk %5.1f  def %5.1f  ctl %5.1f  (familiarity %.0f)",
            label, r.attack, r.defence, r.control, t.familiarity))
    }

    println("=== every control, measured ===")
    show("as picked")
    t.mentality = 0; show("very defensive")
    t.mentality = 4; show("very attacking")
    t.mentality = 2
    t.press = 2; show("press high")
    t.press = 1
    t.line = 0; show("deep line")
    t.line = 2; show("high line")
    t.line = 1
    t.timeWasting = 2; show("waste time")
    t.timeWasting = 1
    t.playOut = true; show("play out from the back")
    t.playOut = false
    t.tempo = 2; show("high tempo")
    t.tempo = 1

    println()
    println("=== familiarity: the cost of chopping and changing ===")
    t.familiarity = 100.0; t.familiarWith = t.formation
    show("settled in ${t.formation}")
    val other = Formations.ALL.first { it.name != t.formation && !it.name.startsWith(t.formation.substringBefore('-')) }
    t.changeFormation(other.name)
    show("just switched to ${other.name}")
    for (wk in 1..6) { w.week = wk; career.advanceWeek() }
    show("six weeks of work")
    career.trainingFocus = 6
    for (wk in 7..12) { w.week = wk; career.advanceWeek() }
    show("six more, drilling the shape")
}
