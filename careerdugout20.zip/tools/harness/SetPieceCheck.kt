import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Do the corner routines actually change what happens? */
fun main() {
    val labels = arrayOf("Near post", "Far post (default)", "Work it short", "Edge of the box")
    println("=== 300 matches per routine, user side only ===")
    println(String.format("%-20s %8s %8s %10s", "routine", "goals", "conceded", "corners"))
    for (r in 0..3) {
        for (men in intArrayOf(1)) {
            var gf = 0; var ga = 0; var corners = 0; var n = 0
            for (seed in 0 until 450) {
                val w = World.build(4000L + seed)
                val s = Season(w); s.buildCalendar()
                val fx = s.fixtures.first { it.comp == 0 }
                w.club(fx.homeId)!!.tactics.cornerRoutine = r
                w.club(fx.homeId)!!.tactics.cornerMen = men
                val m = MatchEngine(w, s, fx)
                m.replaysEnabled = false
                m.speed = 6f
                m.start()
                var guard = 0
                while (!m.finished && guard++ < 200_000) m.update(1f / 36f)
                gf += m.score[0]; ga += m.score[1]; corners += m.corners[0]; n++
            }
            println(String.format("%-20s %8.2f %8.2f %10.2f",
                labels[r], gf.toDouble() / n, ga.toDouble() / n, corners.toDouble() / n))
        }
    }
    // and the cost of sending everyone up
    println()
    println(String.format("%-20s %8s %8s", "men up (far post)", "goals", "conceded"))
    for (men in 0..2) {
        var gf = 0; var ga = 0; var n = 0
        for (seed in 0 until 450) {
            val w = World.build(4000L + seed)
            val s = Season(w); s.buildCalendar()
            val fx = s.fixtures.first { it.comp == 0 }
            w.club(fx.homeId)!!.tactics.cornerMen = men
            val m = MatchEngine(w, s, fx)
            m.replaysEnabled = false
            m.speed = 6f
            m.start()
            var guard = 0
            while (!m.finished && guard++ < 200_000) m.update(1f / 36f)
            gf += m.score[0]; ga += m.score[1]; n++
        }
        println(String.format("%-20s %8.2f %8.2f",
            arrayOf("Keep men back", "Normal", "Everyone up")[men],
            gf.toDouble() / n, ga.toDouble() / n))
    }
}
