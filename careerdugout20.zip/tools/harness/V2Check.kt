import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- engine v2 against v1, same fixtures, same seeds.
 *
 * The acceptance table from docs/ENGINE_V2.md, both cores in one run so there
 * is a control row rather than a number remembered from a previous session.
 */
private class Row(val label: String, val v2: Boolean) {
    var frames = 0L; var inFlight = 0L; var atFeet = 0L; var loose = 0L
    var nearestSum = 0.0; var nearestN = 0L
    var carrierPressed = 0.0; var carrierSecs = 0.0
    var goals = 0L; var shots = 0L; var matches = 0L
    var tackles = 0L; var fouls = 0L; var corners = 0L
    var stuck = 0L

    fun run(n: Int) {
        MatchEngine.ENGINE_V2 = v2
        val dt = 1f / 36f
        for (i in 0 until n) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false
            m.start()
            var guard = 0
            while (!m.finished && guard++ < 900_000) {
                m.update(dt)
                m.sound.clear()
                frames++
                if (m.ball.t < 1f) inFlight++
                else if (m.ball.holder != null) atFeet++
                else loose++

                val att = m.possessionSide
                val opp = m.players.filter { it.onPitch && it.side != att && it.pos != Pos.GK }
                val d = opp.minOfOrNull {
                    Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(),
                        ((it.y - m.ball.y) * 0.68).toDouble())
                } ?: 99.0
                nearestSum += d; nearestN++

                val h = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
                if (h != null && h.pos != Pos.GK) {
                    carrierSecs += dt.toDouble()
                    val dh = opp.minOfOrNull {
                        Math.hypot(((it.x - h.x) * 1.05).toDouble(),
                            ((it.y - h.y) * 0.68).toDouble())
                    } ?: 99.0
                    if (dh < 2.0) carrierPressed += dt.toDouble()
                }
            }
            if (guard >= 900_000) stuck++
            goals += m.score[0] + m.score[1]
            shots += m.shots[0] + m.shots[1]
            tackles += m.players.sumOf { it.tackles }.toLong()
            fouls += m.fouls[0] + m.fouls[1]
            corners += m.corners[0] + m.corners[1]
            matches++
        }
        MatchEngine.ENGINE_V2 = false
    }

    fun print() {
        val mm = maxOf(1L, matches)
        println(String.format("%-8s %8.1f%% %8.1f%% %8.1f%% %9.2f %9.1f%% %8.2f %8.1f %8.1f %8.1f %8.1f %6d",
            label,
            100.0 * inFlight / maxOf(1L, frames),
            100.0 * atFeet / maxOf(1L, frames),
            100.0 * loose / maxOf(1L, frames),
            nearestSum / maxOf(1L, nearestN),
            100.0 * carrierPressed / maxOf(1.0, carrierSecs),
            goals.toDouble() / mm, shots.toDouble() / mm,
            tackles.toDouble() / mm, fouls.toDouble() / mm,
            corners.toDouble() / mm, stuck))
    }
}

fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 10
    println("=== engine v2 against v1, same seeds ($n matches each) ===")
    println(String.format("%-8s %9s %9s %9s %9s %10s %8s %8s %8s %8s %8s %6s",
        "", "inFlight", "at feet", "loose", "nearest", "carrier", "goals", "shots",
        "tackles", "fouls", "corners", "stuck"))
    println(String.format("%-8s %9s %9s %9s %9s %10s %8s %8s %8s %8s %8s %6s",
        "", "", "", "", "opp m", "pressed", "/match", "/match", "/match", "/match", "/match", ""))
    val a = Row("v1", false); a.run(n); a.print()
    val b = Row("v2", true); b.run(n); b.print()
    println()
    println("targets: inFlight under 30%, at feet over 45%, nearest 3-5 m,")
    println("carrier pressed most of the time, goals 2.5-2.7, 'stuck' zero.")
}
