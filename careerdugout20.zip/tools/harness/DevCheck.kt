import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Does a young player actually get better, season on season? */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world)
    season.buildCalendar()
    val club = world.divisions[0].clubIds.first().let { world.club(it)!! }
    club.isUser = true
    world.userClubId = club.id
    val career = Career(world, season)
    career.intensity = 1

    // follow the four youngest with real headroom
    val watched = club.squad.mapNotNull { world.player(it) }
        .filter { it.age <= 20 }
        .sortedByDescending { it.potential - it.overall() }
        .take(4)
    if (watched.isEmpty()) { println("no youngsters in this squad"); return }

    println("=== youth development ===")
    println(String.format("%-26s %4s %5s %5s", "player", "age", "ovr", "pot"))
    for (p in watched) println(String.format("%-26s %4d %5d %5d", p.full, p.age, p.overall(), p.potential))

    val trace = watched.map { arrayListOf(it.overall()) }
    for (yr in 1..5) {
        for (wk in 1..38) {
            world.week = wk
            for (p in watched) p.minutes += 70     // a regular starter
            career.applyTraining()
        }
        season.rolloverPlayers()
        world.season++
        for (i in watched.indices) trace[i].add(watched[i].overall())
    }
    println()
    println(String.format("%-26s %s", "player", "overall by season  (start -> +5 yrs)"))
    for (i in watched.indices) {
        val p = watched[i]
        println(String.format("%-26s %s   pot %d", p.full, trace[i].joinToString(" -> "), p.potential))
    }
    val gained = watched.indices.sumOf { trace[it].last() - trace[it].first() }
    println()
    println(String.format("mean gain over five seasons: %.1f overall points", gained.toDouble() / watched.size))
    println(String.format("youth development reports filed: %d",
        career.news.count { it.kind == 5 }))
}
