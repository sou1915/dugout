import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Do dribbles happen, and does a week actually have something to show for it? */
fun main() {
    val w = World.build(20260727L)
    val s = Season(w); s.buildCalendar()
    val club = w.club(w.divisions[0].clubIds.first())!!
    val career = Career(w, s)
    career.start(club.id, "A Manager", "ENG")

    val m = MatchEngine(w, s, s.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    var dribbleLines = 0
    for (i in 0 until 60000) {
        m.update(1f / 36f)
        if (m.finished) break
    }
    val total = m.players.sumOf { it.dribbles }
    val best = m.players.maxByOrNull { it.dribbles }
    println("=== one match ===")
    println("take-ons: $total, most by ${best?.name} with ${best?.dribbles}")
    println("commentary mentioning a beaten man:")
    for (f in m.feed.filter { it.text.contains(" past ") || it.text.contains("nutmeg") ||
            it.text.contains("stepover") || it.text.contains("left for dead") }.take(3))
        println("  ${f.minute}'  ${f.text}")

    println()
    println("=== a week between matches ===")
    for (wk in 1..6) { w.week = wk; career.advanceWeek() }
    val b = career.briefing()
    println("briefing items: ${b.size}")
    for (x in b.take(6)) println("  ${if (x.urgent) "!" else " "} ${x.title}")
}
