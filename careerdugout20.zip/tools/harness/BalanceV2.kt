import com.dugout.career.sim.MatchEngine

/**
 * BalanceBig, pointed at engine v2.
 *
 * Same 9,120 matches and the same seeds, so the figure is directly comparable
 * with the v1 number BalanceBigKt prints. Reflection rather than a call into
 * BalanceBig's main, so that harness stays exactly as it is.
 */
fun main(args: Array<String>) {
    MatchEngine.ENGINE_V2 = true
    println("*** ENGINE_V2 = true ***")
    val cls = Class.forName("BalanceBigKt")
    val m = cls.getMethod("main", Array<String>::class.java)
    m.invoke(null, args)
}
