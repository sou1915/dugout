import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How fast the players actually move, in metres per second of wall clock.
 * The pitch is 100 units across its 105 m length, so one x-unit is 1.05 m.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start()

    val dt = 1f / 36f
    val last = HashMap<String, Pair<Float, Float>>()
    var samples = 0
    var sum = 0.0
    var peak = 0.0
    val buckets = DoubleArray(5)
    val counts = IntArray(5)

    for (i in 0 until 6000) {
        for (p in m.players) if (p.onPitch) last[p.key] = Pair(p.x, p.y)
        m.update(dt)
        if (i < 200) continue
        for (p in m.players) {
            if (!p.onPitch) continue
            val prev = last[p.key] ?: continue
            val dx = (p.x - prev.first) * 1.05
            val dy = (p.y - prev.second) * 0.68
            val mps = Math.sqrt(dx * dx + dy * dy) / dt
            if (mps > 40) continue                        // teleports on a restart
            sum += mps; samples++
            if (mps > peak) peak = mps
            val dB = Math.hypot((m.ball.x - p.x).toDouble(), (m.ball.y - p.y).toDouble())
            val b = when { dB < 14 -> 0; dB < 30 -> 1; dB < 50 -> 2; else -> 3 }
            buckets[b] += mps; counts[b]++
        }
        if (m.finished) break
    }
    println("=== player speed, metres per second ===")
    println(String.format("mean across all outfield play  %.2f m/s", sum / samples))
    println(String.format("fastest seen                   %.2f m/s", peak))
    println()
    val names = arrayOf("within 14 units of ball", "14 - 30 units", "30 - 50 units", "far side")
    for (b in 0 until 4) if (counts[b] > 0)
        println(String.format("%-26s %.2f m/s", names[b], buckets[b] / counts[b]))
    println()
    println("for reference: a match average is about 2 m/s, a hard sprint 8 - 9 m/s")
}
