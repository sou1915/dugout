import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** Exactly what the "start with nothing" button does, step by step. */
fun main() {
    println("building world...")
    val w = World.build(20260727L)
    println("  ${w.clubs.size} clubs, ${w.players.size} players")

    println("assigning faces...")
    com.dugout.career.ui.Face.assignAll(w.players.values)

    println("creating season...")
    val s = Season(w)

    println("creating career with no club...")
    val car = Career(w, s)
    w.managerName = "A Manager"
    w.managerNation = "ENG"
    w.userClubId = -1
    w.managerRep = w.profile.ageInfo.startingRep
    println("  unemployed = ${w.unemployed}, rep ${w.managerRep}")

    println("autosaving with no club...")
    val ctx = Context()
    val ok = Save.write(ctx, w, s, car)
    println("  write returned $ok")

    println("reading it back...")
    val back = Save.read(ctx)
    println("  read returned ${back != null}, unemployed ${back?.world?.unemployed}")

    println("listing vacancies...")
    val v = car.vacancies()
    println("  ${v.size} jobs")

    println("all steps completed")
}
