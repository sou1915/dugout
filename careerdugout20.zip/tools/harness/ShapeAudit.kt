import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * DO THE TWENTY TWO MOVE LIKE A TEAM, OR LIKE A SHOAL?
 *
 * The owner, after every fix so far: the players still move wrongly. He is
 * right and nothing in this folder measured it. `MotionCheck` measures
 * SMOOTHNESS -- turn rates, teleports -- and `GaitSpread` measures EFFORT --
 * how much walking against sprinting. Both can be perfect while all ten
 * outfielders drift across the pitch together in a clump, which is the thing
 * the eye actually reads as wrong.
 *
 * So this measures SHAPE and INDEPENDENCE, against figures from the real game:
 *
 *   distance covered   10-11 km a man, 90 minutes
 *   team width         35-45 m between the widest two, in possession
 *   team depth         30-40 m between the deepest and highest
 *   nearest team mate  15-20 m on average; under 3 m is two men in one place
 *   togetherness       the mean pairwise cosine of ten men's velocities. A real
 *                      team is around 0.2-0.3: they mostly move the same way
 *                      because play has a direction, but each man has his own
 *                      job. At 0.7+ they are one object being dragged.
 *   slot lock          share of the match a man spends within 5 m of the spot
 *                      his formation drew for him. A footballer is nowhere
 *                      near his "position" most of the time.
 *
 * Pitch units are not metres: 1 x-unit = 1.05 m, 1 y-unit = 0.68 m. Everything
 * below is converted, because a shape audit in the wrong units is worse than
 * none -- it looks quantitative and is off by a third on one axis.
 */
private const val MX = 1.05
private const val MY = 0.68

private fun m(ax: Float, ay: Float, bx: Float, by: Float) =
    hypot((ax - bx) * MX, (ay - by) * MY)

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 8
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var covered = 0.0; var coveredN = 0.0
    var width = 0.0; var depth = 0.0; var shapeN = 0.0
    var nearest = 0.0; var nearestN = 0.0
    var crowded = 0.0                 // frames where two men are inside 3 m
    var together = 0.0; var togetherN = 0.0
    var slotLock = 0.0; var slotN = 0.0
    var still = 0.0; var stillN = 0.0
    var wall = 0.0                    // seconds of animation, not match minutes

    for (i in 0 until matches) {
        val mm = MatchEngine(world, season, league[i % league.size])
        mm.replaysEnabled = false
        mm.start()
        val last = HashMap<String, Pair<Float, Float>>()
        val vel = HashMap<String, Pair<Double, Double>>()
        var guard = 0
        var frames = 0
        while (!mm.finished && guard++ < 300_000) {
            mm.update(dt); mm.sound.clear()
            if (mm.finished) break
            frames++
            wall += dt

            /*
             * Distance covered, and the velocity every other figure here needs.
             *
             * `LivePlayer.vx/vy` say "Engine v3 integrates this" and that is
             * exactly true: under ENGINE_V2 nothing ever writes them, so the
             * first version of this harness read a togetherness of NaN off
             * twenty two zero vectors. One more piece of correct code on a
             * path that does not run. Velocity is taken from where the man
             * actually was a frame ago instead.
             */
            for (p in mm.players) {
                if (!p.onPitch) continue
                val prev = last[p.key]
                if (prev != null) {
                    covered += m(p.x, p.y, prev.first, prev.second)
                    vel[p.key] = ((p.x - prev.first) * MX / dt) to ((p.y - prev.second) * MY / dt)
                }
                last[p.key] = p.x to p.y
            }

            // the rest on a slower sample: shape does not change in 1/36 s
            if (frames % 12 != 0) continue

            for (side in 0..1) {
                val out = mm.players.filter {
                    it.onPitch && it.side == side && it.pos != Pos.GK
                }
                if (out.size < 6) continue
                shapeN++
                width += (out.maxOf { it.y } - out.minOf { it.y }) * MY
                depth += (out.maxOf { it.x } - out.minOf { it.x }) * MX

                for (p in out) {
                    val d = out.filter { it.key != p.key }
                        .minOf { m(p.x, p.y, it.x, it.y) }
                    nearest += d; nearestN++
                    if (d < 3.0) crowded++
                    // his formation slot, and whether he ever leaves it
                    slotN++
                    if (m(p.x, p.y, p.baseX, p.baseY) < 5.0) slotLock++
                    stillN++
                    if (p.speedNow < 0.15f) still++
                }

                /*
                 * TOGETHERNESS. Every pair of outfielders, the cosine of the
                 * angle between their velocities. One number for "are these
                 * ten men doing ten things or one thing".
                 */
                var sum = 0.0; var pairs = 0
                for (a in out.indices) for (b in a + 1 until out.size) {
                    val p = out[a]; val q = out[b]
                    val pv = vel[p.key] ?: continue
                    val qv = vel[q.key] ?: continue
                    val pa = hypot(pv.first, pv.second)
                    val qa = hypot(qv.first, qv.second)
                    if (pa < 0.5 || qa < 0.5) continue     // a standing man has no direction
                    sum += (pv.first * qv.first + pv.second * qv.second) / (pa * qa)
                    pairs++
                }
                if (pairs > 0) { together += sum / pairs; togetherN++ }
            }
        }
        coveredN += mm.players.count { it.onPitch }.toDouble()
    }

    println("=== shape and independence, $matches matches ===")
    println()
    println(String.format("  %-34s %9s   %s", "", "measured", "a real match"))
    /*
     * A MATCH HERE IS 402 SECONDS OF ANIMATION, NOT 5,400.
     *
     * The first run of this reported 1.0 km a man against a real 10-11 and it
     * looked like the defect of the year. It is not a defect at all: the men
     * are only ALIVE for the wall clock, which the speed control compresses,
     * while the match clock runs ninety minutes. Comparing the two directly is
     * an arithmetic mistake dressed up as a measurement.
     *
     * So: metres per second of animation, and the same figure scaled to a real
     * ninety minutes, which is the only honest way to put it beside 10 km.
     */
    // `covered` and `wall` are both totals across every match, so they divide
    // straight into each other; only the head count needs the per-match mean.
    val mps = covered / wall / (coveredN / matches)
    println(String.format("  %-34s %8.2f m/s  %s",
        "average speed, per man", mps, "1.9 m/s (10.5 km / 90 min)"))
    println(String.format("  %-34s %8.1f km   %s",
        "  the same, over a full 90 minutes", mps * 5400.0 / 1000.0, "10 - 11 km"))
    println(String.format("  %-34s %8.1f m    %s",
        "team width", width / shapeN, "35 - 45 m"))
    println(String.format("  %-34s %8.1f m    %s",
        "team depth", depth / shapeN, "30 - 40 m"))
    println(String.format("  %-34s %8.1f m    %s",
        "nearest team mate", nearest / nearestN, "15 - 20 m"))
    println(String.format("  %-34s %8.1f%%    %s",
        "two men inside 3 m of each other", 100.0 * crowded / nearestN, "rare"))
    println(String.format("  %-34s %8.2f     %s",
        "togetherness (pairwise cosine)", together / togetherN, "0.2 - 0.3"))
    println(String.format("  %-34s %8.1f%%    %s",
        "within 5 m of his formation slot", 100.0 * slotLock / slotN, "a small share"))
    println(String.format("  %-34s %8.1f%%    %s",
        "standing still", 100.0 * still / stillN, "some"))
    println()
    println("Togetherness is the one to read first. MotionCheck can say every man")
    println("turns smoothly and GaitSpread can say the effort mix is right while")
    println("all ten of them do the same smooth thing at the same time, which is")
    println("what a shoal looks like and is not what a team looks like.")
}
