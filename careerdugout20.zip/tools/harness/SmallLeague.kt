import com.dugout.career.core.World
import com.dugout.career.core.tiersOf
import com.dugout.career.sim.Season

/**
 * A career in a country that has only one division.
 *
 * Every country used to have three tiers, so the promotion ladder, the fixture
 * builder and the season roll had never seen a pyramid with nothing above or
 * below it. The ladder pairs adjacent divisions, so a one division country has
 * no pairs at all and nobody should move; the fixture builder has to give ten
 * clubs a full calendar. This walks a whole season in one and checks both.
 */
fun main(args: Array<String>) {
    val codes = args.toList().ifEmpty { listOf("ISL", "QAT", "WAL", "AUS", "CHN") }
    for (code in codes) {
        val w = World.build(20260727L)
        w.playerCountry = code
        val pyramid = w.pyramidOf(code)
        val top = pyramid.first()
        val club = w.club(top.clubIds.first())!!
        club.isUser = true
        w.userClubId = club.id
        val season = Season(w)
        season.buildCalendar()

        val own = season.fixtures.filter { it.comp == 0 && it.divisionId == top.id }
        print(String.format("%-4s tiers %d  clubs %2d  fixtures %3d  ",
            code, tiersOf(code), top.clubIds.size, own.size))

        var guard = 0
        var wk = 1
        while (wk <= 60 && guard++ < 200) {
            w.week = wk
            season.simWeek(wk, -1)
            wk++
        }
        val table = season.table(top.id)
        val played = own.count { it.played }
        val pts = table.sumOf { it.points }
        val gf = table.sumOf { it.goalsFor }
        val ga = table.sumOf { it.goalsAgainst }
        print(String.format("played %3d  ", played))

        // Only this country's clubs. The English pyramid promotes and
        // relegates twenty four clubs every year whatever else is going on, so
        // counting moves across the whole world says nothing.
        val mine = w.clubs.filter { w.division(it.divisionId)?.country == code }.map { it.id }.toSet()
        val before = w.clubs.associate { it.id to it.divisionId }
        season.endSeason()
        val moved = w.clubs.count { it.id in mine && before[it.id] != it.divisionId }
        val orphan = w.clubs.count { w.division(it.divisionId) == null }
        val stillIn = w.division(top.id)?.clubIds?.size ?: -1

        // Two up and two down between every adjacent pair, so a one division
        // country must move nobody at all and a three division one moves eight.
        val expectMoved = (tiersOf(code) - 1) * 4
        val ok = played == own.size && gf == ga && pts > 0 &&
                moved == expectMoved && orphan == 0 && stillIn == top.clubIds.size
        println(String.format("goals %3d  moved %d  orphans %d  in league %2d  %s",
            gf, moved, orphan, stillIn, if (ok) "ok" else "FAIL"))
    }
}
