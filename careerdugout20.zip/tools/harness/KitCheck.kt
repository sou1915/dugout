import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView

/** Can you actually pick the keeper out from his own outfield players? */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.start()
    m.danger = 1f
    m.shake = 0f

    // put a keeper and an outfielder of the same side side by side
    for (p in m.players) p.onPitch = false
    val gk = m.players.first { it.side == 0 && it.pos == Pos.GK }
    val out = m.players.first { it.side == 0 && it.pos != Pos.GK }
    for (p in listOf(gk, out)) {
        p.onPitch = true
        p.action = Act.RUN
        p.speedNow = 0f
        p.facing = (Math.PI / 2).toFloat()
        p.y = 50f
    }
    gk.x = 44f
    out.x = 56f
    m.ball.holder = null; m.ball.x = 20f; m.ball.y = 90f
    m.refCard = 0; m.banner = null; m.celebrateKey = null

    val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(Context(), m)
    v.followBall = false
    repeat(40) { v.renderAt(c, 1280, 720) }
    v.renderAt(c, 1280, 720)
    javax.imageio.ImageIO.write(bmp.image, "png", java.io.File("out/kit_check.png"))

    // find the two figures by differencing against the empty pitch, then take
    // the commonest shirt colour inside each blob. Guessing screen coordinates
    // does not work: the camera clamps and squashes.
    for (p in listOf(gk, out)) p.onPitch = false
    val bmp2 = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
    val c2 = Canvas(bmp2)
    val v2 = MatchView(Context(), m)
    v2.followBall = false
    repeat(40) { v2.renderAt(c2, 1280, 720) }
    v2.renderAt(c2, 1280, 720)
    for (p in listOf(gk, out)) p.onPitch = true

    fun dominant(xFrom: Int, xTo: Int): Triple<Int, Int, Int> {
        val counts = HashMap<Int, Int>()
        for (y in 0 until 720) {
            for (x in xFrom until xTo) {
                val a1 = bmp.image.getRGB(x, y)
                val b1 = bmp2.image.getRGB(x, y)
                val dr = ((a1 shr 16) and 0xFF) - ((b1 shr 16) and 0xFF)
                val dg = ((a1 shr 8) and 0xFF) - ((b1 shr 8) and 0xFF)
                val db = (a1 and 0xFF) - (b1 and 0xFF)
                if (maxOf(Math.abs(dr), Math.abs(dg), Math.abs(db)) < 30) continue
                val rgb = a1 and 0xFFFFFF
                val r = (rgb shr 16) and 0xFF; val g = (rgb shr 8) and 0xFF; val bb = rgb and 0xFF
                // skip skin, boots, socks white and near black
                if (r > 150 && g in 90..200 && bb in 60..160) continue
                if (r + g + bb < 120 || r + g + bb > 700) continue
                counts[rgb] = (counts[rgb] ?: 0) + 1
            }
        }
        val top = counts.maxByOrNull { it.value }?.key ?: 0
        return Triple((top shr 16) and 0xFF, (top shr 8) and 0xFF, top and 0xFF)
    }

    val (gr, gg, gb) = dominant(0, 640)
    val (orr, og, ob) = dominant(640, 1280)
    val gap = Math.abs(gr - orr) + Math.abs(gg - og) + Math.abs(gb - ob)
    println("keeper shirt      rgb($gr, $gg, $gb)")
    println("outfield shirt    rgb($orr, $og, $ob)")
    println("difference        $gap  (over about 90 means they read as different kits)")
}
