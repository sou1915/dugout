import com.dugout.career.core.World
import com.dugout.career.sim.Season

fun main() {
    val t0 = System.nanoTime()
    val w = World.build(20260727L)
    val ms = (System.nanoTime() - t0) / 1e6
    println(String.format("world built in %.0f ms: %d clubs, %d players", ms, w.clubs.size, w.players.size))

    val names = w.clubs.map { it.name }
    val dupClubs = names.size - names.toSet().size
    val pnames = w.players.values.map { it.full }
    val dupPlayers = pnames.size - pnames.toSet().size
    println("duplicate club names: $dupClubs      duplicate player names: $dupPlayers")

    val shorts = w.clubs.map { it.shortName }
    println("distinct short codes: ${shorts.toSet().size} of ${shorts.size}")

    // every club must sit in exactly one division
    val orphan = w.clubs.count { c -> w.division(c.divisionId) == null }
    println("clubs with no division: $orphan")
    val mismatched = w.allDivisions().sumOf { d -> d.clubIds.count { w.club(it)?.divisionId != d.id } }
    println("clubs listed in the wrong division: $mismatched")

    println()
    for (code in w.playableCountries()) {
        val py = w.pyramidOf(code)
        val clubs = py.sumOf { it.clubIds.size }
        val sample = py.firstOrNull()?.clubIds?.firstOrNull()?.let { w.club(it)?.name } ?: "-"
        println(String.format("%-4s %d tiers, %3d clubs   e.g. %s", code, py.size, clubs, sample))
    }

    // saves and load times scale with fixture count
    for (c in listOf("ENG", "ITA")) {
        w.playerCountry = c
        val s = Season(w); s.buildCalendar()
        println()
        println("playing in $c: ${s.fixtures.size} fixtures total")
    }
}
