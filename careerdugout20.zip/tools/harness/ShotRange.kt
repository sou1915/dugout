import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Where shots are struck from, and where GOALS are struck from.
 *
 * Reported from the device: "the players can score from before half of the
 * pitch". GoalPlace already checks where the BALL is when a goal is given, and
 * it is always on the goal line — but that is the end of the flight. Nobody
 * had ever measured where the man who hit it was standing.
 *
 * Distances are metres from the centre of the goal being attacked. The pitch
 * is 105 m long, so a shot from inside your own half is 55 m or more, and a
 * goal from there should be somewhere between rare and never: in real football
 * roughly one a season across an entire league.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L
    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }

    val shotD = ArrayList<Double>()
    val goalD = ArrayList<Double>()
    // split by what produced the shot, because a guard on open play does
    // nothing about a corner headed in by a man still in his own half
    val bySrc = HashMap<String, ArrayList<Double>>()

    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var guard = 0
        var lastShot = -1.0
        val prevShots = HashMap<String, Int>()
        for (p in m.players) prevShots[p.key] = p.shots
        while (!m.finished && guard++ < 300_000) {
            val goalsBefore = m.score[0] + m.score[1]
            m.update(1f / 36f)
            if (m.finished) break
            // The shooter is the man whose OWN shot counter went up. Finding
            // him by his pose instead picks whoever happens to be first in the
            // list with a SHOOT pose, which is not reliably the striker.
            var shooter: com.dugout.career.sim.LivePlayer? = null
            for (p in m.players) {
                val was = prevShots[p.key] ?: 0
                if (p.shots > was) { shooter = p; prevShots[p.key] = p.shots }
            }
            if (shooter != null) {
                val goalX = if (shooter.side == 0) 100f else 0f
                val d = Math.hypot(((goalX - shooter.x) * 1.05), ((50f - shooter.y) * 0.68))
                shotD.add(d)
                lastShot = d
                val src = when (m.scene) {
                    1 -> "corner"; 2 -> "penalty"; 3 -> "free kick"
                    4 -> "throw-in"; 5 -> "goal kick"; 6 -> "kick off"
                    8 -> "substitution"
                    else -> "open play"
                }
                bySrc.getOrPut(src) { ArrayList() }.add(d)
            }
            if (m.score[0] + m.score[1] > goalsBefore && lastShot >= 0) {
                goalD.add(lastShot)
                lastShot = -1.0
            }
        }
    }

    fun report(label: String, v: List<Double>) {
        if (v.isEmpty()) { println("$label: none"); return }
        val s = v.sorted()
        println(String.format("%-10s n=%-5d median %.1f m   mean %.1f m   longest %.1f m",
            label, v.size, s[s.size / 2], v.average(), s.last()))
        println(String.format("           inside 18 m %.0f%%   18-30 m %.0f%%   30-40 m %.0f%%   " +
            "over 40 m %.0f%%   from own half (>52.5 m) %.1f%%",
            v.count { it < 18 } * 100.0 / v.size, v.count { it in 18.0..30.0 } * 100.0 / v.size,
            v.count { it in 30.0..40.0 } * 100.0 / v.size, v.count { it > 40 } * 100.0 / v.size,
            v.count { it > 52.5 } * 100.0 / v.size))
    }

    println("=== shooting range: $matches matches, world $worldSeed ===")
    report("shots", shotD)
    report("goals", goalD)
    println()
    println()
    println("by what produced the shot:")
    for ((k, v) in bySrc.entries.sortedByDescending { it.value.size }) {
        println(String.format("  %-12s n=%-5d median %.1f m   from own half %.0f%%",
            k, v.size, v.sorted()[v.size / 2], v.count { it > 52.5 } * 100.0 / v.size))
    }
    println()
    println("real football: most shots come from 12-25 m, the median goal from about")
    println("11 m, and a goal from inside your own half is a highlight of the decade.")
}
