import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * LOOK AT A GOAL, AND AT WHAT HAPPENS AFTER IT.
 *
 * Two things the owner reported that no aggregate can see: the replay never
 * shows the ball going into the net, and there is no restart from the centre
 * circle after a goal. Both are now claimed fixed, and the project's own rule
 * is that a visual change is not fixed until somebody has looked at the frames.
 *
 * This films the run-up to the first goal of a match and then the thirty
 * seconds after it, so the strike, the ball crossing the line, the celebration
 * and the kick-off are all in one strip.
 *
 *   java -cp build/h.jar GoalFilmKt [seed]
 */
fun main(args: Array<String>) {
    val seed = args.firstOrNull()?.toLongOrNull() ?: 20260727L
    val m = newEngine(seed)
    m.replaysEnabled = false
    m.start()

    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(android.content.Context(), m)
    val closeField = MatchView::class.java.getDeclaredField("closeUp")
    closeField.isAccessible = true

    File("out/goal").mkdirs()
    println("=== the first goal, frame by frame ===")
    println(String.format("%-5s %-6s %-8s %-26s %s", "file", "min", "score", "ball", "scene"))

    var taken = 0
    var guard = 0
    // Frames before the goal cannot be known to be interesting until the goal
    // happens, so the run-up is filmed by replaying: first find when it is.
    var goalFrame = -1
    run {
        val probe = newEngine(seed)
        probe.replaysEnabled = false
        probe.start()
        var f = 0
        while (!probe.finished && f < 300_000) {
            probe.update(1f / 36f); probe.sound.clear()
            f++
            if (probe.score[0] + probe.score[1] > 0) { goalFrame = f; break }
        }
    }
    if (goalFrame < 0) { println("no goal in this match; try another seed"); return }

    val from = goalFrame - 30      // most of a second before it is given
    val to = goalFrame + 36 * 26   // and the celebration and restart after it

    var f = 0
    while (!m.finished && guard++ < 300_000 && f <= to) {
        m.update(1f / 36f); m.sound.clear()
        if (m.finished) break
        f++
        if (f < from) continue
        // dense through the strike, then one frame a second
        val dense = f <= goalFrame + 12
        if (!dense && (f - goalFrame) % 36 != 0) continue

        closeField.setFloat(v, 1f)
        v.renderAt(c, W, H)
        taken++
        val name = String.format("out/goal/%02d.png", taken)
        stampFrame(c, W.toFloat(), H.toFloat())
        ImageIO.write(bmp.image, "png", File(name))

        val past = if (m.ball.x > 50f) m.ball.x - 100f else -m.ball.x
        val sx = com.dugout.career.ui.lastBallSX
        val sy = com.dugout.career.ui.lastBallSY
        println(String.format("%-5d %-6.1f %-8s %-26s %s  screen (%.0f,%.0f)", taken, m.clock,
            "${m.score[0]}-${m.score[1]}",
            String.format("(%.1f,%.1f) %s the line", m.ball.x, m.ball.y,
                if (past > 0f) String.format("%.1f past", past) else "short of"),
            com.dugout.career.sim.Scene.LABEL[m.scene].ifEmpty { "open play" }, sx, sy))
    }
    println()
    println("written to out/goal/. The ball must be seen INSIDE the net, and the")
    println("restart must be seen on the centre spot with both sides in their half.")
}
