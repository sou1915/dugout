import com.dugout.career.core.*
import com.dugout.career.sim.Career
import com.dugout.career.sim.Season

/** Does the signing verdict actually vary with what you did? */
fun main() {
    println(String.format("%-34s %-12s %-12s %s", "signing", "board", "fans", "squad"))
    for (case in listOf("bargain star", "wild overpay", "squad filler", "teenager")) {
        val w = World.build(20260727L)
        val s = Season(w); s.buildCalendar()
        val c = w.club(w.divisions[0].clubIds.first())!!
        val car = Career(w, s); car.start(c.id, "M", "ENG")
        c.balance = 500_000_000L; c.transferBudget = 300_000_000L; c.wageBudget = 4_000_000

        val pool = w.players.values.filter { it.clubId != c.id && it.clubId >= 0 }
        val p = when (case) {
            "bargain star" -> pool.filter { it.overall() >= 84 }.maxByOrNull { it.overall() }
            "wild overpay" -> pool.filter { it.overall() in 60..66 }.firstOrNull()
            "squad filler" -> pool.filter { it.overall() in 68..72 }.firstOrNull()
            else -> pool.filter { it.age <= 19 && it.potential >= 84 }.firstOrNull()
        } ?: continue
        val fee = when (case) {
            "bargain star" -> (p.value() * 0.6).toLong()
            "wild overpay" -> (p.value() * 2.2).toLong()
            else -> p.value()
        }
        val before = w.squadRating(c)
        val v = car.verdictOn(p, fee, before)
        fun mood(m: Int) = when (m) { 2 -> "delighted"; 1 -> "pleased"; 0 -> "neutral"; -1 -> "unimpressed"; else -> "furious" }
        println(String.format("%-34s %-12s %-12s %s",
            "$case: ${p.overall()} for ${Fmt.money(fee)}", mood(v.boardMood), mood(v.fanMood),
            if (v.slotsStraightIn) "straight in" else "competition"))
        if (v.riskLine != null) println("      warning: ${v.riskLine}")
    }
}
