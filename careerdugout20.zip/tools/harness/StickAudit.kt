import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * The ball sits a mean 0.50 m from the man in possession and the README claims
 * 0.32 m, with a worst case of 2.70 m against a real figure of about 0.6 m.
 * A mean can move because everything drifted or because a few frames are very
 * wrong, and the fix is different in each case, so profile it.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    val buckets = IntArray(14)
    var held = 0; var sum = 0.0
    var bySpeed = DoubleArray(5); var nSpeed = IntArray(5)
    var px = 0f; var py = 0f
    for (match in 0 until matches) {
    val m = MatchEngine(world, season, league[match % league.size])
    m.replaysEnabled = false
    m.start()
    for (i in 0 until 8000) {
        m.update(dt)
        if (m.finished) break
        if (i < 200) continue
        val h = m.ball.holder ?: continue
        if (m.ball.t < 1f) continue
        val p = m.players.firstOrNull { it.key == h } ?: continue
        val dx = (m.ball.x - p.x) * 1.05
        val dy = (m.ball.y - p.y) * 0.68
        val d = Math.sqrt(dx * dx + dy * dy)
        held++; sum += d
        buckets[minOf(13, (d * 4).toInt())]++
        // how fast is he moving? a ball should trail further at a sprint
        val sp = Math.sqrt(((p.x - px) * 1.05).toDouble() * ((p.x - px) * 1.05) +
                ((p.y - py) * 0.68).toDouble() * ((p.y - py) * 0.68)) / dt
        px = p.x; py = p.y
        val b = minOf(4, (sp / 2).toInt())
        bySpeed[b] += d; nSpeed[b]++
    }
    }
    println(String.format("held frames %d, mean %.2f m", held, sum / held))
    println()
    println("distance from his body:")
    for (b in buckets.indices) {
        if (buckets[b] == 0) continue
        val lab = if (b == 13) ">=3.25" else String.format("%.2f-%.2f", b * 0.25, b * 0.25 + 0.25)
        println(String.format("  %11s %5d %s", lab, buckets[b],
            "#".repeat(minOf(60, buckets[b] * 60 / held)))) }
    println()
    println("mean distance by how fast he is running:")
    for (b in 0 until 5) {
        if (nSpeed[b] == 0) continue
        val lab = if (b == 4) ">=8 m/s" else "${b * 2}-${b * 2 + 2} m/s"
        println(String.format("  %9s  %.2f m over %d frames", lab, bySpeed[b] / nSpeed[b], nSpeed[b]))
    }
}
