import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Do touchline orders change the match?
 *
 * Same fixture, same seed, played three ways: left alone, told to tighten up at
 * ten minutes, told to throw everyone forward. If the three come out the same
 * then the orders are decoration.
 */
fun main() {
    val n = 400
    println(String.format("%-26s %8s %10s %9s %8s", "instruction", "scored", "conceded", "shots", "ratings"))
    for (mode in 0..2) {
        var gf = 0; var ga = 0; var sh = 0
        var atkSeen = 0.0; var defSeen = 0.0
        for (seed in 0 until n) {
            val w = World.build(6000L + seed)
            val s = Season(w); s.buildCalendar()
            val fx = s.fixtures.first { it.comp == 0 }
            val m = MatchEngine(w, s, fx)
            m.replaysEnabled = false
            m.speed = 6f
            m.start()
            val home = w.club(fx.homeId)!!
            val t = home.tactics
            var applied = false
            var guard = 0
            while (!m.finished && guard++ < 200_000) {
                m.update(1f / 36f)
                if (!applied && m.clock >= 10.0) {
                    applied = true
                    when (mode) {
                        1 -> {   // tighten up
                            t.mentality = 0; t.line = 0; t.tackling = 0
                        }
                        2 -> {   // throw everyone forward
                            t.mentality = 4; t.line = 2; t.press = 2
                        }
                    }
                    if (mode != 0) m.refreshRatings()
                    if (seed == 0) {
                        // what the engine now thinks of them
                        val r = w.teamRating(home, true)
                        atkSeen = r.attack; defSeen = r.defence
                    }
                }
            }
            gf += m.score[0]; ga += m.score[1]; sh += m.shots[0]
        }
        val label = arrayOf("left alone", "tighten up", "everyone forward")[mode]
        println(String.format("%-26s %8.2f %10.2f %9.2f   %.0f/%.0f",
            label, gf.toDouble() / n, ga.toDouble() / n, sh.toDouble() / n, atkSeen, defSeen))
    }
}
