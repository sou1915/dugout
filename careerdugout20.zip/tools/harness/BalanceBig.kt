import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Goals per game in the TOP DIVISION, over enough matches to know the figure,
 * and a sweep of the one lever that moves it.
 *
 * WHY THE OLD FIGURE COULD NOT BE TUNED AGAINST. BalanceHarness plays 400
 * matches, which sounds like plenty. Goals per game is a mean of a roughly
 * Poisson count with a variance near its mean of 2.6, so 400 matches carries a
 * standard error of sqrt(2.6/400) = 0.08 goals. The brief's "2.45 / 2.52 /
 * 2.70 across three seeds" is a spread of 0.25 on a quantity measured to plus
 * or minus 0.16 at 95%: the seeds were not reliably different from each other
 * at all, and chasing that spread by moving the lever would have been chasing
 * noise. Every figure below comes with its interval, so that cannot happen
 * again.
 *
 * More matches from the same world without changing division: `world.week`
 * goes into the match seed, so replaying the same fixture list in a later week
 * gives an independent sample of the SAME division. Raising the match count on
 * BalanceHarness instead walks off the end of the top flight and into the
 * second division, which is why a long run there reads low.
 *
 *   java -cp build/h.jar BalanceBigKt              # measure as it stands
 *   java -cp build/h.jar BalanceBigKt sweep        # try values of the lever
 */
fun main(args: Array<String>) {
    val sweep = args.firstOrNull() == "sweep"
    val reps = args.getOrNull(1)?.toIntOrNull() ?: 6
    val seeds = listOf(20260727L, 5150L, 99001L, 777333L)

    if (!sweep) {
        report(MatchEngine.CHANCE_QUALITY, seeds, reps, verbose = true)
        return
    }
    println("=== sweeping chance quality, ${seeds.size} worlds x $reps seasons of the top flight ===")
    println()
    println(String.format("%-8s %8s %16s %8s %8s %8s", "quality", "goals", "95% interval", "home", "draw", "away"))
    for (q in listOf(0.113, 0.119, 0.125, 0.131)) {
        report(q, seeds, reps, verbose = false)
    }
    println()
    println("the target is a top division at 2.5 - 2.7, so the value to want is")
    println("the one whose interval sits inside that band rather than straddling it")
    // leave it as the game has it
    MatchEngine.CHANCE_QUALITY = 0.113
}

private fun report(q: Double, seeds: List<Long>, reps: Int, verbose: Boolean) {
    MatchEngine.CHANCE_QUALITY = q

    var games = 0
    var goals = 0
    var goalsSq = 0.0
    var hw = 0; var dr = 0; var aw = 0
    var cards = 0
    val perSeed = ArrayList<String>()

    for (seed in seeds) {
        val world = World.build(seed)
        val season = Season(world); season.buildCalendar()
        val top = world.divisions.first()
        val fx = season.fixtures.filter { it.comp == 0 && it.divisionId == top.id }
        var sg = 0; var sn = 0; var shw = 0

        for (week in 0 until reps) {
            // the week goes into the match seed, so this is a fresh sample of
            // the same division rather than the same matches over again
            world.week = week
            for (f in fx) {
                val m = MatchEngine(world, season, f)
                m.speed = 6f
                m.replaysEnabled = false
                m.start()
                var guard = 0
                while (!m.finished && guard++ < 200_000) {
                    m.update(1f / 30f)
                    if (!m.running && !m.finished) m.start()
                    m.sound.clear()
                }
                val g = m.score[0] + m.score[1]
                goals += g; goalsSq += (g * g).toDouble(); games++
                sg += g; sn++
                when {
                    m.score[0] > m.score[1] -> { hw++; shw++ }
                    m.score[0] == m.score[1] -> dr++
                    else -> aw++
                }
                cards += m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]
            }
        }
        perSeed.add(String.format("  seed %-9d %.2f goals over %d games, home %.0f%%",
            seed, sg.toDouble() / sn, sn, shw * 100.0 / sn))
    }

    val n = games.toDouble()
    val mean = goals / n
    val variance = goalsSq / n - mean * mean
    val ci = 1.96 * Math.sqrt(variance / n)

    if (verbose) {
        println(String.format("=== top division, %d worlds x %d seasons = %d matches ===", seeds.size, reps, games))
        println(String.format("chance quality     %.3f", q))
        println(String.format("goals per game     %.2f  +/- %.2f at 95%%   target 2.5 - 2.7", mean, ci))
        println(String.format("home wins          %.1f%%     target ~45%%", hw * 100 / n))
        println(String.format("draws              %.1f%%     target ~25%%", dr * 100 / n))
        println(String.format("away wins          %.1f%%     target ~30%%", aw * 100 / n))
        println(String.format("cards per game     %.2f", cards / n))
        println()
        perSeed.forEach { println(it) }
        println()
        val low = mean - ci; val high = mean + ci
        println(if (low >= 2.5 && high <= 2.7) "INSIDE THE TARGET BAND"
                else if (high < 2.5 || low > 2.7) "OUTSIDE THE TARGET BAND"
                else "STRADDLES THE EDGE OF THE BAND")
    } else {
        println(String.format("%-8.3f %8.2f %8.2f -%5.2f %7.0f%% %7.0f%% %7.0f%%",
            q, mean, mean - ci, mean + ci, hw * 100 / n, dr * 100 / n, aw * 100 / n))
    }
}
