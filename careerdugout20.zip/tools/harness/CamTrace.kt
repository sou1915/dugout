import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView

/** Is the pan code even running? camera x against ball x, frame by frame. */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(Context(), m)
    m.danger = 1f
    repeat(60) { v.renderAt(c, 1280, 720) }
    println("after warm-up: camX ${v.cameraX()}  ballX ${m.ball.x}")
    var moved = 0
    var prev = v.cameraX()
    for (i in 0 until 400) {
        m.update(1f / 36f)
        if (m.finished) break
        m.danger = 1f
        v.renderAt(c, 1280, 720)
        val now = v.cameraX()
        if (Math.abs(now - prev) > 0.001f) moved++
        if (i % 25 == 0) println(String.format("  f%-4d camX %6.2f  ballX %6.2f  lag %6.2f",
            i, now, m.ball.x, Math.abs(m.ball.x - now)))
        prev = now
    }
    println("frames where the camera moved at all: $moved of 400")
}
