import com.dugout.career.core.Instr
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import kotlin.math.abs

/**
 * DOES ANYTHING YOU SAY FROM THE TOUCHLINE CHANGE THE FOOTBALL?
 *
 * The owner reports that shouts, and changes made in the dugout during a match,
 * have no effect on the pitch. Both write to the same place -- the club's
 * Tactics -- so this measures that one path: play half an hour, change one
 * instruction, play on, and compare the shape against a control that changed
 * nothing on the same seed.
 *
 * Measured on the side that made the change:
 *   line     mean x of the ten outfield men, in their own attacking direction
 *            (higher = further up the pitch)
 *   width    standard deviation of their y, in units
 *   press    metres from the man on the ball to the nearest opponent
 *   territory share of frames with the ball in the opposition half
 *
 * A change that reads the same as the control in every column is a change the
 * player cannot see, whatever the toast said.
 */
private class Shape {
    var n = 0L
    var line = 0.0
    var width = 0.0
    var press = 0.0
    var pressN = 0L
    var inTheirHalf = 0L
}

private fun sample(m: MatchEngine, side: Int, s: Shape) {
    val on = m.players.filter { it.onPitch && it.side == side && it.pos != com.dugout.career.core.Pos.GK }
    if (on.isEmpty()) return
    s.n++
    // x in the side's own attacking direction, so both sides read the same way
    s.line += on.sumOf { (if (side == 0) it.x else 100f - it.x).toDouble() } / on.size
    val my = on.sumOf { it.y.toDouble() } / on.size
    s.width += Math.sqrt(on.sumOf { (it.y - my) * (it.y - my) } / on.size)
    val theirHalf = if (side == 0) m.ball.x > 50f else m.ball.x < 50f
    if (theirHalf) s.inTheirHalf++
    /*
     * The press is what THIS side does to the OTHER side's man on the ball.
     *
     * The first version of this averaged over both carriers, and that is a
     * confound rather than a measurement: a side that presses well wins the
     * ball higher and then HAS it more, in the opposition half, where the
     * opponents are not yet organised -- so its own carrier has more space and
     * the average moves the wrong way for the right reason.
     */
    val carrier = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k && it.onPitch } }
    if (carrier != null && carrier.side != side) {
        val foes = m.players.filter { it.onPitch && it.side != carrier.side }
        val d = foes.minOfOrNull {
            Math.hypot(((it.x - carrier.x) * 1.05).toDouble(), ((it.y - carrier.y) * 0.68).toDouble())
        }
        if (d != null) { s.press += d; s.pressN++ }
    }
}

private fun run(seed: Long, matches: Int, change: ((MatchEngine, Int) -> Unit)?): Shape {
    val world = World.build(seed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f
    val out = Shape()
    for (i in 0 until matches) {
        val m = MatchEngine(world, season, league[i % league.size])
        m.replaysEnabled = false
        m.start()
        var applied = false
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt); m.sound.clear()
            if (m.finished) break
            // the shout goes in at the half-hour, exactly as a manager would
            if (!applied && m.clock >= 30.0) { change?.invoke(m, 0); applied = true }
            // and only the twenty minutes AFTER it are measured
            if (m.clock >= 32.0 && m.clock <= 52.0) sample(m, 0, out)
        }
    }
    return out
}

private fun show(label: String, s: Shape, base: Shape?) {
    fun d(v: Double, b: Double?) =
        if (b == null) "" else String.format("  (%+.1f)", v - b)
    val line = s.line / s.n
    val width = s.width / s.n
    val press = if (s.pressN == 0L) 0.0 else s.press / s.pressN
    val terr = 100.0 * s.inTheirHalf / s.n
    println(String.format("  %-22s %6.1f%s %8.1f%s %8.1f%s %8.1f%%%s",
        label,
        line, d(line, base?.let { it.line / it.n }),
        width, d(width, base?.let { it.width / it.n }),
        press, d(press, base?.let { if (it.pressN == 0L) 0.0 else it.press / it.pressN }),
        terr, d(terr, base?.let { 100.0 * it.inTheirHalf / it.n })))
}

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 8
    val seed = 20260727L

    println("=== what a shout does, $matches matches, measured 32'-52' ===")
    println()
    println(String.format("  %-22s %6s %10s %10s %10s",
        "shout", "line", "width", "press m", "territory"))

    val control = run(seed, matches, null)
    show("SAY NOTHING", control, null)

    show("Push them forward", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        if (t.mentality < 4) t.mentality++
        if (t.line < 2) t.line++
        m.refreshRatings()
    }, control)

    show("Tighten up", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        if (t.mentality > 0) t.mentality--
        if (t.line > 0) t.line--
        t.tackling = 0
        m.refreshRatings()
    }, control)

    show("Get it wide", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        t.width = 2; t.focus = 3
        m.refreshRatings()
    }, control)

    show("Through the middle", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        t.width = 0; t.focus = 1
        m.refreshRatings()
    }, control)

    show("Press them", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        t.press = 2
        m.refreshRatings()
    }, control)

    show("Throw everyone up", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        t.mentality = 4; t.line = 2; t.press = 2; t.counter = false
        m.refreshRatings()
    }, control)

    show("See it out", run(seed, matches) { m, side ->
        val t = if (side == 0) m.home.tactics else m.away.tactics
        t.mentality = 0; t.line = 0; t.timeWasting = 2; t.tackling = 0
        m.refreshRatings()
    }, control)

    println()
    println("The bracket is the difference from saying nothing on the same seeds.")
    println("A shout that reads (+0.0) everywhere is one the player cannot see.")
    println("Instr.WIDTH = ${Instr.WIDTH.joinToString("/")}")
}
