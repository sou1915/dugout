import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import kotlin.math.abs

/**
 * DOES PLAY EVER GO NEAR A TOUCHLINE?
 *
 * Throw-ins read 0.6 a match against a real forty, and the obvious fix -- a
 * width term in the pass scorer -- was tried and made it WORSE (1.0 to 0.5),
 * so the cause is not that passes are aimed centrally. Before anything else is
 * changed, measure what the ball and the men actually do across the pitch.
 *
 * Per match:
 *   - where the ball spends its time, in five bands across the width
 *   - where the MEN are and where the man ON the ball is, in the same bands,
 *     so "the ball is central" can be told apart from "the men are central"
 *   - how often it gets within a yard of going out and is retrieved anyway
 *   - how many deliveries are aimed off the field at all, which turned out to
 *     be the whole answer: 1.7 a match, of which 0.5 cross
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 12
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    val band = LongArray(5)
    val menBand = LongArray(5)
    val carrierBand = LongArray(5)
    var menFrames = 0L
    var carrierFrames = 0L
    var frames = 0L
    var nearOut = 0L          // frames with the ball beyond y 95 or under 5
    var wentOut = 0           // times it actually crossed
    var retrieved = 0         // times it came back from beyond 95/5 without crossing
    var spreadSum = 0.0
    var aimedOut = 0          // strikes aimed beyond a touchline
    var aimedOutWent = 0      // ...that actually crossed one

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var wasNear = false
        var wasOut = false
        var wasAim = 50f
        var aimPending = false
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt); m.sound.clear()
            if (m.finished) break
            /*
             * ONLY LIVE PLAY COUNTS.
             *
             * The first version of this counted every frame, and read 64% of
             * the match inside the middle fifth -- a figure that barely moved
             * when the carrier was stopped from drifting infield, which is
             * what gave it away. Around a third of a match is dead ball: 20
             * goal kicks, 5 corners, 4 kick-offs and 3 celebrations, and
             * almost all of that time the ball sits on or near the centre
             * line. Counting it measured the STOPPAGES, not the football.
             */
            if (!com.dugout.career.sim.Scene.isLive(m.scene)) continue
            if (m.celebrationTime > 0f) continue
            frames++
            val y = m.ball.y
            band[(y / 20f).toInt().coerceIn(0, 4)]++
            val near = y > 95f || y < 5f
            val out = y > 98.8f || y < 1.2f
            if (near) nearOut++
            if (out && !wasOut) wentOut++
            if (wasNear && !near && !wasOut) retrieved++
            wasNear = near; wasOut = out
            // a new delivery whose AIM is off the field
            val aim = m.ball.toY
            if (aim != wasAim) {
                if (aim > 99f || aim < 1f) { aimedOut++; aimPending = true }
                else aimPending = false
                wasAim = aim
            }
            if (out && aimPending) { aimedOutWent++; aimPending = false }

            val on = m.players.filter { it.onPitch }
            if (on.isNotEmpty()) {
                val mean = on.sumOf { it.y.toDouble() } / on.size
                spreadSum += Math.sqrt(on.sumOf { (it.y - mean) * (it.y - mean) } / on.size)
                // where the MEN are, in the same bands, so "the ball is
                // central" can be separated from "the men are central"
                for (p in on) {
                    if (p.pos == com.dugout.career.core.Pos.GK) continue
                    menBand[(p.y / 20f).toInt().coerceIn(0, 4)]++
                    menFrames++
                }
            }
            // and where the man ON the ball is standing
            m.ball.holder?.let { k ->
                on.firstOrNull { it.key == k }?.let {
                    carrierBand[(it.y / 20f).toInt().coerceIn(0, 4)]++
                    carrierFrames++
                }
            }
        }
    }

    println("=== where play happens, over $matches matches ===")
    println()
    val names = arrayOf("y 0-20 (left touch)", "y 20-40", "y 40-60 (middle)", "y 60-80",
        "y 80-100 (right touch)")
    for (i in 0..4)
        println(String.format("  %-24s %5.1f%%", names[i], 100.0 * band[i] / frames))
    println()
    println("  the men, and the man on the ball, in the same bands:")
    for (i in 0..4)
        println(String.format("  %-24s men %5.1f%%   carrier %5.1f%%", names[i],
            100.0 * menBand[i] / menFrames, 100.0 * carrierBand[i] / carrierFrames))
    println()
    println(String.format("ball within a yard of out  %.1f%% of frames", 100.0 * nearOut / frames))
    println(String.format("crossed a touchline        %.2f a match", wentOut.toDouble() / matches))
    println(String.format("came back from the edge    %.2f a match", retrieved.toDouble() / matches))
    println(String.format("aimed off the field        %.2f a match", aimedOut.toDouble() / matches))
    println(String.format("  ...of which crossed      %.2f a match", aimedOutWent.toDouble() / matches))
    println(String.format("men spread across width    %.1f units sd", spreadSum / frames))
    println()
    println("The band split has NO reference figure -- an even 20/20/20/20/20 was")
    println("asserted in the first draft of this harness and is not a measured fact;")
    println("real football does play more through the middle than down either wing.")
    println("The number that IS unambiguous is the last pair: a real match has about")
    println("forty throw-ins, and almost nothing here is ever aimed out of play.")
}
