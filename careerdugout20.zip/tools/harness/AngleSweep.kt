import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.sim.Scene
import com.dugout.career.ui.BroadcastCamera
import com.dugout.career.ui.MatchView
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/**
 * The same moment, drawn from four camera angles, at the size it has to survive.
 *
 * The reference the game is aiming at looks DOWN onto the pitch; the current
 * camera depresses only 17.2 degrees to the pitch centre. Which angle is right
 * is not a thing to settle from a number, so this renders identical moments at
 * several angles and writes each one twice: full size, and downscaled to
 * 320x240.
 *
 * The downscale is the real test. The reference style exists because of a small
 * screen -- if the two sides cannot be told apart, or the ball cannot be found,
 * at 320x240, the frame fails however it looks at 1280x720.
 *
 * The camera cannot affect the simulation, so every angle renders the SAME tick
 * of the SAME match and the frames are directly comparable.
 *
 *   java -cp build/angle.jar AngleSweepKt
 */
private fun writePair(bmp: Bitmap, dir: String, name: String) {
    File(dir).mkdirs()
    ImageIO.write(bmp.image, "png", File("$dir/$name.png"))
    // 320x240 keeps the game's landscape aspect while matching the reference's
    // pixel budget; the reference itself is portrait 240x320.
    val small = BufferedImage(320, 240, BufferedImage.TYPE_INT_RGB)
    val g = small.createGraphics()
    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
        RenderingHints.VALUE_INTERPOLATION_BILINEAR)
    g.drawImage(bmp.image, 0, 0, 320, 240, null)
    g.dispose()
    ImageIO.write(small, "png", File("$dir/$name-320.png"))
}

/** Height that puts the pitch centre at [deg] below horizontal. */
private fun heightFor(deg: Float): Float =
    (Math.tan(Math.toRadians(deg.toDouble())) * (BroadcastCamera.backM + 34.0)).toFloat()

fun main(args: Array<String>) {
    val seed = args.firstOrNull()?.toLongOrNull() ?: 20260727L
    val angles = listOf(17.2f, 30f, 40f, 50f)

    // Find the ticks worth photographing ONCE, on a throwaway run, so every
    // angle is then rendered at exactly the same moments.
    val probe = newEngine(seed)
    probe.replaysEnabled = false
    probe.start()
    var openPlay = -1
    var finalThird = -1
    var corner = -1
    var t = 0
    while (!probe.finished && t < 200_000 && (openPlay < 0 || finalThird < 0 || corner < 0)) {
        probe.update(1f / 36f); probe.sound.clear(); t++
        val x = probe.ball.x
        if (openPlay < 0 && t > 600 && x > 40f && x < 60f) openPlay = t
        if (finalThird < 0 && t > 600 && (x > 80f || x < 20f)) finalThird = t
        if (corner < 0 && probe.scene == Scene.CORNER && probe.sceneTime in 0.2f..0.8f) corner = t
    }
    val shots = listOf("open-play" to openPlay, "final-third" to finalThird, "corner" to corner)
        .filter { it.second > 0 }
    println("moments chosen: " + shots.joinToString { "${it.first}@${it.second}" })

    val origH = BroadcastCamera.heightM
    val origT = BroadcastCamera.tiltDeg

    for (deg in angles) {
        // Point the optical axis down the same amount the ground has moved, or
        // the pitch slides off the bottom of the frame as the camera rises.
        BroadcastCamera.heightM = heightFor(deg)
        BroadcastCamera.tiltDeg = deg
        val tag = String.format("%02.0f", deg)
        println(String.format("  %s deg  -> height %.0f m, tilt %.0f", tag,
            BroadcastCamera.heightM, BroadcastCamera.tiltDeg))

        for ((label, at) in shots) {
            val m = newEngine(seed)
            m.replaysEnabled = false
            m.start()
            val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val v = MatchView(android.content.Context(), m)
            val close = MatchView::class.java.getDeclaredField("closeUp")
            close.isAccessible = true
            var i = 0
            while (i < at && !m.finished) {
                m.update(1f / 36f); m.sound.clear(); i++
                // the camera eases toward the ball, so it must render as it goes
                if (i % 2 == 0 || i > at - 120) {
                    close.setFloat(v, 1f)
                    v.renderAt(c, W, H)
                }
            }
            close.setFloat(v, 1f)
            v.renderAt(c, W, H)
            stampFrame(c, W.toFloat(), H.toFloat())
            writePair(bmp, "out/angle", "$label-$tag")
        }
    }

    BroadcastCamera.heightM = origH
    BroadcastCamera.tiltDeg = origT
    println()
    println("written to out/angle/. The -320 files are the ones that decide it.")
}
