import com.dugout.career.core.World
import com.dugout.career.ui.Face

/** Does a face survive a reload, and does it not depend on view order? */
fun main() {
    val w1 = World.build(20260727L)
    Face.assignAll(w1.players.values)
    val sample = w1.players.values.sortedBy { it.id }.filter { it.id % 900 == 0 }.take(6)
    val first = sample.map { Face.vector(Face.of(it)).joinToString(",") }

    // same world, assigned again: must be identical
    val w2 = World.build(20260727L)
    Face.assignAll(w2.players.values)
    val second = w2.players.values.sortedBy { it.id }.filter { it.id % 900 == 0 }.take(6)
        .map { Face.vector(Face.of(it)).joinToString(",") }

    // and now with the collection handed over in a shuffled order
    val w3 = World.build(20260727L)
    Face.assignAll(w3.players.values.shuffled(java.util.Random(99)))
    val third = w3.players.values.sortedBy { it.id }.filter { it.id % 900 == 0 }.take(6)
        .map { Face.vector(Face.of(it)).joinToString(",") }

    println("=== the same six players, three assignments ===")
    var same2 = 0; var same3 = 0
    for (i in first.indices) {
        if (first[i] == second[i]) same2++
        if (first[i] == third[i]) same3++
    }
    println("rebuilt world matches:        $same2 of ${first.size}")
    println("shuffled input order matches: $same3 of ${first.size}")
    println()
    for (i in first.indices) println("  ${sample[i].full.padEnd(24)} ${first[i]}")
}
