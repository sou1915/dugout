import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.CameraCut

/**
 * How the cuts between the board and the broadcast camera are spaced, how much
 * of the match each camera holds, and — the question nobody had asked — whether
 * the broadcast camera is ever actually reached.
 *
 * THREE THINGS WERE WRONG HERE, and all three flattered the game.
 *
 * 1. It re-implemented the cut rule instead of calling it, and the copy had
 *    drifted: its comment said the thresholds were 0.55 and 0.30 when the
 *    renderer used 0.58 and 0.22, and it modelled coming back in as needing the
 *    high threshold when the shipped rule only needed the low one. It now calls
 *    [CameraCut], which is the code MatchView runs, so they cannot drift again.
 *
 * 2. It ran one match. "13 cuts a match, median 5.5 s apart" was a single
 *    sample. It is 33 cuts a match, median 3.0 s.
 *
 * 3. It only ever looked at the decision, never at the picture. The decision
 *    flipped, so it reported cuts; `closeUp` never got past 0.22 out of 1.00,
 *    so there were no cuts. Every run prints the peak now.
 *
 * The clock: MatchView measures the minimum hold on the wall clock, and a
 * harness renders far faster than real time, so a wall clock here would hold
 * the board for the whole match — the trap that made an earlier camera
 * measurement worthless. The clock below advances 1/36 s a frame, which is what
 * a device at a steady frame rate hands the renderer anyway.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 40
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L

    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    for (rule in 0..1) {
        val gaps = ArrayList<Double>()
        val closeSpells = ArrayList<Double>()
        var cuts = 0
        var frames = 0
        var drawnClose = 0
        var reallyClose = 0
        var peak = 0f

        for (match in 0 until matches) {
            val m = MatchEngine(world, season, league[match % league.size])
            m.replaysEnabled = false
            m.start()
            var closeUp = 0f
            var onClose = false
            var lastCut = 0
            var i = 0
            var guard = 0
            while (!m.finished && guard++ < 300_000) {
                m.update(dt)
                if (m.finished) break
                val heldFor = (i - lastCut) / 36f
                if (rule == 0) {
                    // exactly as shipped: the camera we are on is inferred from
                    // the eased value, so a cut that has only had one frame to
                    // ease still reads as "we are on the board"
                    val minHold = if (closeUp > 0.5f) CameraCut.HOLD_CLOSE else CameraCut.HOLD_BOARD
                    val raw = m.danger >= CameraCut.CUT_IN ||
                        (closeUp > 0f && m.danger >= CameraCut.CUT_OUT)
                    val want = if (heldFor < minHold) (closeUp > 0.5f) else raw
                    if (want != (closeUp > 0.5f) && heldFor >= minHold) {
                        cuts++
                        if (lastCut > 0) gaps.add((i - lastCut) / 36.0)
                        if (closeUp > 0.5f) closeSpells.add((i - lastCut) / 36.0)
                        lastCut = i
                    }
                    closeUp = CameraCut.ease(closeUp, want)
                } else {
                    val want = CameraCut.wantClose(onClose, m.danger, heldFor)
                    if (want != onClose) {
                        cuts++
                        if (lastCut > 0) gaps.add((i - lastCut) / 36.0)
                        if (onClose) closeSpells.add((i - lastCut) / 36.0)
                        onClose = want
                        lastCut = i
                    }
                    closeUp = CameraCut.ease(closeUp, onClose)
                }
                if (closeUp >= 0.06f) drawnClose++
                if (closeUp > 0.5f) reallyClose++
                if (closeUp > peak) peak = closeUp
                frames++
                i++
            }
        }

        println("=== ${if (rule == 0) "as shipped: camera inferred from the eased value"
                       else "fixed: the camera we are on is remembered"} ===")
        println(String.format("matches                  %d", matches))
        println(String.format("cuts a match             %.1f", cuts.toDouble() / matches))
        println(String.format("highest closeUp reached  %.2f   (1.00 is the broadcast camera)", peak))
        println(String.format("broadcast view drawn     %.0f%% of frames  (closeUp >= 0.06)",
            drawnClose * 100.0 / frames))
        println(String.format("settled on that camera   %.0f%% of frames  (closeUp > 0.5)",
            reallyClose * 100.0 / frames))
        if (closeSpells.isNotEmpty())
            println(String.format("mean spell on the close   %.1f s  (%d spells)",
                closeSpells.average(), closeSpells.size))
        if (gaps.isNotEmpty()) {
            val sorted = gaps.sorted()
            println(String.format("shortest gap             %.1f s", sorted.first()))
            println(String.format("median gap               %.1f s", sorted[sorted.size / 2]))
            println(String.format("gaps under 5 seconds     %d of %d  (%.0f%%)",
                gaps.count { it < 5.0 }, gaps.size, gaps.count { it < 5.0 } * 100.0 / gaps.size))
        }
        println()
    }
    println("a match is about 113 seconds of real time at speed 1, so a cut every")
    println("three seconds is not a camera, it is a strobe.")
    println()

    // With the camera reachable at last, CUT_OUT decides how much of the match
    // is played on it, and that had never been a live choice before. danger is
    // 1.00 inside 20 units of goal, 0.45 to 30, 0.20 to 44: so CUT_OUT below
    // 0.20 holds the close camera almost anywhere, 0.22 holds it to 30 units,
    // and anything above 0.45 drops it the moment the ball leaves the box.
    println("=== what CUT_OUT buys, ${matches / 2} matches each ===")
    println("cut_out   cuts/match   settled on the close camera   mean spell")
    for (cutOut in listOf(0.15f, 0.22f, 0.30f, 0.46f, 0.60f)) {
        var cuts = 0; var frames = 0; var close = 0
        val spells = ArrayList<Double>()
        for (match in 0 until matches / 2) {
            val m = MatchEngine(world, season, league[match % league.size])
            m.replaysEnabled = false
            m.start()
            var closeUp = 0f; var onClose = false; var lastCut = 0; var i = 0; var guard = 0
            while (!m.finished && guard++ < 300_000) {
                m.update(dt)
                if (m.finished) break
                val heldFor = (i - lastCut) / 36f
                val want = if (heldFor < CameraCut.minHold(onClose)) onClose
                           else m.danger >= CameraCut.CUT_IN || (onClose && m.danger >= cutOut)
                if (want != onClose) {
                    cuts++
                    if (onClose && lastCut > 0) spells.add((i - lastCut) / 36.0)
                    onClose = want; lastCut = i
                }
                closeUp = CameraCut.ease(closeUp, onClose)
                if (closeUp > 0.5f) close++
                frames++; i++
            }
        }
        println(String.format("%.2f      %8.1f   %24.0f%%   %8.1f s", cutOut,
            cuts.toDouble() / (matches / 2), close * 100.0 / frames,
            if (spells.isEmpty()) 0.0 else spells.average()))
    }
}
