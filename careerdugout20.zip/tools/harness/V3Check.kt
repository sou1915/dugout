import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/** Engine v3 against v2 and v1, same seeds, same tick. */
private class Row(val label: String, val v2: Boolean, val v3: Boolean) {
    var frames = 0L; var inFlight = 0L; var atFeet = 0L; var loose = 0L
    var carrierPressed = 0.0; var carrierSecs = 0.0
    var goals = 0L; var shots = 0L; var matches = 0L
    var tackles = 0L; var fouls = 0L; var corners = 0L; var throwIns = 0L
    var stuck = 0L; var wall = 0.0

    fun run(n: Int) {
        MatchEngine.ENGINE_V2 = v2; MatchEngine.ENGINE_V3 = v3
        val dt = 1f / 36f
        for (i in 0 until n) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false; m.start()
            var g = 0
            var wasThrow = false
            val t0 = System.nanoTime()
            while (!m.finished && g++ < 900_000) {
                m.update(dt); m.sound.clear(); frames++
                if (m.ball.t < 1f && !v3) inFlight++
                else if (m.ball.holder != null) atFeet++
                else if (v3 && (Math.abs(m.ball.vx) > 0.4f || Math.abs(m.ball.vy) > 0.4f)) inFlight++
                else loose++
                val h = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
                if (h != null && h.pos != Pos.GK) {
                    carrierSecs += dt.toDouble()
                    val dh = m.players.filter { it.onPitch && it.side != h.side && it.pos != Pos.GK }
                        .minOfOrNull { Math.hypot(((it.x - h.x) * 1.05).toDouble(),
                            ((it.y - h.y) * 0.68).toDouble()) } ?: 99.0
                    if (dh < 2.0) carrierPressed += dt.toDouble()
                }
                val nowThrow = m.sceneTime > 0f && m.scene == 4
                if (nowThrow && !wasThrow) throwIns++
                wasThrow = nowThrow
            }
            wall += (System.nanoTime() - t0) / 1e9
            if (g >= 900_000) stuck++
            goals += m.score[0] + m.score[1]; shots += m.shots[0] + m.shots[1]
            tackles += m.players.sumOf { it.tackles }.toLong()
            fouls += m.fouls[0] + m.fouls[1]; corners += m.corners[0] + m.corners[1]
            matches++
        }
        MatchEngine.ENGINE_V2 = true; MatchEngine.ENGINE_V3 = false
    }
    fun print() {
        val mm = maxOf(1L, matches)
        println(String.format("%-5s %8.1f%% %8.1f%% %8.1f%% %9.1f%% %7.2f %7.1f %8.1f %7.1f %8.1f %7.1f %6d %7.1fs",
            label, 100.0*inFlight/maxOf(1L,frames), 100.0*atFeet/maxOf(1L,frames),
            100.0*loose/maxOf(1L,frames), 100.0*carrierPressed/maxOf(1.0,carrierSecs),
            goals.toDouble()/mm, shots.toDouble()/mm, tackles.toDouble()/mm,
            fouls.toDouble()/mm, corners.toDouble()/mm, throwIns.toDouble()/mm, stuck, wall/mm))
    }
}

fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 8
    println("=== v1 / v2 / v3, same seeds ($n matches each) ===")
    println(String.format("%-5s %9s %9s %9s %10s %7s %7s %8s %7s %8s %7s %6s %8s",
        "", "inFlight", "at feet", "loose", "pressed", "goals", "shots", "tackles",
        "fouls", "corners", "throws", "stuck", "cpu/match"))
    Row("v1", false, false).also { it.run(n) }.print()
    Row("v2", true, false).also { it.run(n) }.print()
    Row("v3", false, true).also { it.run(n) }.print()
    println()
    println("v3 targets: at feet over 50%, pressed over 30%, goals 2.5-2.7,")
    println("throws 5+, stuck zero, cpu well under the 408 s a match lasts.")
}
