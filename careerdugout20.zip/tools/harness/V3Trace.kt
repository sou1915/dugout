import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/** First seconds of a v3 match, tick by tick. */
fun main() {
    MatchEngine.ENGINE_V3 = true
    val m = newEngine(20260727L)
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var t = 0.0
    println(String.format("%6s %7s %7s %7s %7s %8s %9s %9s %8s",
        "t", "ballx", "bally", "ballvx", "ballvy", "holder", "nearest", "hisTgtD", "moved"))
    var prevX = 0f; var prevY = 0f
    for (i in 0 until 400) {
        m.update(dt); m.sound.clear(); t += dt
        val near = m.players.filter { it.onPitch }.minByOrNull {
            Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(), ((it.y - m.ball.y) * 0.68).toDouble())
        }
        val nd = if (near == null) 99.0 else Math.hypot(
            ((near.x - m.ball.x) * 1.05).toDouble(), ((near.y - m.ball.y) * 0.68).toDouble())
        val td = if (near == null) 0.0 else Math.hypot(
            ((near.targetX - near.x) * 1.05).toDouble(), ((near.targetY - near.y) * 0.68).toDouble())
        val moved = if (near == null) 0.0 else Math.hypot(
            ((near.x - prevX) * 1.05).toDouble(), ((near.y - prevY) * 0.68).toDouble())
        if (i % 12 == 0) println(String.format("%6.2f %7.1f %7.1f %7.2f %7.2f %8s %9.1f %9.1f %8.3f",
            t, m.ball.x, m.ball.y, m.ball.vx, m.ball.vy,
            if (m.ball.holder == null) "-" else "yes", nd, td, moved))
        if (near != null) { prevX = near.x; prevY = near.y }
    }
}
