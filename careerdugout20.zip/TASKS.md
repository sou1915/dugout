# TASKS.md — the queue

Rewritten after playing the build on a phone. The football looks repetitive and
almost nothing is named on screen, and the cause is now known: **the whole
event-presentation layer is authored and switched off.**

```
Ev4.COUNT           = 90 events
Ev4.SHOWN           = 90 rows: scene, pose, caption, crowd, referee — all written
Ev4Say.SAY          = commentary banks with weights, on the cosmetic stream
fire(show = true)   = called from ZERO places in the app
note()              = fire(show = false), used at all 30 call sites
evCaption, spoken   = read by NOTHING in ui/ or MainActivity
```

`MatchEngine.kt` says it itself: *"NOTHING CALLS THIS YET. Step two of five is
the plumbing."* Step three (counting) landed. **Step four — the picture — was
never done.** That is the whole of what the phone is showing.

Second finding: under `ENGINE_V2`, the events reported at all are throw-in,
corner, goal kick, tackle, interception, foul, take-on and offside. **No shot,
no cross, no through ball, no header, no save variant is reported.** So between
two stoppages there is literally nothing named — which is exactly the loop that
reads as repetition.

Order below reflects that. One task at a time. `[ ]` · `[~]` · `[x]`

---

**Measured after task 2, and it reframes everything below: see
`docs/DEAD_CODE.md`.** A third of the match code never executes -- 2,400 of
~7,800 lines -- and 1,045 of those were written specifically to make the twenty
one players without the ball intelligent (`OffBall.kt`, `Pitch.kt`,
`RoleTree.kt`). None of it runs. The build on the phone is the oldest layer
because it is the only one switched on.

So the queue below is right in its ORDER but wrong in its FRAMING: nothing here
needs to be written, it needs to be **turned on**, one flag at a time, each with
a gate. A flag that has been `false` for two sessions is either switched on or
deleted.

---

## [ ] 1. Bring the gate up

Unchanged from before, and now it matters more: turning presentation rows on
will move results, and without a fingerprint you cannot tell which row did it.

**Done when:** `GateKt` prints PASS against a baseline the owner recorded,
`UiFlow` prints 0 crashed, CI runs both on push, APK builds from the checkout.

> Task 1. Add the Gradle wrapper (`gradle wrapper --gradle-version 8.9`) and
> switch the CI APK step to `./gradlew assembleDebug`. Compile `tools/gate/Gate.kt`
> with the command in CLAUDE.md and report any compile errors — I have not been
> able to compile it here. Do NOT run `--record`; I record the baseline. Then
> tell me exactly what you need from me for CI to go green.

---

## [x] 2. Report what v2 already does

Before anything is drawn, the census has to be full. `note()` is
`fire(show = false)`: it increments a counter and writes a commentary line on
`sfxRng`. It draws nothing and it must not move the fingerprint.

**Done when:** `EventCensus` over 20 matches shows non-zero counts for shots,
passes, crosses, saves and clearances, with plausible per-match rates, and
`GateKt` is byte-identical.

> Task 2. Add `note(...)` calls for the events engine v2 already performs but
> never reports: in `v2Strike` — SHOT_STRUCK / SHOT_HEADER / SHOT_LONG_RANGE /
> SHOT_BLOCKED / SHOT_WIDE; in `v2Give` — PASS_SHORT / PASS_LONG / PASS_SWITCH /
> THROUGH_BALL / CROSS / CUT_BACK, chosen from the pass that was actually
> played, not at random; in `v2Claim` — FIRST_TOUCH / TOUCH_HEAVY; in
> `attemptShot` — the SAVE_* variant matching what the keeper did; plus
> CLEARANCE and CLEARANCE_HEADED where they happen. Use `note` only — nothing
> is drawn in this task. Paste `EventCensus` per-match rates and the `GateKt`
> output. The fingerprint must be identical; if it is not, you changed behaviour
> somewhere and I want to know where before anything else.

---

## [x] 3. Make the screen able to show a caption and hear the commentator

Nothing reads `evCaption` or drains `spoken`, so even a correctly fired row
would be invisible.

**Done when:** `MatchFilm` frames show the caption; the feed shows commentary
lines; `PoseTime` reports seconds on screen; `GateKt` identical.

> Task 3. In `MatchView`, draw `engine.evCaption` in the scene-caption slot, and
> drain `engine.spoken` each frame into the match feed, highest weight first,
> dropping anything queued behind something better rather than showing it late —
> the weight design is documented on `spoken`. Show me three `MatchFilm` frames
> with captions visible and the `GateKt` output. Pure presentation: the
> fingerprint must be identical.

---

## [~] 4. Turn the table on, row by row

**4a landed** (gate identical). **4b landed** (gate `da1caad36bfeca9b`, BalanceBig
2.54 +/- 0.03, inside the band). **4c is still the owner's to approve.**

`fire(show = true)`, one group per commit, in this order, because the groups
differ in whether they can move a result.

**4a — caption and crowd only (no pose, no scene). Fingerprint MUST be identical.**
PASS_SWITCH, THROUGH_BALL, ONE_TWO, CROSS, CUT_BACK, SHOT_WIDE, SHOT_DEFLECTED,
GOAL_DISALLOWED, FOUL_ADVANTAGE, KEEPER_CLAIM_CROSS, KEEPER_SWEEP, MELEE,
DROP_BALL, TIME_WASTING, FORMATION_CHANGE, SHOUT, ADDED_TIME, HALF_TIME,
FULL_TIME.

**4b — scene, no pose. May move the fingerprint: a scene changes dead-ball speed.**
THROW_IN, THROW_LONG, GOAL_KICK, CORNER_WON, FREE_KICK_DIRECT,
FREE_KICK_INDIRECT, PENALTY_AWARDED, KICK_OFF, SECOND_HALF, OFFSIDE,
OFFSIDE_TRAP_SPRUNG, SAVE_ROUTINE, WOODWORK, REBOUND, INTERCEPTION,
CARD_YELLOW, CARD_SECOND_YELLOW, CARD_RED, DISSENT, SUBSTITUTION,
SUBSTITUTION_FORCED.

**4c — pose-bearing. WILL move the fingerprint, by design. Ask first.**
TACKLE_WON, TACKLE_SLIDING, TACKLE_LAST_DITCH, BLOCK, GOAL_LINE_CLEARANCE,
FOUL, FOUL_IN_BOX, PROFESSIONAL_FOUL, GOAL, OWN_GOAL, PENALTY_SCORED,
PENALTY_MISSED, SAVE_DIVING, SAVE_TIP_OVER, SAVE_PARRY, SAVE_PENALTY,
KEEPER_PUNCH, CLEARANCE_HEADED, FLICK_ON, the SHOT_* rows carrying a pose,
INJURY_KNOCK, INJURY_SERIOUS, CRAMP.

`act(Act.TACKLE)` and `act(Act.DOWN)` **stop a man moving**, and who can play
the next ball is a result. That is why 4c is separate and why it is the owner's
to approve.

> Task 4a. Switch group 4a from `note` to `fire` — captions and crowd only. One
> commit for the group. Then show me `PoseTime` (seconds on screen per caption,
> not counts), five `MatchFilm` frames, and `GateKt`. The fingerprint must be
> identical; a caption cannot change football. If it moved, revert and tell me
> which row did it.

> Task 4b. Switch group 4b, one commit per handful. Expect the fingerprint to
> move: a scene changes dead-ball movement speed. For each commit give me the
> old and new hash, `SceneCheck` (every scene reached, dead-ball vs live speed)
> and `BalanceBig` before and after. If goals per game leaves 2.5–2.7, stop.

> Task 4c. Do not start. Ask me.

---

## [ ] 5. Make the harnesses say which engine is running

`BalanceBig` still sweeps `CHANCE_QUALITY`, dead under v2 — the same failure
shape as `v2Defend` never called and `Scene.TAKE_ON` at 0.00 a match.

> Task 5. Add a banner naming the live engine and its master lever to
> `Harness.kt`, called from the top of every harness. Point `BalanceBig`'s sweep
> at the lever alive under `ENGINE_V2`. Add `EngineFingerprints.kt` printing v1,
> v2 and v3 fingerprints on the same seeds. No behaviour change; gate must PASS.

---

## [ ] 6. The corner that renders an empty box

`AUDIT.md` §1 has the diagnosis: the staging gate is open on 100% of corners
with 9.32 s to run, so both hypotheses in `PROJECT_STATE.md` §6 are wrong and
three time bases disagree.

> Task 6. Read `AUDIT.md` §1 in full and fix the time-base disagreement. Show me
> `StageGate` before and after, and two `CornerFilm` frames at the moment the
> caption appears. Trust the picture over the table.

---

## [ ] 7. Why the players look stupid

Separate from the captions, and already measured in `PROJECT_STATE.md` §6:
block 48.8 m against a real 30–40; **1.25 of ten men goal-side** of a ball in
their own box against a real 8–9; headers ~5 a match against a real 40.

> Task 7. One change at a time, `BalanceBig` and `ShapeCheck` after each, and
> revert anything that does not measure better — §5 lists what has already
> failed, do not retry it. Start with the defensive block: 48.8 m to under 44 m
> without losing shots. Then headers. Give me `MatchFilm` strips before and
> after each, and say which changes you reverted.

---

## [ ] 8. Split `MatchEngine.kt` and `update()`

Follow `REFACTOR_MATCHENGINE.md`: 11 commits, fingerprint identical after every
one. Then `MainActivity.kt` into one file per screen, `UiFlow` at 0 crashed.

---

## [ ] 9. Platform and runtime

`targetSdk` 34 → 35; release signing read from `local.properties`; world
generation (~630 ms) off the main thread; `Choreographer` instead of
`postDelayed(28L)`; kill the per-frame allocations in `applyReplayFrame`,
`restoreLiveFrame` and the HUD clock; implement `onSaveInstanceState`.

---

## [ ] 10. `Save.kt`

Positional rows, and `read()` discards a wrong version **in silence**. The
format is the owner's decision.

> Task 10. Do not change `Save.kt`. Write me a one-page comparison: keyed rows
> versus positional rows with a per-version reader — what happens to a v2 save
> under each, how much code each costs, how each fails when a field is added
> mid-row, and what a migration test looks like. I will choose.

---

## [ ] 11. Decision scores

`PROJECT_STATE.md` §6.5: the man on the ball never chooses. Do not start without
the owner. Tasks 1–8 exist so that when this moves the fingerprint, the number
is information rather than a surprise.

---

## Standing rules

- Read `CLAUDE.md` first. One task, one commit series, then stop.
- End with: what changed, the `GateKt` output, the harness number that shows it
  worked, and anything you could not verify.
- Never run `GateKt --record`. Never edit `tools/gate/baseline.properties`.
- If the gate fails and you believe the new football is right, stop and say so
  with both hashes. Do not "fix" the gate.
