# Career Dugout — where the project stands

Everything below was measured, not assumed. Where a figure is real football it
says so. Where something is still wrong it says that too, with the number.

Last verified: commit `7cccaa9`, branch `claude/do-the-work-9vb0pp`.

---

## 1. What the thing is

An Android football management game in Kotlin, about 18,000 lines, no engine and
no third-party libraries. A 60-league world of 1,236 clubs and 32,136 players is
generated from a seed in about 630 ms. Matches play out on a pitch in a
perspective broadcast view.

```
app/src/main/java/com/dugout/career/
  core/          Names.kt (RNG + name pools for 185 nations)
                 Model.kt (Player, Club, Tactics, Presets)
                 World.kt, Save.kt
  sim/           MatchEngine.kt   the match — by far the biggest file
                 League.kt, Career.kt
  ui/            MatchView.kt         renderer entry, camera, HUD
                 BroadcastRenderer.kt perspective figures
                 FaceGen.kt, Theme.kt, Icons.kt   (the game is SILENT:
                 MatchAudio.kt is deleted and Synth.kt is now only the names
                 of the cues -- see AUDIT.md 9.1)
  MainActivity.kt   every screen
tools/harness/    ~80 measurement programs, none of it ships
```

### How the match engine works

This matters more than anything else in the file, because almost every mistake
in this project came from not understanding it.

The match is **phase-based**. A phase is one spell of possession:

1. `newPhase()` picks a **pattern** (build-up, cross, through ball, counter,
   long shot) from the two sides' tactics.
2. It **pre-rolls the outcome** from the two sides' attack / defence / control
   ratings: `OUT_FOUL`, `OUT_SHOT`, `OUT_CORNER`, `OUT_THROW`, `OUT_TURNOVER`.
3. It builds a sequence of players the ball will travel through.
4. `stepPhase()` plays each pass; `resolvePhase()` delivers the outcome.

**The outcome is decided before the ball moves.** Everything visible — where men
run, which receiver is chosen, how the ball flies — changes *the path to a result
that was already decided*. This is why presentation work is safe and why
anything touching the phase count is not.

### Two RNG streams

- `rng` — anything that can change a result.
- `sfxRng` / `physRng` — presentation only.

The separation used to leak, and it mattered: adding a commentary flourish
changed the scoreline, because firing a take-on at a different moment unfroze a
different defender. `act(..., cosmetic = true)` and `ResultFingerprint.kt` exist
to keep that shut. **If you add a draw, put it on the right stream, and re-run
`ResultFingerprint` — it must come back byte-identical when only presentation
changed.**

---

## 2. The measurement harness — read this before writing any code

`tools/harness/` compiles the real app off-device against a Java2D shim
(`shim/Android*.kt`) that fakes `android.graphics`, `view`, `widget`, `app`,
`media`, `os`, `text`, `util`. The **shipped** renderer and engine run on a
desktop JVM, so a visual claim can be measured instead of asserted.

```sh
export PATH=$PATH:/opt/kotlin/kotlinc/bin
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt tools/harness/Harness.kt \
    tools/harness/BalanceBig.kt -include-runtime -d build/reg.jar
java -Djava.awt.headless=true -cp build/reg.jar BalanceBigKt
```

### The rules that were learned the hard way

1. **RENDER FRAMES AND LOOK AT THEM.** Every aggregate can be correct while the
   screen is still wrong. Two of the largest bugs in this document — the radar
   sitting on top of the football, and a corner being captioned over an empty
   box — were invisible to every number and obvious in one PNG.
2. **MEASURE, NEVER ASSERT.** "Fixed" means "measured in a harness", and that is
   still not "fixed on the device".
3. **A control row or the measurement is worthless.** `PressureCheck`'s first
   version gated the computation behind the same flag it was testing, so the
   control read 0.000 everywhere and compared nothing.
4. **Know your standard error.** Goals per game is roughly Poisson with mean
   2.6, so SE = `sqrt(2.6/n)`. At 40 matches that is ±0.51 at 95%. A sweep that
   swung 2.27–2.73 across settings was read as a trend and was entirely noise.
   `BalanceBig` runs 9,120 matches for a reason.
5. **Never edit by line index.** A scripted removal spanning a needed line
   deleted `var ty = ...` and only compilation caught it. Use anchored string
   replacement.
6. **If a change does not do what you intended, revert it and say so.** Several
   entries in §5 are there because of this rule.
7. **Never merge two AI systems at once.** Measure and commit each alone.

---

## 3. Current verified state

`BalanceBig`, 4 worlds × 6 seasons = **9,120 matches**:

| | measured | target |
|---|---|---|
| goals per game | **2.52 ± 0.03** | 2.5–2.7 |
| home wins | 42.3% | ~45% |
| draws | 26.1% | ~25% |
| away wins | 31.6% | ~30% |
| cards per game | 1.88 | ~4 |

`UiFlow` 33/33 steps, 0 crashes — every screen, plus getting sacked and applying
again.

### The match clock — the single most important constant

```
SECONDS_PER_MINUTE = 4.0     (was 1.15)
PHASE_SCALE        = 0.75
CHANCE_QUALITY     = 0.1038  (was 0.113)
```

The ball flies in **real seconds** — a 20 m pass takes 1.26 of them, capped at
26 m/s. A move ran on **compressed match minutes** and gave each pass 0.38 s. The
ball was three times too slow for the rhythm it was played at, and the engine
coped by **striking it again in mid-air**.

Opening the clock to 4.0 gives the ball its time. It does not change how many
moves a match holds (`phaseDuration` is in match minutes), but *waiting for the
ball* does, so `PHASE_SCALE` shortens the nominal move to put the chance count
back. A match now takes **408 s at 1×** instead of 120 — there is a 1×/2×/4×
button, so 102 s at 4×.

---

## 4. Every fault found, and what the numbers were

### The ball

| | before | after |
|---|---|---|
| flights containing a kink >15° in one frame | **54%** | **4%** |
| reversals >120° per match | 39.9 | 3.8 |
| single-frame jumps over 3 m | 1.1/match | 0.9/match |
| goals scored from the shooter's own half | 25.9% | 0.0% |
| woodwork | 2.9/match | ~0.5/match |
| share of match spent in the air | 38% | normal |

**Cause of the kinks:** the next pass was played on a timer, unrelated to the
ball's flight time, so 98% of direction changes were the ball being **struck
again mid-flight at 34 m/s**. Fixed by gating the move on the ball's arrival
(`WAIT_FOR_BALL`), paid for by the clock change above.

Also fixed: the ball's position used to be a *function* of an aim point that
other systems mutated (`ball.x = fromX + (toX-fromX)*e`). It now advances by a
step along what remains of its journey, so a moving target bends it instead of
teleporting it. Mathematically identical when nothing retargets.

**Killed hypothesis:** the ball was thought to be left behind by a running
carrier. It is at his feet — median **0.21 m** over 5,555 carrying frames.

### Defending

With the ball inside a side's **own penalty area**:

| | before | after | real |
|---|---|---|---|
| defenders goal-side of the ball | 0.32 / 10 | 1.25 | 8–9 |
| defenders inside their own area | 1.09 | 3.26 | 5–7 |
| **nobody in the area at all** | **56.7%** | **13.7%** | ~never |
| deepest outfielder from own line | 20 m | 13 m | — |

Two causes. Effort fell away with distance **from the ball**, which is exactly
backwards for a defender caught upfield — he jogged back while his goal was
under attack. And the defensive shape was one rigid 46 m block translated toward
the ball, so with the ball on the goal line its centre sat 24 m out. Fixed with
recovery sprints and **defender zones** (near post, back post, in front of the
keeper, two half-spaces, edge of the area).

### Attacking — Player Jobs

A pattern used to move only the ball. A cross was worked wide, swung in, and
nobody was in the box because every player stood in his formation slot. Jobs
send named men to named places before the ball arrives.

| | jobs off | jobs on (8 s) |
|---|---|---|
| attackers in box when ball is there | 1.03 | 1.16 |
| delivery reaching an empty box | 49.9% | 43.9% |

A 4.5 s job did **nothing** — it expired during the walk up the pitch, before
the delivery.

### Passing — the pressure layer

| weight | receiver pressed | team average | went to the **most marked** man |
|---|---|---|---|
| **off** | **0.353** | 0.277 | 17.8% |
| 12 (shipped) | 0.336 | 0.280 | 15.7% |
| 20 | 0.309 | 0.280 | 13.6% |

Read the control row: **the receiver was more pressed than the average team
mate** — the ball systematically found marked men, because the receiver was
whoever stood nearest a geometric aim point.

Weight 20 finds the most space and was put back: balance fell to 2.47, under the
band, because a side that always passes into space concedes fewer turnovers and
so creates fewer chances.

### Scenes

`Scene.LABEL` existed since set pieces were written and was **referenced nowhere
in the app**. The captions were authored and never drawn. A booking had no scene
at all — the referee and his card were drawn for 2.6 s while play carried on
around them and the free-kick scene overwrote the moment a tick later.

Per match now: take-on 38.0, goal kick 20.7, corner 8.7, throw-in 7.1, save 7.3,
free kick 3.9, tackle 3.0, booking 1.3, kick-off 1.0, penalty 0.2.
**31.1% of the match is a named moment.**

**Dead-ball behaviour:** players used to move *faster* at a stoppage (3.10
units/s) than in play (2.87). Now 1.67 vs 2.73.

**Set-piece staging.** `stageCorner` sends attackers 30 units to the box and the
scene lasted 1.3 s, in which a man covers 4 units:

| corner hold | attackers in box | defenders | in position |
|---|---|---|---|
| 1.3 s (shipped) | 1.04 | 1.96 | 34% |
| **8.0 s (now)** | **3.43** | **3.81** | 42% |
| 10.0 s | 3.80 | 4.00 | 51% |

Real is 5–6 attackers and 8 defenders. Two bugs behind this: the arrangement was
held only while the *caption* said CORNER, but `stageCorner` runs when the corner
is **conceded** — so it was wiped by the next tick. And FREEKICK was never in
that list at all, so **the wall was destroyed the instant it was built**.

### Slide tackles

| | before | after | real |
|---|---|---|---|
| slides per match | 9.5 | 4.8 | 4–6 |
| mean distance to ball when he goes down | 5.0 m | 2.6 m | at the ball |
| **slides starting >5 m from the ball** | **39%** | 2% | ~never |

Men were throwing themselves along the grass at nothing, because the tackler is
chosen as the nearest defender to the last man in the move and the slide played
wherever he stood.

### Presentation

- The **radar was drawn on top of the pitch**, covering the football. Moved out.
- The **camera framed the crowd**. Reframed; ball off-screen 0.4% of frames.
- The **board view** (top-down discs on a table) was shown roughly half the time
  and *none* of the poses, scenes or figures existed on that path. Deleted, so
  there is one camera and one code path.
- Figures reproportioned to PS1 / ISS Pro '98 chunkiness, with per-action poses.
- Celebration was throttled to a walk — the mob closed 3.5 m of a 21 m gap in
  five seconds. They sprint now.

---

## 5. Things tried, measured, and reverted

Kept here so they are not tried a fourth time.

| attempt | result |
|---|---|
| Four team-shape compaction variants | every one traded shape against shooting |
| Random off-ball runs | stretched the block 46 → 48 m (`fc44c76`) |
| Bounded receiver lead | achieved nothing measurable |
| Engine v2 support positioning | did not win across the board |
| Just-in-time receivers | same |
| Cancelling out-of-range attacks | wrecked the result distribution |
| Distance curve on chance quality | same |
| **Defensive anticipation** (shape to where the ball is *going*) | 0.50 goal-side either way; 0.49 combined vs 0.54 for recovery alone |
| **A shot scene** | 1.7/match against 28 shots — four in five miss and the goal kick fires in the same call, so it flickered and vanished |

---

## 6. What is still wrong

Ordered by how much it matters.

1. **A rendered corner still shows an empty box** while `StagingCheck` on the
   same build says 3.4 attackers are in it, with the radar putting every outfield
   player at the far end. One of the two is lying. **Start here**, and trust the
   picture over the table.
2. **Team shape.** The block is **48.8 m**; real sides keep 30–40. Every attempt
   to compact it has traded against shooting. Width is 46.6 m, inside the real
   45–55.
3. **Defending is 4× better and still wrong** — 1.25 of ten men goal-side of a
   ball in their own box against a real 8–9.
4. **Cards 1.88 a match against a real ~4.** Headers ~5 against a real 40.
   Throw-ins 7 against a real 40.
5. **The man on the ball has no decision.** He never chooses between shooting,
   crossing, carrying or recycling — the outcome is pre-rolled and he executes
   the next pass. This is the **decision-score layer** and it is the most likely
   single change to alter how the football *reads*.
6. **Unbuilt AI layers** from the design: attack intent, tactical objectives,
   opportunity evaluation, dynamic pattern adaptation, team memory.

### The layered AI plan, and where it got to

```
Coach → Intent → Objectives → Decision Scores → Player Jobs → Movement → Physics → Presentation
```

| layer | state |
|---|---|
| Player Jobs | **done**, measured |
| Defender zones | **done**, measured |
| Pressure | **done**, measured, weight capped by balance |
| Scene behaviour | **done**, measured |
| Decision scores | **not started** — the next one |
| Attack intent / objectives / memory | not started |

---

## 7. Practical notes

- `Save.kt`: new fields go on the **end** of a row. Inserting one mid-row breaks
  every existing save.
- Player generation moves match balance. Re-run `BalanceBig` after touching it.
- `MainActivity.kt`, `Theme.kt`, `Icons.kt` need the Android UI classes; the shim
  covers them, so the whole app type-checks locally.
- A comment can be confidently wrong and cost a year. The camera-pan comment
  described a deliberate choice that was actually a bug.
- **`git push` returns 403** from the git proxy. Read works — `git fetch` and
  `ls-remote` succeed on the same remote — write is withheld. It needs write
  access granted for `sou1915/dugout`. All 32 commits are signed and verify `G`;
  local verification needs `openssh-client` installed and
  `gpg.ssh.allowedSignersFile` set, or everything reads `N`.

---

## 8. Useful harnesses

| harness | question it answers |
|---|---|
| `BalanceBig` | 9,120 matches — goals, home/draw/away, cards |
| `MatchFilm` | renders a strip of frames — **look at them** |
| `SceneFilm` | one frame of each named moment |
| `CrossFilm` | photographs a cross reaching the final third |
| `BallPath` | how sharply the ball turns, and what caused each kink |
| `BallJump` | single-frame teleports |
| `ClockCheck` | sweeps match clock against move length |
| `DefendCheck` | where a side stands as the ball comes at it |
| `StagingCheck` | has anyone arrived when the set piece is **taken** |
| `SceneCheck` | every scene reached, and dead-ball vs live speed |
| `PressureCheck` | does the ball go to the man in space |
| `SlideCheck` | slides, and how far from the ball they start |
| `BoxCheck` | is anybody in the box when the ball gets there |
| `ShapeCheck` | block length, width, nearest team mate |
| `UiFlow` | 33 screens without crashing |
| `ResultFingerprint` | proves a cosmetic change moved no result |
| `GoalNet` | does the ball reach the net, and is there a kick-off after |
| `GoalFilm` | films a goal, the celebration and the restart, with where the ball lands ON SCREEN |
| `WidthCheck` | where play happens across the pitch, and how much is ever aimed out |
| `FirstJobs` | how much is really on the first screen of a new career |
