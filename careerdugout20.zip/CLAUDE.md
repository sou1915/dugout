# CLAUDE.md — how to work in this repository

Read this before touching anything. Then read `PROJECT_STATE.md` §2, and treat
`AUDIT.md` as the more current of the two documents.

---

## What this is

An Android football management game in Kotlin. ~35,000 lines, no game engine,
no third-party libraries. The player manages; he never controls a footballer.
The match is watched, so **the only test that finally matters is whether the
picture is right.**

```
app/src/main/java/com/dugout/career/
  core/   Names.kt  Model.kt  World.kt  Manager.kt  Staff.kt  DressingRoom.kt
  sim/    MatchEngine.kt (6,292 lines)  League.kt  Career.kt  Save.kt
          MatchEvents.kt  Physics.kt  OffBall.kt  Pitch.kt  RoleTree.kt
  ui/     MatchView.kt  BroadcastRenderer.kt  FaceGen.kt  Theme.kt  Icons.kt
  MainActivity.kt (4,507 lines — every screen)
tools/harness/   ~90 measurement programs, none of it ships
tools/gate/      Gate.kt — the CI gate. See "The gate" below.
```

## Which engine is actually running

**`MatchEngine.ENGINE_V2 = true`, `ENGINE_V3 = false`.** Continuous play. The
v1 phase engine (`newPhase` / `stepPhase` / `resolvePhase`, ~850 lines) sits in
a dead `else` branch and never executes in the shipped build.

This matters more than it sounds. Three defects in `AUDIT.md` are the same
shape — work done on a path that was no longer the path that runs:

- `CHANCE_QUALITY` swept for four rows in `BalanceBig` while dead under v2;
- `v2Defend` written and never called;
- `Scene.TAKE_ON` reachable only from v1, so it measures 0.00 a match.

**Before changing any engine behaviour, prove the line you are editing executes
in the shipped configuration.** Print a counter from it, run a harness, and say
the number. "It's in the code path" is not a claim this project accepts.

`PROJECT_STATE.md` §3 describes the v1 build and its fingerprint no longer
matches. Do not quote its numbers as current. `AUDIT.md` §0 already says so.

---

## Building and measuring, off-device

The whole app — engine, renderer and `MainActivity` — compiles against a Java2D
shim and runs headless. This is why a visual claim here can be measured instead
of asserted, and it is the most valuable thing in the repository.

```sh
export PATH=$PATH:/opt/kotlin/kotlinc/bin
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt tools/harness/shim/ThemeStub.kt \
    tools/harness/Harness.kt tools/harness/UiFlow.kt tools/gate/Gate.kt \
    -include-runtime -d build/gate.jar
java -Djava.awt.headless=true -cp build/gate.jar GateKt
```

Swap the last harness file for whichever one you need (`BalanceBig.kt`,
`MatchFilm.kt`, `StageGate.kt`, …). Compiling takes ~30 s. `BalanceBig` takes
~9 minutes; the gate takes about one.

## The gate

`tools/gate/Gate.kt` plays 200 matches and hashes every score, shot, card and
corner (FNV-1a, the same fields as `ResultFingerprint.kt`). It exits non-zero
when the results move.

- **A change meant to be cosmetic must leave the fingerprint byte-identical.**
  If it moved, the change was not cosmetic: something on the presentation path
  froze a player, and positions feed the outcome model.
- **A pure file move must leave it byte-identical.** If a refactor moves the
  fingerprint, the refactor was not a move.
- **Never run `GateKt --record`.** Not once, not "to unblock", not with an
  explanation. `tools/gate/baseline.properties` is changed by the owner only.
  If the gate fails and you believe the new football is correct, stop and say
  so, with the old hash, the new hash and what you changed.

---

## Hard rules

1. **Measure, never assert.** "Fixed" means "measured in a harness", and that
   is still not "fixed on the device". Every claim comes with its number and
   the harness that produced it.
2. **Render frames and look at them.** Two of the largest bugs in this project
   were invisible to every aggregate and obvious in one PNG. `MatchFilm`,
   `SceneFilm`, `GoalFilm`, `CrossFilm`.
3. **Know your standard error.** Goals per game is roughly Poisson with mean
   2.6, so 400 matches carries ±0.16 at 95%. A sweep that moves less than its
   interval has measured nothing. `BalanceBig` runs 9,120 matches for a reason.
4. **A measurement without a control row is worthless.** `PressureCheck`'s
   first version gated the computation behind the flag it was testing.
5. **Never edit by line index.** Use anchored string replacement. A scripted
   removal spanning a needed line once deleted a `var` declaration and only the
   compiler caught it.
6. **Never change two systems in one commit.** Measure and commit each alone.
7. **If a change does not do what you intended, revert it and say so.**
   `PROJECT_STATE.md` §5 is a list of things already tried, measured and
   reverted. Read it before proposing anything on it.
8. **A comment can be confidently wrong.** The camera-pan comment described a
   deliberate choice that was a bug. Trust the harness over the comment, and
   the picture over the harness.
9. **Presentation and results are separate RNG streams.** `rng` decides
   outcomes; `sfxRng` / `physRng` decide presentation. A new draw goes on the
   right stream, and then the gate proves it.
10. **`Save.kt`: new fields go on the END of a row.** Inserting one mid-row
    breaks every existing save, and `read()` discards a wrong version in
    silence.

## Working agreement

- One task at a time, from `TASKS.md`, in order. Do not start the next one.
- Each task ends with: what changed, the gate output pasted in, the harness
  number that shows it worked, and anything you could not verify.
- Say plainly when something is unverified. An unverified claim costs more here
  than an unfinished task.
- Do not add a dependency. Do not add a build plugin. If you think one is
  needed, stop and ask.
- Do not touch `tools/gate/baseline.properties`, `.github/workflows/`, or
  `PROJECT_STATE.md` §5.

## Decisions that are not yours

Stop and ask rather than choosing:

- the save file format, and whether old careers are migrated or dropped;
- whether engine v1 is deleted;
- anything that changes how the football reads (decision scores, intent,
  objectives) — the plan exists, the timing is the owner's;
- art direction, faces, kits, the camera;
- anything that would move the fingerprint on purpose.
