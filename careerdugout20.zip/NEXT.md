# What to do next — ordered

Written against the zip as uploaded. Nothing here was compiled: this machine
has no `kotlinc` and the proxy blocks `dl.google.com` / Maven Central, so
step 0 is you running it once. Everything below names the file it touches.

---

## 0. Turn the harness into a gate (half a day)

The single biggest gap: **35,000 lines, ~90 measurement programs, and not one
of them can fail a build.** No `exitProcess` anywhere in `tools/`, no `src/test`,
and `.github/workflows/build.yml` is `workflow_dispatch` only and unzips a zip
out of the repo root — so the source is not versioned as source and no push is
ever checked.

Added here:

- `tools/gate/Gate.kt` — same FNV-1a fingerprint as `ResultFingerprint.kt` over
  the same fields, so the hashes stay comparable with the ones in your docs.
  Exits 1 when the results move, when a match never reaches full time, or when
  goals/game leaves a wide sanity band. `--record` writes the baseline.
- `.github/workflows/ci.yml` — on every push and PR: compile the shipped app
  against the shim, run the gate, run `UiFlow` and fail on any crash, then
  build the APK from the checkout.
- `.github/workflows/nightly-balance.yml` — `BalanceBig` nightly, artifact kept
  90 days.

**To bring it up:**

```sh
export PATH=$PATH:/opt/kotlin/kotlinc/bin
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt tools/harness/shim/ThemeStub.kt \
    tools/harness/Harness.kt tools/harness/UiFlow.kt tools/gate/Gate.kt \
    -include-runtime -d build/gate.jar
java -Djava.awt.headless=true -cp build/gate.jar GateKt --record   # once
git add tools/gate/baseline.properties && git commit
java -Djava.awt.headless=true -cp build/gate.jar GateKt            # must PASS
```

Then get write access on `sou1915/dugout` (the 403 on `git push` in
PROJECT_STATE §7). A gate on a repo nobody can push to is decoration.

Also missing: **no Gradle wrapper.** `gradle/wrapper/` and `gradlew` are not in
the zip, so CI builds with whatever Gradle the runner ships. Run
`gradle wrapper --gradle-version 8.9` and commit it, then switch the CI step to
`./gradlew assembleDebug`.

---

## 1. The docs describe an engine that is no longer the one running

`MatchEngine.ENGINE_V2 = true` is the shipped default, and the code itself says
`CHANCE_QUALITY` is "dead since ENGINE_V2 was switched" — but `BalanceBig`
still *sweeps* `CHANCE_QUALITY` and prints four rows of it, and PROJECT_STATE §3
still quotes it as the clock constant to reason about. `AUDIT.md` already caught
the fingerprint mismatch and said the verified state describes a build that no
longer exists.

Cheap and worth doing before any engine work: point `BalanceBig`'s sweep at
`V2_*` (the live lever), and put a one-line "which engine is on" banner at the
top of every harness's output. A sweep of a dead lever is the exact failure
mode the v4 comment says killed three systems in silence.

---

## 2. P1 from the audit: the corner that renders empty

`AUDIT.md` §1 already did the hard part — the staging gate is open on 100% of
corners with 9.32 s left, so the two hypotheses in PROJECT_STATE §6 are both
wrong and the fault is three time bases disagreeing. Finish that, with
`StageGate` + a rendered frame, not a table.

---

## 3. Break up the two files that make every fix expensive

| file | lines | worst function |
|---|---|---|
| `sim/MatchEngine.kt` | 6,292 | `update()` — **533 lines** |
| `MainActivity.kt` | 4,507 | `screenTactics()` — 288 |
| `ui/BroadcastRenderer.kt` | 1,494 | `drawPlayer()` — 356 |

Split by lifecycle, not by taste, and **with the gate green on either side of
each move** — the fingerprint must come back byte-identical, since a pure file
move changes no football:

- `MatchEngine` → `Phase.kt` (`newPhase`/`stepPhase`/`resolvePhase`),
  `Movement.kt` (`updateTargets`/`moveTowardTargets`), `SetPieces.kt`
  (`stageCorner`/`stageFreeKick`/walls), `Officials.kt`, `Replay.kt`.
- `MainActivity` → one file per screen, Activity keeps only routing.

## 4. Runtime and platform, before any store submission

- `targetSdk = 34`. Play requires 35 for new apps and updates now. Bump and
  re-test the landscape lock and `configChanges` path.
- No signing config, no release variant in CI, `versionCode = 1`.
- **World generation (~630 ms) runs on the main thread** in `buildWorld()`.
  On a low-end device that is an ANR waiting to happen — move it off, show the
  splash while it builds.
- The match loop is `loopHandler.postDelayed(this, 28L)` — a fixed 35 Hz timer,
  not vsync. `Choreographer.postFrameCallback`, or a `SurfaceView` with its own
  render thread, gets you an even frame and takes the sim off the UI thread.
- Per-frame allocation in the render path: `ArrayList<LivePlayer>(22)` in
  `applyReplayFrame()` and `restoreLiveFrame()`, `String.format` for the clock
  in the HUD. Hoist them into fields like `rPlayers` already is.
- No `onSaveInstanceState`; state lives in the Activity and survives only
  through `autosave()`. Process death mid-match loses the match.

## 5. `Save.kt` will eat a career

Positional `\u0001`-delimited rows, and `read()` rejects any header whose
version is not exactly `VERSION`, **deleting silently**. The file's own comment
documents this honestly, which is why it should be fixed now rather than after
players exist: move to `key=value` rows, tolerate unknown keys and missing
trailing fields, and keep the `.bak` you already write.

## 6. Only then: the decision-score layer

PROJECT_STATE §6.5 is right that this is the change that alters how the football
*reads* — the man on the ball never chooses. It will move the fingerprint by
design, and it will move balance. Do it after steps 0–1, so "it moved" is
information instead of a surprise.
