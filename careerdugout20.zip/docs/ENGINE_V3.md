# Engine v3 — physics, space, roles, utility

The owner's decision: rebuild again, on an architecture genuinely different from
both previous engines. Chosen shape: **a mix of full 2D physics, role-based
behaviour trees, and an influence-map space model**, with utility scoring on
top.

They are not three competing options. They stack:

```
  PHYSICS    the ball and the men are bodies with momentum and turn limits
     |
  SPACE      a pitch-control grid: who reaches which cell first
     |
  ROLES      a behaviour tree per man, from his role, choosing an INTENT
     |
  UTILITY    the man on the ball scores concrete actions against the space
```

Each layer only reads the one below it, which is what makes it testable and
what neither previous engine had.

---

## 1. Why again

v1 was a phase engine: outcome rolled before the ball moved, so eleven men could
never touch it. v2 fixed that with continuous possession and is measurably
better (2.59 goals, 45.7% home, ball at feet 26% → 44%). But v2 still decides
with *ad hoc* scoring — a hand-weighted sum in `v2Decide` — and its players have
no model of space at all. Every remaining v2 defect traces to that: play stays
central because the sum rewards centrality, off-ball movement barely exists
because nothing evaluates where space *is*, and pressing is one man because
there is no notion of covering a region.

v3 replaces the ad hoc sum with an actual model of the pitch.

## 2. The layers

### 2.1 Physics — `sim/Physics.kt`

Real integration, no interpolation along a path.

- **Ball**: position, velocity `(vx, vy, vz)`, spin. Rolling friction, air drag,
  gravity, bounce with restitution, Magnus drift from spin. A struck ball gets a
  velocity, not a destination — so where it ends up is a consequence, which is
  what makes deflections and misplaced passes free.
- **Bodies**: players have velocity, a maximum acceleration and a maximum turn
  rate scaled by their pace and agility. They cannot reverse instantly and they
  lose speed through a hard turn.

### 2.2 Space — `sim/Pitch.kt`

A pitch-control grid, the standard analytics model.

- The pitch is a coarse grid. For each cell, compute each player's
  **time-to-reach** given his current velocity (not just distance — a man
  running the wrong way is further away than one standing still).
- The cell belongs to whoever gets there first; team control is the share.
- Derived, and used by everything above: **space value** (control × how
  dangerous the cell is), **lane safety** for a pass, and **pressure** on a man
  as the opposition's control of his own cell.

This is the layer neither previous engine had, and it is what lets a player
run into space rather than at a team mate.

### 2.3 Roles — `sim/Roles.kt`

One small behaviour tree per man, selected from his position and the club's
tactics. It chooses an **intent**, not a destination:

```
  PRESS      go and close the man on the ball
  COVER      protect the space behind the press
  MARK       stay with a specific opponent
  HOLD       keep the line and the shape
  SUPPORT    offer an angle for the man on the ball
  RUN        attack space beyond the last defender
  WIDE       stretch the pitch
  RECOVER    get back goal-side
```

The manager's tactical instructions are the tree's parameters, so the tactics
screen edits football directly instead of nudging a rating.

### 2.4 Utility — the man on the ball

Every concrete option is scored against the space model rather than a
hand-tuned sum: pass to each team mate, carry in each of eight directions,
shoot, clear. Score = space gained + danger created − risk of loss, all read
off the grid.

## 3. The contract, unchanged

Same as v2: the renderer must not change. `MatchView`, `Career`, `League` and
`Save` all read the same public surface (`ball`, `players`, `score`, `scene`,
`clock`, `feed`, …). Scenes, staging, cards, subs, injuries and replay are kept
— they are measured correct and they are not the engine.

`UiFlow` 33/33 remains the cheap proof the contract held.

## 4. Kept honest the same way

`ENGINE_V3` is a flag, default off until it beats v2 on the harness. **All three
engines stay in the build.** That is not sentimentality: v1 as a control row is
what made every finding in this project provable, and it costs one boolean.

Acceptance, against the measured v2 figures:

| harness | v1 | v2 | v3 target |
|---|---|---|---|
| `BalanceBig` goals | 2.51 | 2.59 | 2.5–2.7 |
| home wins | 42.3% | 45.7% | ~45% |
| `BallAir` in flight | 55.4% | 24.9% | under 25% |
| ball at feet | 25.7% | 44.0% | over 50% |
| carrier pressed | 14.0% | 17.9% | over 30% |
| throw-ins per match | 8.0 | 1.0 | 5+ |
| `SceneAudit` | see doc | see doc | no worse than v2 |
| `UiFlow` | 33/33 | 33/33 | 33/33 |

Throw-ins are on the list because a real space model should fix them for free:
play uses the flanks when the flanks are where the space is.

## 5. Risks

- **Cost per tick.** A pitch-control grid over 22 players is the expensive part.
  It runs at a coarse resolution and on a reduced cadence (not every tick) for
  exactly this reason — this has to run on a phone.
- **Balance, again.** Third time earning it. Same levers, same 9-minute
  `BalanceBig` per attempt.
- **Nothing may be believed from a small sample.** A 20-match read said 2.35
  where 9,120 matches said 1.91. That mistake is not to be repeated.

## 6. State — SCAFFOLDED, NOT WORKING

- [x] Design agreed
- [x] `Physics.kt` — momentum, drag, gravity, bounce, spin, time-to-reach
- [x] `Pitch.kt` — pitch-control grid, space value, lane safety, best space
- [x] `RoleTree.kt` — behaviour trees, eleven intents, tactics as parameters
- [x] Utility scoring and the `v3Tick` adapter, wired and compiling
- [ ] **A match that actually plays** — this is where it stands
- [ ] Balance

**v3 does not work yet. It is off by default and must stay off.**

`V3Check`, 6 matches, all three engines on the same seeds:

```
      inFlight  at feet   loose  pressed  goals  shots  tackles  throws  stuck  cpu
v1       55.5%    25.8%   18.7%    14.3%   2.00   25.8     34.0     8.8      0  0.3s
v2       26.1%    45.7%   28.2%    11.8%   3.00   23.2     52.3     0.7      0  0.2s
v3        1.2%     6.4%   92.4%     1.0%   0.00    1.2      5.5     1.0      1  9.7s
```

The ball is loose for 92% of the match, almost nothing is struck, no goals are
scored, and one match in six runs to the tick guard rather than finishing.

### What has been fixed already

1. **Nothing put the ball into play at kick-off.** v2 got it moving through a
   pending restart; v3 had no equivalent, so the ball sat on the centre spot
   with nobody inside the 1.8 m control radius. A stall guard now hands it over.
2. **The decision layer ran at 36 Hz.** `RoleTree.targetFor` scans the grid for
   the best space, for 22 men, every tick, over a 408-second match — tens of
   millions of cell evaluations, measured at 8.8 s of CPU per match against
   v2's 0.2 s. It would have been unplayable on a phone. Intents now recompute
   at 6 Hz while movement stays at full rate; the grid is 16×11 rather than
   24×16.
3. **No intent meant "go and get a loose ball."** `PRESS` targets a cut-off
   angle, not the ball, so when nobody had possession all twenty two men held
   their shape and the ball simply lay there. Added `CHASE`.

### What is still wrong

`V3Trace` shows the opening of a match working — the ball is collected at about
four seconds, passes are struck and travel, the carrier holds it and moves with
it. So the layers are sound. Matches then **degenerate**: possession is not
recovered, the ball spends the rest of the match loose, and occasionally the
match never reaches full time at all.

The next session should trace a match at 30 s, 300 s and 2,000 s rather than
only the opening, and find where the loop stops recovering. The suspects, in
order: `v3Restart` never expiring on some path; `v3Contest` refusing every
candidate once ball speed stays above its threshold; and `v3LastTouch` going
stale so `v3Boundary` cannot award a restart.

### Cost is a real risk, not a theoretical one

Even fixed, v3's decision layer is far more expensive than v2's. The grid and
the 6 Hz cadence are load-bearing, not tuning. Any change that puts a grid scan
back on the per-tick path will make the game unplayable on a phone, and the CPU
column in `V3Check` is there to catch exactly that.

### v2 is unaffected

Verified after all v3 work: `BalanceBig` 9,120 matches still 2.59 ± 0.03 goals,
45.7% home, and `UiFlow` 33/33. v3 is quarantined behind its flag and cannot
break the shipping engine.
