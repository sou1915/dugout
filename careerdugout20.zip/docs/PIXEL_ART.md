# Pixel-art conversion

Reference supplied by the owner: a pixel-art football game — chunky low-res
sprites, hard edges, muted mown pitch, a shallow camera, a centre-pill
scoreboard and a bottom-centre radar.

**Graphics and art style only.** No simulation behaviour was changed by any of
this, and `UiFlow` 33/33 plus an unchanged `BalanceBig` are the proof.

---

## What was done

### 1. The pixel pipeline — the whole look, in two changes

`MatchView` already rendered the scene into an offscreen buffer and scaled it to
the screen. That is exactly the pipeline a pixel-art game wants; it was simply
being used at full resolution with a smooth filter, so the result read as flat
vector shapes.

- `PIXEL_WIDTH = 400` — the buffer is now the game's real resolution.
- The blit is **nearest-neighbour** (`isFilterBitmap = false`), so every source
  pixel becomes a hard square block.

No sprite sheets and no binary assets: the figures are still generated
procedurally from the seed, they are just drawn into a small grid. The
project's no-assets rule is intact.

### 2. The UI is drawn AFTER the upscale

The first rendered frame showed the scoreboard as `YARW 2-0 ULLF` — text
rendered into a 400-pixel buffer and blown up is unreadable. Pixel-art games
render the *world* at low resolution and the *interface* at the screen's own,
because a scoreboard is meant to be read. `drawOverlay` now draws the HUD,
captions and banners onto the full-resolution canvas after the blit.

### 3. Palette and camera

- Mown stripes moved from the arcade greens (`#48B41E` / `#3E9E18`, chosen for
  the J2ME reference) to muted naturals (`#6FA84C` / `#5E9440`). Contrast
  between the bands matters far more once every colour edge is a visible block.
- Camera depression 40° → **27°**. The reference shows the goal frame from the
  side with depth in the net; a flatter camera is most of that difference.

Everything is behind `PIXEL_ART`, `PIXEL_WIDTH` and `PIXEL_TILT`, so the
previous look is one boolean away and the two can be compared side by side.

### 4. The HUD, rebuilt to the reference layout

- **Centre pill**: each side's kit colour and three-letter code facing inward,
  the score in a darker inset between them, and the clock on a small tab riding
  above. The old top-left scoreboard was a broadcast convention, not an arcade
  one, and left the top of the frame lopsided.
- **Radar moved to bottom centre**, where the reference has it.

That last one deserves care, because it is where the radar *used* to be and it
was moved to the corner for a real reason: at 22% of the width it sat exactly
where the ball is, and every rendered frame had a green rectangle on top of the
football. "The reference does it" is not evidence that it works here.

So it is measured. `RadarCover` renders live matches and asks how often the
ball actually falls behind the HUD:

```
frames sampled              3175
ball behind the RADAR          0    0.00%
ball behind a NAME PLATE       0    0.00%
```

It is safe now because it is 15% of the width rather than 22%, and because the
shallower camera puts the ball higher in the frame. If either figure ever climbs
above about a percent, it goes back to the corner — the reference is a guide,
not a licence to reintroduce a bug that was caught by looking.

### 5. Figure proportions

`headR` 0.195 → **0.285** of the figure scale, with the body shortened to match
so overall height barely moves and the camera framing is unaffected.

0.195 puts the head at about H/4.5, which is a real human being and is correct
for the broadcast look. The pixel-art reference draws its footballers nearer
H/3 — a big head on a short stocky body — and that is not stylistic
indulgence: at the size these sprites occupy, a correctly proportioned head is
three or four pixels and simply disappears.

## What is NOT done

Judged against the reference, honestly:

- **Sprite OUTLINES.** Head proportions are done (see below); the reference
  also draws a hard dark outline around each figure, which is what separates a
  sprite from the grass at these sizes. Not attempted.
- **No crowd at this angle.** The reference shows stands and a fence behind the
  boundary; at 27° the existing crowd band still leaves the frame.
- **Effects**: the reference has dust puffs on a tackle, motion streaks and
  confetti. None of that exists here.
- `PIXEL_WIDTH = 400` is a first guess. It wants sweeping by eye against the
  reference — 320 is chunkier, 480 finer.
