# The graveyard

Measured, not asserted. Numbers from the tree at commit `fb527d0`.

The owner, after playing the build: *"kan7es ba9i kayn chi secret mazal
mate7nach 3lih 7it ga3 l7olol li derti still l players f terain w animation w
scenes ya makayninch ya kaytdaro btari9a ghabiya."*

He is right, and this is the answer. It is not a missing feature. **A third of
the match code never executes**, and it is consistently the good third.

## What does not run

| what | lines | why it is dark |
|---|---:|---|
| `OffBall.kt` — what the other 21 are doing | 671 | `ENABLED = false` |
| `Pitch.kt` — the model of space | 169 | only v3 calls it, and v3 is off |
| `RoleTree.kt` — roles and intents | 205 | same |
| the v3 path inside `MatchEngine` | 395 | `ENGINE_V3 = false` |
| the v1 path (`newPhase`, `stepPhase`, `resolvePhase`) | ~670 | the `else` under `ENGINE_V2` |
| the body of `fire(show = true)` | ~40 | **nothing anywhere passes `show = true`** |
| `Ev4.SHOWN` — 90 authored rows of scene/pose/caption/crowd/referee | 489 | read only by that body |

≈ **2,400 of the ~7,800 lines** of match code.

## The number that explains the complaint

    1,045 lines were written to make the twenty one players without the ball
    intelligent -- OffBall.kt + Pitch.kt + RoleTree.kt.
    Not one of them runs.

What actually moves those twenty one is `updateTargets`, and its whole model is:

    a formation slot, plus a pull toward the ball

That is why they look stupid. Not for want of code — the code exists and is
switched off.

## The same shape in the presentation layer

```kotlin
fun fire(ev: Int, ..., show: Boolean = true) {
    evCount[ev]++
    buildLine(ev, actor, foe)
    if (!show) return          // <- every caller stops here
    val sh = Ev4.SHOWN[ev]     // <- never executed
    ...
}
```

All 30 call sites use `note()`, which is `fire(show = false)`. So 90 authored
rows of presentation have never been drawn once.

## Why this keeps happening

This is the fifth time the same defect shape has been found in this project:
correct code on a path that is no longer the path that runs. `v2Defend` never
called. `CHANCE_QUALITY` swept while dead. Skills and `Scene.TAKE_ON` reachable
only from v1. `L_DRIBBLE` indexing out of bounds because nothing had ever called
it. And now the whole event table.

The habit behind it: each session writes the right thing, puts it behind a flag,
and moves on. The next session writes something **new** instead of switching on
what is already there. The build the owner plays is therefore the oldest and
dumbest layer, because it is the only one turned on.

## What to do about it

Not "write more". **Drain the graveyard**, one flag at a time, each with a gate:

1. `fire(show = true)` for the rows that carry no pose. Captions and scenes
   appear. Fingerprint must stay `7afa3890202dabdd`.
2. Fix `OffBall`'s four measured defects, then `ENABLED = true`. The twenty one
   get jobs instead of slots.
3. Lift `Pitch.kt` out of v3 so "where is the space" has an answer at all. This
   is the root of: no width, no crosses (1.00 a match), a third of passes played
   to men already offside.
4. Delete what stays dead. A dead path costs nothing to run and everything to
   read, and it is where the last five defects hid.

A rule that would have prevented all of it, and should now hold: **a flag that
has been `false` for two sessions is either switched on or deleted.**

---

## Draining it, run by run

### 4a — captions and crowd. Landed.

`Ev4.DRAWN` decides which rows may draw themselves, in one table next to
`Ev4.SHOWN`. Group 4a on. Gate `7afa3890202dabdd`, byte identical, as a word on
a screen must be. PoseTime, seconds a match: SWITCH 21.1, ADDED TIME 2.8,
HALF TIME 1.5, CROSS 1.4, THROUGH BALL 1.1, CUT-BACK 0.2.

### 4b — scenes. Landed.

Fingerprint `7afa3890202dabdd` → `da1caad36bfeca9b`, expected: a scene changes
dead-ball movement speed. BalanceBig over 9,120 matches: **2.54 ± 0.03 goals,
45.9% home, inside the target band.** Kept.

### OffBall — two defects found, fixed, and it is still not switched on

**Defect 1: the whole layer was a no-op.** Measured on and off over six
matches, the two runs were identical to three significant figures — 4.00 goals,
51.9% of men in the middle fifth, the same CPU — while the job distribution
showed the layer working normally. `updateTargets` assigns `targetX` from the
formation slot EVERY frame; `tick` re-decides every `THINK_HZ` = 0.22 s, about
one frame in eight, and returned early on the other seven without putting its
own target back. A man moved toward his job for a single 1/36 s frame and was
then pulled back into the diagram. Fixed by `reapply`. **Sixth instance of the
same defect shape in this project.**

**Defect 2: nobody ever entered the penalty area.** `ATTACK_BOX` required a
wide carrier, and v2 does not play down the flanks — 1.00 cross a match. The
row fired for 0.3% of player-time. Now it fires when the ball is in the final
third, whoever has it.

**And with both fixed, the layer must still stay off.** Eight matches, on
against off:

| | goals | shots | men in the middle fifth | ball carried to |
|---|---:|---:|---:|---:|
| off | 3.88 | 23.5 | 52.0% | x = 38.6 |
| on | 0.75 | 8.0 | 33.8% | x = 45.3 |

Every column except the first two is **better**: the men spread out, and the
ball is carried further up the pitch. What the layer does is make the defending
side actually defend — and that exposes the real hole, which is that v2's
attack cannot break down a defence that works. Shots fall by two thirds because
the carrier no longer strolls into range.

That also explains the 23.5 shots in the "off" column: they are struck from an
average carry position of x = 38.6 out of 100, which is the attacking side's
OWN HALF. The old number was never 23 chances; it was 23 hopeful strikes from
distance that nothing prevented.

`V2_SHOT_BASE` cannot put this back. Conversion would have to run at 32% to
reach 2.6 goals from 8 shots, against a real 11%. The missing thing is
build-up, not finishing, and build-up is what `Pitch.kt` was written for.

**So: `ENABLED` stays `false`, and the reason is now a measurement rather than
a worry.** The next piece is the one that lets a side advance the ball against
an organised defence.

### Pitch.kt into v2 — TRIED AND REVERTED

The obvious next move, and it does not work. `Pitch.kt`'s control grid was
computed on a 0.40 s beat under v2 and used in two places: a `spaceValue` term
in the pass scorer, and `bestSpace` for the carrier's run. Eight matches:

| | goals | shots | ball carried to |
|---|---:|---:|---:|
| before | 3.88 | 23.5 | x = 38.6 |
| space in the scorer + carry | 3.00 | 22.8 | x = **37.8** |
| same, carry constrained to forward space only | 3.38 | 21.9 | x = 38.7 |

The ball goes no further up the pitch and slightly fewer shots are taken. The
cause is in `spaceValue` itself:

    spaceValue = controlFor(side) * (0.34 + danger(side))

A side's control is highest **behind its own ball**, where its own players are.
Danger is highest near the opponents' goal, where its control is lowest. The
product is therefore largest in the comfortable middle, so the term rewards
keeping the ball where the team already is — which is precisely the behaviour
that needed changing. Constraining the carrier to forward cells only recovered
the lost ground and no more.

`spaceValue` is a good answer to "is this a good place to HAVE the ball". Build-
up needs "what is the best place to have it NEXT", which is a gradient over
phases, not a level. That is a different piece of work, and bolting a level
onto v2's existing pass score is not it.

Reverted whole; the gate returned to `da1caad36bfeca9b` exactly, which is the
proof the revert was clean. **No flag was left behind** — leaving a switched-off
`V2_SPACE` would have been one more line in this same document.

---

## The movement itself, finally measured

The owner, after all of the above: the players still move wrongly. He is right,
and nothing in `tools/harness/` measured the thing he is looking at.
`MotionCheck` measures SMOOTHNESS -- turn rates, teleports. `GaitSpread`
measures EFFORT -- walking against sprinting. Both can read perfectly while all
ten outfielders drift across the pitch as one clump, which is what the eye
actually calls wrong. `ShapeAudit.kt` measures shape and independence.

Eight matches:

| | measured | a real match |
|---|---:|---|
| average speed, per man | 2.56 m/s | 1.9 m/s |
| **togetherness (pairwise cosine)** | **0.50** | **0.2 – 0.3** |
| nearest team mate | 10.7 m | 15 – 20 m |
| two men inside 3 m of each other | 10.4% | rare |
| team width | 44.0 m | 35 – 45 m |
| team depth | 44.7 m | 30 – 40 m |
| within 5 m of his formation slot | 7.2% | a small share |
| standing still | 28.4% | some |

**Togetherness 0.50 is the defect.** It is the mean cosine between every pair of
outfielders' velocities: 0 is ten men going ten ways, 1 is one object being
dragged. A real team sits at 0.2–0.3 — mostly the same way, because play has a
direction, but each man has his own job. At 0.50 they are half a shoal, and
that is the single number behind "they move wrongly".

It follows directly from the model, which is exactly one rule:

    a formation slot, plus a pull toward the ball

The slot is the same for everybody in a phase and the pull is the same vector
for everybody, so the only thing distinguishing two players' movement is where
they started. They are not doing different things; they are the same thing
offset.

The two crowding numbers are the same fault seen from the side. Nearest team
mate 10.7 m against a real 15–20, and two men standing inside 3 m of each other
for 10.4% of the match: nothing in the model keeps players apart, so the
common pull collapses them together.

### Three things this rules out

- **Not slot lock.** Men are within 5 m of their formation spot only 7.2% of
  the time, so they are not glued to a diagram — they are being dragged off it,
  together.
- **Not speed.** 2.56 m/s of animation is if anything slightly busy.
- **Not shape at the extremes.** Width 44.0 m is inside the real band and depth
  44.7 m is only a little stretched. The team's outline is roughly right; what
  is wrong is everything inside it.

### And a seventh dead path found on the way

`LivePlayer.vx` and `vy` carry the comment *"Engine v3 integrates this"*, and
that is literally true — under `ENGINE_V2` nothing ever writes them. The first
run of this harness read a togetherness of `NaN` off twenty two zero vectors.
Velocity is now taken from where each man actually was a frame ago.

`OffBall` is the layer that would fix togetherness — twelve different jobs is
twelve different directions — and `ObCheck` already shows it pulling the men
apart, 52.0% to 33.8% in the middle fifth. It cannot be switched on until a
side can advance the ball against a defence that works. That is the one piece
of real work left, and everything now points at it from a different direction.

### Scaling the shared pull — TRIED AND REVERTED, and the failure is the proof

The obvious answer to togetherness 0.50: stop giving every man the same pull.
A centre half tracks the ball's x hard because he holds a line off it; a
striker does not drop thirty metres because the ball went back to the keeper. A
wide man's job is his y, and a winger who slides infield every time the ball
does is why half the side sits in the middle fifth. So the coefficients were
made role-dependent, read from the position group and the slot the formation
drew:

    xPull   forwards 0.60   midfield 0.88   defence 1.12
    yPull   wide 0.42       central 1.14

Eight matches:

| | before | after |
|---|---:|---:|
| togetherness | 0.50 | **0.49** |
| nearest team mate | 10.7 m | 11.0 m |
| team width | 44.0 m | 44.8 m |
| standing still | 28.4% | **34.6%** |

Nothing, and the one column that moved got worse.

**Why it cannot work, which is worth more than the change.** Togetherness is a
measure of DIRECTION — the cosine between two velocity vectors. Every player's
target is a function of one shared input, the ball's position, so every
player's movement points along the same line however the gain is set. A man
pulled at 0.60 and a man pulled at 1.12 move the same way at different speeds,
and the cosine between them is 1 either way. Scaling a shared signal cannot
produce independence; it can only produce a bigger or smaller version of the
same motion. The extra standing-still is the same fact seen from the side:
weaker gains leave more men already close enough to their target to stop.

Independence needs different DESTINATIONS, not different gains. Twelve jobs
pointing twelve ways is the only thing in this repository that produces them,
and `OffBall` is that layer. `ObCheck` already measures it doing exactly this —
52.0% to 33.8% of men in the middle fifth.

So every road now ends at the same place: **switch `OffBall` on, which requires
that a side can advance the ball against a defence that works.** Three separate
attempts from three different directions have now been reverted onto that one
conclusion, and it is the whole of what is left.

Reverted; gate back to `da1caad36bfeca9b` exactly, UiFlow 33/33, and no flag
left behind.

---

## Why `OffBall` cannot simply be switched on: the census with it running

`EventCensus` now takes a second argument that turns the layer on, because a
census of a football where nobody is marking is a census of a different game.
Twelve matches each:

| | layer off | layer on |
|---|---:|---:|
| short pass | 61.33 | **238.08** |
| long pass | 75.25 | **6.00** |
| first touch | 144.92 | 256.50 |
| heavy touch | 3.58 | 44.17 |
| shots | 25.8 | 6.75 |
| interception | 29.92 | 35.17 |
| goal kick | 19.58 | 5.25 |
| corner won | 4.83 | 1.08 |
| offside | 7.33 | 1.17 |

This is not a side being strangled. It is a side that **keeps the ball
beautifully and never goes anywhere with it**: 238 short passes against 6 long
ones. Every man it can see is beside it and safe, because the attacking half of
the layer offers `SUPPORT` and `SHOW_SHORT` and almost nothing that breaks a
line — `RUN_BEYOND` fires for 0.1% of player-time.

And it says something uncomfortable about the shipped engine in the left-hand
column. **75 long passes against 61 short ones** is how v2 currently advances:
it hoofs it and hopes, and the 25.8 shots it produces are the yield of that
lottery, struck from an average carry position in its own half. The layer does
not remove real chances; it removes a lottery and has nothing to replace it
with yet.

### The progress lever, swept

`V2_PROGRESS_W` — what a pass is worth for gaining ground, against a lane term
worth 16 for being safe — was a hard-coded 1.15. Six matches at each setting,
with the layer both ways:

| weight | layer | goals | shots | carry x | middle fifth |
|---:|---|---:|---:|---:|---:|
| 1.15 | off | 3.33 | 24.5 | 38.2 | 53.9% |
| 1.15 | on | 1.00 | 7.8 | 44.4 | 33.0% |
| 2.20 | on | 1.00 | 11.7 | 43.7 | 37.5% |
| 3.40 | on | 1.83 | 10.8 | 44.0 | 37.9% |
| 5.00 | on | 1.50 | 10.5 | 44.6 | 40.1% |
| 7.50 | on | 1.83 | 15.2 | 42.6 | 44.0% |

It buys shots and gives back the spread: by 7.50 the middle fifth is at 44.0%,
most of the way back to the 53.9% the layer was supposed to fix, and goals are
still 1.83 against a target of 2.6. **One lever does not do it**, and pushing
this one undoes the thing the layer is for.

### What is actually missing

The defensive half of `OffBall` is finished — press, cover, mark, recover — and
it works, which is why the ball stops going anywhere. The attacking half is
`SUPPORT` and `SHOW_SHORT`, both of which offer the carrier a man BESIDE him.
There is nothing that offers him a man PAST somebody. `RUN_BEYOND` exists and
fires for 0.1% of player-time; `ATTACK_BOX` for 0.4%.

That is the job, and it is design rather than tuning: runs that break a line,
timed against the carrier's think, so that a forward pass has a receiver worth
more than the safe sideways one. Until then the layer's own measurements are
the argument for it and the reason it stays off.

### The one change that did land: he looks up before he hoofs it

The hurried clearance was decided BEFORE anybody was scored — in his own third,
under pressure, half the time, the ball went long and wide full stop, whether
or not a team mate stood free ten metres away. It is now decided AFTER the
options are scored, and only fires when the best of them is genuinely poor
(`V2_CLEAR_BELOW`, on the pass scorer's own scale).

That is a decision-quality change and it holds either way — the same football
with the layer on or off. It is also the only thing in this session's engine
work that survived measurement.

    gate         da1caad36bfeca9b -> abdd486e4a3b9af2
    BalanceBig   2.60 +/- 0.03 goals, 45.4% home, INSIDE THE TARGET BAND
    clearances   5.35 -> 1.58 a match
    UiFlow       33/33

It does not rescue `OffBall`: shots with the layer on went 8.0 to 8.0. It was
never the bottleneck, and finding that out is what the census was for.
