# The graveyard

Measured, not asserted. Numbers from the tree at commit `fb527d0`.

The owner, after playing the build: *"kan7es ba9i kayn chi secret mazal
mate7nach 3lih 7it ga3 l7olol li derti still l players f terain w animation w
scenes ya makayninch ya kaytdaro btari9a ghabiya."*

He is right, and this is the answer. It is not a missing feature. **A third of
the match code never executes**, and it is consistently the good third.

## What does not run

| what | lines | why it is dark |
|---|---:|---|
| `OffBall.kt` — what the other 21 are doing | 671 | `ENABLED = false` |
| `Pitch.kt` — the model of space | 169 | only v3 calls it, and v3 is off |
| `RoleTree.kt` — roles and intents | 205 | same |
| the v3 path inside `MatchEngine` | 395 | `ENGINE_V3 = false` |
| the v1 path (`newPhase`, `stepPhase`, `resolvePhase`) | ~670 | the `else` under `ENGINE_V2` |
| the body of `fire(show = true)` | ~40 | **nothing anywhere passes `show = true`** |
| `Ev4.SHOWN` — 90 authored rows of scene/pose/caption/crowd/referee | 489 | read only by that body |

≈ **2,400 of the ~7,800 lines** of match code.

## The number that explains the complaint

    1,045 lines were written to make the twenty one players without the ball
    intelligent -- OffBall.kt + Pitch.kt + RoleTree.kt.
    Not one of them runs.

What actually moves those twenty one is `updateTargets`, and its whole model is:

    a formation slot, plus a pull toward the ball

That is why they look stupid. Not for want of code — the code exists and is
switched off.

## The same shape in the presentation layer

```kotlin
fun fire(ev: Int, ..., show: Boolean = true) {
    evCount[ev]++
    buildLine(ev, actor, foe)
    if (!show) return          // <- every caller stops here
    val sh = Ev4.SHOWN[ev]     // <- never executed
    ...
}
```

All 30 call sites use `note()`, which is `fire(show = false)`. So 90 authored
rows of presentation have never been drawn once.

## Why this keeps happening

This is the fifth time the same defect shape has been found in this project:
correct code on a path that is no longer the path that runs. `v2Defend` never
called. `CHANCE_QUALITY` swept while dead. Skills and `Scene.TAKE_ON` reachable
only from v1. `L_DRIBBLE` indexing out of bounds because nothing had ever called
it. And now the whole event table.

The habit behind it: each session writes the right thing, puts it behind a flag,
and moves on. The next session writes something **new** instead of switching on
what is already there. The build the owner plays is therefore the oldest and
dumbest layer, because it is the only one turned on.

## What to do about it

Not "write more". **Drain the graveyard**, one flag at a time, each with a gate:

1. `fire(show = true)` for the rows that carry no pose. Captions and scenes
   appear. Fingerprint must stay `7afa3890202dabdd`.
2. Fix `OffBall`'s four measured defects, then `ENABLED = true`. The twenty one
   get jobs instead of slots.
3. Lift `Pitch.kt` out of v3 so "where is the space" has an answer at all. This
   is the root of: no width, no crosses (1.00 a match), a third of passes played
   to men already offside.
4. Delete what stays dead. A dead path costs nothing to run and everything to
   read, and it is where the last five defects hid.

A rule that would have prevented all of it, and should now hold: **a flag that
has been `false` for two sessions is either switched on or deleted.**
