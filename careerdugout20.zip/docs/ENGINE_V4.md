# Engine v4 — keep what is proven, rewrite what is measured broken

The owner's instruction, in his words: take from every version only what was
right, put it in a new engine, and rewrite from scratch whatever still has a
problem — and try ideas that have never been tried here, because nobody knows
until they are measured.

This document is the split, and the new ideas. Every line of it points at a
number that already exists in AUDIT.md or a named harness.

---

## 1. What is kept, and why

| Kept | From | The evidence |
|---|---|---|
| `Physics.kt` — momentum, drag, gravity, bounce, spin, time-to-reach | v3 | written and sound; a struck ball gets a velocity, not a destination |
| `Pitch.kt` — pitch-control grid, 16×11 at 6 Hz | v3 | the layer neither v1 nor v2 had, and cost-controlled (v3's CPU column) |
| `RoleTree.kt` — one behaviour tree per man, eleven intents | v3 | tactics become the tree's parameters instead of nudging a rating |
| The ball is a contested OBJECT, not an assignment | v2 | ball at feet 26% → 44%, in flight 55% → 25% (`BallAir`, `V3Check`) |
| Scenes, staging, cards, subs, injuries, replay | v1/v2 | `SceneAudit` 83–95%; `GoalNet` 100% of goals in the net |
| Renderer, camera, HUD, radar | — | `RadarCover` 0.00% ball occlusion; frames rendered and looked at |
| `Save`, `League`, `Career`, world generation | — | untouched and working |
| `BalanceBig`, `ResultFingerprint`, `UiFlow` and ~120 harnesses | — | the only reason anything here is provable |

## 2. What is rewritten, and the number that condemns it

| Rewritten | The measurement |
|---|---|
| `v2Decide` — a hand-weighted sum of distances | play is 69% central for the man on the ball (`WidthCheck`); two attempts to fix it by re-weighting the sum moved nothing |
| `updateTargets` — formation slots plus a pull toward the ball | the men sit 48% inside the middle fifth; the shape has no idea where space is |
| the urgency table in `moveTowardTargets` | **at a corner the attacking side closes 20 m of a 40 m gap in 4.4 s and the corner is over before they arrive: 2 attackers in the box against 8 defenders** (`CornerFilm`) |
| `tactics.press` | "Press them" makes the press WORSE — carrier's nearest opponent 5.7 m → 6.5 m (`ShoutCheck`) |
| `driftX` applied per frame | the ball's run-on depends on frame rate and is a quarter of what it should be at 4× |
| pose durations | a slide is on screen 2.1 s of a 407 s match, a foul 2.0 s, the referee 2.8 s (`PoseTime`) |

## 3. The new ideas — none of these has been tried in this project

### 3.1 ARRIVE BY, not RUN HARD  *(replaces the urgency table)*

Every version so far answered "how fast should this man run?" with a table of
distance-to-ball bands multiplied by a hand-tuned urgency. That is why a corner
fails: the men are told to go to the box, the table gives them 0.80 of their
pace, and the corner is taken before they get there. No amount of tuning the
multiplier fixes it, because the multiplier does not know the deadline.

So invert it. A target comes with a **time**: *be there in N seconds*. Speed is
then derived, not chosen:

```
  needed = distance / secondsLeft        clamped to his physical maximum
```

A man 40 m from the six yard box with 8 seconds runs at 5 m/s and **arrives**.
The same man with 30 seconds walks. A defender who must be goal-side before the
ball gets there sets his own pace from `Physics.timeToReach`. Nobody sprints
because a number said 0.95; they move at the speed the situation requires.

This is testable on its own, inside the current engine, before anything else of
v4 exists — which is why it is first.

### 3.2 The ball belongs to whoever gets there first  *(replaces control radii)*

v2 hands the ball to anyone inside a 1.8 m radius. v3 refuses candidates whose
ball speed is too high, and that refusal is the leading suspect for why a v3
match degenerates into a 92%-loose ball.

Instead, no radius and no roll: every player continuously has a **claim time** —
`Physics.timeToReach` to where the ball will be — and the ball goes to the
lowest claim, with the strength/composure difference deciding a genuine 50-50.
A ball nobody can reach stays loose because nobody's claim is low, not because a
threshold said no. That removes the whole class of "the ball just sits there".

### 3.3 A set piece is a PLAY, with parts and deadlines  *(replaces scatter)*

`stageCorner` sends nine men to random points in a box and hopes. A real corner
has parts: a taker (at the arc, deadline 1.5 s), a near-post runner and a far-post
runner with **staggered** arrival deadlines so they attack the ball rather than
stand in it, a short option, an edge-of-the-box man, and two holding against the
counter. Written as parts with deadlines, using 3.1, the routine plays itself out
and the tactical corner settings (near post / far post / short / edge, and how
many men go up) finally mean something.

### 3.4 Instructions reach the code that does the thing

`tactics.press` currently only slides the shape toward the ball. In v4 an
instruction is a parameter of the layer it names: pressing sets how many men
join the press and how early they engage; width sets where the role trees look
for space; tempo sets how long a man holds the ball. If an instruction cannot be
seen in a measurement, it does not ship — `ShoutCheck` is the gate.

## 4. How it stays honest

Unchanged from v2 and v3, because it is the only reason this project can tell
progress from noise:

- `ENGINE_V4` is a flag, default OFF, and v1/v2/v3 all stay in the build.
- Nothing lands without `BalanceBig` — 9,120 matches, target 2.5–2.7 goals,
  ~45% home. v2 currently sits at **2.59 ± 0.03, 43.8% home**.
- `ResultFingerprint` for anything claimed cosmetic.
- `UiFlow` 33/33.
- Render frames and LOOK at them. `CornerFilm` and `GoalFilm` exist for exactly
  this and both found defects no aggregate had seen.
- Revert what does not work and write down that it did not.

## 5. Order of work

1. **3.1 ARRIVE BY** — **DONE**. `CornerFilm`: attackers in the box at the
   delivery 5 → 8, mean gap to target 7.6 m → 3.6 m. `BalanceBig` 2.56 ± 0.03,
   43.9% home. AUDIT.md §11.
2. **3.3 the corner as a play** — **DONE**. `CornerPlay`: the four routines and
   the three commitment settings now put men in measurably different places;
   everyone-up 6.3 in the box against keep-men-back 3.9 with 4.0 held in their
   own half. Mean gap at the delivery 2.1 m. AUDIT.md §12.
3. **3.2 claim-time possession** — next, and it is also the fix for v3
   degenerating into a 92%-loose ball.
4. **3.4 instructions**, gated on `ShoutCheck`. The known defect is that
   "Press them" moves the carrier's nearest opponent from 5.7 m to 6.5 m.
5. Then, and only then, the decision layer on the grid.

Each step is shippable on its own. That is deliberate: three engines have been
written in this project and the two that landed did so because they could be
measured one piece at a time.

---

## 6. Idea 6 — the event tree  *(the owner's, and it is the right one)*

His words: *make a tree for every event that happens in a normal football match,
like a trigger — if this event happens, this scene happens.*

### Why it is the right idea

Three separate defects in this audit are the same defect:

| found | what it was |
|---|---|
| `v2Defend` | written, correct, **never called** — 56 tackles and zero fouls |
| `CHANCE_QUALITY` | swept by `BalanceBig` for months while **dead** under v2 |
| skills and `Scene.TAKE_ON` | correct, and **only reachable from v1** — 0.00 a match |

Every one is presentation or logic wired directly into one engine's decision
path, which then stopped being the engine that runs. Nothing declares "a foul
must produce a free kick, a whistle and a man on the floor", so when the caller
moves, the scene dies **in silence**.

The event tree makes that impossible: the engine reports **what happened**, and
one table decides what is shown.

### The table

Seventy one events. The columns are what the table OWNS: nothing outside it may
set `scene`, `sceneTime`, call `act`, `cue` or move `crowdTarget`.

- **scene** — the caption machinery's scene, or `-` for none
- **pose** — the actor's `Act`, and who the actor is
- **caption** — what is written on screen
- **ref** — what the referee does: whistle, card, spray, advantage, flag
- **crowd** — target crowd level, `+n` meaning a nudge rather than a level
- **hold** — `live` keeps play running, `dead` stops it

```
  ON THE BALL                scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  FIRST_TOUCH                -          -           -                -         -     live
  TOUCH_HEAVY                -          -           -                -         -     live
  SHIELD_BALL                -          SHIELD      -                -         -     live
  TURN_AWAY                  -          TURN        -                -         -     live
  DRIVE_FORWARD              -          -           -                -        +0.05  live
  TAKE_ON_ATTEMPT            TAKE_ON    DRIBBLE     TAKE-ON          -        0.55   live
  TAKE_ON_WON                TAKE_ON    DRIBBLE     TAKE-ON          -        0.65   live
  TAKE_ON_LOST               -          -           -                -         -     live
  SKILL_MOVE                 TAKE_ON    DRIBBLE     <trick name>     -        0.80   live
  NUTMEG                     TAKE_ON    DRIBBLE     NUTMEG           -        0.85   live
  BACKHEEL                   -          FLICK       -                -        0.60   live
  FLICK_ON                   -          HEADER      -                -         -     live
  DISPOSSESSED               -          -           -                -         -     live

  PASSING                    scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  PASS_SHORT                 -          -           -                -         -     live
  PASS_LONG                  -          PASS_LONG   -                -         -     live
  PASS_SWITCH                -          PASS_LONG   SWITCH           -        +0.05  live
  THROUGH_BALL               -          PASS        THROUGH BALL     -        0.70   live
  ONE_TWO                    -          -           ONE-TWO          -        0.60   live
  CROSS                      -          CROSS       CROSS            -        0.65   live
  CUT_BACK                   -          PASS        CUT-BACK         -        0.70   live
  PASS_MISPLACED             -          -           -                -         -     live
  PASS_INTERCEPTED           TACKLE     -           INTERCEPTION     -        0.40   live

  SHOOTING                   scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  SHOT_STRUCK                SHOT       SHOOT       SHOT             -        0.80   live
  SHOT_HEADER                SHOT       HEADER      HEADER           -        0.80   live
  SHOT_VOLLEY                SHOT       VOLLEY      VOLLEY           -        0.88   live
  SHOT_LONG_RANGE            SHOT       SHOOT       FROM DISTANCE    -        0.82   live
  SHOT_CHIP                  SHOT       SHOOT       CHIPPED          -        0.85   live
  SHOT_FREE_KICK             SHOT       SHOOT       FREE KICK        -        0.85   live
  SHOT_BLOCKED               -          BLOCK       BLOCKED          -        0.55   live
  SHOT_DEFLECTED             -          -           DEFLECTED        -        0.70   live
  SHOT_WIDE                  -          -           -                -        0.35   live
  WOODWORK                   SHOT       -           OFF THE POST     -        0.95   live
  REBOUND                    SHOT       -           REBOUND          -        0.90   live
  GOAL                       -          CELEBRATE   GOAL!            -        1.00   dead
  GOAL_DISALLOWED            -          -           NO GOAL          whistle  0.20   dead
  OWN_GOAL                   -          DOWN        OWN GOAL         -        0.55   dead

  GOALKEEPING                scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  SAVE_ROUTINE               SAVE       CATCH       SAVE             -        0.50   live
  SAVE_DIVING                SAVE       DIVE        SAVE             -        0.75   live
  SAVE_TIP_OVER              SAVE       DIVE        TIPPED OVER      -        0.85   live
  SAVE_PARRY                 SAVE       DIVE        PARRIED          -        0.75   live
  SAVE_PENALTY               SAVE       DIVE        SAVED IT!        -        1.00   live
  KEEPER_CLAIM_CROSS         -          CATCH       -                -        0.30   live
  KEEPER_PUNCH               -          PUNCH       -                -        0.45   live
  KEEPER_SWEEP               -          -           OFF HIS LINE     -        0.60   live
  KEEPER_DISTRIBUTION        -          THROW       -                -         -     live
  KEEPER_UP_FOR_CORNER       CORNER     -           KEEPER IS UP     -        0.95   dead

  DEFENDING                  scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  TACKLE_WON                 TACKLE     TACKLE      TACKLE           -        0.50   live
  TACKLE_SLIDING             TACKLE     TACKLE      SLIDING IN       -        0.65   live
  TACKLE_LAST_DITCH          TACKLE     TACKLE      LAST-DITCH       -        0.90   live
  INTERCEPTION               TACKLE     -           INTERCEPTION     -        0.35   live
  BLOCK                      -          BLOCK       BLOCKED          -        0.60   live
  CLEARANCE                  -          CLEAR       -                -         -     live
  CLEARANCE_HEADED           -          HEADER      -                -         -     live
  RECOVERY_RUN               -          -           -                -         -     live
  OFFSIDE_TRAP_SPRUNG        FREEKICK   -           OFFSIDE          flag     0.30   dead
  GOAL_LINE_CLEARANCE        -          CLEAR       OFF THE LINE!    -        0.95   live

  FOULS AND DISCIPLINE       scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  FOUL                       FREEKICK   DOWN        FREE KICK        whistle  0.40   dead
  FOUL_ADVANTAGE             -          -           ADVANTAGE        advant.  0.45   live
  FOUL_IN_BOX                PENALTY    DOWN        PENALTY          whistle  1.00   dead
  HANDBALL                   FREEKICK   -           HANDBALL         whistle  0.50   dead
  CARD_YELLOW                CARD       -           BOOKED           card     0.65   dead
  CARD_SECOND_YELLOW         CARD       -           SENT OFF         card     0.90   dead
  CARD_RED                   CARD       -           RED CARD         card     0.95   dead
  PROFESSIONAL_FOUL          CARD       TACKLE      CYNICAL          card     0.80   dead
  DISSENT                    CARD       -           DISSENT          card     0.55   dead
  MELEE                      -          -           TEMPERS FRAYING  whistle  0.75   dead
  OFFSIDE                    FREEKICK   -           OFFSIDE          flag     0.30   dead

  SET PIECES AND RESTARTS    scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  THROW_IN                   THROW_IN   THROW       THROW-IN         -         -     dead
  THROW_LONG                 THROW_IN   THROW       LONG THROW       -        0.55   dead
  GOAL_KICK                  GOAL_KICK  -           GOAL KICK        -         -     dead
  CORNER_WON                 CORNER     -           CORNER           -        0.55   dead
  FREE_KICK_DIRECT           FREEKICK   -           FREE KICK        spray    0.70   dead
  FREE_KICK_INDIRECT         FREEKICK   -           FREE KICK        whistle  0.45   dead
  PENALTY_AWARDED            PENALTY    -           PENALTY          whistle  1.00   dead
  PENALTY_SCORED             -          CELEBRATE   GOAL!            -        1.00   dead
  PENALTY_MISSED             -          DOWN        MISSED           -        0.30   dead
  KICK_OFF                   KICK_OFF   -           KICK OFF         whistle  0.30   dead
  DROP_BALL                  -          -           DROP BALL        whistle  0.20   dead

  PHYSICAL AND MANAGEMENT    scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  INJURY_KNOCK               -          DOWN        -                -        0.20   live
  INJURY_SERIOUS             -          DOWN        INJURY           whistle  0.25   dead
  CRAMP                      -          DOWN        -                -        0.15   live
  SUBSTITUTION               SUB        -           SUBSTITUTION     -        0.35   dead
  SUBSTITUTION_FORCED        SUB        -           FORCED CHANGE    -        0.30   dead
  FORMATION_CHANGE           -          -           <shape>          -        0.25   live
  SHOUT                      -          -           <shout>          -        +0.10  live
  TIME_WASTING               -          -           -                -        0.25   live

  THE MATCH ITSELF           scene      pose        caption          ref      crowd  hold
  ---------------------------------------------------------------------------------------
  HALF_TIME                  -          -           HALF TIME        whistle  0.35   dead
  SECOND_HALF                KICK_OFF   -           KICK OFF         whistle  0.40   dead
  ADDED_TIME                 -          -           +<n> MINUTES     -        0.45   live
  FULL_TIME                  -          -           FULL TIME        whistle  0.60   dead
```

### The gate that makes it worth doing

One harness walks the table and, for every row, reports **how many seconds a
match that event is on screen for**. "There are no scenes in the simulation"
then stops being an argument and becomes a column of numbers with zeroes in it,
answerable in a minute rather than after months. `PoseTime` is already most of
that harness.

It also fixes shouts, which the owner reports as invisible: a shout becomes a
row in the same table, with a banner and a crowd reaction, instead of a silent
write to `Tactics`.

### What the seventy one rows are actually for

Most of them do not exist in the engine yet, and that is the point. The table is
not a description of what the match currently does — it is a **list of what a
football match contains**, and the harness that walks it turns "there is nothing
happening in the simulation" into a column with about fifty zeroes in it, each
one a named, addressable job.

Some are already there and only need routing through the table (FOUL, CARD,
GOAL, CORNER_WON, THROW_IN, SAVE_DIVING, TAKE_ON_WON, OFFSIDE). Some exist and
have measured zero for months (SKILL_MOVE until this session, PENALTY_AWARDED,
SHOT_STRUCK's caption). Most have never existed at all: ONE_TWO, CUT_BACK,
GOAL_LINE_CLEARANCE, SAVE_TIP_OVER, KEEPER_UP_FOR_CORNER, FOUL_ADVANTAGE,
LAST_DITCH, MELEE, ADDED_TIME.

That is the content the owner is asking for, and none of it costs a byte of
assets — every row is a few lines of engine and a pose the renderer already
knows how to draw, or a small addition to it.

### The order to build it in

1. `MatchEvents.kt` — the enum and the table, nothing else.
2. `fire(event, actor, at)` in `MatchEngine`, and the presentation fields become
   private to it.
3. Route the events that ALREADY happen through `fire`. Nothing new yet:
   `ResultFingerprint` must be byte identical and `PoseTime` must be unchanged.
   That step is pure risk reduction and it proves the plumbing.
4. `EventCensus` — walk the table, print seconds a match per row.
5. Then work down the zeroes, cheapest first, `BalanceBig` on anything that
   touches a result.

### Status

Table designed, engine not written. It should come before any further scene
fixes, because every scene fixed by hand before it exists is a scene that can
die in silence again — which has now happened three times in this file.

---

## 7. Idea 7 — the commentator says it out loud  *(the owner's)*

His words: everything should have a scene, and everything the commentator says,
could we hear it spoken in the match — so he keeps talking.

### It costs nothing

Android carries `android.speech.tts.TextToSpeech` in the platform. No asset, no
library, **no megabytes**. And the game already has the words: `BANKS`,
`DRIBBLE_LINES` and `sayRaw`, with player and club names generated from the seed.
What is missing is only somebody to speak them.

**One note in fairness:** the owner asked for all sound to be removed and it was.
This is sound coming back, but a different kind — not the crowd mixer, a voice.
It ships as its own setting: `Commentary: off / captions only / spoken`, so a
player who wants silence keeps silence.

### It is a column on the table that already exists

Each row of `MatchEvents.kt` gains two fields:

```
Shown(..., say = <line bank>, weight = <how much it matters>)
```

```
  THROUGH_BALL     "{a} threads it between the lines to {b}."
  SAVE_TIP_OVER    "{gk} gets a hand to it and over the bar."
  CARD_RED         "And that is a red. {a} is off."
```

### And it settles "everything should have a scene"

Ninety events have a row; **sixty five have a caption and twenty five do not**,
and that is deliberate. A caption on `PASS_SHORT` would put text on screen every
two seconds for ninety minutes. That is not a broadcast, it is noise.

What a broadcast actually does is split the two channels:

| what happens | the screen | the commentator |
|---|---|---|
| `PASS_SHORT`, `FIRST_TOUCH`, `CLEARANCE` | nothing | **talks over it** |
| `TAKE_ON`, `TACKLE`, `SAVE` | short caption | talks |
| `GOAL`, `CARD_RED`, `PENALTY` | big caption | shouts |

So everything has a row and everything is *heard*; not everything is *written*.
That is what makes a match feel full without making it feel cluttered.

### What it needs to be built properly

1. **A priority queue on `weight`.** A goal interrupts. `PASS_SHORT` never
   queues while anything better is waiting. Without this the voice ends up
   thirty seconds behind the football, which is worse than silence.
2. **A rate limit** — about one line every three or four seconds in open play.
3. **Spoken forms for generated names.** TTS will mispronounce some of 32,136
   invented surnames; the fix is a spoken form generated alongside the name.
4. **A shim stub** for `TextToSpeech` so the harnesses keep compiling.

### The gate

`EventCensus` (step 4 of section 6) already has to walk every row. It then also
reports **how many lines a match the commentator speaks** and **which events have
no line at all** — so "he is too quiet" becomes a number instead of a feeling,
the same way "there are no scenes" did.

### Order

Commentary comes AFTER the event tree is routed, not before. The tree is what
gives every line a place to hang, and routing it is the step that must come back
byte identical on `ResultFingerprint`; adding a voice at the same time would make
that proof impossible to read.

---

## 8. What the census said once v2 reported itself

Task 2 added `note` at the shooting, passing, control and clearing sites that
engine v2 already ran through and never named. Nothing was drawn and nothing was
tuned; the gate came back `7afa3890202dabdd`, byte identical.

Three of the numbers that came out are defects in the football, not in the
reporting, and they are written down here so they are not re-discovered.

### v2 plays one pass

Every attempt to separate a through ball from an ordinary forward pass caught
about a third of all passes:

| rule tried | through balls a match |
|---|---|
| receiver level with their last defender | 52.50 |
| receiver genuinely **beyond** their last defender | 44.65 |
| ground, 10 units forward, open lane, final third | 47.25 |
| ground, 14 forward, empty lane, into the penalty area | **0.70** |

The same answer three times is not a classifier that needs tuning. v2's pass
scorer maximises progress and lane, so nearly every ball it plays *is* a forward
ground pass down an open lane into the final third. There is no variety to sort
into rows. The last line is what survives, and 0.70 a match is the honest rate
at which v2 threads one.

### A third of v2's passes go to a man already past the last defender

44.65 a match, against an offside flag that goes up 6.30 times. Both numbers are
right: the offence needs the intended man to actually *collect* it, and under the
claim model somebody else usually gets there first. So the shape is a side
permanently standing offside, mostly getting away with it.

### v2 does not cross

`CROSS` was reading 36.00 a match, from a rule that called any ball with
`loft > 5` a cross — which included the hurried clearance (loft 7.2), the
hopeful punt (6.5) and the goalkeeper's kick downfield (6.8). Asked properly —
from a wide area, in the final third, delivered into the middle — it reads
**1.00 a match**. That agrees with what `WidthCheck` has said all along: v2 does
not play down the flanks, so it has nothing to cross from.

### And the smaller ones

- Half of all shots (11.40 of 22.85) are struck from more than 25 m.
- Long passes outnumber short ones, 75.35 to 59.00, at the existing 24-unit line.
- Corners are won 3.80 times a match and produce **no header at goal at all**:
  the corner-to-shot route lives on the v1 path.
- `TACKLE_WON` reads 0.00 because v2 reports every challenge as
  `TACKLE_SLIDING`; `SHOT_BLOCKED`, `SHOT_DEFLECTED` and `PASS_INTERCEPTED` read
  0.00 because v2 has no block, no deflection and no misplaced-pass model.
