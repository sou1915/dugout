# Engine v4 — keep what is proven, rewrite what is measured broken

The owner's instruction, in his words: take from every version only what was
right, put it in a new engine, and rewrite from scratch whatever still has a
problem — and try ideas that have never been tried here, because nobody knows
until they are measured.

This document is the split, and the new ideas. Every line of it points at a
number that already exists in AUDIT.md or a named harness.

---

## 1. What is kept, and why

| Kept | From | The evidence |
|---|---|---|
| `Physics.kt` — momentum, drag, gravity, bounce, spin, time-to-reach | v3 | written and sound; a struck ball gets a velocity, not a destination |
| `Pitch.kt` — pitch-control grid, 16×11 at 6 Hz | v3 | the layer neither v1 nor v2 had, and cost-controlled (v3's CPU column) |
| `RoleTree.kt` — one behaviour tree per man, eleven intents | v3 | tactics become the tree's parameters instead of nudging a rating |
| The ball is a contested OBJECT, not an assignment | v2 | ball at feet 26% → 44%, in flight 55% → 25% (`BallAir`, `V3Check`) |
| Scenes, staging, cards, subs, injuries, replay | v1/v2 | `SceneAudit` 83–95%; `GoalNet` 100% of goals in the net |
| Renderer, camera, HUD, radar | — | `RadarCover` 0.00% ball occlusion; frames rendered and looked at |
| `Save`, `League`, `Career`, world generation | — | untouched and working |
| `BalanceBig`, `ResultFingerprint`, `UiFlow` and ~120 harnesses | — | the only reason anything here is provable |

## 2. What is rewritten, and the number that condemns it

| Rewritten | The measurement |
|---|---|
| `v2Decide` — a hand-weighted sum of distances | play is 69% central for the man on the ball (`WidthCheck`); two attempts to fix it by re-weighting the sum moved nothing |
| `updateTargets` — formation slots plus a pull toward the ball | the men sit 48% inside the middle fifth; the shape has no idea where space is |
| the urgency table in `moveTowardTargets` | **at a corner the attacking side closes 20 m of a 40 m gap in 4.4 s and the corner is over before they arrive: 2 attackers in the box against 8 defenders** (`CornerFilm`) |
| `tactics.press` | "Press them" makes the press WORSE — carrier's nearest opponent 5.7 m → 6.5 m (`ShoutCheck`) |
| `driftX` applied per frame | the ball's run-on depends on frame rate and is a quarter of what it should be at 4× |
| pose durations | a slide is on screen 2.1 s of a 407 s match, a foul 2.0 s, the referee 2.8 s (`PoseTime`) |

## 3. The new ideas — none of these has been tried in this project

### 3.1 ARRIVE BY, not RUN HARD  *(replaces the urgency table)*

Every version so far answered "how fast should this man run?" with a table of
distance-to-ball bands multiplied by a hand-tuned urgency. That is why a corner
fails: the men are told to go to the box, the table gives them 0.80 of their
pace, and the corner is taken before they get there. No amount of tuning the
multiplier fixes it, because the multiplier does not know the deadline.

So invert it. A target comes with a **time**: *be there in N seconds*. Speed is
then derived, not chosen:

```
  needed = distance / secondsLeft        clamped to his physical maximum
```

A man 40 m from the six yard box with 8 seconds runs at 5 m/s and **arrives**.
The same man with 30 seconds walks. A defender who must be goal-side before the
ball gets there sets his own pace from `Physics.timeToReach`. Nobody sprints
because a number said 0.95; they move at the speed the situation requires.

This is testable on its own, inside the current engine, before anything else of
v4 exists — which is why it is first.

### 3.2 The ball belongs to whoever gets there first  *(replaces control radii)*

v2 hands the ball to anyone inside a 1.8 m radius. v3 refuses candidates whose
ball speed is too high, and that refusal is the leading suspect for why a v3
match degenerates into a 92%-loose ball.

Instead, no radius and no roll: every player continuously has a **claim time** —
`Physics.timeToReach` to where the ball will be — and the ball goes to the
lowest claim, with the strength/composure difference deciding a genuine 50-50.
A ball nobody can reach stays loose because nobody's claim is low, not because a
threshold said no. That removes the whole class of "the ball just sits there".

### 3.3 A set piece is a PLAY, with parts and deadlines  *(replaces scatter)*

`stageCorner` sends nine men to random points in a box and hopes. A real corner
has parts: a taker (at the arc, deadline 1.5 s), a near-post runner and a far-post
runner with **staggered** arrival deadlines so they attack the ball rather than
stand in it, a short option, an edge-of-the-box man, and two holding against the
counter. Written as parts with deadlines, using 3.1, the routine plays itself out
and the tactical corner settings (near post / far post / short / edge, and how
many men go up) finally mean something.

### 3.4 Instructions reach the code that does the thing

`tactics.press` currently only slides the shape toward the ball. In v4 an
instruction is a parameter of the layer it names: pressing sets how many men
join the press and how early they engage; width sets where the role trees look
for space; tempo sets how long a man holds the ball. If an instruction cannot be
seen in a measurement, it does not ship — `ShoutCheck` is the gate.

## 4. How it stays honest

Unchanged from v2 and v3, because it is the only reason this project can tell
progress from noise:

- `ENGINE_V4` is a flag, default OFF, and v1/v2/v3 all stay in the build.
- Nothing lands without `BalanceBig` — 9,120 matches, target 2.5–2.7 goals,
  ~45% home. v2 currently sits at **2.59 ± 0.03, 43.8% home**.
- `ResultFingerprint` for anything claimed cosmetic.
- `UiFlow` 33/33.
- Render frames and LOOK at them. `CornerFilm` and `GoalFilm` exist for exactly
  this and both found defects no aggregate had seen.
- Revert what does not work and write down that it did not.

## 5. Order of work

1. **3.1 ARRIVE BY** — **DONE**. `CornerFilm`: attackers in the box at the
   delivery 5 → 8, mean gap to target 7.6 m → 3.6 m. `BalanceBig` 2.56 ± 0.03,
   43.9% home. AUDIT.md §11.
2. **3.3 the corner as a play** — **DONE**. `CornerPlay`: the four routines and
   the three commitment settings now put men in measurably different places;
   everyone-up 6.3 in the box against keep-men-back 3.9 with 4.0 held in their
   own half. Mean gap at the delivery 2.1 m. AUDIT.md §12.
3. **3.2 claim-time possession** — next, and it is also the fix for v3
   degenerating into a 92%-loose ball.
4. **3.4 instructions**, gated on `ShoutCheck`. The known defect is that
   "Press them" moves the carrier's nearest opponent from 5.7 m to 6.5 m.
5. Then, and only then, the decision layer on the grid.

Each step is shippable on its own. That is deliberate: three engines have been
written in this project and the two that landed did so because they could be
measured one piece at a time.

---

## 6. Idea 6 — the event tree  *(the owner's, and it is the right one)*

His words: *make a tree for every event that happens in a normal football match,
like a trigger — if this event happens, this scene happens.*

### Why it is the right idea

Three separate defects in this audit are the same defect:

| found | what it was |
|---|---|
| `v2Defend` | written, correct, **never called** — 56 tackles and zero fouls |
| `CHANCE_QUALITY` | swept by `BalanceBig` for months while **dead** under v2 |
| skills and `Scene.TAKE_ON` | correct, and **only reachable from v1** — 0.00 a match |

Every one is presentation or logic wired directly into one engine's decision
path, which then stopped being the engine that runs. Nothing declares "a foul
must produce a free kick, a whistle and a man on the floor", so when the caller
moves, the scene dies **in silence**.

The event tree makes that impossible: the engine reports **what happened**, and
one table decides what is shown.

### The table

```
EVENT             SCENE      pose       caption      referee   crowd
TAKE_ON_WON       TAKE_ON    DRIBBLE    TAKE-ON        -        0.60
TACKLE_WON        TACKLE     TACKLE     TACKLE         -        0.50
INTERCEPTION      TACKLE     -          TACKLE         -        0.35
FOUL              FREEKICK   DOWN       FREE KICK    whistle    0.40
FOUL_IN_BOX       PENALTY    DOWN       PENALTY      whistle    1.00
CARD              CARD       -          BOOKING      card       0.70
SHOT_STRUCK       SHOT       SHOOT      SHOT           -        0.80
SAVE              SAVE       DIVE       SAVE           -        0.60
WOODWORK          SHOT       -          OFF THE POST   -        0.90
GOAL              -          CELEBRATE  GOAL!          -        1.00
KICK_OFF          KICK_OFF   -          KICK OFF       -        0.30
OFFSIDE           FREEKICK   -          OFFSIDE      flag       0.30
BALL_OUT_SIDE     THROW_IN   -          THROW-IN       -         -
BALL_OUT_GOAL     GOAL_KICK  -          GOAL KICK      -         -
CORNER_WON        CORNER     -          CORNER         -        0.55
SUBSTITUTION      SUB        -          SUBSTITUTION   -        0.35
INJURY            -          DOWN       INJURY       whistle    0.25
SHOUT             -          -          banner         -        +0.10
```

The engine calls `fire(Event.FOUL, who, where)` and never touches `scene`,
`sceneTime`, `act`, `cue` or `crowdTarget` again.

### The gate that makes it worth doing

One harness walks the table and, for every row, reports **how many seconds a
match that event is on screen for**. "There are no scenes in the simulation"
then stops being an argument and becomes a column of numbers with zeroes in it,
answerable in a minute rather than after months. `PoseTime` is already most of
that harness.

It also fixes shouts, which the owner reports as invisible: a shout becomes a
row in the same table, with a banner and a crowd reaction, instead of a silent
write to `Tactics`.

### Status

Designed, not written. It is the next piece of work and it should come before
any further scene fixes, because every scene fixed by hand before it exists is a
scene that can die in silence again.
