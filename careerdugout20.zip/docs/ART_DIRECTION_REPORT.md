# Camera angle report — required by CLAUDE_CODE_PROMPT §7 before touching the renderer

Nothing in the renderer has been changed. This answers the three questions and
stops, as instructed.

Measured on `9a6ce16` from `out/film/04.png` and `out/scenes/corner.png`.

---

## 1. How steep the current camera is

`BroadcastCamera` is a real perspective camera, not a fixed projection:

```
heightM  42.0      metres above the pitch surface
backM   101.3      metres behind the near touchline
tiltDeg  30.0      fixed downward tilt of the optical axis
aimBias   0.44     where the tracked point sits vertically on screen
focalK    4.8      focal length in units of screen width
```

The tilt is not the angle you see. What matters is the **depression angle to the
ground**, and the camera sits far enough back that it is shallow:

| looking at | depression below horizontal |
|---|---|
| near touchline | 22.5° |
| pitch centre | **17.2°** |
| far touchline | 13.9° |

The brief describes the reference as "close to oblique/isometric", which is
roughly 40–60°. **The current camera is about a third of that.** The brief's
ranking is correct: this is the largest single difference.

To reach that angle by raising the camera alone:

| target at centre | required height |
|---|---|
| 40° | 114 m |
| 45° | 135 m |
| 55° | 193 m |

Raising `tiltDeg` alone does **not** do it — tilt rotates the optical axis and
moves what is centred in frame, but the depression to the ground is set by
height over distance. Pulling the camera in (`backM`) raises the angle for less
height but narrows the field of view, so it would need `focalK` opened up to
compensate.

## 2. What raising it would break

I traced the drawing paths rather than guessing.

**Figures — safe.** This was the real question and the answer is good. Every
joint is built in three dimensions as `(u, v, z)` in body-local metres — hip,
knee, ankle, shoulder, elbow, head — and each is passed through `cam.proj` and
joined with `bone()`. There is no billboard and no pre-baked sprite anywhere in
`drawPlayer`. A steeper camera renders the same skeleton correctly from above,
foreshortened as it should be. The action poses are joint angles, so they
survive too.

**Shadows — safe, and improved.** One blob per figure on the ground plane,
projected like everything else. A steeper angle makes a ground-plane shadow read
*better*, not worse.

**Crowd — safe, and this is a benefit.** The stands are drawn as a band above
the far touchline. Raising the angle lifts the horizon further out of frame and
pushes the crowd out of shot, which is exactly the direction §7 wants. It also
makes "draw crowd only near a boundary" easy, because at a steep angle the crowd
is naturally absent from midfield.

**Goal net — needs checking, not assumed.** It is drawn as a mesh in three
dimensions, so it should project, but a net seen from above is mostly the top
face, and the current mesh may have been tuned to read side-on. This is the one
item I would expect to need retouching.

**The pitch markings and the ball — safe.** Both go through the same projection.

**What genuinely changes and is not a bug:** figure height on screen. §7 measures
the reference at 6.7–8.4% of frame height and the current renderer at ~10%.
Raising the camera reduces apparent size, so this moves *toward* the reference on
its own — which is why §7 says to leave `figureScale` alone until the angle is
settled. That is right.

## 3. Recommendation and cost

**It is a parameter change, not a new drawing path.** That is the finding that
matters. `heightM`, `backM`, `focalK` and `aimBias` are all `@JvmField var` on
`BroadcastCamera`, and the whole scene — pitch, lines, figures, shadows, net,
crowd — goes through one projection. Nothing needs a second code path, which
also keeps the "one camera, one code path" rule intact.

Recommended, in this order:

1. **Sweep the angle as a parameter and render, do not choose it by argument.**
   Add the 320×240 downscale harness §7 asks for, render the standard moments at
   17° (today), 30°, 40° and 50°, and look at the downscaled versions. This costs
   one harness and no renderer change, and it answers the question with pictures.
2. **Then set the angle once**, and only then revisit `figureScale`.
3. **The palette is separable and cheap.** Measured from the current frames:
   `#608030`, `#507020`, `#407020` — olive, exactly as §7 says. The reference is
   `#41BD01` / `#5DBC3E`. This is a constants change, independent of the camera,
   and probably the largest visible improvement per line in the project.

**One correction to §7's measured gaps.** Item 2 says "the crowd is always on
screen" and implies the frame is crowd-heavy. Measured, the current frames are
**78% grass** (`out/film/04.png`) and **75%** (`corner.png`), against a reference
range of 56–93%. Grass share is already inside the reference band. The crowd
*band* and the league ticker are still worth removing for the reasons §7 gives —
the reference has no ticker at all — but this is a layout and palette problem,
not a proportion one, and it is smaller than the angle or the colour.

**Cost.** Steps 1 and 3 are each a few hours and both are fingerprint-safe.
Step 2 depends on what the sweep shows. The goal net is the only thing I would
budget rework for.

---

## Awaiting a decision

§7 says to report and wait, so the renderer is untouched. What I need from you:

- **the angle to aim for** — or approval to run the sweep in step 1 and bring
  back pictures at 17 / 30 / 40 / 50° so the choice is made from frames
- whether to do the palette now, since it is independent of the camera decision

## Note on the reference material

The five screenshots came through as inline images rather than as files, so I
could not write them to `docs/reference/`. If you re-send them as file
attachments they will be committed there.

`real_football_2016_256286.jar` is on disk and has **not** been opened. §7
permits measuring proportion, colour and layout from reference material and
forbids copying any sprite, tile or font, and `HANDOFF.md` requires the game to
ship no binary assets beyond the launcher icon. Extracting a commercial game's
art to measure sits close enough to that line that I would rather ask first. The
figures in this report all come from our own rendered frames and from the
measurements in §7.
