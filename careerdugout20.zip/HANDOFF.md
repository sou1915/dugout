Continue work on Career Dugout, my Android football management game in Kotlin.
Project zip attached. Read tools/harness/README.md before anything else.

=================== WHAT IT IS ===================
Single player football management sim, landscape phone, Kotlin, minSdk 24.
Everything is generated from a seed at runtime: clubs, players, badges, faces,
kits. The game is SILENT -- the synthesised crowd and match audio were
removed on the owner's instruction. There are no binary assets except the
launcher icon, and no
real clubs, players or sponsors. Around 18,000 lines.

Source: app/src/main/java/com/dugout/career/
  core/   Names.kt (Rng + name pools for 185 nations), Model.kt (Player, Club,
          Tactics, Presets), World.kt (generation, rivalries), Staff.kt,
          Manager.kt, DressingRoom.kt, Synth.kt (now only the cue names)
  sim/    MatchEngine.kt (live match), League.kt (fixtures, tables, season roll,
          continental cup), Career.kt (training, finance, transfers, jobs,
          press, loans, player talks), Save.kt
  ui/     Theme.kt, Icons.kt, MatchView.kt, BroadcastRenderer.kt (perspective
          camera), FaceGen.kt
  MainActivity.kt  every screen, built programmatically

THE BUILD PIPELINE IS MANUAL. The zip is uploaded to the GitHub repo by hand
and a workflow unzips it and runs gradle. Pushing from the agent has been 403
for the whole of the last session, so nothing reaches the repo automatically.
If you fix something, the human has to upload the zip before they can see it —
and at least once they tested a build that predated the change and reported it
as unfixed. CHECK WHAT IS ACTUALLY IN THE REPO ZIP before concluding a fix
failed on device: read it with the GitHub API and grep the constants.

=================== HOW TO BUILD AND TEST ===================
There is no Android SDK here. Install a JDK, then kotlinc 2.1.20 from GitHub
releases — Maven Central is NOT reachable from this container.

tools/harness/shim/Android*.kt is a Java2D shim covering android.graphics,
view, widget, app, media, os, text and util. It compiles the WHOLE app
off-device, MainActivity included.

BUILD IN TWO STAGES. The app compile is about 30 seconds:

  SRC=app/src/main/java/com/dugout/career
  kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
      tools/harness/shim/Android*.kt -d /tmp/app
  kotlinc -nowarn -cp /tmp/app tools/harness/UiFlow.kt -d /tmp/h
  java -Djava.awt.headless=true -cp /tmp/h:/tmp/app:$KOTLIN_HOME/lib/kotlin-stdlib.jar UiFlowKt

=================== THE RULE THAT MATTERS MOST ===================
MEASURE, NEVER ASSERT — AND LOOK AT THE PICTURE, NOT ONLY THE NUMBERS.

The last session tuned aggregate after aggregate — goals per game, mean pass
length, median shot distance — and every one of them moved into range while the
human kept reporting that nothing had changed. All of those measurements were
correct. They were also measuring the wrong thing.

The first time anyone rendered a strip of frames from a live match and LOOKED at
them, the answer was in the first image: the radar was 22% of the screen width,
opaque, centred along the bottom edge, sitting directly on top of the football
in every frame of every match. No aggregate can see that.

  java -cp build/h.jar MatchFilmKt 10 260     # writes out/film/*.png — LOOK AT THEM

Render frames before and after ANY visual change. If you cannot see the change
in a rendered frame, the player cannot see it either.

=================== MEASUREMENT TRAPS ===================
1. A HARNESS THAT RUNS PAST THE WHISTLE MEASURES NOTHING. update() returns
   immediately once `finished` is set. Put `if (m.finished) break` at the TOP of
   the loop, never below a `continue`.

2. ONE MATCH IS NOT A SAMPLE. Use 20-40 matches for anything per-frame and say
   how many you used. Goals per game has a standard error of 0.08 at 400
   matches — plus or minus 0.16 at 95% — so a 400-match run CANNOT distinguish
   2.45 from 2.70. A previous session tried to tune away exactly that spread and
   was chasing its own sampling noise. Use BalanceBig, which prints intervals.

3. ANYTHING MEASURING THE CAMERA MUST FORCE THE CLOSE VIEW. The cut is gated on
   WALL CLOCK time and a harness renders thousands of frames in seconds, so the
   hold never expires. CamFollow and MatchFilm pin closeUp by reflection.

4. ALWAYS HAVE A CONTROL. ShoutCheck measures each shout against a DO-NOTHING
   row, without which every shout is credited with whatever the shape does on
   its own — and "Get it wide" appeared to make the side narrower.

5. "COSMETIC" IS A CLAIM THAT NEEDS PROVING. ResultFingerprint hashes every
   score, shot, card and corner in a run. A change that is really cosmetic
   leaves it BYTE IDENTICAL. An sfxRng draw used for NOTHING once moved goals
   per game from 2.850 to 2.750, because a cosmetic act landing on a man
   mid-tackle stood him up, and nextMan picks the next man in a move by who is
   standing nearby.

6. SCRIPTED PYTHON EDITS HAVE DELETED CODE TWICE. After any scripted edit, grep
   for what you expected to change AND compile immediately.

=================== VERIFIED STATE ===================
All measured with the current build unless marked inherited.

world        1,236 clubs, 32,136 players, 60 countries with leagues, 185
             nationalities, 0 duplicate names, 0 orphans
save         round trip clean, older saves still load
balance      top flight 2.66 +/- 0.03 goals over 9,120 matches (4 worlds x 6
             seasons), home 44.4%, draws 24.1%, away 31.5%
             quick sim independently agrees at 2.61 — keep it that way, it is
             what lets 59 other countries be simmed cheaply
passes       20.2 m mean, 58/24/17 forward/side/back (real 18 m, 45/35/20)
shots        median 27 m, 0.0% of GOALS from the shooter's own half (was 25.9%)
ball         23.0-23.2 m/s mean, 41.9 peak against a modelled ceiling of 40.3,
             airborne 18-19%, teleports over 8 m: 1.0 a match (was 5.0)
camera       reaches the broadcast view at last (closeUp was capped at 0.22 of
             1.00 and the perspective renderer was never seen in a live match),
             16.3 cuts a match, mean spell 9.3 s, pitch fills ~4/5 of frame
patterns     build-up 36% / cross 24% / through 20% / counter 9% / long shot 12%
             and the touchline moves it: "Get it wide" takes crosses to 39%
shouts       five of six move the side up to 15 pitch units; "Get it wide" is a
             no-op, see open problem 3
events       corners 8.3 a match, free kicks 6.1, subs 3.9, keeper dives 11.1,
             woodwork 0.53, take-ons 34.9
UI           UiFlow 33 steps, 0 crashes

=================== WHAT THE LAST SESSION DID ===================
Presentation, which turned out to be most of the problem:
- THE BROADCAST CAMERA WAS NEVER REACHED. closeUp never exceeded 0.22 of 1.00
  in 40 matches, because "which camera are we on" was inferred from the eased
  value instead of remembered. Every camera figure ever quoted was measured
  with closeUp pinned by reflection, so nobody had measured the arriving.
- THE RADAR SAT ON THE FOOTBALL. Moved to the corner and shrunk.
- THE CAMERA FRAMED THE CROWD. tiltDeg 22 -> 30, aimBias 0.62 -> 0.44,
  BROADCAST_CLOSE 0.72 -> 0.56. Widening ALONE made it worse — the extra field
  of view went into the stand — which is why aimBias had to come down with it.
- NOTHING WAS EVER POSED. RPlayer had no action field, so every figure was
  drawn running whatever it was doing. Eight poses now, measured by PoseCheck.
- FIGURE PROPORTIONS were a modern athlete scaled down; now short and chunky,
  about 4.5 heads, which is what reads at the size a player appears.
- SET PIECES WERE PAINTED OVER: corners and free kicks staged a scene and then
  called attemptShot in the SAME tick, and attemptShot sets its own scene, so
  the set piece was overwritten before a frame was drawn.
- THE BALL TELEPORTED to free kicks instead of rolling.
- Rebounds: a save is now live one time in five.

Simulation:
- MOVES NOW HAVE A NAMED SHAPE (the big one — see below).
- Goals from the shooter's own half: 25.9% -> 0.0%.
- Chance quality retuned twice to hold 2.5-2.7 as timing changed.
- Cosmetic stream made genuinely cosmetic (act() `cosmetic` flag).

THE IDEA THAT UNLOCKED IT came from the human's own earlier web prototype
(gen_scenario.py / matchdata.js). That project AUTHORS each moment as a named
pattern — cross, counter, through, long shot, tap-in — and plays it back, which
is why it reads as football. This engine had no such concept: a phase was a
shapeless run of passes between whoever happened to be near enough. A scene IS
a pattern.

Five patterns now, chosen LIVE per phase from the side's tactics (deliberately
not scripted at kick-off, because a match authored before it starts cannot
respond to a shout at sixty minutes):

  PAT_BUILD    short and central
  PAT_CROSS    work it wide, then swing it in
  PAT_THROUGH  a ball into space beyond the last man
  PAT_COUNTER  few touches, straight up the pitch
  PAT_LONGSHOT worked to the edge and struck

=================== OPEN PROBLEMS, IN PRIORITY ORDER ===================

1. PATTERNS DO NOT YET MOVE THE PLAYERS — ONLY THE BALL.
   This is the biggest remaining piece and the natural continuation. A pattern
   currently shapes where the BALL goes. It does not tell anybody to make a
   run. The web prototype's `BOX CRASH` is the missing half: when a cross is
   played, two attackers should be sent to the near post and the penalty spot;
   on a through ball someone should be running in behind BEFORE it is played.
   Until that exists the movement will still not look like football, because
   the men are still standing in formation slots while the ball does clever
   things around them.
   Do NOT do this with random runs — that was tried and reverted (commit
   fc44c76): it stretched the block from 46 m to 48 m and looked like chaos.
   The runs must belong to the pattern.

2. TEAM SHAPE IS TOO LONG AND THE OBVIOUS FIX BACKFIRES.
   45.8 m back to front against a real 30-40 (ShapeCheck, 20 matches, 11,694
   samples). Width and spacing are fine.
   SHAPE_COMPACT 0.62 -> 0.45 fixes the shape AND shortens passes — and puts
   goals back into the shooter's own half, because a compact block lifts the
   defending line, the offside clamp holds attackers behind it, and play moves
   away from goal. Four variants were tried, all reverted; the table is in
   tools/harness/README.md. Shape, the offside clamp and how far a move can
   reach are ONE mechanism. Check with ShapeCheck AND ShotRange together.

3. "GET IT WIDE" IS A NO-OP, and the cause is known exactly.
   widthMul is 1.38 for wide, applied to each man's offset from the centre
   line, but targets are clamped with ty.coerceIn(5f, 95f) and the default
   formation already stands its widest men on the touchline. Widening pushes
   the target off the pitch where the clamp eats it; narrowing works perfectly.
   The fix is to remap the width scale so NORMAL sits inside the band and WIDE
   reaches the touchline. That changes the default shape of every side, so
   BalanceBig on the other side of it.

4. SHOTS ARE STILL TOO LONG. Median goal 27 m against a real 11. A distance
   curve on chance quality is correct football and DID work on its own terms
   (goals from inside 18 m went 21% -> 34%), but together with a range guard it
   left home wins at 49-51% and draws at 18-20% against real 45 and 25. Both
   reverted. This is probably downstream of problems 1 and 2 — if men make runs
   into the box, shots come from the box.

5. THE BOARD VIEW HAS NO POSES AND NO SCENES. Every scene overlay (penalty,
   corner, free kick, referee's card, woodwork, skill move) is drawn AFTER the
   `closeUp < 0.06f` early return, so it only ever appears on the broadcast
   camera. The board view draws flat figures that know nothing about actions.
   The game is on the broadcast camera 69% of the time now, so this matters
   less than it did, but a third of the match is still presentation-free.

6. EVENT RATES THE PHASE MODEL CANNOT REACH: headers 5.4 a match against a real
   40, throw-ins 8.4 against 40, cards 1.63 against 4. Headers need more aerial
   balls, which is a change to the flight model. These are properties of what a
   phase IS, not bugs.

7. NONE OF THIS HAS EVER BEEN PROFILED ON A PHONE. The broadcast renderer is
   now drawn 76% of frames rather than never, so PerfCheck's 6.4 ms worst case
   is suddenly the frame budget that matters. The world is 24.6 MB in memory.

8. THE SAVE IS AROUND 8 MB AND GROWING. Agreed limit was 10 MB.

9. LOANS, CONVERSATIONS AND RIVALRIES are each about two thirds built. Details
   in tools/harness/README.md.

=================== THE HARNESSES THAT EARN THEIR KEEP ===================
  MatchFilm.kt        renders frames from a live match — USE THIS FIRST
  BalanceBig.kt       goals per game with confidence intervals, and a sweep
  ResultFingerprint.kt proves a change is really cosmetic
  PatternCheck.kt     the mix of move shapes, and whether tactics change it
  ShoutCheck.kt       what each touchline shout actually moves, with a control
  ShotRange.kt        where shots and GOALS are struck from
  ShapeCheck.kt       back to front, width, spacing, over many matches
  PassAudit.kt        pass length and direction, counted off the engine's own
                      pass counter rather than an edge test that saw 14% of them
  AliveCensus.kt      how often every action and scene actually happens
  EngineCompare.kt    old move construction against new, on every figure at once
  PoseCheck.kt        does each action change the drawn figure
  UiFlow.kt           drives the real MainActivity through every screen

=================== HOW I WANT YOU TO WORK ===================
Measure before and after. RENDER FRAMES for anything visual. If a change does
not achieve what you intended, revert it and say so rather than leaving it in —
several things in this project were made worse by fixes that measured better.
Tell me plainly when something is not done. If a number looks wrong, suspect
the harness first; six of them were lying at various points. State the sample
size. Comments should say what was WRONG before, so the reasoning survives.

And do not tell me something is fixed when what you mean is that it is fixed in
a harness. Say which.
