package com.dugout.career.core

/**
 * The names of the moments a match reports. Nothing here makes a noise.
 *
 * This file used to be the whole audio engine: every sound in the match built
 * from noise and sine waves at run time -- whistles, the kick, the net, the
 * post, a crowd bed that never repeated -- roughly 370 lines of synthesis,
 * deliberately free of Android imports so it could be rendered to a WAV on a
 * desktop and measured.
 *
 * The owner asked for the game to be silent, so the synthesis, the mixer and
 * the AudioTrack in ui/MatchAudio.kt are gone.
 *
 * These constants stay because they are not sounds. MatchEngine.cue records
 * WHAT HAPPENED and WHERE -- the ball hit the post, the referee blew, the
 * crowd went up -- and the engine, the replay and around thirty harnesses read
 * that list. Deleting it would have meant changing the simulation to satisfy a
 * change to the presentation, which is backwards. If sound is ever wanted
 * again, the cues are still all there and only the mixer has to come back.
 */
object Synth {

    /** Which moment a cue names. */
    object Sfx {
        const val WHISTLE_SHORT = 0
        const val WHISTLE_LONG = 1
        const val KICK = 2
        const val KICK_HARD = 3
        const val NET = 4
        const val POST = 5
        const val ROAR = 6
        const val GROAN = 7
        const val APPLAUSE = 8
        const val OOH = 9
        const val TACKLE = 10
        const val COUNT = 11
    }
}
