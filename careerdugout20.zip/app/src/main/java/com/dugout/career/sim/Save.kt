package com.dugout.career.sim

import android.content.Context
import com.dugout.career.core.*
import java.io.File
import kotlin.math.roundToInt

/**
 * The whole career, written to a single file and read back exactly.
 *
 * Everything is stored as delimited text rather than a library format: it
 * keeps the save readable, avoids any dependency, and a career of nine
 * thousand players still writes in well under a second.
 */
object Save {

    private const val FILE = "career.sav"
    // 2 added the nation the manager is working in, so a career abroad reloads
    // in the right country.
    //
    // This used to claim "version 1 files still load and default to home". They
    // do not, and never did: read() rejects any header whose version is not
    // exactly this one, so a v1 save is discarded in silence. Adding the field
    // shifted every index in the header row, which is the same hazard the
    // player and club rows document -- there is no v1 reader to fall back on.
    // The comment is corrected rather than the behaviour, because a wrong
    // comment about save compatibility is how a career gets eaten.
    private const val VERSION = 2
    private const val SEP = "\u0001"     // field separator, never appears in a name
    private const val ROW = "\n"

    class Snapshot(val world: World, val season: Season, val career: Career)

    private fun usable(f: File) = f.exists() && f.length() > 64

    fun exists(ctx: Context): Boolean =
        usable(File(ctx.filesDir, FILE)) || usable(File(ctx.filesDir, "$FILE.bak"))

    /** Starting again means starting again: the backup goes too. */
    fun delete(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
        File(ctx.filesDir, "$FILE.bak").delete()
        File(ctx.filesDir, "$FILE.tmp").delete()
    }

    /* --------------------------------------------------------- WRITING */

    fun write(ctx: Context, world: World, season: Season, career: Career): Boolean {
        return try {
            val b = StringBuilder(1 shl 22)
            b.append(VERSION).append(SEP).append(world.seed).append(SEP)
                .append(world.season).append(SEP).append(world.week).append(SEP)
                .append(world.userClubId).append(SEP).append(world.managerName).append(SEP)
                .append(world.managerNation).append(SEP).append(world.managerRep).append(SEP)
                .append(world.managerP).append(SEP).append(world.managerW).append(SEP)
                .append(world.managerD).append(SEP).append(world.managerL).append(SEP)
                .append(world.seasonsManaged).append(SEP)
                .append(world.playerCountry).append(SEP)
                .append(world.profile.ageBand).append(SEP).append(world.profile.age).append(SEP)
                .append(world.profile.school).append(SEP).append(world.profile.philosophy).append(SEP)
                .append(world.profile.manner).append(SEP)
                .append(spellsOf(world)).append(ROW)

            // clubs
            b.append("C").append(SEP).append(world.clubs.size).append(ROW)
            for (c in world.clubs) {
                b.append(c.id).append(SEP).append(c.name).append(SEP).append(c.shortName).append(SEP)
                    .append(c.city).append(SEP).append(c.nation).append(SEP).append(c.crestSeed).append(SEP)
                    .append(c.primary).append(SEP).append(c.secondary).append(SEP).append(c.kitPattern).append(SEP)
                    .append(c.divisionId).append(SEP).append(c.foreignLeague).append(SEP).append(c.tier).append(SEP)
                    .append(c.reputation).append(SEP).append(if (c.isUser) 1 else 0).append(SEP)
                    .append(c.stadiumName).append(SEP).append(c.capacity).append(SEP)
                    .append(c.balance).append(SEP).append(c.transferBudget).append(SEP)
                    .append(c.wageBudget).append(SEP).append(c.sponsor).append(SEP)
                    .append(c.played).append(SEP).append(c.won).append(SEP).append(c.drawn).append(SEP)
                    .append(c.lost).append(SEP).append(c.goalsFor).append(SEP).append(c.goalsAgainst).append(SEP)
                    .append(c.points).append(SEP).append(c.morale).append(SEP).append(c.boardConfidence).append(SEP)
                    .append(c.form.joinToString("")).append(SEP)
                    .append(c.squad.joinToString(",")).append(SEP)
                    .append(c.honours.joinToString("|")).append(SEP)
                    .append(tacticsOf(c)).append(SEP)
                    .append(staffOf(c)).append(SEP)
                    // On the end, after the backroom. See the note on the
                    // player row: an index inserted in the middle shifts
                    // everything after it and corrupts it silently.
                    .append(c.loanWageOut).append(ROW)
            }

            // players
            b.append("P").append(SEP).append(world.players.size).append(ROW)
            for (p in world.players.values) {
                b.append(p.id).append(SEP).append(p.first).append(SEP).append(p.last).append(SEP)
                    .append(p.full).append(SEP).append(p.nation).append(SEP).append(p.age).append(SEP)
                    .append(p.pos).append(SEP).append(p.altPos).append(SEP).append(p.role).append(SEP)
                for (a in 0 until Att.COUNT) b.append(p.att[a]).append(",")
                b.append(SEP).append(p.potential).append(SEP).append(p.clubId).append(SEP)
                    .append(p.shirt).append(SEP).append(p.fitness).append(SEP).append(p.sharpness).append(SEP)
                    .append(p.morale).append(SEP).append(p.form).append(SEP)
                    .append(p.injuryType ?: "").append(SEP).append(p.injuryWeeks).append(SEP)
                    .append(p.suspended).append(SEP).append(p.yellowSeason).append(SEP).append(p.redSeason).append(SEP)
                    .append(p.wage).append(SEP).append(p.contractYears).append(SEP).append(p.squadStatus).append(SEP)
                    .append(if (p.listed) 1 else 0).append(SEP).append(p.scouted).append(SEP)
                    .append(p.traits.joinToString(",")).append(SEP).append(p.personality).append(SEP)
                    .append(p.apps).append(SEP).append(p.goals).append(SEP).append(p.assists).append(SEP)
                    .append(p.cleanSheets).append(SEP).append(p.motm).append(SEP).append(p.minutes).append(SEP)
                    .append(p.ratingSum).append(SEP).append(p.ratingN).append(SEP)
                    .append(p.cApps).append(SEP).append(p.cGoals).append(SEP).append(p.cAssists).append(SEP)
                    .append(p.cTrophies).append(SEP)
                    // Contract clauses go on the end of the row on purpose.
                    // Slotting them into the middle shifts every index after
                    // them and quietly corrupts traits, personality and every
                    // career statistic on load.
                    .append(p.appearanceFee).append(SEP).append(p.goalBonus).append(SEP)
                    .append(p.cleanSheetBonus).append(SEP).append(p.releaseClause).append(SEP)
                    .append(p.promisedStatus).append(SEP)
                    // Loans, added last and therefore last on the row.
                    .append(p.loanFromId).append(SEP).append(p.loanWeeks).append(SEP)
                    .append(p.loanWageShare).append(SEP).append(p.loanLocked).append(SEP)
                    .append(p.brokenPromises).append(ROW)
            }

            // fixtures
            b.append("F").append(SEP).append(season.fixtures.size).append(ROW)
            for (f in season.fixtures) {
                b.append(f.id).append(SEP).append(f.comp).append(SEP).append(f.divisionId).append(SEP)
                    .append(f.round).append(SEP).append(f.week).append(SEP).append(f.homeId).append(SEP)
                    .append(f.awayId).append(SEP).append(if (f.played) 1 else 0).append(SEP)
                    .append(f.homeGoals).append(SEP).append(f.awayGoals).append(SEP)
                    .append(f.attendance).append(SEP).append(f.winnerId).append(ROW)
            }

            // the manager's own state
            b.append("M").append(SEP).append(career.trainingFocus).append(SEP)
                .append(career.intensity).append(SEP)
                .append(career.shortlist.joinToString(",")).append(SEP)
                .append(career.scoutFinds.joinToString(",")).append(ROW)

            b.append("N").append(SEP).append(career.news.size).append(ROW)
            for (n in career.news) {
                b.append(n.icon).append(SEP).append(n.text).append(SEP)
                    .append(n.season).append(SEP).append(n.week).append(SEP).append(n.kind).append(ROW)
            }

            b.append("I").append(SEP).append(career.inbox.size).append(ROW)
            for (m in career.inbox) {
                b.append(m.id).append(SEP).append(m.from).append(SEP).append(m.subject).append(SEP)
                    .append(m.body.replace(ROW, " ")).append(SEP).append(m.icon).append(SEP)
                    .append(m.season).append(SEP).append(m.week).append(SEP)
                    .append(if (m.read) 1 else 0).append(SEP).append(m.offerId).append(ROW)
            }

            b.append("D").append(SEP).append(career.transferLog.size).append(ROW)
            for (d in career.transferLog) {
                b.append(d.player).append(SEP).append(d.pos).append(SEP).append(d.age).append(SEP)
                    .append(d.rating).append(SEP).append(d.from).append(SEP).append(d.to).append(SEP)
                    .append(d.fee).append(SEP).append(d.season).append(SEP).append(d.week).append(ROW)
            }

            /*
             * A CAREER IS 7.8 MB AND THERE WAS ONE COPY OF IT.
             *
             * The old sequence was: write the temp file, DELETE the target,
             * rename the temp over it -- and then return true unconditionally,
             * whatever renameTo said. Two faults. Between the delete and the
             * rename there is no career.sav at all, and exists() is what the
             * front screen uses to decide between "Continue" and "New career",
             * so a process death in that window shows a returning player a new
             * game. And a rename that fails -- out of space, which is exactly
             * when a 7.8 MB write goes wrong -- was reported as a successful
             * save, so the caller carried on believing the career was on disk.
             *
             * The previous save is now kept as a backup and only retired once
             * the new one is in place, and the return value is the truth.
             */
            val tmp = File(ctx.filesDir, "$FILE.tmp")
            tmp.writeText(b.toString())
            val target = File(ctx.filesDir, FILE)
            val backup = File(ctx.filesDir, "$FILE.bak")
            if (target.exists()) {
                if (backup.exists()) backup.delete()
                // a rename, not a copy: it costs nothing and cannot half-finish
                target.renameTo(backup)
            }
            if (!tmp.renameTo(target)) {
                // put the career back the way it was rather than leaving none
                if (backup.exists() && !target.exists()) backup.renameTo(target)
                tmp.delete()
                return false
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** The backroom, as id:name:role:quality:wage:years, pipe separated. */
    private fun staffOf(c: Club): String =
        c.staff.joinToString("|") {
            "${it.id}~${it.name}~${it.role}~${it.quality}~${it.wage}~${it.contractYears}"
        }

    private fun readStaff(c: Club, raw: String) {
        c.staff.clear()
        if (raw.isBlank()) return
        for (row in raw.split("|")) {
            val f = row.split("~")
            if (f.size < 6) continue
            c.staff.add(
                Staff(f[0].toInt(), f[1], f[2].toInt(), f[3].toInt(), f[4].toInt(), f[5].toInt())
            )
        }
    }

    /**
     * The manager's spells, pipe separated. Honours and movements are joined
     * with a semicolon inside each spell, so none of the outer separators can
     * appear in them.
     */
    private fun spellsOf(w: World): String =
        w.record.spells.joinToString("|") { sp ->
            listOf(
                sp.clubId, sp.clubName.replace("~", "-"), sp.startSeason,
                sp.divisionName.replace("~", "-"), sp.endSeason,
                sp.played, sp.won, sp.drawn, sp.lost,
                sp.goalsFor, sp.goalsAgainst, sp.ending,
                sp.honours.joinToString(";").replace("~", "-"),
                sp.movements.joinToString(";").replace("~", "-")
            ).joinToString("~")
        }

    private fun readSpells(w: World, raw: String) {
        w.record.spells.clear()
        if (raw.isBlank()) return
        for (row in raw.split("|")) {
            val f = row.split("~")
            if (f.size < 14) continue
            val sp = Spell(f[0].toInt(), f[1], f[2].toInt(), f[3])
            sp.endSeason = f[4].toInt()
            sp.played = f[5].toInt(); sp.won = f[6].toInt()
            sp.drawn = f[7].toInt(); sp.lost = f[8].toInt()
            sp.goalsFor = f[9].toInt(); sp.goalsAgainst = f[10].toInt()
            sp.ending = f[11].toInt()
            if (f[12].isNotBlank()) sp.honours.addAll(f[12].split(";"))
            if (f[13].isNotBlank()) sp.movements.addAll(f[13].split(";"))
            w.record.spells.add(sp)
        }
    }

    private fun tacticsOf(c: Club): String {
        val t = c.tactics
        val sb = StringBuilder()
        sb.append(t.formation).append(",").append(t.mentality).append(",").append(t.tempo).append(",")
            .append(t.passing).append(",").append(t.width).append(",").append(t.line).append(",")
            .append(t.press).append(",").append(t.tackling).append(",")
            .append(if (t.counter) 1 else 0).append(",").append(if (t.offsideTrap) 1 else 0).append(",")
            .append(t.focus).append(",").append(t.marking).append(",").append(t.timeWasting).append(",")
            .append(if (t.playOut) 1 else 0).append(",")
            .append(t.cornerTaker).append(",").append(t.freeKickTaker).append(",")
            .append(t.penaltyTaker).append(",").append(t.captain).append(",")
            .append(t.oppTargetId).append(",").append(t.oppMode).append(",")
            .append(t.lineup.joinToString("+")).append(",")
            .append(t.bench.joinToString("+")).append(",")
            .append(t.slotRoles.joinToString("+")).append(",")
            .append(t.slotInstructions.joinToString("+")).append(",")
            .append(t.familiarity.roundToInt()).append(",").append(t.familiarWith).append(",")
            .append(t.cornerRoutine).append(",").append(t.cornerMen).append(",")
            .append(t.freeKickRoutine)
        return sb.toString()
    }

    private fun readTactics(c: Club, s: String) {
        val v = s.split(",")
        if (v.size < 24) return
        val t = c.tactics
        t.formation = v[0]; t.mentality = v[1].toInt(); t.tempo = v[2].toInt()
        t.passing = v[3].toInt(); t.width = v[4].toInt(); t.line = v[5].toInt()
        t.press = v[6].toInt(); t.tackling = v[7].toInt()
        t.counter = v[8] == "1"; t.offsideTrap = v[9] == "1"
        t.focus = v[10].toInt(); t.marking = v[11].toInt(); t.timeWasting = v[12].toInt()
        t.playOut = v[13] == "1"
        t.cornerTaker = v[14].toInt(); t.freeKickTaker = v[15].toInt()
        t.penaltyTaker = v[16].toInt(); t.captain = v[17].toInt()
        t.oppTargetId = v[18].toInt(); t.oppMode = v[19].toInt()
        t.lineup = v[20].split("+").map { it.toInt() }.toIntArray()
        t.bench = v[21].split("+").map { it.toInt() }.toIntArray()
        t.slotRoles = v[22].split("+").map { it.toInt() }.toIntArray()
        t.slotInstructions = v[23].split("+").map { it.toInt() }.toIntArray()
        // added later; a version 1 file simply has not learnt a shape yet
        if (v.size > 28) {
            t.cornerRoutine = v[26].toInt(); t.cornerMen = v[27].toInt()
            t.freeKickRoutine = v[28].toInt()
        }
        if (v.size > 25) {
            t.familiarity = v[24].toDouble()
            t.familiarWith = v[25]
        } else {
            t.familiarity = 65.0
            t.familiarWith = t.formation
        }
    }

    /* --------------------------------------------------------- READING */

    /**
     * The career, or null if there is not one that can be read.
     *
     * A truncated or corrupt save used to return null and that was the end of
     * it: the front screen then offered "New career" and the player's save was
     * gone with nothing said. Since [write] now retires the previous file to a
     * backup rather than deleting it, there is one more thing to try before
     * giving up, and losing one week of a career beats losing all of it.
     */
    fun read(ctx: Context): Snapshot? =
        readFrom(File(ctx.filesDir, FILE)) ?: readFrom(File(ctx.filesDir, "$FILE.bak"))

    private fun readFrom(f: File): Snapshot? {
        return try {
            if (!f.exists()) return null
            val lines = f.readText().split(ROW)
            var i = 0

            val head = lines[i++].split(SEP)
            if (head[0].toInt() != VERSION) return null
            val world = World(head[1].toLong())
            world.season = head[2].toInt()
            world.week = head[3].toInt()
            world.userClubId = head[4].toInt()
            world.managerName = head[5]
            world.managerNation = head[6]
            world.managerRep = head[7].toInt()
            world.managerP = head[8].toInt(); world.managerW = head[9].toInt()
            world.managerD = head[10].toInt(); world.managerL = head[11].toInt()
            world.seasonsManaged = head[12].toInt()
            world.playerCountry = if (head.size > 13) head[13] else "ENG"
            // the manager profile replaced the seed box; older files have none
            if (head.size > 18) {
                world.profile.ageBand = head[14].toInt(); world.profile.age = head[15].toInt()
                world.profile.school = head[16].toInt()
                world.profile.philosophy = head[17].toInt()
                world.profile.manner = head[18].toInt()
            }
            // added later; an older file simply has no career record
            if (head.size > 19) readSpells(world, head[19])
            world.buildStructureOnly()

            // clubs
            var h = lines[i++].split(SEP)
            val clubCount = h[1].toInt()
            world.clubs.clear()
            for (d in world.allDivisions()) d.clubIds.clear()
            world.foreignClubIds.clear()
            repeat(clubCount) {
                val v = lines[i++].split(SEP)
                val c = Club(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(),
                    v[6].toInt(), v[7].toInt(), v[8].toInt())
                c.divisionId = v[9].toInt(); c.foreignLeague = v[10].toInt(); c.tier = v[11].toInt()
                c.reputation = v[12].toInt(); c.isUser = v[13] == "1"
                c.stadiumName = v[14]; c.capacity = v[15].toInt()
                c.balance = v[16].toLong(); c.transferBudget = v[17].toLong()
                c.wageBudget = v[18].toInt(); c.sponsor = v[19].toLong()
                c.played = v[20].toInt(); c.won = v[21].toInt(); c.drawn = v[22].toInt()
                c.lost = v[23].toInt(); c.goalsFor = v[24].toInt(); c.goalsAgainst = v[25].toInt()
                c.points = v[26].toInt(); c.morale = v[27].toDouble(); c.boardConfidence = v[28].toInt()
                for (ch in v[29]) c.form.add(ch)
                if (v[30].isNotEmpty()) for (id in v[30].split(",")) c.squad.add(id.toInt())
                if (v[31].isNotEmpty()) c.honours.addAll(v[31].split("|"))
                readTactics(c, v[32])
                // added later; an older file simply has no backroom stored
                if (v.size > 33) readStaff(c, v[33])
                if (v.size > 34) c.loanWageOut = v[34].toIntOrNull() ?: 0
                world.clubs.add(c)
                if (c.divisionId >= 0) world.division(c.divisionId)?.clubIds?.add(c.id)
                else world.foreignClubIds.add(c.id)
            }

            // players
            h = lines[i++].split(SEP)
            val playerCount = h[1].toInt()
            world.players.clear()
            repeat(playerCount) {
                val v = lines[i++].split(SEP)
                val att = IntArray(Att.COUNT)
                val nums = v[9].split(",")
                for (a in 0 until Att.COUNT) att[a] = nums[a].toInt()
                val p = Player(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(),
                    v[6].toInt(), v[7].toInt(), v[8], att, v[10].toInt())
                p.clubId = v[11].toInt(); p.shirt = v[12].toInt()
                p.fitness = v[13].toDouble(); p.sharpness = v[14].toDouble()
                p.morale = v[15].toDouble(); p.form = v[16].toDouble()
                p.injuryType = v[17].ifEmpty { null }; p.injuryWeeks = v[18].toInt()
                p.suspended = v[19].toInt(); p.yellowSeason = v[20].toInt(); p.redSeason = v[21].toInt()
                p.wage = v[22].toInt(); p.contractYears = v[23].toInt(); p.squadStatus = v[24].toInt()
                p.listed = v[25] == "1"; p.scouted = v[26].toInt()
                p.traits = if (v[27].isEmpty()) IntArray(0) else v[27].split(",").map { it.toInt() }.toIntArray()
                p.personality = v[28]
                p.apps = v[29].toInt(); p.goals = v[30].toInt(); p.assists = v[31].toInt()
                p.cleanSheets = v[32].toInt(); p.motm = v[33].toInt(); p.minutes = v[34].toInt()
                p.ratingSum = v[35].toDouble(); p.ratingN = v[36].toInt()
                p.cApps = v[37].toInt(); p.cGoals = v[38].toInt(); p.cAssists = v[39].toInt()
                p.cTrophies = v[40].toInt()
                // added after the fact, so an older file simply stops here
                if (v.size > 45) {
                    p.appearanceFee = v[41].toInt(); p.goalBonus = v[42].toInt()
                    p.cleanSheetBonus = v[43].toInt(); p.releaseClause = v[44].toLong()
                    p.promisedStatus = v[45].toInt()
                }
                // added later still: a save from before loans existed simply
                // has nobody out on loan, which is the correct reading of it
                if (v.size > 49) {
                    p.loanFromId = v[46].toInt(); p.loanWeeks = v[47].toInt()
                    p.loanWageShare = v[48].toInt(); p.loanLocked = v[49].toInt()
                }
                if (v.size > 50) p.brokenPromises = v[50].toInt()
                world.players[p.id] = p
                Names.register(p.full)
            }

            val season = Season(world)
            h = lines[i++].split(SEP)
            val fixtureCount = h[1].toInt()
            season.fixtures.clear()
            repeat(fixtureCount) {
                val v = lines[i++].split(SEP)
                val fx = Fixture(v[0].toInt(), v[1].toInt(), v[2].toInt(), v[3].toInt(),
                    v[4].toInt(), v[5].toInt(), v[6].toInt())
                fx.played = v[7] == "1"
                fx.homeGoals = v[8].toInt(); fx.awayGoals = v[9].toInt()
                fx.attendance = v[10].toInt(); fx.winnerId = v[11].toInt()
                season.fixtures.add(fx)
            }
            season.rebuildCups()

            val career = Career(world, season)
            val mv = lines[i++].split(SEP)
            career.trainingFocus = mv[1].toInt()
            career.intensity = mv[2].toInt()
            if (mv[3].isNotEmpty()) for (id in mv[3].split(",")) career.shortlist.add(id.toInt())
            if (mv[4].isNotEmpty()) for (id in mv[4].split(",")) career.scoutFinds.add(id.toInt())

            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                career.news.add(NewsItem(v[0], v[1], v[2].toInt(), v[3].toInt(), v[4].toInt()))
            }
            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                val m = InboxItem(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(), v[6].toInt())
                m.read = v[7] == "1"; m.offerId = v[8].toInt()
                career.inbox.add(m)
            }
            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                career.transferLog.add(
                    Deal(v[0], v[1].toInt(), v[2].toInt(), v[3].toInt(), v[4], v[5],
                        v[6].toLong(), v[7].toInt(), v[8].toInt())
                )
            }
            career.setObjectives()
            /*
             * Rivalries are derived, not stored.
             *
             * They come out of the seed and the finished club list, so
             * recomputing them costs nothing and keeps them out of the save
             * format entirely — which means an old save loads with derbies in
             * it rather than needing a migration. It has to happen HERE though,
             * after the clubs and divisions are read: buildStructureOnly gives
             * an empty world, and rivalries worked out from that would be empty
             * too and would stay empty for the rest of the career.
             */
            world.buildRivalries()
            Snapshot(world, season, career)
        } catch (e: Exception) {
            null
        }
    }
}
