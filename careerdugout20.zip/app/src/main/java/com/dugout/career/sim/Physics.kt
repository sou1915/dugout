package com.dugout.career.sim

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * ENGINE V3, LAYER 1: bodies and a ball that obey momentum.
 *
 * Both previous engines moved the ball by interpolating along a path: pick a
 * destination, walk a parameter t from 0 to 1. That is why the ball could never
 * be deflected, why a misplaced pass had to be faked by jittering the aim
 * point, and why "where does it end up" was an input rather than a consequence.
 *
 * Here a struck ball is given a VELOCITY and nothing else. Where it finishes is
 * whatever friction, gravity, the bounce and anything it hits decide. A
 * deflection is then free: change the velocity and the rest follows.
 *
 * Units are the pitch units the rest of the engine uses -- one x-unit is about
 * 1.05 m and one y-unit about 0.68 m -- so speeds here are in units per second
 * and the helpers convert where a real-world figure is meant.
 */
object Physics {

    /** One x-unit in metres. */
    const val MX = 1.05f
    /** One y-unit in metres. */
    const val MY = 0.68f

    /** Distance in METRES between two points given in pitch units. */
    fun metres(ax: Float, ay: Float, bx: Float, by: Float): Float =
        hypot(((ax - bx) * MX).toDouble(), ((ay - by) * MY).toDouble()).toFloat()

    /* ------------------------------------------------------------- BALL */

    /** Rolling resistance on grass, per second, as a fraction of speed kept. */
    const val ROLL_DRAG = 0.62f
    /** Air drag on a ball off the ground. Much lower than rolling. */
    const val AIR_DRAG = 0.09f
    /** Gravity, in metres per second squared. */
    const val G = 9.81f
    /** How much vertical speed survives a bounce. */
    const val RESTITUTION = 0.52f
    /** How much horizontal speed survives a bounce. */
    const val BOUNCE_KEEP = 0.78f
    /** Hardest strike in football, metres per second. */
    const val MAX_STRIKE_MPS = 36f

    /**
     * Advance the ball one step.
     *
     * [dt] is in real seconds. Returns true while it is still moving, so a
     * caller can cheaply tell a live ball from a dead one.
     */
    fun stepBall(b: Ball, dt: Float): Boolean {
        if (dt <= 0f) return false

        // --- vertical
        if (b.height > 0f || b.vz != 0f) {
            b.vz -= G * dt
            b.height += b.vz * dt
            if (b.height <= 0f) {
                b.height = 0f
                if (b.vz < -0.6f) {
                    // it bounces, and loses pace off the turf
                    b.vz = -b.vz * RESTITUTION
                    b.vx *= BOUNCE_KEEP
                    b.vy *= BOUNCE_KEEP
                } else {
                    b.vz = 0f
                }
            }
        }

        // --- horizontal, with the right drag for whether it is on the deck
        val airborne = b.height > 0.12f
        val drag = if (airborne) AIR_DRAG else ROLL_DRAG
        val keep = max(0f, 1f - drag * dt)
        b.vx *= keep
        b.vy *= keep

        /*
         * Spin pushes it sideways while it is in the air -- the reason a cross
         * bends away from a keeper. Applied perpendicular to travel, and only
         * off the ground, so a rolling ball does not curve.
         */
        if (airborne && abs(b.spinRate) > 0.01f) {
            val sp = hypot(b.vx.toDouble(), b.vy.toDouble()).toFloat()
            if (sp > 0.01f) {
                val nx = -b.vy / sp
                val ny = b.vx / sp
                b.vx += nx * b.spinRate * dt
                b.vy += ny * b.spinRate * dt
            }
        }

        b.x += b.vx * dt
        b.y += b.vy * dt

        // it rotates in proportion to how far it actually travelled
        b.spin += hypot((b.vx * dt).toDouble(), (b.vy * dt).toDouble()).toFloat() * 0.55f

        val speed = hypot(b.vx.toDouble(), b.vy.toDouble()).toFloat()
        if (speed < 0.25f && b.height <= 0f) { b.vx = 0f; b.vy = 0f; return false }
        return true
    }

    /**
     * Strike it: a direction, a speed in METRES per second, and a launch angle.
     *
     * The caller says how hard and where at, never where to. A pass that is too
     * hard runs out of play, which is how it should be and is what neither
     * previous engine could express.
     */
    fun strike(b: Ball, dirX: Float, dirY: Float, mps: Float, launchDeg: Float, spin: Float = 0f) {
        val len = hypot(dirX.toDouble(), dirY.toDouble()).toFloat()
        if (len < 1e-4f) return
        val speed = min(mps, MAX_STRIKE_MPS)
        val rad = launchDeg * (Math.PI.toFloat() / 180f)
        val flat = speed * cos(rad.toDouble()).toFloat()
        // convert metres per second into units per second on each axis
        b.vx = (dirX / len) * flat / MX
        b.vy = (dirY / len) * flat / MY
        b.vz = speed * sin(rad.toDouble()).toFloat()
        b.spinRate = spin
        b.height = max(b.height, 0f)
        // v3 does not use the interpolation fields, but the renderer reads t
        // to decide whether the ball is in flight, so it is held at 1.
        b.t = 1f
        b.rolling = launchDeg < 3f
        b.struck = false
    }

    /**
     * ENGINE V4, IDEA 5: WHERE WILL IT STOP?
     *
     * The question every previous engine could not answer, and the reason two
     * separate attempts to make a man meet a pass measured worse than doing
     * nothing. An interpolated ball has an AIM POINT, and the aim point is not
     * where the ball ends up -- v2Strike jitters it by up to twenty units for a
     * hurried pass and the ball then runs on past it. Running to the aim point
     * is running to a place the ball merely passes through.
     *
     * A ball with a velocity and a drag has a rest position, and it is
     * arithmetic. Rolling speed decays as v * (1 - drag * dt) per step, so the
     * distance still to travel is the sum of that series: v / drag. An airborne
     * ball is stepped forward until it lands and then rolls, which is why this
     * simulates rather than solving in closed form -- but it is a handful of
     * steps, not a per-tick grid scan, and it runs at the rate a decision is
     * made rather than the rate a frame is drawn.
     *
     * Returns the resting point in pitch units, and how long it takes to get
     * there. A man can then ask "can I be there by then?" -- which is idea 1,
     * and is what turns a pass into a pass and a run.
     */
    fun restPoint(b: Ball, out: FloatArray) {
        var x = b.x; var y = b.y
        var vx = b.vx; var vy = b.vy; var vz = b.vz; var h = b.height
        var t = 0f
        val dt = 0.05f
        var steps = 0
        while (steps++ < 120) {
            val speed = hypot(vx.toDouble(), vy.toDouble()).toFloat()
            if (speed < 0.25f && h <= 0f) break
            if (h > 0f || vz != 0f) {
                vz -= G * dt
                h += vz * dt
                if (h <= 0f) {
                    h = 0f
                    if (vz < -0.6f) { vz = -vz * RESTITUTION; vx *= BOUNCE_KEEP; vy *= BOUNCE_KEEP }
                    else vz = 0f
                }
            }
            val drag = if (h > 0.12f) AIR_DRAG else ROLL_DRAG
            val keep = max(0f, 1f - drag * dt)
            vx *= keep; vy *= keep
            x += vx * dt; y += vy * dt
            t += dt
            // it has left the field: it stops being anybody's business there
            if (x < -2f || x > 102f || y < -2f || y > 102f) break
        }
        out[0] = x; out[1] = y; out[2] = t
    }

    /**
     * How long, in seconds, it takes a man to reach a point, allowing for the
     * fact that he is already moving.
     *
     * This is the whole difference between a distance and a real evaluation of
     * space: a defender sprinting the wrong way is FURTHER from a cell than one
     * standing still the same distance off, and only a time-based model says so.
     */
    fun timeToReach(
        px: Float, py: Float, vx: Float, vy: Float,
        tx: Float, ty: Float, topSpeed: Float, accel: Float
    ): Float {
        val dx = (tx - px) * MX
        val dy = (ty - py) * MY
        val d = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (d < 0.01f) return 0f
        // speed already pointing the right way helps; pointing the wrong way costs
        val ux = dx / d
        val uy = dy / d
        val along = (vx * MX) * ux + (vy * MY) * uy
        // time to get up to speed from the component he already has
        val deficit = max(0f, topSpeed - along)
        val tAccel = deficit / max(0.5f, accel)
        val dAccel = max(0f, along) * tAccel + 0.5f * accel * tAccel * tAccel
        return if (dAccel >= d) {
            // reached before topping out: solve the quadratic
            val a = 0.5f * accel
            val bq = max(0f, along)
            val disc = bq * bq + 4f * a * d
            (-bq + kotlin.math.sqrt(disc.toDouble()).toFloat()) / (2f * a)
        } else {
            tAccel + (d - dAccel) / max(0.5f, topSpeed)
        }
    }

    /* ------------------------------------------------------------ BODIES */

    /**
     * Move a man toward a point under acceleration and turn limits.
     *
     * He cannot reverse on the spot and he cannot carry full pace through a
     * hard turn, so his path is an arc. Returns the distance actually covered.
     */
    fun stepBody(
        p: LivePlayer, tx: Float, ty: Float, dt: Float,
        topSpeed: Float, accel: Float, turnRate: Float
    ): Float {
        val dx = tx - p.x
        val dy = ty - p.y
        val d = hypot((dx * MX).toDouble(), (dy * MY).toDouble()).toFloat()
        if (d < 0.05f) {
            p.vx *= max(0f, 1f - 6f * dt)
            p.vy *= max(0f, 1f - 6f * dt)
            p.x += p.vx * dt; p.y += p.vy * dt
            p.speedNow = 0f
            return 0f
        }

        val want = atan2((dy * MY).toDouble(), (dx * MX).toDouble()).toFloat()
        if (!p.headingSet) { p.heading = want; p.headingSet = true }
        var delta = want - p.heading
        while (delta > Math.PI) delta -= (Math.PI * 2).toFloat()
        while (delta < -Math.PI) delta += (Math.PI * 2).toFloat()
        val speed = hypot((p.vx * MX).toDouble(), (p.vy * MY).toDouble()).toFloat()
        // quick on his toes at a walk, heavy at a sprint
        val maxTurn = turnRate * dt / (1f + speed * 0.22f)
        p.heading += delta.coerceIn(-maxTurn, maxTurn)

        // slow down for a hard turn and to arrive rather than overshoot
        val turnCost = 1f - min(0.6f, abs(delta) * 0.34f)
        val arrive = min(1f, 0.3f + d / 3f)
        val target = topSpeed * turnCost * arrive

        val newSpeed = if (speed < target) min(target, speed + accel * dt)
                       else max(target, speed - accel * 1.6f * dt)
        val hx = cos(p.heading.toDouble()).toFloat()
        val hy = sin(p.heading.toDouble()).toFloat()
        p.vx = hx * newSpeed / MX
        p.vy = hy * newSpeed / MY
        val stepX = p.vx * dt
        val stepY = p.vy * dt
        p.x += stepX
        p.y += stepY
        p.facing = p.heading
        p.speedNow = newSpeed
        val moved = hypot((stepX * MX).toDouble(), (stepY * MY).toDouble()).toFloat()
        p.runPhase += moved * 1.0f
        return moved
    }
}
