package com.dugout.career.core

/**
 * Deterministic xorshift RNG. The same seed always rebuilds the same world,
 * so a save only has to store the seed plus whatever the manager changed.
 */
class Rng(seed: Long) {
    /**
     * The seed is scrambled before use.
     *
     * A raw xorshift started on a small number produces a small first output,
     * so the very first draw off a fresh Rng was biased hard toward zero. Club
     * badges were generated as three draws from Rng(crestSeed), and the first
     * of those chose the shape: every one of the four hundred and sixty clubs
     * in the world came out with the same shield. Anything else seeding an Rng
     * with a counter or a small id had the same problem on its first draw.
     *
     * This is the SplitMix64 finalizer, which turns any seed, however small or
     * however close to its neighbour, into a well spread 64 bits.
     */
    private var s: Long = run {
        var z = if (seed == 0L) 88172645463325252L else seed
        z = (z xor (z ushr 30)) * -0x40A7B892E31B1A47L
        z = (z xor (z ushr 27)) * -0x6B2FB644ECCEEE15L
        z = z xor (z ushr 31)
        if (z == 0L) 88172645463325252L else z
    }

    fun next(): Long {
        s = s xor (s shl 13)
        s = s xor (s ushr 7)
        s = s xor (s shl 17)
        return s
    }

    /** 0.0 until 1.0 */
    fun f(): Double = ((next() ushr 11).toDouble()) / (1L shl 53).toDouble()

    /** inclusive on both ends */
    fun i(a: Int, b: Int): Int = if (b <= a) a else a + (f() * (b - a + 1)).toInt().coerceAtMost(b - a)

    fun chance(p: Double): Boolean = f() < p

    fun <T> pick(list: List<T>): T = list[i(0, list.size - 1)]
    fun <T> pick(arr: Array<T>): T = arr[i(0, arr.size - 1)]

    /** Bell-shaped roll: most results land near [mean]. */
    fun norm(mean: Double, spread: Double, min: Int, max: Int): Int {
        val v = mean + (f() + f() + f() - 1.5) * spread
        return v.toInt().coerceIn(min, max)
    }

    fun <T> shuffle(src: List<T>): MutableList<T> {
        val a = src.toMutableList()
        for (k in a.indices.reversed()) {
            val j = i(0, k)
            val t = a[k]; a[k] = a[j]; a[j] = t
        }
        return a
    }
}

/**
 * The flag emoji for a two letter country code.
 *
 * These were written out as literal surrogate pairs, which was fine for
 * sixteen nations. At a hundred and eighty five it is a hundred and eighty five
 * chances to mistype an invisible character and not find out until a flag
 * renders as a pair of empty boxes on a phone. A regional indicator symbol is
 * just the letter's code point plus a fixed offset, so it is cheaper and safer
 * to compute it. Codes that have no flag of their own (the home nations, which
 * are subdivisions) fall back to what was already there.
 */
fun flagOf(iso2: String): String {
    val special = when (iso2) {
        "GB" -> "\uD83C\uDFF4"          // no per-nation emoji reaches every device
        "XK" -> "\uD83C\uDDFD\uD83C\uDDF0"
        else -> null
    }
    if (special != null) return special
    if (iso2.length != 2) return ""
    val sb = StringBuilder(4)
    for (ch in iso2.uppercase()) {
        if (ch !in 'A'..'Z') return ""
        // regional indicator symbols live at U+1F1E6 for 'A'
        sb.appendCodePoint(0x1F1E6 + (ch - 'A'))
    }
    return sb.toString()
}

/** A footballing nation: name pools, flag, and how strong its clubs are. */
class Nation(
    val code: String,
    val label: String,
    val flag: String,
    first: String,
    last: String,
    val strength: Int
) {
    val first: List<String> = first.split(",")
    val last: List<String> = last.split(",")
    val combos: Int get() = this.first.size * this.last.size
}

/**
 * Every footballer in the game is invented here. Nobody real, no photographs,
 * and the registry guarantees a name is never issued twice in a save.
 */
object Names {

    /**
     * Nations that produce players but have no league of their own.
     *
     * A league costs three divisions, thirty six clubs and nearly a thousand
     * players; a nationality costs a list of names. Real squads are mixed, and
     * a world where every player at an English club is English is the thing
     * that actually looks wrong. These fill out the rest of the map.
     */
    private fun extra(code: String, label: String, flag: String, first: String, last: String, strength: Int) =
        Nation(code, label, flag, first, last, strength)

    val EXTRA_NATIONS: List<Nation> = listOf(
        extra("BIH", "Bosnia and Herzegovina", flagOf("BA"),
            "Edin,Miralem,Sead,Amar,Haris,Ermedin,Denis,Adnan,Armin,Rade,Ivan,Anel,Nihad,Dzenan,Benjamin,Elvis",
            "Hodzic,Begic,Delic,Softic,Music,Kovacevic,Hadzic,Salihovic,Muratovic,Cengic,Bajric,Zukic,Osmanovic,Halilovic", 63),
        extra("ALB", "Albania", flagOf("AL"),
            "Armando,Elseid,Keidi,Kristjan,Nedim,Klaus,Marash,Berat,Qazim,Ardian,Endri,Sokol,Ilir,Genti,Arber,Fatjon",
            "Hoxha,Shehu,Prifti,Bardhi,Gjoka,Berisha,Kola,Meta,Zeqiri,Doci,Kastrati,Lleshi,Rrahmani,Cela", 57),
        extra("NMK", "North Macedonia", flagOf("MK"),
            "Goran,Eljif,Enis,Stefan,Darko,Bojan,Vlatko,Ezgjan,Ilija,Aleksandar,Kire,Marjan,Ferhan,Milan,Tihomir,Zoran",
            "Trajkovski,Ristovski,Nikolov,Spirovski,Stojanovski,Velkoski,Bardhi,Alioski,Dimitrievski,Musliu,Zajkov,Ademi,Kostadinov,Ilievski", 56),
        extra("MNE", "Montenegro", flagOf("ME"),
            "Stefan,Nikola,Marko,Milos,Risto,Vasilije,Andrija,Igor,Sead,Balsa,Deni,Milutin,Zarko,Dejan,Petar,Filip",
            "Jovetic,Savic,Vukcevic,Radunovic,Bakic,Kosovic,Perisic,Vujacic,Scepanovic,Boljevic,Ivanovic,Djurdjevic,Krstovic,Sofranac", 56),
        extra("KOS", "Kosovo", flagOf("XK"),
            "Milot,Vedat,Amir,Besar,Elbasan,Lirim,Florent,Zymer,Edon,Betim,Arber,Valon,Ibrahim,Leart,Fidan,Mergim",
            "Rashica,Muriqi,Rrahmani,Halimi,Zeneli,Kryeziu,Dresevic,Aliti,Hadergjonaj,Krasniqi,Berisha,Bytyqi,Loshaj,Selmani", 55),
        extra("BLR", "Belarus", flagOf("BY"),
            "Maksim,Ivan,Vitali,Yury,Igor,Denis,Pavel,Aleksandr,Nikita,Gleb,Sergei,Anton,Roman,Yegor,Artem,Kirill",
            "Kovalev,Sidorov,Volkov,Kozlov,Zhuk,Savitsky,Bandarenka,Klimovich,Yablonski,Hleb,Dragun,Karpovich,Shitov,Malashevich", 56),
        extra("GEO", "Georgia", flagOf("GE"),
            "Khvicha,Giorgi,Zuriko,Otar,Saba,Luka,Levan,Nika,Guram,Vakhtang,Irakli,Budu,Lasha,Tornike,Davit,Beka",
            "Kvaratskhelia,Mamardashvili,Chakvetadze,Lobjanidze,Kiteishvili,Gvilia,Tabidze,Kashia,Dvali,Beridze,Zivzivadze,Altunashvili,Gocholeishvili,Shengelia", 61),
        extra("ARM", "Armenia", flagOf("AM"),
            "Henrikh,Eduard,Tigran,Vahan,Kamo,Sargis,Norberto,Varazdat,Hovhannes,Artak,Gevorg,Aram,Levon,Arman,Karen,Zhirayr",
            "Sargsyan,Hovhannisyan,Grigoryan,Petrosyan,Harutyunyan,Avetisyan,Ghazaryan,Barseghyan,Voskanyan,Mkrtchyan,Manoyan,Bichakhchyan,Spertsyan,Muradyan", 52),
        extra("AZE", "Azerbaijan", flagOf("AZ"),
            "Emin,Ramil,Renat,Mahir,Anton,Tamkin,Rahil,Ismayil,Elvin,Bahlul,Ozan,Rahman,Eddy,Filip,Nariman,Kamran",
            "Mahmudov,Aliyev,Guseynov,Sheydayev,Mammadov,Huseynov,Bayramov,Cafarquliyev,Medvedev,Krivotsyuk,Ismayilov,Qurbanli,Rustamov,Abdullayev", 51),
        extra("KAZ", "Kazakhstan", flagOf("KZ"),
            "Bakhtiyor,Baktiyar,Askhat,Islambek,Nuraly,Yan,Abat,Serikzhan,Maxim,Gafurzhan,Ramazan,Yerkebulan,Bagdat,Aleksandr,Damir,Sultanbek",
            "Zaynutdinov,Tagybergen,Kuat,Vorogovskiy,Alip,Suyumbayev,Marochkin,Aymbetov,Samorodov,Fedin,Orazov,Shomko,Erlanov,Kasym", 50),
        extra("MDA", "Moldova", flagOf("MD"),
            "Ion,Vadim,Serghei,Artur,Oleg,Veaceslav,Mihail,Radu,Danila,Vitalie,Igor,Dinu,Catalin,Maxim,Alexandru,Nichita",
            "Nicolaescu,Rata,Ionita,Cojocaru,Reabciuk,Craciun,Posmac,Bolohan,Damascan,Platica,Caimacov,Dros,Motpan,Grosu", 48),
        extra("LVA", "Latvia", flagOf("LV"),
            "Roberts,Janis,Vladislavs,Kristers,Raivis,Andrejs,Eduards,Aleksejs,Marcis,Antonijs,Gints,Davis,Kristaps,Daniels,Rihards,Toms",
            "Ozols,Berzins,Kalnins,Krastins,Liepins,Jaunzems,Gutkovskis,Uldrikis,Ikaunieks,Cernomordijs,Zjuzins,Tobers,Sorokins,Vanins", 47),
        extra("LTU", "Lithuania", flagOf("LT"),
            "Fedor,Arvydas,Edvinas,Vykintas,Gvidas,Rolandas,Justas,Ovidijus,Domantas,Modestas,Nauris,Deimantas,Paulius,Linas,Tomas,Karolis",
            "Kazlauskas,Petrauskas,Jankauskas,Stankevicius,Vaitkus,Butkus,Girdvainis,Simkus,Slivka,Novikovas,Cernych,Dapkus,Vorobjovas,Baravykas", 47),
        extra("EST", "Estonia", flagOf("EE"),
            "Konstantin,Ragnar,Karol,Henrik,Rauno,Vlasi,Mattias,Sergei,Joonas,Markus,Karl,Robi,Erik,Maksim,Kristjan,Taijo",
            "Vassiljev,Klavan,Mets,Pikk,Sappinen,Kams,Sorga,Tamm,Kuusk,Lepik,Ojamaa,Puri,Anier,Saliste", 47),
        extra("FRO", "Faroe Islands", flagOf("FO"),
            "Klaemint,Jogvan,Hallur,Brandur,Sonni,Teitur,Rene,Gunnar,Odmar,Heini,Petur,Meinhard,Arni,Bardur,Poul,Jann",
            "Olsen,Hansen,Joensen,Davidsen,Nielsen,Poulsen,Thomsen,Jacobsen,Petersen,Frederiksberg,Vatnhamar,Sorensen,Egilsson,Bartalsstovu", 42),
        extra("LUX", "Luxembourg", flagOf("LU"),
            "Gerson,Danel,Leandro,Mathias,Vincent,Christopher,Olivier,Maxime,Sebastien,Aiman,Florian,Dirk,Marvin,Yvandro,Enes,Tim",
            "Rodrigues,Sinani,Barreiro,Olesen,Thill,Martins,Jans,Chanot,Carlson,Mahmutovic,Bohnert,Deville,Korac,Dardari", 46),
        extra("MLT", "Malta", flagOf("MT"),
            "Teddy,Andrei,Jodi,Kurt,Steve,Joseph,Matthew,Ryan,Paul,Zach,Luke,Alexander,Juan,Karl,Myles,Nikolai",
            "Camilleri,Borg,Farrugia,Vella,Zammit,Micallef,Grech,Mifsud,Attard,Muscat,Spiteri,Galea,Bonello,Cassar", 44),
        extra("NIR", "Northern Ireland", flagOf("GB"),
            "Steven,Conor,Jamal,Shea,Paddy,Daniel,Trai,Isaac,Ethan,Ciaron,Bailey,Dion,Ross,Eoin,Callum,Terry",
            "Davis,Bradley,Lewis,Charles,McNair,Ballard,Hume,Price,Galbraith,Brown,Peacock,Toal,Devlin,Marshall", 56),
        extra("AND", "Andorra", flagOf("AD"),
            "Ricard,Marc,Cristian,Marcio,Berto,Chus,Ludovic,Alex,Ivan,Albert,Joan,Emili,Jordi,Aaron,Guillaume,Sergi",
            "Fernandez,Vales,Rebes,Rossell,Vieira,Rubio,Cervos,Martinez,Alavedra,Clemente,Sanchez,Pujol,Riera,Gomes", 38),
        extra("SMR", "San Marino", flagOf("SM"),
            "Nicola,Filippo,Alessandro,Dante,Marcello,Enrico,Michele,Simone,Luca,Fabio,Matteo,Lorenzo,Manuel,Cristian,Davide,Andrea",
            "Nanni,Berardi,Golinucci,Rossi,Cevoli,Zafferani,Palazzi,Cesarini,Battistini,Mularoni,Grandoni,Ceccoli,Tomassini,Della Valle", 34),
        extra("GIB", "Gibraltar", flagOf("GI"),
            "Liam,Roy,Kian,Tjay,Ethan,Louie,Reece,Bernardo,Aaron,Jayce,Graeme,Anthony,Jack,Ryan,Kane,Julian",
            "Chipolina,Walker,Ronan,Britto,Torrilla,Annesley,Coombes,Lopes,Sergeant,Olivero,Casciaro,Barnett,Mouelhi,Wiseman", 36),
        extra("LIE", "Liechtenstein", flagOf("LI"),
            "Sandro,Yanik,Marcel,Nicolas,Jens,Aron,Fabio,Simon,Livio,Noah,Andreas,Martin,Dennis,Maximilian,Robin,Seyhan",
            "Wieser,Frick,Buchel,Hasler,Hofer,Salanovic,Goppel,Malin,Meier,Kaufmann,Ospelt,Beck,Sele,Marxer", 34),
        extra("BOL", "Bolivia", flagOf("BO"),
            "Marcelo,Carmelo,Roberto,Diego,Ramiro,Luis,Boris,Erwin,Jaume,Gabriel,Bruno,Henry,Jose,Moises,Leonel,Efrain",
            "Moreno,Algaranaz,Fernandez,Bejarano,Vaca,Haquin,Justiniano,Villamil,Cuellar,Saucedo,Terceros,Chura,Melgar,Arce", 52),
        extra("VEN", "Venezuela", flagOf("VE"),
            "Salomon,Yeferson,Josef,Darwin,Jhon,Tomas,Wilker,Eduard,Jefferson,Jose,Yangel,Nahuel,Cristian,Alexander,Rafael,Ronald",
            "Rondon,Soteldo,Machis,Savarino,Chancellor,Osorio,Gonzalez,Bello,Herrera,Martinez,Casseres,Ferraresi,Romo,Rivas", 60),
        extra("HON", "Honduras", flagOf("HN"),
            "Alberth,Romell,Anthony,Denil,Jorge,Kervin,Deybi,Edwin,Luis,Carlos,Alexander,Bryan,Rigoberto,Marcelo,Jonathan,Elvin",
            "Elis,Quioto,Lozano,Alvarez,Garcia,Arriaga,Rodriguez,Palma,Beckeles,Crisanto,Pinto,Acosta,Flores,Meza", 54),
        extra("PAN", "Panama", flagOf("PA"),
            "Adalberto,Michael,Anibal,Fidel,Cristian,Eric,Jose,Ismael,Adolfo,Cecilio,Edgar,Omar,Roderick,Andres,Freddy,Harold",
            "Carrasquilla,Murillo,Godoy,Escobar,Martinez,Davis,Fajardo,Diaz,Machado,Waterman,Barcenas,Cordoba,Andrade,Blackman", 55),
        extra("SLV", "El Salvador", flagOf("SV"),
            "Alex,Nelson,Enrico,Jairo,Darwin,Ronald,Mario,Bryan,Joshua,Amando,Eriq,Kevin,Christian,Marvin,Diego,Steve",
            "Roldan,Bonilla,Duenas,Henriquez,Cerritos,Rodriguez,Portillo,Landaverde,Zavaleta,Moran,Larin,Reyes,Menjivar,Alvarado", 47),
        extra("GUA", "Guatemala", flagOf("GT"),
            "Nicholas,Rubio,Oscar,Jose,Carlos,Antonio,Jorge,Rodrigo,Marco,Stheven,Aaron,Alejandro,Darwin,Luis,Kevin,Jesus",
            "Hagen,Rubin,Santis,Ardon,Lopez,Mejia,Aparicio,Saravia,Morales,Lom,Herrera,Cardoza,Ruiz,Estrada", 46),
        extra("NCA", "Nicaragua", flagOf("NI"),
            "Byron,Juan,Jaime,Marlon,Justo,Josue,Bancy,Manuel,Ariagner,Bryan,Henry,Luis,Carlos,Emilio,Oscar,Renato",
            "Bonilla,Barrera,Moreira,Lopez,Quijano,Quijada,Chavarria,Rosas,Alvarez,Garcia,Nino,Reyes,Torres,Palacios", 41),
        extra("HAI", "Haiti", flagOf("HT"),
            "Duckens,Frantzdy,Steeven,Zachary,Carlens,Ricardo,Danley,Andrew,Josue,Mondy,Johny,Derrick,Steven,Kevin,Wilde,Garven",
            "Nazon,Pierrot,Saintini,Herivaux,Alcenat,Etienne,Placide,Jean,Dorsainvil,Prophete,Louis,Michel,Charles,Delva", 52),
        extra("TRI", "Trinidad and Tobago", flagOf("TT"),
            "Levi,Alvin,Reon,Kevin,Aubrey,Justin,Duane,Nathaniel,Noah,Malcolm,Marvin,Ryan,Sheldon,Andre,Che,Joevin",
            "Garcia,Jones,Molino,Bateau,David,Phillip,Muckette,Powder,Bailey,James,Fraser,Peltier,Charles,Hackshaw", 50),
        extra("CUB", "Cuba", flagOf("CU"),
            "Maykel,Aricheell,Onel,Luis,Yordan,Adrian,Roberney,Karel,Andy,Jorge,Yasmany,Osvaldo,Daniel,Marcel,Yanser,Alberto",
            "Reyes,Desangles,Bermudez,Paradela,Santos,Diago,Perez,Espinosa,Baro,Corrales,Alarcon,Alonso,Vidal,Hernandez", 44),
        extra("DOM", "Dominican Republic", flagOf("DO"),
            "Angel,Junior,Edarlyn,Peter,Dorny,Mariano,Jimmy,Heinz,Steven,Oscar,Ronaldo,Jean,Josue,Edison,Luis,Joao",
            "Montes,Firpo,Marte,Gonzalez,Romero,Diaz,Kaba,Mosquera,Rodriguez,Sierra,Vasquez,Urena,Peguero,Adames", 44),
        extra("CUW", "Curacao", flagOf("CW"),
            "Leandro,Juninho,Jurien,Cuco,Roshon,Jearl,Livano,Kenji,Rangelo,Tahith,Sherel,Darren,Shanon,Elson,Gervane,Justin",
            "Bacuna,Martina,Rojer,Antonia,Floranus,Margaret,Chong,Gustavo,Kwidama,Kirindongo,Sluis,Isenia,Curiel,Doran", 50),
        extra("SUR", "Suriname", flagOf("SR"),
            "Sheraldo,Ridgeciano,Damil,Kelvin,Jaime,Miquel,Gleofilo,Diego,Ivenzo,Anfernee,Denzel,Warner,Jason,Shaquille,Radinio,Justin",
            "Becker,Haps,Dabo,Leerdam,Comvalius,Vlijter,Nagelhout,Biseswar,Balker,Hiariej,Jubitana,Pinas,Kappel,Sordam", 48),
        extra("CMR", "Cameroon", flagOf("CM"),
            "Andre,Vincent,Karl,Bryan,Jean,Olivier,Christian,Nouhou,Collins,Georges,Martin,Frank,Ignatius,Pierre,Michael,Enzo",
            "Ngamaleu,Bassogog,Fai,Ntcham,Hongla,Tolo,Kemen,Nkoulou,Anguissa,Bahoken,Choupo,Wooh,Ebosse,Mbekeli", 69),
        extra("MLI", "Mali", flagOf("ML"),
            "Amadou,Yves,Moussa,Hamari,Cheick,Diadie,Massadio,Sekou,Adama,Falaye,Boubacar,Ibrahima,Lassana,Mamadou,Kalifa,Aliou",
            "Haidara,Bissouma,Doumbia,Traore,Diaby,Samassekou,Koita,Sacko,Camara,Coulibaly,Kone,Dembele,Fofana,Sissoko", 67),
        extra("BFA", "Burkina Faso", flagOf("BF"),
            "Bertrand,Issa,Edmond,Dango,Cyrille,Blati,Adama,Zakaria,Issoufou,Gustavo,Ismahila,Steeve,Mohamed,Abdoul,Lassina,Hassane",
            "Traore,Kabore,Ouedraogo,Sangare,Bayala,Toure,Zongo,Nagalo,Tapsoba,Guira,Sanou,Compaore,Kone,Nikiema", 63),
        extra("GUI", "Guinea", flagOf("GN"),
            "Naby,Serhou,Ilaix,Mohamed,Amadou,Morlaye,Aguibou,Ibrahima,Sory,Mamadou,Issiaga,Mohammed,Julian,Seydouba,Francois,Alhassane",
            "Keita,Guirassy,Moran,Bayo,Diakhaby,Sylla,Camara,Conte,Kaba,Diallo,Soumah,Toure,Cisse,Barry", 62),
        extra("COD", "DR Congo", flagOf("CD"),
            "Cedric,Chancel,Yoane,Gael,Arthur,Meschak,Fiston,Theo,Dieumerci,Samuel,Grady,Silas,Ngonda,Merveille,Simon,Joris",
            "Bakambu,Mbemba,Wissa,Kakuta,Masuaku,Elia,Mayele,Bongonda,Moutoussamy,Mukoko,Bolingi,Kalulu,Ndombele,Kayembe", 64),
        extra("CGO", "Congo", flagOf("CG"),
            "Prince,Silvere,Merveil,Beranger,Yhoan,Junior,Bradley,Gaius,Dylan,Antoine,Warren,Kevin,Bissiki,Fernand,Christ,Yann",
            "Oniangue,Ganvoula,Bifouma,Ndinga,Bakouma,Makouta,Mavoungou,Bouanga,Nkounkou,Ibara,Loemba,Kaya,Mabanza,Tsoumou", 53),
        extra("GAB", "Gabon", flagOf("GA"),
            "Pierre,Denis,Mario,Aaron,Andre,Guelor,Bruno,Anthony,Lloyd,Johann,Jim,Yannis,Shavy,Ulrich,Axel,Didier",
            "Bouanga,Lemina,Ecuele,Poko,Obiang,Ndong,Allevinah,Boupendza,Palun,Ndoumbou,Mounie,Meye,Kanga,Aubame", 58),
        extra("ANG", "Angola", flagOf("AO"),
            "Fredy,Gelson,Zito,Mabululu,Bastos,Manuel,Show,Jonathan,Milson,Chico,Depu,Ary,Clinton,Wilson,Edmilson,Beni",
            "Bastos,Dala,Luvumbo,Cabral,Buatu,Fortunato,Mateus,Kialonda,Massunguna,Gaspar,Papel,Djalma,Nurio,Ricardo", 55),
        extra("MOZ", "Mozambique", flagOf("MZ"),
            "Reinildo,Geny,Clesio,Witiness,Domingues,Stanley,Edmilson,Alfonso,Nene,Bruno,Zainadine,Diogo,Gildo,Elias,Telinho,Isac",
            "Mandava,Catamo,Baptista,Quembo,Ratifo,Junior,Amade,Machava,Cuana,Langa,Mabjaia,Chirindza,Nhaga,Domingues", 50),
        extra("ZAM", "Zambia", flagOf("ZM"),
            "Patson,Fashion,Enock,Lameck,Kings,Clatous,Frankie,Emmanuel,Edward,Benson,Golden,Rally,Larry,Kabaso,Roderick,Aaron",
            "Daka,Sakala,Mwepu,Banda,Kangwa,Chama,Musonda,Mulenga,Phiri,Sinkala,Njobvu,Kalaba,Bwalya,Tembo", 52),
        extra("ZIM", "Zimbabwe", flagOf("ZW"),
            "Marvelous,Knowledge,Marshall,Tino,Khama,Jordan,Tendayi,Teenage,Tawanda,Alec,Terrence,Divine,Andy,Brendan,Gerald,Prince",
            "Nakamba,Musona,Munetsi,Kadewere,Billiat,Zemura,Darikwa,Hadebe,Chirewa,Mudimu,Takwara,Lunga,Rusike,Mhango", 50),
        extra("MWI", "Malawi", flagOf("MW"),
            "Gabadinho,Richard,Charles,Frank,John,Chimwemwe,Peter,Denis,Limbikani,Francisco,Robert,Yamikani,Gerald,Stanley,Chiukepo,Blessings",
            "Mhango,Mbulu,Petro,Gawa,Banda,Idana,Cholopi,Chembezi,Mzava,Madinga,Ngwira,Chirwa,Phiri,Msowoya", 44),
        extra("TAN", "Tanzania", flagOf("TZ"),
            "Mbwana,Simon,Novatus,Aishi,Feisal,Himid,Ibrahim,Yassin,Farid,Bakari,Kelvin,Abdi,Salum,Shomari,Mohamed,David",
            "Samatta,Msuva,Miroshi,Manula,Salum,Mgunda,Ajib,Mkami,Mussa,Nondo,Kapombe,Banka,Mnata,Kaseja", 46),
        extra("UGA", "Uganda", flagOf("UG"),
            "Denis,Farouk,Emmanuel,Khalid,Allan,Bevis,Milton,Fahad,Halid,Joseph,Ibrahim,Kenneth,Steven,Jude,Bobosi,Rogers",
            "Onyango,Miya,Okwi,Aucho,Kyambadde,Mugabi,Karisa,Bayo,Lwanga,Ochaya,Sadam,Semakula,Mutyaba,Byaruhanga", 47),
        extra("KEN", "Kenya", flagOf("KE"),
            "Michael,Victor,Masoud,Ayub,Eric,Erick,Johanna,Musa,Abud,Kenneth,Duke,Richard,Timothy,Cliff,Brian,Daniel",
            "Olunga,Wanyama,Juma,Timbe,Ouma,Johanna,Omurwa,Mohammed,Muguna,Ochieng,Otieno,Wanjala,Anyembe,Mudde", 47),
        extra("SUD", "Sudan", flagOf("SD"),
            "Mohamed,Abdelrahman,Saifeldin,Waleed,Mustafa,Yasir,Salah,Ammar,Sharaf,Ramadan,Athar,Bakri,Nazar,Musab,Almoez,Tayseer",
            "Abdallah,Bashir,Osman,Idris,Hassan,Ahmed,Karshoum,Tia,Eldin,Salim,Mudathir,Nasreldin,Elmahdi,Adam", 42),
        extra("ETH", "Ethiopia", flagOf("ET"),
            "Getaneh,Shimelis,Abubeker,Ramkel,Yared,Amanuel,Surafel,Mesud,Dawa,Bezabih,Kenean,Abel,Tafese,Fitsum,Beyene,Hailu",
            "Kebede,Bekele,Nasir,Lual,Baye,Gebremichael,Dagnachew,Mohammed,Hotessa,Meseret,Markneh,Yohannes,Tesfaye,Girma", 42),
        extra("TOG", "Togo", flagOf("TG"),
            "Emmanuel,Kevin,Ihlas,Djene,Peniel,Mathieu,Thomas,Yendoutie,Malcolm,Dove,Kossi,Loic,Roger,Etienne,Zakari,Sadate",
            "Adebayor,Denkey,Bebou,Dakonam,Mlapa,Dossevi,Djene,Nane,Barcola,Wome,Ayite,Agassa,Aholou,Sabi", 50),
        extra("BEN", "Benin", flagOf("BJ"),
            "Steve,Cedric,Jodel,Marcelin,Olivier,David,Sessi,Junior,Yohan,Desire,Tidjani,Khaled,Rodrigue,Andreas,Imourane,Marc",
            "Mounie,Hountondji,Dossou,Koukpo,Verdon,Kiki,Adenon,Sessegnon,Roche,Anaane,Ouorou,Adeoti,Tosin,Djigla", 49),
        extra("GAM", "Gambia", flagOf("GM"),
            "Musa,Ablie,Yusupha,Modou,Ebrima,Assan,Saidy,Alagie,Omar,Sulayman,Momodou,Bubacarr,Alieu,Lamin,Noah,Steve",
            "Barrow,Jallow,Bojang,Colley,Ceesay,Darboe,Sanneh,Njie,Touray,Trawally,Gaye,Marena,Sowe,Manneh", 48),
        extra("GNB", "Guinea-Bissau", flagOf("GW"),
            "Mama,Zezinho,Nanu,Alfa,Jose,Mimito,Toni,Franculino,Frederico,Opa,Sana,Bura,Ianique,Marcelo,Pele,Joseph",
            "Balde,Semedo,Djalo,Correia,Cande,Injai,Camara,Sanha,Nanque,Mendes,Baldé,Embalo,Sanca,Antonio", 50),
        extra("SLE", "Sierra Leone", flagOf("SL"),
            "Kei,Mustapha,Alhaji,Musa,Amadou,Umaru,Mohamed,Issa,Steven,George,John,Yeami,Alie,Augustus,Sheriff,Osman",
            "Kamara,Bundu,Sesay,Turay,Bangura,Koroma,Conteh,Fofanah,Caulker,Davies,Kanu,Mansaray,Jalloh,Sankoh", 45),
        extra("LBR", "Liberia", flagOf("LR"),
            "Sam,Marcus,Terrence,Mohammed,William,Kpah,Christopher,Allen,Oscar,Tonia,Sampson,Darlington,Emmanuel,Anthony,Peter,Solomon",
            "Johnson,Sackor,Tisdell,Sangare,Jebor,Njie,Wreh,Dorley,Gonzalez,Tchato,Kollie,Nyanti,Barsee,Weah", 42),
        extra("CPV", "Cape Verde", flagOf("CV"),
            "Ryan,Jamiro,Kevin,Garry,Bruno,Deroy,Bebe,Jovane,Logan,Steven,Roberto,Dylan,Gilson,Kenny,Laros,Willy",
            "Mendes,Monteiro,Pina,Rodrigues,Tavares,Cabral,Lima,Semedo,Varela,Silva,Duarte,Andrade,Lopes,Fernandes", 56),
        extra("MTN", "Mauritania", flagOf("MR"),
            "Aboubakar,Sidi,Bessam,Ibrahima,Pape,Yeli,Hemeya,Adama,Mohamed,El Hacen,Souleymane,Bakary,Dellahi,Ely,Cheikh,Abdoul",
            "Kamara,Bouna,Ba,Diallo,Sy,Wagne,Yali,Cheikh,Doudou,Traore,Anne,Sow,Sarr,Coulibaly", 45),
        extra("NIG", "Niger", flagOf("NE"),
            "Youssouf,Victorien,Amadou,Ismael,Boubacar,Daniel,Zakari,Moussa,Souleymane,Ibrahim,Abdoul,Koffi,Yacouba,Salifou,Ali,Rachid",
            "Oumarou,Adamou,Moussa,Diallo,Sabo,Alhassane,Issoufou,Maazou,Amadou,Kader,Yayha,Halidou,Salou,Boubacar", 41),
        extra("CHA", "Chad", flagOf("TD"),
            "Casimir,Ezechiel,Marius,Nathan,Kevin,Karl,Yannick,Brahim,Marcel,Alaa,Hassan,Ali,Djibrine,Mahamat,Idriss,Abakar",
            "Ninga,Mbaiam,Mouloungui,Djim,Bebe,Ahmat,Kedigui,Nadji,Alhadj,Yousouf,Hamid,Ousmane,Adoum,Djasnabaille", 38),
        extra("CTA", "Central African Republic", flagOf("CF"),
            "Louis,Geoffrey,Habib,Yakou,Eddy,Anicet,Wilfried,Bevic,Jordan,Foxi,Yannick,Herve,Steeve,Junior,Kevin,Terry",
            "Mafouta,Kondogbia,Habibou,Meite,Gbandi,Abbey,Kanga,Moukoko,Ikaunieks,Kingue,Ngaissona,Namkoisse,Bello,Yatabare", 42),
        extra("MAD", "Madagascar", flagOf("MG"),
            "Anicet,Njiva,Lalaina,Marco,Rayan,Loic,Melvin,Tokinantenaina,Warren,Romain,Thomas,Jerome,Ibrahim,Andriamirado,Faneva,Voavy",
            "Abel,Andriatsima,Raveloson,Ilaimaharitra,Nomenjanahary,Fontaine,Adrien,Randrianasolo,Caizergues,Metanire,Rakotoharimalala,Dax,Amada,Andriamanitra", 46),
        extra("MRI", "Mauritius", flagOf("MU"),
            "Jonathan,Kevin,Ashley,Kervens,Bryan,Adrien,Christopher,Dylan,Jean,Fabrice,Steeve,Yohan,Denis,Nicolas,Ludovic,Anthony",
            "Bru,Perle,Nazira,Jacques,Lafleur,Rasoanaivo,Naiko,Casimir,Curpen,Sadien,Labour,Auguste,Mardemootoo,Ithier", 36),
        extra("BOT", "Botswana", flagOf("BW"),
            "Kabelo,Thero,Onkabetse,Mothusi,Segolame,Tumisang,Thabang,Mogakolodi,Motlhabankwe,Lemponye,Katlego,Gape,Tebogo,Mmusi,Keitumetse,Lesego",
            "Seakanyeng,Setsile,Makwana,Kgetholetsile,Ramatlhakwane,Orebonye,Mogorosi,Nato,Sesinyi,Modiri,Bagaki,Mothibi,Motlhabane,Kabelo", 40),
        extra("NAM", "Namibia", flagOf("NA"),
            "Peter,Deon,Absalom,Ryan,Denzil,Riaan,Wangu,Ivan,Charles,Petrus,Prins,Aprocius,Immanuel,Benson,Willy,Elmo",
            "Shalulile,Hotto,Iimbondi,Nyambe,Hoaseb,Hanamub,Kavezeri,Kambala,Hambira,Shipanga,Tjiueza,Petrus,Stephanus,Kamberipa", 42),
        extra("LES", "Lesotho", flagOf("LS"),
            "Nkoto,Tsoanelo,Motebang,Litsepe,Thabo,Jane,Sera,Bokang,Hlompho,Katleho,Lehlohonolo,Tumelo,Mohau,Sammy,Realeboha,Thabang",
            "Malefane,Koetle,Moletsane,Motikoe,Mahlelebe,Thaba,Motale,Ramaili,Nyabela,Mokhachane,Seturumane,Letsie,Mothibeli,Mabaleha", 36),
        extra("SWZ", "Eswatini", flagOf("SZ"),
            "Sabelo,Sanele,Felix,Sibusiso,Tony,Bongani,Wonder,Thabiso,Mlungisi,Sifiso,Nhlanhla,Vusi,Mduduzi,Njabulo,Musa,Wandile",
            "Ndzinisa,Dlamini,Badenhorst,Simelane,Tsabedze,Mabuza,Nhlengethwa,Sifundza,Mamba,Magagula,Zwane,Shongwe,Matsebula,Gama", 36),
        extra("RWA", "Rwanda", flagOf("RW"),
            "Kevin,Djihad,Herve,Innocent,Ange,Fitina,Emery,Olivier,Jacques,Yannick,Bosco,Muhadjiri,Claude,Eric,Dominique,Thierry",
            "Muhire,Bizimana,Rutanga,Nshuti,Mutsinzi,Omborenga,Bimenyimana,Manzi,Tuyisenge,Niyonzima,Imanishimwe,Hakizimana,Mugiraneza,Nsabimana", 41),
        extra("BDI", "Burundi", flagOf("BI"),
            "Saido,Gael,Cedric,Fiston,Blaise,Youssouf,Shassiri,Elvis,Yannick,Frederic,Amissi,Karim,Djabel,Selemani,Papy,Jules",
            "Berahino,Bigirimana,Amissi,Abedi,Nahimana,Ndikumana,Kamikazi,Nizigiyimana,Mugisha,Ntahomvukiye,Manirakiza,Havyarimana,Bukuru,Ndayishimiye", 40),
        extra("COM", "Comoros", flagOf("KM"),
            "Faiz,Youssouf,El Fardou,Ali,Chaker,Rafidine,Nakibou,Ben,Mohamed,Ibroihim,Fouad,Kassim,Yacine,Alexis,Bendjaloud,Myziane",
            "Selemani,MDahoma,Ben,Ahamada,Alhadhur,Abdallah,Aboubakari,Youssouf,Bakari,Djoudja,Bachirou,Mmadi,Soumah,Maamria", 44),
        extra("STP", "Sao Tome and Principe", flagOf("ST"),
            "Harramiz,Zinho,Deivid,Luis,Bruno,Fabio,Nilson,Nadjack,Osvaldo,Aylton,Wilson,Djoszy,Edmilson,Jose,Herberto,Kanu",
            "Costa,Neto,Amado,Espirito,Ferreira,Lopes,Aguiar,Barros,Trindade,Alves,Bandeira,Ceita,Vaz,Pontes", 34),
        extra("LBY", "Libya", flagOf("LY"),
            "Muaid,Hamdou,Ahmed,Sand,Anis,Faisal,Mohamed,Sanad,Ali,Motasem,Omar,Abdulrahman,Zakaria,Salem,Hamza,Ihaab",
            "Elabid,Elhouni,Benali,Alwarfali,Saltou,Almusrati,Sulaiman,Alsanoussi,Elmusrati,Zubya,Alshaibani,Elmesmari,Bengasi,Alfitouri", 47),
        extra("DJI", "Djibouti", flagOf("DJ"),
            "Warsama,Ali,Mahdi,Hamza,Ahmed,Ismail,Youssouf,Abdi,Osman,Farid,Idris,Mohamed,Said,Naguib,Hassan,Aboubaker",
            "Hassan,Bourhan,Ismael,Ahmed,Omar,Djama,Abdo,Robleh,Waberi,Guirreh,Elmi,Hamadou,Ibrahim,Farah", 32),
        extra("SOM", "Somalia", flagOf("SO"),
            "Omar,Abdisalam,Mohamed,Said,Hassan,Yusuf,Abdirahman,Liban,Farhan,Ali,Ahmed,Ismail,Khalid,Abdi,Bashir,Osman",
            "Abdulle,Hussein,Ahmed,Farah,Warsame,Ali,Osman,Mohamud,Jama,Nur,Aden,Ibrahim,Gedi,Hersi", 32),
        extra("ERI", "Eritrea", flagOf("ER"),
            "Yonas,Tesfay,Henok,Simon,Robel,Berhane,Filmon,Awet,Yohannes,Nahom,Samson,Daniel,Mewael,Tesfalem,Michael,Aman",
            "Tesfay,Ghebremichael,Kidane,Habtom,Weldu,Mehari,Berhe,Okbay,Tewelde,Solomon,Gebremedhin,Andemariam,Hagos,Yohannes", 32),
        extra("SSD", "South Sudan", flagOf("SS"),
            "Tito,James,Roy,Nelson,Peter,Dominic,Ater,Emmanuel,Deng,Malish,Atem,Kuol,Wani,Lual,Bol,Simon",
            "Okello,Moga,Gama,Deng,Kuol,Ladu,Yakobo,Bol,Lado,Juma,Ajak,Mayen,Malual,Chol", 32),
        extra("GNQ", "Equatorial Guinea", flagOf("GQ"),
            "Emilio,Iban,Pablo,Josete,Basilio,Federico,Saul,Jose,Jannick,Carlos,Luis,Salomon,Diosdado,Esteban,Ivan,Randy",
            "Nsue,Salvador,Ganet,Miranda,Obiang,Bikoro,Coco,Machin,Buyla,Akapo,Nnandi,Edu,Owono,Sipo", 48),
        extra("IRN", "Iran", flagOf("IR"),
            "Sardar,Mehdi,Alireza,Saeid,Karim,Ehsan,Milad,Ramin,Omid,Vahid,Shoja,Saman,Morteza,Ali,Hossein,Amir",
            "Azmoun,Taremi,Jahanbakhsh,Ansarifard,Hajsafi,Rezaeian,Mohammadi,Noorollahi,Ghoddos,Amiri,Torabi,Karimi,Beiranvand,Cheshmi", 64),
        extra("IRQ", "Iraq", flagOf("IQ"),
            "Mohanad,Aymen,Ibrahim,Ali,Bashar,Hussein,Amjed,Sherko,Alaa,Zidane,Osama,Rebin,Mustafa,Safaa,Hasan,Frans",
            "Ali,Hussein,Bayesh,Adnan,Resan,Jasim,Attwan,Karim,Abbas,Mimi,Rashid,Sulaka,Nadhim,Dhurgham", 56),
        extra("UZB", "Uzbekistan", flagOf("UZ"),
            "Eldor,Jaloliddin,Odiljon,Abbosbek,Otabek,Jasurbek,Rustam,Azizbek,Husniddin,Islom,Farrukh,Bobur,Sanjar,Oston,Doston,Javokhir",
            "Shomurodov,Masharipov,Hamrobekov,Fayzullaev,Yakhshiboev,Norchaev,Ashurmatov,Turgunboev,Alijonov,Kholmatov,Sayfiev,Urunov,Abdixolikov,Sergeev", 57),
        extra("JOR", "Jordan", flagOf("JO"),
            "Musa,Yazan,Mahmoud,Mousa,Ehsan,Nizar,Ali,Yazeed,Rajaei,Anas,Noor,Hamza,Abdallah,Saleh,Mohammad,Ihsan",
            "Al Tamari,Al Naimat,Mardi,Al Taamari,Haddad,Al Rashdan,Olwan,Abu Layla,Ayed,Bani Attiah,Al Arab,Nasib,Dahoud,Kanaan", 54),
        extra("UAE", "United Arab Emirates", flagOf("AE"),
            "Ali,Fabio,Caio,Harib,Khalifa,Yahya,Sultan,Tahnoon,Khalfan,Bandar,Majed,Abdullah,Saeed,Zayed,Marcus,Ahmed",
            "Mabkhout,De Lima,Lucas,Abdalla,Al Hammadi,Al Ghassani,Suhail,Mubarak,Nasser,Al Ameri,Hassan,Al Attas,Salem,Khalil", 54),
        extra("OMA", "Oman", flagOf("OM"),
            "Muhsen,Abdulaziz,Jameel,Issam,Salaah,Ali,Arshad,Khalid,Amjad,Harib,Zahir,Mohsin,Ibrahim,Ahmed,Rabia,Thani",
            "Al Ghassani,Al Muqbali,Al Yahyaei,Al Sabhi,Al Mukhaini,Al Busaidi,Al Alawi,Al Hajri,Al Kaabi,Al Rushaidi,Al Balushi,Al Mushaifri,Al Saadi,Al Habsi", 50),
        extra("BHR", "Bahrain", flagOf("BH"),
            "Abdullah,Mohamed,Kamil,Ali,Ahmed,Sayed,Hashim,Waleed,Komail,Jasim,Ismaeel,Sami,Mahdi,Abdulwahab,Redha,Husain",
            "Al Hashimi,Marhoon,Al Aswad,Madan,Abdulnabi,Shubbar,Bughammar,Al Hayam,Al Romaihi,Al Aradi,Helal,Naser,Jaafar,Ashoor", 48),
        extra("KUW", "Kuwait", flagOf("KW"),
            "Yousef,Fahad,Bader,Sultan,Hamad,Faisal,Eid,Mubarak,Abdullah,Mohammad,Sami,Khaled,Ali,Nawaf,Rashed,Salman",
            "Nasser,Al Rashidi,Al Mutawa,Al Enezi,Al Ajmi,Al Dhefiri,Al Blooshi,Al Hajeri,Al Sabah,Al Fadhel,Al Hamad,Marzouq,Al Otaibi,Al Dosari", 47),
        extra("LIB", "Lebanon", flagOf("LB"),
            "Hassan,Bassel,Soony,Karim,Walid,Mohamad,Khalil,Hilal,Felix,Maher,Nader,Kassem,Zein,Ali,Rabih,Joan",
            "Maatouk,Jradi,Saad,Darwich,Chaito,Haidar,Bader,El Helwe,Melki,Sabbagh,Matar,Zeineddine,Kanaan,Atwi", 48),
        extra("SYR", "Syria", flagOf("SY"),
            "Omar,Mahmoud,Sanharib,Aias,Mohammad,Alaa,Khaled,Ibrahim,Fahd,Ammar,Moayad,Kamel,Ward,Zaher,Youssef,Amro",
            "Khribin,Al Mawas,Malki,Aldin,Almarmour,Kalfa,Alhalbi,Alkhatib,Youssef,Ramadan,Ajan,Ismail,Jouma,Saleh", 50),
        extra("PLE", "Palestine", flagOf("PS"),
            "Oday,Mahmoud,Layth,Tamer,Musab,Mohammed,Wajdi,Khaled,Islam,Yaser,Ataa,Shehab,Zaid,Ahmed,Amid,Camilo",
            "Dabbagh,Wadi,Kharoub,Seyam,Battat,Rashid,Nasser,Salem,Batran,Hamed,Qunbar,Termanini,Jondi,Saleh", 47),
        extra("YEM", "Yemen", flagOf("YE"),
            "Ala,Ahmed,Abdulwasea,Mohammed,Ayman,Waleed,Ali,Saeed,Nasser,Haitham,Akram,Fuad,Salem,Hamza,Ammar,Yaser",
            "Al Sasi,Al Sarori,Al Matari,Boqshan,Al Hubaishi,Fuad,Al Worafi,Nasser,Al Sunaini,Mansour,Barakat,Al Hifdi,Ghaleb,Al Amri", 36),
        extra("IND", "India", flagOf("IN"),
            "Sunil,Sandesh,Sahal,Anirudh,Lallianzuala,Manvir,Ashique,Brandon,Rahul,Naorem,Liston,Jeakson,Akash,Gurpreet,Amrinder,Nikhil",
            "Chhetri,Jhingan,Thapa,Kuruniyan,Fernandes,Singh,Kumar,Sahoo,Colaco,Bheke,Ralte,Mahato,Das,Mandal", 47),
        extra("PAK", "Pakistan", flagOf("PK"),
            "Otis,Easah,Harun,Abdullah,Rahis,Hassan,Adil,Umar,Yousuf,Saddam,Mohammad,Ali,Faisal,Zeeshan,Waleed,Shayak",
            "Khan,Hameed,Bashir,Iqbal,Nabi,Ahmed,Aslam,Raza,Butt,Malik,Chaudhry,Rehman,Sultan,Younis", 34),
        extra("BAN", "Bangladesh", flagOf("BD"),
            "Jamal,Rakib,Topu,Tariq,Mohammad,Sohel,Anisur,Mahbubur,Ibrahim,Rahmat,Sabbir,Faisal,Rimon,Bishwanath,Sheikh,Yeasin",
            "Bhuyan,Hossain,Barman,Kazi,Rana,Islam,Ahmed,Chowdhury,Sarker,Mia,Das,Rahman,Ali,Uddin", 34),
        extra("NEP", "Nepal", flagOf("NP"),
            "Kiran,Anjan,Bimal,Rohit,Suman,Ananta,Sujal,Sunil,Bishal,Ayush,Tej,Arik,Manish,Nawayug,Dinesh,Suraj",
            "Chemjong,Bista,Gharti,Chand,Aryal,Tamang,Shrestha,Bal,Rai,Ghising,Thapa,Magar,Limbu,Karki", 34),
        extra("SRI", "Sri Lanka", flagOf("LK"),
            "Mohamed,Chalana,Dilan,Sujan,Ahmed,Duckson,Nishantha,Charitha,Roshan,Waseem,Nuwan,Ishan,Kavindu,Rizan,Fazal,Dulaj",
            "Fazal,Perera,Silva,Fernando,Ratnayake,Puswella,Dias,Jayasuriya,Wickramasinghe,Bandara,Kumara,Gunasekara,Amarasinghe,Rathnayake", 32),
        extra("MDV", "Maldives", flagOf("MV"),
            "Ali,Ibrahim,Hamza,Naiz,Hussain,Ahmed,Mohamed,Assadhulla,Akram,Hassan,Nasir,Adam,Yoosuf,Ismail,Sifau,Rilwan",
            "Fasir,Waheed,Mohamed,Hassan,Nasir,Rasheed,Shifau,Abdulla,Ashfaq,Ibrahim,Latheef,Saeed,Naseem,Rilwan", 34),
        extra("THA", "Thailand", flagOf("TH"),
            "Chanathip,Teerasil,Theerathon,Supachok,Ekanit,Sarach,Kritsada,Bordin,Weerathep,Suphanat,Sarawut,Peeradon,Worachit,Patrik,Elias,Jaroensak",
            "Songkrasin,Dangda,Bunmathan,Sarachat,Panya,Yooyen,Kaewsawat,Boonyu,Namwiset,Chuchuen,Kongyot,Chanpleng,Aromsawa,Wongkham", 50),
        extra("VIE", "Vietnam", flagOf("VN"),
            "Quang,Cong,Van,Duy,Tien,Hoang,Nguyen,Thanh,Tuan,Xuan,Minh,Hong,Ngoc,Duc,Anh,Trong",
            "Nguyen,Tran,Le,Pham,Hoang,Phan,Vu,Dang,Bui,Do,Ho,Ngo,Duong,Ly", 50),
        extra("IDN", "Indonesia", flagOf("ID"),
            "Marselino,Egy,Witan,Asnawi,Pratama,Rizky,Yakob,Ricky,Dendy,Rachmat,Saddil,Arhan,Jordi,Ivar,Sandy,Marc",
            "Ferdinan,Maulana,Sulaeman,Mangkualam,Arhan,Ridho,Sayuri,Kambuaya,Sumardi,Irfan,Ramdani,Walsh,Amat,Klok", 47),
        extra("MAS", "Malaysia", flagOf("MY"),
            "Safawi,Faisal,Syafiq,Matthew,Dominic,Akhyar,Arif,Sergio,Mohamadou,Darren,Nik,Shahrul,Endrick,Muhammad,Aiman,Hadi",
            "Rasid,Halim,Ahmad,Davies,Tan,Rashid,Aiman,Aguero,Sumareh,Lok,Sharul,Saari,Fandi,Zulkifli", 46),
        extra("SIN", "Singapore", flagOf("SG"),
            "Ikhsan,Ilhan,Song,Hariss,Shawal,Faris,Safuwan,Hassan,Irfan,Jacob,Amirul,Shah,Zulqarnaen,Adam,Glenn,Hafiz",
            "Fandi,Harun,Ui,Ramli,Nazeeh,Adam,Baharudin,Sunny,Yusof,Mahmud,Adli,Shariff,Zulkifli,Nur", 42),
        extra("PHI", "Philippines", flagOf("PH"),
            "Bienvenido,Patrick,Amani,Stephan,Kevin,Mike,Jarvey,Oskari,Sandro,Justin,Michael,Jesse,Manuel,Jefferson,Daizo,John",
            "Maranon,Reichelt,Aguinaldo,Schrock,Ingreso,Ott,Gayoso,Ojala,Reyes,Baas,Kempter,Curran,Palaña,Tabinas", 42),
        extra("MYA", "Myanmar", flagOf("MM"),
            "Aung,Maung,Kyaw,Zaw,Thet,Hein,Nanda,Win,Naing,Soe,Myat,Yan,Thura,Khin,Sithu,Hlaing",
            "Thu,Naing,Oo,Aung,Win,Htike,Lwin,Zaw,Ko,Kyaw,Myint,Tun,Moe,Soe", 38),
        extra("HKG", "Hong Kong", flagOf("HK"),
            "Everton,Michael,Yue,Tsun,Chun,Wai,Sun,Kin,Hei,Ho,Cheuk,Pak,Lok,Ka,Yin,Chi",
            "Camara,Udebuluzor,Cheng,Yuen,Wong,Lam,Chan,Leung,Ho,Tsui,Fung,Lo,Yeung,Tang", 40),
        extra("PRK", "North Korea", flagOf("KP"),
            "Han,Ri,Jong,Kim,Pak,Choe,An,Jang,Om,Sin,Kang,Ryom,So,Ju,Kwon,Hwang",
            "Kwang,Song,Il,Hyok,Chol,Su,Jin,Nam,Hyon,Myong,Bom,Kuk,Chan,Hun", 44),
        extra("TJK", "Tajikistan", flagOf("TJ"),
            "Parvizdzhon,Nuriddin,Ehson,Manuchehr,Vahdat,Rustam,Alisher,Amirbek,Shahrom,Zoir,Komron,Akhtam,Tabrezi,Daler,Sheriddin,Amadoni",
            "Umarbayev,Davronov,Panjshanbe,Dzhalilov,Hanonov,Yatimov,Rahimov,Nazarov,Samiev,Dzhuraboev,Boboev,Ergashev,Hasanov,Kamolov", 42),
        extra("KGZ", "Kyrgyzstan", flagOf("KG"),
            "Erbol,Farkhat,Kai,Bekzhan,Gulzhigit,Bakhtiyar,Aizar,Beknaz,Tamirlan,Joel,Aleksandr,Valery,Erlan,Suyuntbek,Kimi,Mirlan",
            "Abdrakhmanov,Musabekov,Alykulov,Sagynbaev,Kojo,Duishobekov,Israilov,Bekbolotov,Kozubaev,Kokoev,Mirzabekov,Sydykov,Sultonov,Murzaev", 42),
        extra("TKM", "Turkmenistan", flagOf("TM"),
            "Ruslan,Altymyrat,Wepa,Selim,Arslanmyrat,Mekan,Didar,Serdar,Vahyt,Myrat,Gurbangeldi,Ahmet,Guychmyrat,Shanazar,Elman,Begench",
            "Mingazow,Annadurdyyew,Amanow,Nurmuradow,Orazow,Saparow,Durdyyew,Geldiyew,Orazsahedow,Yagshyyew,Batyrow,Ataýew,Annaýew,Meredow", 40),
        extra("CAM", "Cambodia", flagOf("KH"),
            "Chan,Sos,Keo,Sieng,Thierry,Reung,Sareth,Orn,Nick,Vanna,Prak,Yue,Choun,Sin,Vireak,Tes",
            "Vathanaka,Suhana,Sokumpheak,Chanthea,Chantha,Bunheing,Sovannara,Chanpolin,Taylor,Samith,Mony,Chandara,Sopanha,Rathanak", 34),
        extra("LAO", "Laos", flagOf("LA"),
            "Bounphachan,Soukaphone,Phithack,Kaysone,Souliya,Billy,Chony,Vongchiengkham,Khampheng,Phatthana,Damoth,Sonesavanh,Anousack,Peeter,Vilayout,Chanthaphone",
            "Bounkong,Vongchiengkham,Nakhonesy,Souksavath,Phimmasone,Ketphanh,Sanoubane,Xaysongkham,Sengsavang,Bounthisanh,Keomanivong,Douangchak,Vilaysone,Insysiengmay", 32),
        extra("BRU", "Brunei", flagOf("BN"),
            "Abdul,Azwan,Hendra,Shah,Najib,Adi,Faiq,Hakeme,Naim,Muhammad,Wardun,Yura,Amirul,Hariz,Nurikhwan,Aliff",
            "Bolkiah,Ali,Yusof,Hassan,Abdullah,Salleh,Rahman,Ismail,Osman,Rahim,Jaafar,Latif,Mahmud,Zainal", 30),
        extra("BHU", "Bhutan", flagOf("BT"),
            "Chencho,Nima,Karma,Tshering,Kinley,Yeshey,Sonam,Hari,Phuntsho,Ugyen,Jigme,Dorji,Passang,Namgay,Sangay,Tandin",
            "Gyeltshen,Wangdi,Dorji,Tshering,Penjor,Rai,Subba,Gurung,Wangchuk,Namgyal,Zangpo,Norbu,Sherpa,Tobgay", 28),
        extra("TLS", "Timor-Leste", flagOf("TL"),
            "Rufino,Paulo,Gali,Mouzinho,Anggisu,Filomeno,Joao,Nataniel,Jose,Elias,Rodolfo,Alan,Nelson,Zezinho,Feliciano,Mario",
            "Gama,Domingos,Freitas,Pereira,Barbosa,Soares,Mendonca,Reis,Amaral,Guterres,Belo,Sarmento,Ximenes,Fernandes", 28),
        extra("MAC", "Macau", flagOf("MO"),
            "Chan,Leong,Lam,Ho,Cheang,Che,Kuok,Lei,Ng,Sio,Tam,Wong,Ip,Chao,Lao,Kou",
            "Kin,Hou,Chi,Weng,Cheong,Man,Hoi,Wai,Fai,Meng,Seng,Kuan,Long,Tat", 28),
        extra("NZL", "New Zealand", flagOf("NZ"),
            "Chris,Marko,Matthew,Liberato,Bill,Michael,Callum,Ben,Winston,Alex,Joe,Elijah,Storm,Tim,Nando,Dane",
            "Wood,Stamenic,Garbett,Cacace,Tuiloma,Boxall,McCowatt,Waine,Reid,Paulsen,Bell,Just,Roux,Ingham", 50),
        extra("FIJ", "Fiji", flagOf("FJ"),
            "Roy,Setareki,Nickel,Sekove,Beniamino,Iosefo,Simione,Kolinio,Merrill,Dave,Samuela,Antonio,Napolioni,Rusiate,Christopher,Tevita",
            "Krishna,Hughes,Chand,Babitu,Mateinaqara,Baleinadogo,Tamanisau,Verebasaga,Kumar,Radrigai,Nabenia,Tuivuna,Waqa,Naicker", 38),
        extra("NCL", "New Caledonia", flagOf("NC"),
            "Georges,Cesar,Bertrand,Jekob,Joel,Emile,Roy,Antoine,Jean,Michael,Kevin,Terry,Judikael,Steeve,Enzo,Norbert",
            "Gope,Lekafa,Kaiwi,Jajumbo,Wajoka,Bearune,Kayara,Roine,Hmae,Wamedjo,Sinedo,Menango,Kabeu,Wenehoua", 38),
        extra("SOL", "Solomon Islands", flagOf("SB"),
            "Micah,Raphael,Jerry,Atkin,Joses,Tigi,Gagame,Benjamin,Hadisi,Leon,Charles,Kensi,Nelson,Ian,Lency,Alvin",
            "Lea,Waita,Donga,Kaikai,Ngava,Feni,Sale,Totori,Ruaburu,Marau,Nafo,Bebeu,Sui,Hou", 36),
        extra("TAH", "Tahiti", flagOf("PF"),
            "Alvin,Teaonui,Yohann,Raimana,Tamatoa,Heimano,Manutea,Ariitea,Lorenzo,Eddy,Terai,Roonui,Mario,Hiro,Tauhiti,Jonathan",
            "Tehau,Chong,Lopez,Li,Wajoka,Bennett,Tepa,Tinorua,Kolinio,Kautai,Taufa,Temataua,Pito,Vahirua", 36),
        extra("VAN", "Vanuatu", flagOf("VU"),
            "Brian,Bong,Jason,Fenedy,Azariah,Alphonse,Nelson,Sanele,Ronaldo,Kensi,Jeffery,Tony,Kalworai,Micah,Dagon,Steven",
            "Kaltak,Kaltack,Alick,Masauvakalo,Soru,Qorig,Sale,Iaruel,Wilkins,Bibi,Cheung,Kalorib,Natonga,Tariwa", 34),
        extra("PNG", "Papua New Guinea", flagOf("PG"),
            "Nigel,Tommy,Raymond,David,Michael,Alwin,Emmanuel,Ati,Ronald,Jacob,Obert,Gaius,Felix,Yagi,Koriak,Nicholas",
            "Dabinyaba,Semmy,Gunemba,Muta,Foster,Komolong,Simon,Kamasua,Warisan,Sabua,Datoto,Kepo,Bala,Sinaka", 32),
        extra("SAM", "Samoa", flagOf("WS"),
            "Nicholas,Jaiyah,Silao,Desmond,Konelio,Sione,Uili,Tavita,Faalavelave,Peter,Charlie,Lyle,Junior,Alafua,Simeone,Tautalatasi",
            "Swanepoel,Saelua,Malietoa,Faiane,Tuiletufuga,Faasavalu,Nimo,Sanele,Semaia,Lauano,Mailei,Solomona,Fereti,Iosia", 30),
        extra("TGA", "Tonga", flagOf("TO"),
            "Timote,Hemaloto,Lafaele,Kilifi,Sione,Unaloto,Tevita,Fanuatanu,Malakai,Viliami,Sailosi,Aisake,Loni,Semisi,Ofa,Paula",
            "Moleni,Polovili,Moala,Uhatahi,Tuivailala,Tonga,Fifita,Fakalelu,Vaiangina,Latu,Feao,Tupou,Havili,Kaufusi", 28),
        extra("COK", "Cook Islands", flagOf("CK"),
            "Campbell,Harry,Taylor,Justin,Alex,Jarrah,Ngametua,Michael,Tepaeru,Junior,Mataio,Kaitini,Tereapii,Rimson,Antonio,Sione",
            "Best,Napa,Saghabi,Tetauru,Wichman,Ngametua,Tearetoa,Poila,Tinirau,Maka,Mateariki,Puna,Turua,Kea", 26)
    )

    val NATIONS: List<Nation> = listOf(
        Nation("ENG", "England", "\uD83C\uDFF4", 
            "Jack,Harry,Callum,Reece,Mason,Tyler,Kieran,Declan,Ollie,Marcus,Alfie,Jude,Cole,Ryan,Lewis,Connor,Dean,Nathan,Josh,Curtis,Elliot,Bailey,Rhys,Charlie,Freddie,Archie,Louie,Finley,Rory,Toby,Miles,Spencer,Warren,Ashton,Ellis,Jarrod,Kane,Lyle,Morgan,Neville,Perry,Quinn,Reuben,Sonny,Trent,Vince,Wesley,Zack,Aaron,Brandon,Casey,Dexter,Emmett,Fraser,Gethin,Hugo,Isaac,Jonty,Kelvin,Lomax,Marlow,Nolan,Oakley,Paxton,Rowan,Sterling,Teddy,Vaughn,Wilbur,Yates,Alby,Bram,Cass,Dane,Edwin,Flynn,Grady,Hale,Ivor,Jarvis,Keane,Linden,Merrick,Ned,Osric,Piers,Ronan,Stanley,Tobias,Ulric",
            "Whitlock,Sanderson,Brackley,Hendry,Ashworth,Norris,Ravenhill,Tunstall,Feather,Colgrave,Marsden,Ardley,Winstone,Bellwood,Hargate,Pemberton,Radcliffe,Quill,Standen,Verrall,Aldridge,Barlow,Cadwell,Dunmore,Ellery,Fairbrother,Garrick,Hollis,Ingram,Jessop,Kirkbride,Larkham,Mowbray,Newbold,Oldacre,Prescott,Quinnell,Rutherford,Selby,Thackeray,Underhill,Vickery,Wrenshall,Yardley,Ambrose,Blakeney,Croft,Dearden,Ewart,Fenwick,Goodwin,Hartnell,Isley,Jardine,Kelsall,Lindley,Marchant,Nightingale,Ormerod,Peveril,Rainford,Stapleton,Trelawney,Vance,Wexford,Yelland,Ashby,Bidwell,Chadwick,Dalrymple,Everard,Foxcroft,Grimshaw,Halloway,Ingleby,Jocelyn,Kingsford,Lyddon,Merriweather,Norcross,Ottway,Pinnock,Redfern,Southwell,Tresham,Vosper,Waverley",
            88),
        Nation("ESP", "Spain", "\uD83C\uDDEA\uD83C\uDDF8",
            "Iker,Nacho,Álvaro,Sergi,Unai,Pau,Aitor,Rodri,Marcos,Iñaki,Borja,Dani,Gerard,Adrián,Hugo,Javi,Mateo,Bruno,Óscar,Raúl,Aleix,Beñat,Carles,Diego,Enric,Fran,Gonzalo,Héctor,Ignacio,Jorge,Koke,Lucas,Manu,Nico,Oriol,Pablo,Quique,Rubén,Samu,Tomás,Ander,Bernat,Cristian,David,Eric,Fabián,Guillem,Hugo,Isco,Joan,Kike,Lluís,Marc,Nil,Odei,Pedri,Roque,Saúl,Toni,Vicente,Xabi,Yeray,Álex,Biel,César,Dídac,Eneko,Ferrán,Gaizka,Iago,Jon,Luka,Mikel,Nahuel,Óliver,Paco,Ramón,Sergio,Tico,Urko,Víctor,Xavi",
            "Beltrán,Corominas,Escalante,Valverde,Zurita,Olmedo,Miralles,Sáenz,Ferrer,Aranda,Quintana,Berrocal,Herrán,Lozano,Casilla,Peralta,Nogueira,Valdivia,Aguirre,Rivas,Amarante,Bustamante,Cifuentes,Domínguez,Echeverría,Fuentes,Galindo,Hidalgo,Iglesias,Jimeno,Larrea,Maldonado,Navarrete,Ocaña,Pedraza,Quiroga,Rebollo,Salcedo,Tejada,Ugarte,Vergara,Zabala,Arrieta,Bermejo,Cabrera,Delgado,Espinosa,Frías,Gallardo,Hurtado,Izaguirre,Jáuregui,Lastra,Mendoza,Nieves,Orozco,Padilla,Requena,Sanabria,Tellado,Uriarte,Vidal,Yáñez,Arteaga,Bonilla,Carranza,Duarte,Elizalde,Fandiño,Garzón,Herrera,Ibarra,Jurado,Leiva,Mansilla,Novoa,Olarte,Prieto,Rueda,Sarabia,Torrent,Ulloa,Villena",
            94),
        Nation("FRA", "France", "\uD83C\uDDEB\uD83C\uDDF7",
            "Théo,Lucas,Enzo,Maxence,Yanis,Kylian,Amine,Malo,Noam,Ilan,Gaël,Rayan,Corentin,Baptiste,Ousmane,Loïc,Sacha,Nolan,Élias,Warren,Adrien,Bastien,Clément,Damien,Étienne,Florian,Gaspard,Hugo,Ismaël,Jules,Kenzo,Léo,Mathis,Nathan,Olivier,Paul,Quentin,Rémi,Samuel,Thibaut,Ulysse,Valentin,Wilfried,Yohan,Zacharie,Aurélien,Benjamin,Cédric,Dorian,Émile,Fabien,Grégoire,Hakim,Ibrahim,Joris,Karim,Lilian,Marius,Naïm,Octave,Pierrick,Raphaël,Simon,Tanguy,Ugo,Victorien,Wandrille,Yacine,Zaïd,Antoine,Bilal,Charly,Diego,Eliott,Ferdinand,Gauthier,Hicham,Idriss,Jibril",
            "Delaunay,Marchand,Brossard,Vasseur,Chastain,Lemoine,Perrot,Guilbert,Fourcade,Renaudin,Tavernier,Coulibaly,Béranger,Dassault,Nkolo,Sirieix,Mahé,Prévost,Vidal,Corbeau,Aubertin,Bonnaire,Charrier,Delcourt,Estève,Fournier,Gauthier,Hébert,Imbert,Jourdain,Lacombe,Mercier,Noiret,Ollivier,Pasquier,Quérin,Rossignol,Sauvage,Thibault,Urbain,Vaillant,Weber,Yvon,Arnoux,Bellamy,Cazenave,Duguay,Eyraud,Faivre,Gaudin,Hulot,Isnard,Joubert,Kervella,Lasalle,Monnier,Nadeau,Orsini,Pelletier,Ravel,Sablé,Teyssier,Vachon,Wattier,Aubry,Beaulieu,Clavier,Descamps,Escoffier,Fressange,Gilbert,Harcourt,Ivanoff,Janvier,Lacroix,Maréchal,Naudin,Ozanne,Poirier,Rambert,Soulier",
            93),
        Nation("ITA", "Italy", "\uD83C\uDDEE\uD83C\uDDF9",
            "Matteo,Lorenzo,Andrea,Gianluca,Nicolò,Federico,Samuele,Riccardo,Davide,Tommaso,Alessio,Manuel,Simone,Edoardo,Cristian,Giacomo,Fabio,Emanuele,Leonardo,Pietro,Alberto,Bruno,Carlo,Diego,Enrico,Filippo,Gabriele,Ivan,Jacopo,Luca,Marco,Nicola,Ottavio,Paolo,Raffaele,Stefano,Tiziano,Umberto,Valerio,Antonio,Christian,Domenico,Elia,Francesco,Giulio,Ignazio,Leandro,Massimo,Nino,Orlando,Pasquale,Roberto,Salvatore,Sandro,Vittorio,Adriano,Benedetto,Corrado,Dario,Ermanno,Flavio,Giorgio,Lapo,Michele,Nunzio,Osvaldo,Piero,Renzo,Sergio,Tullio",
            "Ricciardi,Bellandi,Trevisan,Marchetti,Sacchetti,Vitiello,Zenoni,Cangiano,Perrone,Fiorini,Loreto,Balestra,Mancuso,Grillo,Renzetti,Turrini,Sabbatini,Delfino,Pagano,Corradi,Ambrosini,Bertolini,Casadei,D'Amico,Esposito,Ferraris,Gattuso,Iachini,Lombardi,Mazzola,Nocerino,Orsolini,Pellegatti,Quagliarella,Ravaglia,Scalvini,Terracciano,Ubaldi,Venturi,Zaccagni,Alberico,Bonucci,Carboni,Dossena,Fagioli,Gabbia,Impallomeni,Locatelli,Miretti,Nardi,Odoardi,Piccoli,Ranocchia,Serpe,Tonali,Vergani,Zampano,Altobelli,Bramante,Ceccarelli,Dellavalle,Frattesi,Gilardino,Isernia,Luvumbo,Montipò,Nasti,Ottaviani,Palladino,Ripamonti,Sottil",
            92),
        Nation("GER", "Germany", "\uD83C\uDDE9\uD83C\uDDEA",
            "Jonas,Luca,Nico,Fynn,Marvin,Tim,Leon,Elias,Maik,Kai,Jannik,Malte,Sven,Bastian,Torben,Ole,Hendrik,Marlon,Florian,Justus,Andreas,Benedikt,Christoph,Dominik,Erik,Felix,Gregor,Hannes,Ingo,Jakob,Konstantin,Lennart,Moritz,Niklas,Oskar,Philipp,Quirin,Robin,Simon,Thilo,Uwe,Valentin,Wolfram,Yannick,Arne,Bjarne,Claas,Detlef,Emil,Frederik,Gunnar,Henning,Ilja,Jörn,Kilian,Lasse,Mattes,Nils,Ove,Piet,Rasmus,Steffen,Tammo,Ulrich,Vincent,Wilko",
            "Brandt,Sieber,Hollmann,Kraushaar,Wendt,Nolte,Fischbach,Rehberg,Zorn,Külzer,Bergmann,Steinmetz,Ohlrich,Vogtland,Dahlke,Reinke,Sattler,Möricke,Bauwens,Gehrke,Achterberg,Bültmann,Clausnitzer,Dettmar,Ehrhardt,Feldkamp,Gerlach,Hasselmann,Iserlohn,Jankowski,Kettner,Lindemann,Maiwald,Niederhoff,Oestreich,Pflüger,Quandt,Riedel,Schwerdt,Thormählen,Uhlenbrock,Vollmer,Wiegand,Zeitler,Ahlers,Bickel,Christiansen,Drewes,Emmerich,Freitag,Gundlach,Heitmann,Illner,Jessen,Kammerer,Lehnhoff,Möbius,Nettelbeck,Ortmann,Petersen,Rothe,Stollberg,Tiedemann,Ummel,Vetter,Wehrmann",
            91),
        Nation("BRA", "Brazil", "\uD83C\uDDE7\uD83C\uDDF7",
            "Rafael,Vinícius,Gabriel,Endrick,Wesley,Matheus,Caio,Douglas,Éverton,Luan,Rodrygo,Kaique,Igor,Yuri,Danilo,Pedrinho,Talles,Bruninho,Ronald,Jhon,Alisson,Bernardo,Carlinhos,Deyverson,Emerson,Fabinho,Gerson,Hulk,Ítalo,Juninho,Kevin,Lucas,Murilo,Nathan,Otávio,Paulinho,Quaresma,Richarlison,Samuel,Thiago,Ueslei,Vitor,Weverton,Yago,Alan,Breno,Cauã,Diego,Erick,Felipe,Guilherme,Heitor,Ivan,João,Kauê,Léo,Marlon,Nícolas,Otoniel,Pablo,Ramon,Sandro,Tales,Vagner,Wanderson",
            "Nascimento,Vasconcelos,Andrade,Bittencourt,Furtado,Queiroz,Marinho,Sampaio,Bezerra,Cavalcanti,Peixoto,Gonçalves,Rezende,Aguiar,Tavares,Simões,Machado,Brandão,Vieira,Coutinho,Albuquerque,Barbosa,Camargo,Dantas,Esteves,Fagundes,Guimarães,Hollanda,Isidoro,Jucá,Lacerda,Monteiro,Negrão,Oliveira,Portela,Quaresma,Ribeiro,Siqueira,Teixeira,Uchôa,Valadares,Xavier,Assunção,Bomfim,Carneiro,Drummond,Escobar,Ferraz,Godoy,Henrique,Ipiranga,Jardim,Loureiro,Medeiros,Novaes,Paiva,Rangel,Salgado,Trindade,Verissimo",
            95),
        Nation("ARG", "Argentina", "\uD83C\uDDE6\uD83C\uDDF7",
            "Facundo,Lautaro,Thiago,Valentín,Santino,Julián,Nehuén,Enzo,Máximo,Agustín,Franco,Tomás,Benjamín,Alan,Ezequiel,Joaquín,Bautista,Nicolás,Lisandro,Gonzalo,Alejo,Braian,Ciro,Dylan,Emiliano,Federico,Gastón,Hernán,Ignacio,Juan,Kevin,Lucas,Matías,Nahuel,Octavio,Patricio,Ramiro,Santiago,Tobías,Ulises,Valentino,Wilson,Yamil,Ariel,Bruno,Cristian,Damián,Elías,Fabricio,Germán,Hugo,Iván,Jeremías,Leandro,Marcos,Nicanor,Osvaldo,Pedro,Rodrigo,Sebastián",
            "Insaurralde,Villalba,Zerpa,Barrientos,Ocampo,Cardozo,Migliore,Frascarelli,Bustos,Almirón,Retegui,Sosa,Quiroga,Palacios,Colombo,Ferreyra,Lanzini,Baldassi,Moyano,Escudero,Aimar,Benedetto,Correa,Dybala,Enrique,Fernández,Gaitán,Heredia,Iturbe,Juárez,Krause,Lamela,Medina,Núñez,Otamendi,Peredo,Quintero,Rojas,Salvio,Tagliafico,Urzúa,Vega,Yedlin,Zabaleta,Arruabarrena,Bianchi,Cambiasso,Domínguez,Estigarribia,Funes,Godoy,Hauche,Ibarra,Jara",
            94),
        Nation("NED", "Netherlands", "\uD83C\uDDF3\uD83C\uDDF1",
            "Sem,Daan,Jurriën,Sven,Bram,Ruben,Tijmen,Mees,Cody,Quinten,Joep,Jorrel,Xavi,Thijs,Stijn,Kick,Milan,Wout,Guus,Lars,Bas,Cas,Dirk,Emiel,Floris,Gijs,Hidde,Ivo,Jelle,Koen,Luuk,Maarten,Niek,Olivier,Pepijn,Rens,Siem,Teun,Vince,Wessel,Youri,Arjen,Boaz,Chris,Dean,Ernst,Frank,Geert,Hein,Ids,Joost,Kees,Lucas,Menno,Noud,Otto,Pim,Roel,Sander,Tycho",
            "van Aerde,Verduijn,de Roon,Klaassen,Boersma,van Rhijn,Groenveld,Steijn,Bosveld,de Vrieze,Hoogland,Vermeulen,Kuipers,van Doorn,Zwart,Dekker,Bakhuis,Nieuwkoop,Ramselaar,Oosting,Aardema,Beukema,Cillessen,Doekhi,Everts,Frimpong,Geertruida,Hartman,Idzes,Janssen,Koopmeiners,Lang,Meerdink,Nijhuis,Olij,Pierie,Rensch,Schuurs,Timber,Veerman,Wieffer,Zirkzee,Aerts,Blokzijl,Cuypers,Diemers,Engels,Faber,Goudmijn,Heitinga",
            90),
        Nation("POR", "Portugal", "\uD83C\uDDF5\uD83C\uDDF9",
            "Gonçalo,Diogo,Tomás,Rúben,Vitinha,Fábio,Afonso,Nuno,Rodrigo,Duarte,Hélder,João,Bernardo,Otávio,Ivan,Salvador,Martim,Dinis,Xavier,Guilherme,André,Bruno,César,Daniel,Eduardo,Filipe,Gil,Henrique,Isaac,Jota,Luís,Miguel,Nélson,Óscar,Pedro,Quim,Ricardo,Sérgio,Tiago,Vasco,Zé,Alexandre,Beto,Carlos,Domingos,Emanuel,Francisco,Gabriel,Hugo,Ilídio",
            "Trincão,Bragança,Esteves,Neves,Carmo,Loureiro,Bastos,Amorim,Coentrão,Beto,Semedo,Rebelo,Palhinha,Ramos,Dâmaso,Cancelo,Varela,Pinheiro,Estrela,Mendonça,Abreu,Baptista,Cardoso,Domingues,Fonseca,Gomes,Horta,Inácio,Jota,Leitão,Marques,Nunes,Oliveira,Pereira,Queirós,Rocha,Sarmento,Teixeira,Vinagre,Azevedo,Botelho,Cunha,Dias,Faria,Guedes,Henriques,Lourenço,Moutinho",
            91),
        Nation("MAR", "Morocco", "\uD83C\uDDF2\uD83C\uDDE6",
            "Youssef,Anass,Bilal,Ayoub,Zakaria,Ilyas,Reda,Oussama,Mehdi,Achraf,Nayef,Amine,Soufiane,Hamza,Walid,Ismail,Yassine,Adam,Marouane,Karim,Abdelilah,Badr,Chakib,Driss,Elmehdi,Fouad,Ghali,Hicham,Imad,Jamal,Khalid,Larbi,Mounir,Nabil,Omar,Rachid,Saad,Tarik,Wassim,Yahya,Zouhair,Anir,Bachir,Charaf,Daoud,Elias,Farouk,Ghassan,Haitam,Idriss,Jawad,Kamal,Lotfi,Mustapha,Nordin,Othmane,Rayane,Samir,Taha,Younes",
            "El Kadiri,Benhaddou,Ouazzani,Zerouali,Lahlou,Bennani,Chraibi,El Idrissi,Mansouri,Sbai,Tazi,Berrada,Hajji,Nabil,El Amrani,Rachidi,Ghanem,Bouzid,Serrar,Alaoui,Amrani,Belkhayat,Cherkaoui,Dahbi,El Fassi,Fikri,Guerrouj,Hammouti,Ibrahimi,Jebli,Kabbaj,Lamrani,Moujahid,Naciri,Ouhadi,Qadiri,Regragui,Sekkat,Tahiri,Wahbi,Yousfi,Zniber,Ait Ali,Bouchta,Chafik,Drissi,El Haddaoui,Fahmi,Gharbi,Hilali",
            84),
        Nation("SEN", "Senegal", "\uD83C\uDDF8\uD83C\uDDF3",
            "Ibrahima,Moussa,Cheikh,Pape,Lamine,Abdoulaye,Habib,Mamadou,Ousseynou,Krépin,Boulaye,Nampalys,Formose,Assane,Seydou,Iliman,Idrissa,Amara,Bamba,Youssouph,Alioune,Baba,Demba,El Hadji,Fallou,Gana,Hamidou,Insa,Joseph,Khadim,Mbaye,Ndiaga,Omar,Pathé,Saliou,Tapha,Waly,Yankuba,Abdou,Birane,Cherif,Daouda,Elimane,Fodé,Gorgui,Ismaila,Jules,Kalidou,Malick,Nicolas",
            "Diatta,Ndiaye,Sarr,Gueye,Faye,Cissé,Diallo,Mbaye,Ba,Sow,Kouyaté,Diedhiou,Thiam,Camara,Seck,Dieng,Boye,Niang,Sylla,Badji,Diagne,Fall,Gassama,Konaté,Lo,Mendy,Ndoye,Samb,Touré,Wade,Barry,Coly,Diaby,Ka,Mané,Ngom,Sagna,Tine,Diakhaté,Guirassy,Jatta,Kanté,Loum,Ndour,Sané,Traoré",
            83),
        Nation("JPN", "Japan", "\uD83C\uDDEF\uD83C\uDDF5",
            "Kaoru,Takumi,Ritsu,Ayase,Daichi,Yuki,Sota,Reo,Kyogo,Hiroki,Junya,Shuto,Koki,Ao,Yuta,Ren,Kota,Naoki,Riku,Takuma,Akihiro,Daisuke,Eiji,Fuma,Genki,Haruto,Isamu,Jun,Kenta,Masaya,Nobuaki,Osamu,Ryota,Shinji,Tatsuya,Wataru,Yamato,Zen,Asahi,Chikara,Hayato,Itsuki,Kazuki,Makoto,Noboru,Rikuto,Shohei,Tomoki,Yudai",
            "Mitoma,Kubo,Endo,Tomiyasu,Doan,Hatate,Morita,Nakamura,Kamada,Ito,Suzuki,Ogawa,Sugawara,Machida,Hashioka,Fujita,Osako,Watanabe,Sakai,Uchida,Asano,Furuhashi,Hara,Inoue,Kaneko,Maeda,Nishikawa,Okazaki,Sano,Takahashi,Ueda,Yamada,Aoki,Fukuda,Hasegawa,Ikeda,Kimura,Matsuda,Nakajima,Ono,Saito,Tanaka,Yoshida",
            80),
        Nation("CRO", "Croatia", "\uD83C\uDDED\uD83C\uDDF7",
            "Luka,Josip,Marko,Ivan,Mateo,Borna,Domagoj,Nikola,Filip,Ante,Lovro,Petar,Duje,Stipe,Roko,Toma,Karlo,Fran,Bruno,Jakov,Andrej,Dario,Emil,Goran,Hrvoje,Igor,Jure,Krešimir,Leon,Matej,Niko,Ozren,Rino,Šime,Tin,Vedran,Zoran,Antonio,Damir,Frane,Gabrijel",
            "Kovačević,Modrić,Perišić,Vlašić,Sosa,Juranović,Petković,Barišić,Erlić,Šutalo,Baturina,Ivanušec,Livaja,Majer,Moro,Pašalić,Brekalo,Halilović,Sučić,Ljubičić,Babić,Čolak,Dilaver,Franjić,Gvardiol,Horvat,Jakić,Kramarić,Lauritsen,Mišić,Nevistić,Oršić,Pjaca,Rebić,Stanišić,Tolić,Uremović,Vida",
            86),
        Nation("SWE", "Sweden", "\uD83C\uDDF8\uD83C\uDDEA",
            "Alexander,Viktor,Emil,Anton,Gustav,Jesper,Hugo,Oscar,Elias,Lucas,Isak,Filip,Måns,Nils,Axel,Melker,Sebastian,Dejan,Linus,Theo,Albin,Benjamin,Casper,Douglas,Edvin,Fredrik,Gabriel,Hampus,Ivar,Joel,Kalle,Ludvig,Marcus,Noel,Olle,Pontus,Rasmus,Simon,Tobias,Vilhelm",
            "Lindqvist,Bergström,Nordfeldt,Åkesson,Sandberg,Hjelm,Wahlström,Ekdal,Öberg,Falk,Svensson,Holmberg,Rydström,Almqvist,Lundgren,Dahlin,Selin,Norling,Vikström,Hult,Anderberg,Blomqvist,Cederholm,Dahlberg,Engström,Forsberg,Gunnarsson,Hedlund,Isaksson,Jonsson,Karlström,Lagerbäck,Malmberg,Nyström,Olofsson,Persson,Rosén,Ström,Thorsell,Wallin",
            82),
        Nation("BEL", "Belgium", "\uD83C\uDDE7\uD83C\uDDEA",
            "Jarne,Senne,Wout,Arthur,Lander,Vic,Milan,Stan,Ferre,Noah,Mathis,Rune,Jasper,Toon,Elias,Kobe,Seppe,Lucas,Warre,Basil,Cedric,Dries,Emile,Gilles,Hendrik,Ilias,Jonas,Korneel,Lowie,Maxim,Nand,Olivier,Pieter,Robbe,Siebe,Thibaud,Viktor,Wannes,Yorbe",
            "Vermeeren,Openda,Trossard,Doku,Onana,Vanaken,Debast,Theate,Faes,Lukebakio,Bakayoko,Vranckx,Casteels,Meunier,Sels,Deman,Balikwisha,Stroeykens,Vanhoutte,Claes,Dendoncker,Engels,Foket,Geraerts,Heynen,Ivanov,Janssens,Keersmaecker,Lammens,Mechele,Nielsen,Odoi,Praet,Raskin,Smets,Tielemans,Vertonghen,Wesley",
            89),
        Nation("NOR", "Norway", "\uD83C\uDDF3\uD83C\uDDF4",
            "Erling,Martin,Sander,Jørgen,Kristian,Håkon,Sondre,Emil,Ola,Tobias,Andreas,Bjørn,Casper,Daniel,Eivind,Fredrik,Gard,Henrik,Isak,Jonas,Kasper,Lars,Magnus,Nikolai,Odin,Petter,Ruben,Sindre,Torstein,Vetle",
            "Haaland,Ødegaard,Berge,Sørloth,Nusa,Ryerson,Strand,Bobb,Aursnes,Thorsby,Hanche-Olsen,Meling,Elyounoussi,Solbakken,Nyland,Østigård,Pedersen,Larsen,Johansen,Andersen,Bakken,Dahle,Engebretsen,Fossum,Gundersen,Haugen,Iversen,Jacobsen,Kristoffersen,Lundberg",
            81),

        /*
         * The rest of the sixty countries that have a league of their own.
         *
         * Nations are ordered so that the sixteen above keep their positions:
         * FOREIGN_CODES is walked in order to build the foreign divisions, and
         * a division id is what a save stores against every club. Appending
         * rather than inserting is what lets a save written before these were
         * added still point at the right league.
         */
        Nation("DEN", "Denmark", flagOf("DK"),
            "Anders,Mikkel,Jonas,Rasmus,Frederik,Kasper,Emil,Mads,Nikolaj,Oliver,Magnus,Tobias,Lasse,Victor,Jeppe,Sander",
            "Jensen,Nielsen,Hansen,Pedersen,Andersen,Christensen,Larsen,Sorensen,Rasmussen,Jorgensen,Madsen,Kristensen,Olsen,Thomsen", 78),
        Nation("CZE", "Czechia", flagOf("CZ"),
            "Tomas,Jakub,Ondrej,Vojtech,Lukas,Martin,Petr,Filip,Adam,David,Matej,Jan,Marek,Radek,Vaclav,Stepan",
            "Novak,Svoboda,Novotny,Dvorak,Cerny,Prochazka,Kucera,Vesely,Horak,Nemec,Marek,Pospisil,Hajek,Kral", 72),
        Nation("ROU", "Romania", flagOf("RO"),
            "Andrei,Ionut,Alexandru,Mihai,Vlad,Razvan,Cristian,Gabriel,Florin,Bogdan,Stefan,Dragos,Marius,Sergiu,Denis,Valentin",
            "Popescu,Ionescu,Popa,Radu,Dumitru,Stoica,Constantin,Marin,Barbu,Dinu,Munteanu,Nistor,Tudor,Vasile", 68),
        Nation("HUN", "Hungary", flagOf("HU"),
            "Adam,Balazs,Daniel,Gergo,Milos,Zsolt,Peter,Marton,Bence,Attila,Krisztian,Roland,Tamas,Norbert,Levente,Akos",
            "Nagy,Kovacs,Toth,Szabo,Horvath,Varga,Kiss,Molnar,Nemeth,Farkas,Balogh,Papp,Lakatos,Juhasz", 67),
        Nation("BUL", "Bulgaria", flagOf("BG"),
            "Georgi,Dimitar,Ivan,Nikolay,Petar,Stefan,Todor,Vasil,Kiril,Martin,Borislav,Aleksandar,Plamen,Radoslav,Zdravko,Emil",
            "Ivanov,Georgiev,Dimitrov,Petrov,Nikolov,Stoyanov,Todorov,Vasilev,Angelov,Kolev,Iliev,Marinov,Popov,Hristov", 62),
        Nation("SVK", "Slovakia", flagOf("SK"),
            "Marek,Juraj,Peter,Milan,Lukas,Tomas,Matus,Patrik,Jakub,Dominik,Adam,Michal,Samuel,Denis,Filip,Rastislav",
            "Horvath,Kovac,Varga,Toth,Nagy,Balaz,Molnar,Lukac,Hudak,Kral,Sedlak,Bezak,Simko,Duda", 64),
        Nation("SVN", "Slovenia", flagOf("SI"),
            "Jan,Miha,Luka,Nejc,Rok,Ziga,Matic,Blaz,Domen,Anze,Tim,Gasper,Aljaz,Nik,Vid,Jaka",
            "Novak,Horvat,Kovacic,Krajnc,Zupan,Potocnik,Kos,Vidmar,Golob,Bizjak,Rozman,Turk,Kralj,Oblak", 63),
        Nation("FIN", "Finland", flagOf("FI"),
            "Teemu,Joel,Eero,Onni,Ville,Mikael,Lauri,Rasmus,Niilo,Sakari,Jere,Aleksi,Otso,Veeti,Elias,Kasper",
            "Virtanen,Korhonen,Makinen,Nieminen,Heikkila,Laine,Koskinen,Salminen,Rantanen,Kallio,Lehtonen,Ojala,Pusa,Hakala", 61),
        Nation("ISL", "Iceland", flagOf("IS"),
            "Gylfi,Arnor,Birkir,Hordur,Jon,Kolbeinn,Runar,Sverrir,Thorir,Aron,Bjarni,Einar,Gunnar,Hafthor,Ingvar,Orri",
            "Sigurdsson,Gudmundsson,Jonsson,Magnusson,Bjarnason,Einarsson,Halldorsson,Palsson,Stefansson,Thorsteinsson,Arnason,Finnbogason,Hauksson,Ragnarsson", 55),
        Nation("WAL", "Wales", flagOf("GB"),
            "Gareth,Aaron,Rhys,Dylan,Owain,Iwan,Ieuan,Morgan,Emlyn,Cerrig,Bryn,Geraint,Huw,Llew,Tomos,Gethin",
            "Evans,Jones,Williams,Davies,Thomas,Hughes,Morgan,Griffiths,Lloyd,Rees,Bevan,Vaughan,Powell,Meredith", 65),
        Nation("CYP", "Cyprus", flagOf("CY"),
            "Andreas,Marios,Charalambos,Nikolas,Christos,Panayiotis,Loizos,Stelios,Kyriakos,Savvas,Demetris,Georgios,Antonis,Pavlos,Grigoris,Alexis",
            "Christodoulou,Georgiou,Papadopoulos,Ioannou,Nicolaou,Constantinou,Charalambous,Andreou,Savva,Kyriakou,Stylianou,Loizou,Panayiotou,Demetriou", 52),
        Nation("SRB", "Serbia", flagOf("RS"),
            "Nikola,Dusan,Filip,Aleksandar,Milos,Stefan,Luka,Uros,Nemanja,Marko,Vladimir,Andrija,Bogdan,Sasa,Petar,Ognjen",
            "Jovanovic,Petrovic,Nikolic,Markovic,Stojanovic,Ilic,Pavlovic,Milosevic,Djordjevic,Ristic,Savic,Todorovic,Lukic,Milic", 70),
        Nation("RUS", "Russia", flagOf("RU"),
            "Aleksandr,Fyodor,Matvei,Anton,Daniil,Ivan,Maksim,Aleksei,Georgi,Arsen,Dmitri,Vladislav,Kirill,Roman,Yegor,Nikita",
            "Ivanov,Smirnov,Kuznetsov,Popov,Sokolov,Lebedev,Novikov,Morozov,Volkov,Zaitsev,Pavlov,Semyonov,Golubev,Vinogradov", 68),
        Nation("GRE", "Greece", flagOf("GR"),
            "Giorgos,Kostas,Dimitris,Anastasios,Petros,Vangelis,Manolis,Stefanos,Andreas,Christos,Nikos,Thanasis,Ilias,Yannis,Sotiris,Lefteris",
            "Papadopoulos,Nikolaidis,Georgiou,Vlachos,Karagiannis,Antoniou,Makris,Papas,Samaras,Dimitriou,Athanasiou,Panagiotou,Sideris,Zafeiris", 66),
        Nation("UKR", "Ukraine", flagOf("UA"),
            "Andriy,Oleksandr,Mykola,Ruslan,Vitaliy,Taras,Bohdan,Illia,Georgiy,Artem,Serhiy,Roman,Yaroslav,Denys,Maksym,Vadym",
            "Shevchenko,Kovalenko,Bondarenko,Tkachenko,Kravchenko,Oliynyk,Melnyk,Shevchuk,Koval,Polishchuk,Boyko,Marchenko,Rudenko,Savchenko", 69),
        Nation("POL", "Poland", flagOf("PL"),
            "Bartosz,Kamil,Piotr,Jakub,Mateusz,Rafal,Szymon,Tomasz,Wojciech,Lukasz,Michal,Krystian,Dawid,Adrian,Pawel,Grzegorz",
            "Nowak,Kowalski,Wisniewski,Wojcik,Kowalczyk,Kaminski,Lewandowski,Zielinski,Szymanski,Wozniak,Dabrowski,Mazur,Krawczyk,Kaczmarek", 72),
        Nation("TUR", "Turkey", flagOf("TR"),
            "Emre,Burak,Hakan,Cengiz,Yusuf,Ozan,Kerem,Merih,Caglar,Okay,Zeki,Serdar,Umut,Baris,Kaan,Efe",
            "Yilmaz,Demir,Kaya,Sahin,Celik,Yildiz,Aydin,Ozturk,Arslan,Dogan,Kilic,Aslan,Cetin,Korkmaz", 76),
        Nation("SCO", "Scotland", flagOf("GB"),
            "Andrew,Scott,Callum,Kieran,Billy,John,Ryan,Stuart,Grant,Che,Lyndon,Aaron,Fraser,Angus,Euan,Ruaridh",
            "Robertson,Macleod,Cameron,Fraser,Murray,Gallacher,Ferguson,Mackay,Sinclair,Buchanan,Muir,Kerr,Rennie,Strachan", 70),
        Nation("SUI", "Switzerland", flagOf("CH"),
            "Granit,Remo,Fabian,Silvan,Noah,Ruben,Renato,Michel,Yann,Loris,Dan,Ulisses,Cedric,Nico,Andrin,Joel",
            "Muller,Meier,Schmid,Keller,Weber,Huber,Steiner,Brunner,Baumann,Frei,Widmer,Zuber,Gerber,Studer", 79),
        Nation("AUT", "Austria", flagOf("AT"),
            "David,Marcel,Konrad,Xaver,Stefan,Florian,Christoph,Michael,Patrick,Maximilian,Nicolas,Andreas,Lukas,Fabian,Manuel,Raphael",
            "Gruber,Huber,Bauer,Wagner,Steiner,Moser,Mayer,Hofer,Leitner,Berger,Fuchs,Eder,Reiter,Winkler", 77),
        Nation("IRL", "Ireland", flagOf("IE"),
            "Evan,Nathan,Josh,Chiedozie,Adam,Seamus,Shane,Jason,Dara,Jayson,Matt,Callum,Cillian,Ruairi,Eoin,Padraig",
            "Murphy,Kelly,OSullivan,Walsh,Byrne,Ryan,OConnor,Doyle,McCarthy,Gallagher,Duffy,Brennan,Fitzgerald,Nolan", 64),
        Nation("MEX", "Mexico", flagOf("MX"),
            "Hirving,Raul,Edson,Cesar,Jesus,Luis,Orbelin,Uriel,Erick,Santiago,Alexis,Roberto,Diego,Carlos,Ivan,Julian",
            "Hernandez,Garcia,Martinez,Lopez,Gonzalez,Rodriguez,Perez,Sanchez,Ramirez,Torres,Flores,Rivera,Gomez,Vazquez", 73),
        Nation("USA", "United States", flagOf("US"),
            "Christian,Weston,Tyler,Brenden,Sergino,Antonee,Yunus,Gio,Ricardo,Malik,Folarin,Joe,Cameron,Tanner,Bryce,Dante",
            "Miller,Johnson,Anderson,Thompson,Harper,Wagner,Sullivan,Brooks,Reyes,Carpenter,Whitfield,Barlowe,Stanton,Cortez", 68),
        Nation("CRC", "Costa Rica", flagOf("CR"),
            "Keylor,Bryan,Celso,Joel,Francisco,Yeltsin,Orlando,Manfred,Jewison,Anthony,Alonso,Randall,Kendall,Douglas,Ariel,Marvin",
            "Rojas,Vargas,Solano,Campbell,Calvo,Aguilera,Chacon,Villalobos,Bolanos,Mora,Zamora,Quesada,Ugalde,Brenes", 57),
        Nation("CAN", "Canada", flagOf("CA"),
            "Alphonso,Jonathan,Stephen,Cyle,Atiba,Tajon,Ismael,Liam,Richie,Kamal,Derek,Samuel,Lucas,Mathieu,Dayne,Jacob",
            "Larin,Cavallini,Hutchinson,Buchanan,Kennedy,Laryea,Adekugbe,Fraser,Millar,Piette,Corbeil,Waterman,Bair,Johnston", 63),
        Nation("JAM", "Jamaica", flagOf("JM"),
            "Leon,Michail,Damion,Andre,Bobby,Ravel,Shamar,Demarai,Dujuan,Kasey,Amari,Norman,Devon,Tyreek,Jamal,Ricardo",
            "Bailey,Campbell,Reid,Brown,Clarke,Williams,Morrison,Thompson,Wilson,Grant,Chambers,Blake,Lawrence,Beckford", 56),
        Nation("COL", "Colombia", flagOf("CO"),
            "Juan,Luis,Camilo,Rafael,Yerry,Davinson,Wilmar,Mateus,Jhon,Santiago,Kevin,Andres,Daniel,Sebastian,Nelson,Oscar",
            "Rodriguez,Gomez,Martinez,Cardenas,Restrepo,Ospina,Zapata,Quintero,Moreno,Arboleda,Mosquera,Valencia,Cuesta,Palacios", 76),
        Nation("CHI", "Chile", flagOf("CL"),
            "Arturo,Claudio,Ben,Charles,Gabriel,Diego,Erick,Marcelino,Guillermo,Alexis,Paulo,Victor,Ignacio,Felipe,Matias,Cristian",
            "Munoz,Rojas,Diaz,Contreras,Silva,Sepulveda,Fuentes,Espinoza,Tapia,Reyes,Castillo,Cortes,Nunez,Bravo", 70),
        Nation("URU", "Uruguay", flagOf("UY"),
            "Federico,Rodrigo,Nicolas,Matias,Sebastian,Facundo,Manuel,Diego,Maxi,Agustin,Santiago,Ronald,Bruno,Emiliano,Ignacio,Gaston",
            "Rodriguez,Fernandez,Silva,Perez,Sosa,Gonzalez,Martinez,Suarez,Pereira,Castro,Olivera,Cabrera,Ramos,Correa", 78),
        Nation("PER", "Peru", flagOf("PE"),
            "Paolo,Renato,Andre,Christian,Edison,Yoshimar,Luis,Alexander,Marcos,Gianluca,Piero,Wilder,Miguel,Aldo,Anderson,Bryan",
            "Flores,Quispe,Rojas,Castillo,Aguirre,Zambrano,Corzo,Advincula,Trauco,Lapadula,Yotun,Callens,Carrillo,Peña", 64),
        Nation("ECU", "Ecuador", flagOf("EC"),
            "Moises,Piero,Enner,Pervis,Jeremy,Angelo,Gonzalo,Felix,Alan,Diego,Djorkaeff,Robert,Byron,Xavier,Jhegson,Kendry",
            "Caicedo,Hincapie,Estupinan,Plata,Preciado,Palacios,Mena,Torres,Franco,Arboleda,Reasco,Sarmiento,Valencia,Quintero", 68),
        Nation("PAR", "Paraguay", flagOf("PY"),
            "Miguel,Gustavo,Angel,Juan,Robert,Julio,Braian,Mathias,Alberto,Omar,Ramon,Hernesto,Fabian,Andres,Diego,Adam",
            "Gonzalez,Benitez,Ramirez,Ortiz,Cabrera,Villalba,Rojas,Escobar,Almiron,Sanabria,Balbuena,Espinola,Duarte,Cardozo", 65),
        Nation("EGY", "Egypt", flagOf("EG"),
            "Mohamed,Omar,Ahmed,Mostafa,Karim,Ramadan,Emam,Mahmoud,Akram,Hamdi,Ibrahim,Yasser,Tarek,Sherif,Amr,Hossam",
            "Hassan,Ibrahim,Abdelrahman,Elsayed,Fathy,Salah,Gaber,Shawky,Nasr,Zaki,Sobhy,Kamal,Rashad,Mansour", 68),
        Nation("ALG", "Algeria", flagOf("DZ"),
            "Riyad,Ismael,Said,Youcef,Ramy,Aissa,Adam,Amine,Nabil,Sofiane,Houssem,Farid,Islam,Mehdi,Zinedine,Adlene",
            "Benali,Boudjemaa,Hamidi,Meziane,Bouzid,Cherif,Zerrouki,Belkacem,Slimani,Kaci,Larbi,Mokrani,Ferhat,Ouali", 70),
        Nation("TUN", "Tunisia", flagOf("TN"),
            "Youssef,Hannibal,Ellyes,Wahbi,Aissa,Mohamed,Ali,Montassar,Anis,Seifeddine,Elias,Naim,Firas,Oussama,Bilel,Chaim",
            "Ben Ali,Trabelsi,Jebali,Chaouachi,Mejri,Gharbi,Hamdi,Bouazizi,Sassi,Khelifi,Rekik,Zouaoui,Aouadi,Belhadj", 66),
        Nation("NGA", "Nigeria", flagOf("NG"),
            "Victor,Wilfred,Alex,Kelechi,Samuel,Ademola,Calvin,Frank,Joe,Moses,Bright,Terem,Chidera,Emeka,Ifeanyi,Sadiq",
            "Okafor,Adeyemi,Eze,Nwachukwu,Balogun,Obi,Okonkwo,Adebayo,Nwosu,Chukwu,Uche,Olawale,Ibrahim,Aigbogun", 75),
        Nation("GHA", "Ghana", flagOf("GH"),
            "Thomas,Mohammed,Jordan,Andre,Kamaldeen,Antoine,Elisha,Alidu,Osman,Baba,Daniel,Ernest,Kwame,Kofi,Yaw,Emmanuel",
            "Mensah,Owusu,Asante,Boateng,Appiah,Agyemang,Adjei,Frimpong,Osei,Kwarteng,Amoah,Gyamfi,Danso,Nyarko", 71),
        Nation("CIV", "Ivory Coast", flagOf("CI"),
            "Franck,Sebastien,Ibrahim,Nicolas,Serge,Wilfried,Jean,Evan,Odilon,Christian,Simon,Amad,Yves,Ousmane,Aboubacar,Karim",
            "Kone,Toure,Coulibaly,Bamba,Diomande,Yao,Kouassi,Traore,Doumbia,Ouattara,Cisse,Gnahore,Sylla,Diarra", 73),
        Nation("RSA", "South Africa", flagOf("ZA"),
            "Percy,Themba,Teboho,Ronwen,Siyanda,Bongokuhle,Lyle,Thapelo,Sipho,Katlego,Mothobi,Evidence,Lebo,Nkosinathi,Zakhele,Rowan",
            "Zwane,Mokoena,Dlamini,Ngcobo,Mahlangu,Radebe,Nkosi,Mabaso,Sithole,Khumalo,Molefe,Tau,Mbatha,Ndlovu", 60),
        Nation("KOR", "South Korea", flagOf("KR"),
            "Heungmin,Minjae,Kangin,Jaesung,Woosang,Youngjun,Uijo,Seungho,Hyunwoo,Taeyong,Jinsu,Sungho,Chanhee,Doyoung,Hyeonjun,Jaehyun",
            "Kim,Lee,Park,Choi,Jung,Kang,Cho,Yoon,Jang,Lim,Han,Oh,Seo,Shin", 70),
        Nation("CHN", "China", flagOf("CN"),
            "Wu,Zhang,Wei,Hao,Jun,Lei,Feng,Yang,Chen,Kai,Peng,Long,Ming,Bo,Tao,Xin",
            "Wang,Li,Zhang,Liu,Chen,Yang,Huang,Zhao,Wu,Zhou,Xu,Sun,Ma,Zhu", 52),
        Nation("KSA", "Saudi Arabia", flagOf("SA"),
            "Salem,Salman,Firas,Abdullah,Saud,Nasser,Hassan,Mohammed,Ali,Fahad,Sultan,Khalid,Yasser,Turki,Majed,Abdulelah",
            "Al Dawsari,Al Shehri,Al Buraikan,Al Malki,Al Ghamdi,Al Harbi,Al Qahtani,Al Otaibi,Al Zahrani,Al Shahrani,Al Faraj,Al Amri,Al Sahafi,Al Najei", 58),
        Nation("QAT", "Qatar", flagOf("QA"),
            "Akram,Almoez,Hassan,Abdelkarim,Karim,Homam,Bassam,Mostafa,Musab,Ahmed,Ismail,Yusuf,Tarek,Jassem,Mohammed,Osama",
            "Al Rawi,Hassan,Al Haydos,Al Hajri,Boudiaf,Ahmed,Khoukhi,Miftah,Meshaal,Al Brake,Waad,Salman,Muntari,Ali", 55),
        Nation("AUS", "Australia", flagOf("AU"),
            "Harry,Jackson,Aiden,Riley,Mathew,Craig,Jordan,Connor,Cameron,Keanu,Ajdin,Nathaniel,Lachlan,Marco,Denis,Kusini",
            "Souttar,Irvine,ONeill,McGree,Ryan,Goodwin,Metcalfe,Burgess,Baccus,Hrustic,Atkinson,Boyle,Duke,Behich", 62)
    )

    private val used = HashSet<String>(8192)
    private val INITIALS = "ABCDEFGHIJKLMNOPRSTUVW"

    /** Total base combinations available across every nation. */
    val capacity: Int get() = NATIONS.sumOf { it.combos }

    fun reset() = used.clear()
    fun register(full: String) { used.add(full) }
    val issued: Int get() = used.size

    /**
     * Issues a name that has never been used in this save. Four escalating
     * tiers mean the pool is effectively bottomless.
     */
    fun make(rng: Rng, nation: Nation): PlayerName {
        // Tier 1 — plain first + last
        for (t in 0 until 14) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val full = "$f $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 2 — middle initial
        for (t in 0 until 14) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val m = INITIALS[rng.i(0, INITIALS.length - 1)]
            val full = "$f $m. $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 3 — double-barrelled surname
        for (t in 0 until 20) {
            val f = rng.pick(nation.first)
            val l = rng.pick(nation.last) + "-" + rng.pick(nation.last)
            val full = "$f $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 4 — never expected to be reached
        var n = 2
        while (true) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val full = "$f $l ${roman(n)}"
            if (used.add(full)) return PlayerName(f, "$l ${roman(n)}", full)
            n++
        }
    }

    private fun roman(n: Int): String = when (n) {
        2 -> "II"; 3 -> "III"; 4 -> "IV"; 5 -> "V"; 6 -> "VI"; 7 -> "VII"
        else -> n.toString()
    }

    fun byCode(code: String): Nation =
        NATIONS.firstOrNull { it.code == code }
            ?: EXTRA_NATIONS.firstOrNull { it.code == code }
            ?: NATIONS[0]

    /** Every nation a player may come from: those with leagues and those without. */
    val ALL_NATIONS: List<Nation> by lazy { NATIONS + EXTRA_NATIONS }
}

class PlayerName(val first: String, val last: String, val full: String)
