package com.dugout.career.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.content.Context
import android.view.View
import com.dugout.career.core.Player
import com.dugout.career.core.Rng

/**
 * A face for every footballer in the game, drawn rather than stored.
 *
 * Twelve thousand portraits would be a large download and a licensing problem;
 * generating them costs a few hundred lines and nothing on disk. Each face is
 * derived from the player's id, so it never changes for the life of a save, and
 * from his nation and age, so a thirty four year old Swede does not look like an
 * eighteen year old Brazilian.
 *
 * Everything is Canvas primitives. No assets, no bitmaps, no fonts.
 */

/* ----------------------------------------------------------------- PALETTES */

private val SKIN = intArrayOf(
    0xFFF6D5BC.toInt(), 0xFFF0C39C.toInt(), 0xFFE0AC80.toInt(), 0xFFD9A377.toInt(),
    0xFFC08A5A.toInt(), 0xFFB9793F.toInt(), 0xFF8A5426.toInt(), 0xFF6B401C.toInt(),
    0xFF4E2E13.toInt()
)

private val HAIR = intArrayOf(
    0xFF1A1512.toInt(),   // black
    0xFF2E2018.toInt(),   // near black
    0xFF4A3122.toInt(),   // dark brown
    0xFF6B4426.toInt(),   // brown
    0xFF8C6239.toInt(),   // light brown
    0xFFC79A4B.toInt(),   // dark blond
    0xFFE3C179.toInt(),   // blond
    0xFFB2542A.toInt(),   // ginger
    0xFFEFEFE8.toInt(),   // bleached
    0xFF9E9E9C.toInt()    // grey
)

private const val GREY = 9
private const val BLEACH = 8

/**
 * Roughly where a nation's players sit in the skin palette. A range rather than
 * a value: squads are mixed everywhere, and this only shifts the odds.
 */
private fun skinRange(nation: String): IntRange = when (nation) {
    "SWE", "NOR", "DEN", "NED", "GER", "POL", "IRL", "SCO" -> 0..4
    "ENG", "FRA", "BEL", "CRO", "ITA", "POR", "ESP", "ARG" -> 0..6
    "BRA" -> 1..8
    "MAR", "SEN", "NGA", "GHA", "CIV" -> 4..8
    "JPN", "KOR" -> 0..3
    else -> 0..6
}

/* -------------------------------------------------------------- THE FEATURES */

class Face(
    val skin: Int,
    val hair: Int,
    val style: Int,        // 0..11
    val brow: Int,         // 0..3
    val eye: Int,          // 0..4
    val nose: Int,         // 0..4
    val mouth: Int,        // 0..3
    val beard: Int,        // 0..5
    val jaw: Int,          // 0..5  face shape
    val ears: Int          // 0..1
) {
    companion object {
        const val STYLES = 12
        const val BEARDS = 6
        const val JAWS = 6

        /*
         * No two faces in a save may repeat, and none may be a minor variation
         * of another.
         *
         * Hashing features independently is not enough. It left four exact
         * duplicates across twelve thousand players, and far worse, sixty five
         * pairs differing in a single feature — two men identical but for their
         * haircut, which reads as the same face.
         *
         * Linear check digits do not fix it either. Weighted sums taken mod 4
         * are blind to a difference that is a multiple of 4: a hair style of 0
         * against 4 moved every check by a multiple of the modulus and so moved
         * none of them. That is what produced the closest pair.
         *
         * So faces are assigned once, in id order, from a deterministic stream
         * of candidates per player, taking the first that is at least
         * MIN_APART features away from every face already given out. Same seed,
         * same world, same faces, and the ordering does not depend on when a
         * card happens to be opened.
         */
        private const val N_JAW = 6
        private const val N_SKIN = 9
        private const val N_STYLE = 12
        private const val N_HAIR = 8      // grey and bleach are earned, not rolled
        private const val N_EYE = 5
        private const val N_NOSE = 5
        private const val N_BEARD = 6
        private const val N_BROW = 4
        private const val N_MOUTH = 4
        private const val N_EARS = 2

        /** How many of the ten features any two faces must differ in. */
        const val MIN_APART = 3

        private val assigned = HashMap<Int, Face>(16384)

        /**
         * Faces already handed out, each packed into one long: ten features of
         * four bits. Comparing packed values is bit work rather than walking an
         * array, which took the assignment for a full world from 900 ms to
         * something that does not show next to world generation.
         */
        private var taken = LongArray(16384)
        private var takenN = 0

        private fun pack(v: IntArray): Long {
            var k = 0L
            for (i in 0 until 10) k = k or ((v[i].toLong() and 0xF) shl (i * 4))
            return k
        }

        /**
         * How many of the ten nibbles differ, stopping once it reaches [cap].
         * The XOR marks every differing nibble; folding each nibble's bits down
         * to its lowest bit turns the count into a popcount.
         */
        private fun apart(a: Long, b: Long): Int {
            var x = a xor b
            // collapse each nibble to 1 if any of its bits are set
            x = x or (x ushr 1)
            x = x or (x ushr 2)
            x = x and 0x1111111111L
            return java.lang.Long.bitCount(x)
        }

        /** Cleared when a new world is generated. */
        fun reset() {
            assigned.clear()
            takenN = 0
        }

        private fun tooClose(packed: Long): Boolean {
            for (i in 0 until takenN) {
                if (apart(taken[i], packed) < MIN_APART) return true
            }
            return false
        }

        /**
         * The face for a player. Deterministic, unique, and never within
         * [MIN_APART] features of anybody else's.
         */
        fun of(p: Player): Face {
            assigned[p.id]?.let { return it }

            val r = Rng(p.id * 2654435761L + 17)
            val range = skinRange(p.nation)

            var chosen: IntArray? = null
            // A generous number of attempts. In practice the first or second
            // candidate is accepted; the loop is here so the guarantee holds
            // rather than degrading quietly if the space ever gets crowded.
            for (attempt in 0 until 4000) {
                val jaw = r.i(0, N_JAW - 1)
                var skin = r.i(range.first, range.last)
                var style = r.i(0, N_STYLE - 1)
                var hair = r.i(0, N_HAIR - 1)
                val eye = r.i(0, N_EYE - 1)
                val nose = r.i(0, N_NOSE - 1)
                var beard = r.i(0, N_BEARD - 1)
                val brow = r.i(0, N_BROW - 1)
                val mouth = r.i(0, N_MOUTH - 1)
                val ears = r.i(0, N_EARS - 1)

                // the years show, applied before the spacing test so what is
                // checked is the face actually drawn
                if (p.age >= 30 && r.chance(0.34 + (p.age - 30) * 0.05)) hair = GREY
                else if (p.age <= 29 && r.chance(0.05)) hair = BLEACH
                if (p.age >= 29 && r.chance(0.26)) style = if (r.chance(0.4)) 8 else 7
                // A shaven head sits in the free feature space, so it could be
                // rolled at any age: sixty six twenty one year olds came out
                // with one. Plenty of young players do shave, but not that many,
                // so below twenty three it becomes a crop instead.
                if (p.age <= 22 && style == 8) style = 0
                if (p.age <= 19 && beard >= 2) beard = if (r.chance(0.7)) 0 else 1

                val v = intArrayOf(jaw, skin, style, hair, eye, nose, beard, brow, mouth, ears)
                if (!tooClose(pack(v))) { chosen = v; break }
            }
            // If the space were ever exhausted, take the last candidate rather
            // than fail: a repeat is better than no face at all.
            val v = chosen ?: intArrayOf(
                r.i(0, N_JAW - 1), r.i(range.first, range.last), r.i(0, N_STYLE - 1),
                r.i(0, N_HAIR - 1), r.i(0, N_EYE - 1), r.i(0, N_NOSE - 1),
                r.i(0, N_BEARD - 1), r.i(0, N_BROW - 1), r.i(0, N_MOUTH - 1), r.i(0, N_EARS - 1)
            )

            val face = Face(
                skin = v[1], hair = v[3], style = v[2], brow = v[7], eye = v[4],
                nose = v[5], mouth = v[8], beard = v[6], jaw = v[0], ears = v[9]
            )
            if (takenN == taken.size) taken = taken.copyOf(taken.size * 2)
            taken[takenN++] = pack(v)
            assigned[p.id] = face
            return face
        }

        /**
         * Hands out faces for a whole world in id order, so the assignment does
         * not depend on which cards the manager happens to open. Call once after
         * the world is built or loaded.
         */
        fun assignAll(players: Collection<Player>) {
            reset()
            for (p in players.sortedBy { it.id }) of(p)
        }

        /** The ten features as a vector, for measuring how far apart two faces are. */
        fun vector(f: Face): IntArray = intArrayOf(
            f.jaw, f.skin, f.style, f.hair, f.eye, f.nose, f.beard,
            f.brow, f.mouth, f.ears
        )
    }

    val skinColour: Int get() = SKIN[skin]
    val hairColour: Int get() = HAIR[hair]
    val isBald: Boolean get() = style == 8
}

/* ---------------------------------------------------------------- DRAWING */

private fun mix(a: Int, b: Int, t: Float): Int {
    fun ch(sh: Int): Int {
        val x = (a shr sh) and 0xFF
        val y = (b shr sh) and 0xFF
        return (x + (y - x) * t).toInt().coerceIn(0, 255)
    }
    return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

private fun darken(c: Int, k: Float) = mix(c, 0xFF000000.toInt(), k)
private fun lighten(c: Int, k: Float) = mix(c, 0xFFFFFFFF.toInt(), k)

/**
 * Draws a head and shoulders portrait centred on [cx], with [size] the width of
 * the whole card area. Everything below is proportional to that, so the same
 * call works for a 24 dp list thumbnail and a 160 dp profile.
 */
fun drawFace(c: Canvas, cx: Float, cy: Float, size: Float, f: Face) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val r = RectF()
    val path = Path()
    val u = size / 100f                      // one unit of the design grid

    val skin = f.skinColour
    val shadow = darken(skin, 0.16f)
    val hair = f.hairColour

    // ---- shoulders and neck, so the head is not floating ----
    p.color = darken(skin, 0.26f)
    r.set(cx - u * 13f, cy + u * 22f, cx + u * 13f, cy + u * 46f)
    c.drawRoundRect(r, u * 6f, u * 6f, p)

    // ---- ears, behind the face ----
    val earR = if (f.ears == 1) u * 7.5f else u * 6f
    p.color = shadow
    c.drawCircle(cx - u * 30f, cy + u * 2f, earR, p)
    c.drawCircle(cx + u * 30f, cy + u * 2f, earR, p)

    // ---- the head. Jaw shape is what makes two faces read as different men ----
    val headW = when (f.jaw) {
        0 -> 29f; 1 -> 31f; 2 -> 33f; 3 -> 28f; 4 -> 30f; else -> 32f
    }
    val headH = when (f.jaw) {
        0 -> 37f; 1 -> 35f; 2 -> 34f; 3 -> 39f; 4 -> 36f; else -> 33f
    }
    val chin = when (f.jaw) {
        0 -> 0.55f    // oval
        1 -> 0.85f    // round
        2 -> 0.28f    // square
        3 -> 0.42f    // long
        4 -> 0.34f    // heart, narrow chin
        else -> 0.70f // diamond
    }
    p.color = skin
    path.reset()
    path.moveTo(cx - u * headW, cy - u * headH * 0.35f)
    path.quadTo(cx - u * headW, cy - u * headH, cx, cy - u * headH)
    path.quadTo(cx + u * headW, cy - u * headH, cx + u * headW, cy - u * headH * 0.35f)
    path.quadTo(
        cx + u * headW * (0.55f + chin * 0.45f), cy + u * headH * 0.72f,
        cx, cy + u * headH * (0.80f + chin * 0.18f)
    )
    path.quadTo(
        cx - u * headW * (0.55f + chin * 0.45f), cy + u * headH * 0.72f,
        cx - u * headW, cy - u * headH * 0.35f
    )
    path.close()
    c.drawPath(path, p)

    // a little modelling: shade the left, catch light on the right cheek
    val sv = c.save()
    c.clipPath(path)
    p.color = darken(skin, 0.10f)
    c.drawRect(cx - u * headW, cy - u * headH, cx - u * headW * 0.30f, cy + u * headH, p)
    p.color = lighten(skin, 0.10f)
    c.drawCircle(cx + u * 13f, cy + u * 4f, u * 10f, p)
    c.restoreToCount(sv)

    // ---- brows ----
    val browY = cy - u * 9f
    val browT = when (f.brow) { 0 -> 2.2f; 1 -> 3.0f; 2 -> 4.2f; else -> 1.6f }
    val browTilt = when (f.brow) { 0 -> 0f; 1 -> -1.8f; 2 -> 1.2f; else -> -0.8f }
    p.color = darken(hair, if (f.hair == GREY || f.hair == BLEACH) 0f else 0.18f)
    for (s in intArrayOf(-1, 1)) {
        r.set(
            cx + s * u * 6f - u * 9f * (if (s < 0) 1f else 0f) + (if (s > 0) 0f else 0f),
            browY - u * browT + s * u * browTilt,
            cx + s * u * 6f + u * 9f * (if (s > 0) 1f else 0f) + (if (s < 0) 0f else 0f),
            browY + u * browT - s * u * browTilt
        )
        // simpler: a rounded bar either side of centre
        r.set(cx + s * u * 15.5f - u * 9f, browY - u * browT, cx + s * u * 15.5f + u * 9f, browY + u * browT)
        c.drawRoundRect(r, u * browT, u * browT, p)
    }

    // ---- eyes ----
    val eyeY = cy - u * 2f
    val eyeW = when (f.eye) { 0 -> 7.0f; 1 -> 8.2f; 2 -> 6.2f; 3 -> 7.6f; else -> 6.8f }
    val eyeH = when (f.eye) { 0 -> 4.4f; 1 -> 3.4f; 2 -> 5.2f; 3 -> 4.0f; else -> 4.8f }
    for (s in intArrayOf(-1, 1)) {
        val ex = cx + s * u * 15.5f
        p.color = 0xFFF8F4EE.toInt()
        r.set(ex - u * eyeW, eyeY - u * eyeH, ex + u * eyeW, eyeY + u * eyeH)
        c.drawOval(r, p)
        p.color = 0xFF3A2A1E.toInt()
        c.drawCircle(ex + s * u * 0.6f, eyeY + u * 0.3f, u * eyeH * 0.62f, p)
        p.color = 0xFF120C08.toInt()
        c.drawCircle(ex + s * u * 0.6f, eyeY + u * 0.3f, u * eyeH * 0.30f, p)
        p.color = 0x99FFFFFF.toInt()
        c.drawCircle(ex + s * u * 0.6f - u * 1.2f, eyeY - u * 1.2f, u * 0.9f, p)
        // lid line
        p.color = shadow
        r.set(ex - u * eyeW, eyeY - u * eyeH * 1.05f, ex + u * eyeW, eyeY - u * eyeH * 0.55f)
        c.drawOval(r, p)
    }

    // ---- nose ----
    val noseL = when (f.nose) { 0 -> 10f; 1 -> 13f; 2 -> 8f; 3 -> 11f; else -> 12f }
    val noseW = when (f.nose) { 0 -> 5.0f; 1 -> 6.4f; 2 -> 4.4f; 3 -> 7.0f; else -> 5.6f }
    p.color = shadow
    path.reset()
    path.moveTo(cx - u * 1.4f, cy - u * 4f)
    path.lineTo(cx - u * noseW, cy + u * noseL)
    path.quadTo(cx, cy + u * (noseL + 2.4f), cx + u * noseW, cy + u * noseL)
    path.lineTo(cx + u * 1.4f, cy - u * 4f)
    path.close()
    c.drawPath(path, p)
    p.color = darken(skin, 0.30f)
    c.drawCircle(cx - u * noseW * 0.55f, cy + u * noseL * 0.92f, u * 1.2f, p)
    c.drawCircle(cx + u * noseW * 0.55f, cy + u * noseL * 0.92f, u * 1.2f, p)

    // ---- mouth ----
    val mouthY = cy + u * 20f
    val mw = when (f.mouth) { 0 -> 11f; 1 -> 13.5f; 2 -> 9.5f; else -> 12f }
    val ml = when (f.mouth) { 0 -> 2.6f; 1 -> 2.0f; 2 -> 3.4f; else -> 2.2f }
    p.color = mix(skin, 0xFF8E4A46.toInt(), 0.55f)
    r.set(cx - u * mw, mouthY - u * ml, cx + u * mw, mouthY + u * ml)
    c.drawRoundRect(r, u * ml, u * ml, p)
    p.color = darken(skin, 0.34f)
    c.drawRect(cx - u * mw * 0.9f, mouthY - u * 0.3f, cx + u * mw * 0.9f, mouthY + u * 0.3f, p)

    // ---- facial hair, over the skin and under the hair ----
    if (f.beard != 0) {
        val bc = if (f.hair == BLEACH) HAIR[2] else darken(hair, 0.08f)
        p.color = bc
        val sv2 = c.save()
        c.clipPath(path)
        when (f.beard) {
            1 -> {   // stubble across the jaw
                p.color = mix(skin, bc, 0.42f)
                c.drawRect(cx - u * headW, mouthY - u * 6f, cx + u * headW, cy + u * headH, p)
            }
            2 -> {   // moustache only
                r.set(cx - u * mw * 0.95f, mouthY - u * 7f, cx + u * mw * 0.95f, mouthY - u * 2.2f)
                c.drawRoundRect(r, u * 2.2f, u * 2.2f, p)
            }
            3 -> {   // goatee
                r.set(cx - u * mw * 0.95f, mouthY - u * 7f, cx + u * mw * 0.95f, mouthY - u * 2.4f)
                c.drawRoundRect(r, u * 2.2f, u * 2.2f, p)
                r.set(cx - u * 7f, mouthY + u * 3f, cx + u * 7f, cy + u * headH * 0.92f)
                c.drawRoundRect(r, u * 5f, u * 5f, p)
            }
            4 -> {   // full beard
                c.drawRect(cx - u * headW, mouthY - u * 8f, cx + u * headW, cy + u * headH, p)
                p.color = skin
                r.set(cx - u * mw * 0.8f, mouthY - u * ml * 1.3f, cx + u * mw * 0.8f, mouthY + u * ml * 1.6f)
                c.drawRoundRect(r, u * ml, u * ml, p)
                p.color = mix(skin, 0xFF8E4A46.toInt(), 0.55f)
                r.set(cx - u * mw, mouthY - u * ml, cx + u * mw, mouthY + u * ml)
                c.drawRoundRect(r, u * ml, u * ml, p)
            }
            else -> { // chinstrap
                p.color = bc
                c.drawRect(cx - u * headW, cy + u * headH * 0.52f, cx + u * headW, cy + u * headH, p)
                r.set(cx - u * mw * 0.95f, mouthY - u * 7f, cx + u * mw * 0.95f, mouthY - u * 2.4f)
                c.drawRoundRect(r, u * 2.2f, u * 2.2f, p)
            }
        }
        c.restoreToCount(sv2)
    }

    // ---- hair, last so it sits over the forehead ----
    drawHair(c, cx, cy, u, headW, headH, f, hair)
}

/** Twelve cuts. Each is drawn against the skull, so they all sit correctly. */
private fun drawHair(
    c: Canvas, cx: Float, cy: Float, u: Float,
    headW: Float, headH: Float, f: Face, hair: Int
) {
    if (f.isBald) {
        // a shaved head still has a shadow where the hair would be
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = mix(f.skinColour, hair, 0.16f)
        val r = RectF(cx - u * headW, cy - u * headH, cx + u * headW, cy - u * headH * 0.18f)
        c.drawOval(r, p)
        return
    }

    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val r = RectF()
    val path = Path()
    p.color = hair

    // the cap every cut is built on
    fun cap(front: Float, extra: Float = 0f) {
        r.set(
            cx - u * (headW + extra), cy - u * (headH + extra * 0.6f),
            cx + u * (headW + extra), cy + u * headH * 0.30f
        )
        val sv = c.save()
        path.reset()
        path.addOval(r, Path.Direction.CW)
        c.clipPath(path)
        c.drawRect(
            cx - u * (headW + extra), cy - u * (headH + extra),
            cx + u * (headW + extra), cy - u * headH * front, p
        )
        c.restoreToCount(sv)
    }

    when (f.style) {
        0 -> cap(0.30f)                                   // short crop
        1 -> {                                            // side parting
            cap(0.34f)
            p.color = darken(hair, 0.28f)
            c.drawRect(cx + u * 4f, cy - u * headH, cx + u * 7f, cy - u * headH * 0.40f, p)
        }
        2 -> {                                            // buzz
            p.color = mix(f.skinColour, hair, 0.62f)
            cap(0.46f)
        }
        3 -> {                                            // curls
            cap(0.28f, 1.5f)
            for (i in 0 until 9) {
                val a = 3.4f + i * 0.38f
                c.drawCircle(
                    cx + kotlin.math.cos(a) * u * headW * 0.92f,
                    cy - u * headH * 0.55f + kotlin.math.sin(a) * u * headH * 0.42f,
                    u * 5.4f, p
                )
            }
        }
        4 -> {                                            // afro
            r.set(cx - u * (headW + 8f), cy - u * (headH + 10f),
                cx + u * (headW + 8f), cy + u * headH * 0.12f)
            c.drawOval(r, p)
            p.color = lighten(hair, 0.10f)
            c.drawCircle(cx - u * 12f, cy - u * headH * 0.78f, u * 8f, p)
        }
        5 -> {                                            // long, past the ears
            cap(0.26f)
            r.set(cx - u * (headW + 3f), cy - u * headH * 0.55f,
                cx - u * headW * 0.42f, cy + u * headH * 0.62f)
            c.drawRoundRect(r, u * 6f, u * 6f, p)
            r.set(cx + u * headW * 0.42f, cy - u * headH * 0.55f,
                cx + u * (headW + 3f), cy + u * headH * 0.62f)
            c.drawRoundRect(r, u * 6f, u * 6f, p)
        }
        6 -> {                                            // topknot
            cap(0.30f)
            c.drawCircle(cx - u * 2f, cy - u * (headH + 5f), u * 9f, p)
        }
        7 -> {                                            // receding
            cap(0.62f)
            r.set(cx - u * (headW + 1f), cy - u * headH * 0.70f,
                cx + u * (headW + 1f), cy + u * headH * 0.20f)
            val sv = c.save()
            path.reset(); path.addOval(r, Path.Direction.CW); c.clipPath(path)
            c.drawRect(cx - u * (headW + 1f), cy - u * headH * 0.70f,
                cx - u * headW * 0.52f, cy + u * headH * 0.20f, p)
            c.drawRect(cx + u * headW * 0.52f, cy - u * headH * 0.70f,
                cx + u * (headW + 1f), cy + u * headH * 0.20f, p)
            c.restoreToCount(sv)
        }
        9 -> {                                            // mohawk
            p.color = mix(f.skinColour, hair, 0.55f)
            cap(0.44f)
            p.color = hair
            r.set(cx - u * 6f, cy - u * (headH + 6f), cx + u * 6f, cy - u * headH * 0.20f)
            c.drawRoundRect(r, u * 4f, u * 4f, p)
        }
        10 -> {                                           // dreads
            cap(0.30f)
            for (i in 0 until 7) {
                val dx = -u * headW * 0.9f + u * headW * 0.3f * i
                r.set(dx + cx - u * 2.2f, cy - u * headH * 0.4f,
                    dx + cx + u * 2.2f, cy + u * headH * (0.35f + (i % 3) * 0.14f))
                c.drawRoundRect(r, u * 2.2f, u * 2.2f, p)
            }
        }
        else -> {                                         // quiff
            cap(0.32f)
            path.reset()
            path.moveTo(cx - u * headW * 0.7f, cy - u * headH * 0.92f)
            path.quadTo(cx - u * 4f, cy - u * (headH + 9f), cx + u * 10f, cy - u * headH * 0.86f)
            path.lineTo(cx - u * headW * 0.7f, cy - u * headH * 0.72f)
            path.close()
            c.drawPath(path, p)
        }
    }

    // a highlight so the hair is not a flat silhouette
    p.color = lighten(hair, if (f.hair == HAIR.size - 2) 0.18f else 0.26f)
    c.drawCircle(cx - u * headW * 0.42f, cy - u * headH * 0.66f, u * 4.6f, p)
}

/* ------------------------------------------------------------------- VIEW */

/** A square portrait, for a squad row or a profile card. */
class FaceView(ctx: Context, player: Player) : View(ctx) {
    private val face = Face.of(player)

    override fun onDraw(c: Canvas) {
        val s = kotlin.math.min(width, height).toFloat()
        // the design grid is 100 wide with the head centred a little high
        drawFace(c, width / 2f, height * 0.46f, s * 0.98f, face)
    }
}

fun Context.playerFace(p: Player, sizeDp: Int): FaceView {
    val v = FaceView(this, p)
    v.layoutParams = null
    return v
}
