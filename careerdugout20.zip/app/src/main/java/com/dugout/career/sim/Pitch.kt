package com.dugout.career.sim

import com.dugout.career.core.Att
import com.dugout.career.core.Pos
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ENGINE V3, LAYER 2: a model of SPACE.
 *
 * This is the layer neither previous engine had, and the absence of it explains
 * most of what was wrong with both. v1 and v2 both reasoned about PLAYERS --
 * who is nearest, who is marked, how far to the next man. Neither had any
 * representation of the pitch itself, so nobody could run into space, nobody
 * could cover a region, and a pass could only be scored by a hand-weighted sum
 * of distances. Play stayed central in v2 because the sum rewarded centrality;
 * there was nothing to tell it the space was out wide.
 *
 * The standard analytics model: divide the pitch into cells, work out who
 * reaches each cell first, and let everything above read off that.
 *
 * Cost matters -- this has to run on a phone -- so the grid is coarse and it is
 * recomputed on a cadence rather than every tick. Control does not change much
 * in 80 ms.
 */
class Pitch(val cols: Int = 16, val rows: Int = 11) {

    /** control[c][r] in -1..1: -1 wholly away, +1 wholly home. */
    private val control = FloatArray(cols * rows)
    /** Seconds for the quickest home / away man to reach each cell. */
    private val tHome = FloatArray(cols * rows)
    private val tAway = FloatArray(cols * rows)

    private fun idx(c: Int, r: Int) = r * cols + c

    fun cellX(c: Int) = (c + 0.5f) * (100f / cols)
    fun cellY(r: Int) = (r + 0.5f) * (100f / rows)

    private fun colOf(x: Float) = ((x / 100f) * cols).toInt().coerceIn(0, cols - 1)
    private fun rowOf(y: Float) = ((y / 100f) * rows).toInt().coerceIn(0, rows - 1)

    /**
     * Recompute who controls what.
     *
     * Time-to-reach, not distance: a man sprinting away from a cell is further
     * from it than one standing still at the same range, and that difference is
     * the entire point of doing this properly.
     */
    fun compute(players: List<LivePlayer>) {
        java.util.Arrays.fill(tHome, Float.MAX_VALUE)
        java.util.Arrays.fill(tAway, Float.MAX_VALUE)

        for (p in players) {
            if (!p.onPitch) continue
            val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f
            val top = (5.4f + pace / 24f) * (0.82f + p.effective.toFloat() / 320f)
            val acc = 4.2f + p.ref.att[Att.ACC] / 26f
            val arr = if (p.side == 0) tHome else tAway
            // a keeper does not contest space up the pitch
            val reach = if (p.pos == Pos.GK) 26f else 999f
            for (r in 0 until rows) {
                val cy = cellY(r)
                for (c in 0 until cols) {
                    val cx = cellX(c)
                    if (reach < 900f &&
                        Physics.metres(p.x, p.y, cx, cy) > reach) continue
                    val t = Physics.timeToReach(p.x, p.y, p.vx, p.vy, cx, cy, top, acc)
                    val i = idx(c, r)
                    if (t < arr[i]) arr[i] = t
                }
            }
        }

        for (i in control.indices) {
            val h = tHome[i]
            val a = tAway[i]
            // a smooth advantage rather than a hard winner, so a cell contested
            // by a tenth of a second is not owned outright by either
            val d = (a - h).coerceIn(-2.5f, 2.5f)
            control[i] = d / 2.5f
        }
    }

    /** -1..1 at a point, positive meaning home controls it. */
    fun controlAt(x: Float, y: Float): Float = control[idx(colOf(x), rowOf(y))]

    /** 0..1, how much THIS side controls the point. */
    fun controlFor(side: Int, x: Float, y: Float): Float {
        val c = controlAt(x, y)
        return ((if (side == 0) c else -c) + 1f) * 0.5f
    }

    /** Seconds for the quickest man of a side to reach a point. */
    fun timeFor(side: Int, x: Float, y: Float): Float =
        (if (side == 0) tHome else tAway)[idx(colOf(x), rowOf(y))]

    /**
     * How dangerous a point is for [side] to have the ball in: near the goal
     * they attack and central. This is the "value" half of space value.
     */
    fun danger(side: Int, x: Float, y: Float): Float {
        val gx = if (side == 0) 100f else 0f
        val d = Physics.metres(x, y, gx, 50f)
        val central = 1f - (abs(y - 50f) / 50f) * 0.75f
        return (1f - (d / 62f).coerceIn(0f, 1f)) * central
    }

    /**
     * What a point is worth to [side]: control times danger.
     *
     * A cell deep in the opposition box is worth nothing if they own it, and a
     * cell in acres of space on the wing is worth something even though it is
     * not dangerous by itself. That trade-off is what produces football that
     * uses the width of the pitch without abandoning the middle.
     */
    fun spaceValue(side: Int, x: Float, y: Float): Float =
        controlFor(side, x, y) * (0.34f + danger(side, x, y))

    /**
     * How pressed a man is: the opposition's control of the ground he stands on.
     */
    fun pressureOn(p: LivePlayer): Float = 1f - controlFor(p.side, p.x, p.y)

    /**
     * Is the line from a to b safe from [foe]? 1 clear, 0 cut off.
     *
     * Sampled along the line against time-to-reach, so a defender who can get
     * across in time closes a lane even if he is not standing in it -- which is
     * how interceptions actually happen.
     */
    fun laneSafety(fromX: Float, fromY: Float, toX: Float, toY: Float,
                   foe: Int, ballMps: Float): Float {
        var worst = 1f
        val steps = 6
        for (i in 1..steps) {
            val f = i / (steps + 1f)
            val px = fromX + (toX - fromX) * f
            val py = fromY + (toY - fromY) * f
            val travel = Physics.metres(fromX, fromY, px, py) / max(4f, ballMps)
            val foeT = timeFor(foe, px, py)
            // he needs to beat the ball there, with a little margin
            val margin = foeT - travel
            worst = min(worst, (margin / 1.1f).coerceIn(0f, 1f))
        }
        return worst
    }

    /**
     * The best cell for [side] to attack from where the ball is, used for
     * off-ball runs. Returns packed x,y.
     */
    fun bestSpace(side: Int, fromX: Float, fromY: Float, maxRange: Float): Pair<Float, Float> {
        var bx = fromX; var by = fromY; var best = -1e9f
        val dir = if (side == 0) 1f else -1f
        for (r in 0 until rows) {
            val cy = cellY(r)
            for (c in 0 until cols) {
                val cx = cellX(c)
                if (Physics.metres(fromX, fromY, cx, cy) > maxRange) continue
                // only forward of, or level with, where he is now
                if ((cx - fromX) * dir < -6f) continue
                val v = spaceValue(side, cx, cy)
                if (v > best) { best = v; bx = cx; by = cy }
            }
        }
        return bx to by
    }
}
