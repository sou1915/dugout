package com.dugout.career.sim

import com.dugout.career.core.Att
import com.dugout.career.core.Instr
import com.dugout.career.core.PI
import com.dugout.career.core.Pos
import com.dugout.career.core.RoleFx
import com.dugout.career.core.Tactics
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ENGINE V4, IDEA 8: WHAT THE OTHER TWENTY ONE ARE DOING.
 *
 * The owner: the AI of the players on the pitch looks stupid.
 *
 * He is right, and this file is an argument about WHY. Almost every hour spent
 * on this match engine has gone into the man ON the ball -- who he passes to,
 * whether he shoots, how hard he strikes it. But the man on the ball is one
 * twenty-second of what is on screen at any moment. The other twenty one are
 * what the eye actually reads as "football" or "not football", and until now
 * they have been driven by this, in `updateTargets`:
 *
 *     a formation slot, plus a pull toward the ball
 *
 * That is the whole model. It has no idea where space is, no idea what anybody
 * else is doing, and no idea what this particular man is for. Which is exactly
 * how it looks: twenty two figures sliding toward the ball as one, holding a
 * shape drawn on a diagram, and drifting into the middle because the ball is
 * usually in the middle. Measured, in AUDIT.md:
 *
 *     the men sit 48% inside the middle fifth of the pitch
 *     the man on the ball is there 69% of the time
 *     the ball leaves down a touchline 0.7 times a match against a real forty
 *
 * ------------------------------------------------------------------------
 *
 * WHAT THIS DOES INSTEAD
 *
 * Every player, every decision tick, answers three questions in order:
 *
 *   1. WHAT AM I FOR RIGHT NOW?   an intent, from his role, the phase of play
 *                                 and where the ball is. Not a slot -- a job.
 *   2. WHERE DOES THAT JOB WANT ME?   candidate positions, scored against the
 *                                 pitch-control grid rather than against a
 *                                 drawn diagram.
 *   3. HOW URGENTLY?              a deadline, which ARRIVE_BY turns into a pace.
 *
 * The second is the one neither v1 nor v2 could ask, because neither had a
 * model of the pitch. `Pitch.kt` is that model and it has been sitting unused
 * behind a flag: this is what it was written for.
 *
 * ------------------------------------------------------------------------
 *
 * WHY IT IS A SEPARATE FILE AND A SEPARATE FLAG
 *
 * Three engines have been written in this project. Two landed because they
 * could be measured one piece at a time; the third is still quarantined because
 * it was switched on whole. This is deliberately the smallest useful piece:
 * it decides WHERE MEN STAND and touches nothing else -- not possession, not
 * passing, not shooting, not the scenes. `ResultFingerprint` will move, because
 * where men stand reaches results, and `BalanceBig` is the gate.
 *
 * OFF_BALL is false until it has been through both.
 */
object OffBall {

    /** Off until it has been through BalanceBig. */
    @JvmField var ENABLED = false

    /**
     * How often a man reconsiders, in seconds.
     *
     * Not every tick. v3's decision layer ran at 36 Hz and cost 8.8 seconds of
     * CPU a match against v2's 0.2, which would have been unplayable on a
     * phone; that is the single most expensive mistake available here and the
     * reason this number exists. A footballer does not re-plan his run six
     * times a second either.
     */
    @JvmField var THINK_HZ = 0.22f

    /** How far a man will look for a better place to be, in pitch units. */
    @JvmField var LOOK = 26f

    /* ------------------------------------------------------------ INTENTS */

    /**
     * What a man is FOR at this moment.
     *
     * These are jobs, not destinations, and that is the whole point of the
     * layer. "Get goal-side of the danger" produces a different position every
     * second as the danger moves; a formation slot produces the same one all
     * match.
     */
    object Job {
        /** Hold the block, keep the line, do nothing clever. */
        const val SHAPE = 0
        /** Go and close the man on the ball down. */
        const val PRESS = 1
        /** Take the space behind whoever is pressing. */
        const val COVER = 2
        /** Stay with a man. */
        const val MARK = 3
        /** Get back between the ball and my own goal. */
        const val RECOVER = 4
        /** Offer an angle to the man on the ball. */
        const val SUPPORT = 5
        /** Attack the space beyond the last defender. */
        const val RUN_BEYOND = 6
        /** Hold the touchline and stretch them. */
        const val HOLD_WIDTH = 7
        /** Get into the box for a delivery. */
        const val ATTACK_BOX = 8
        /** Sit on the edge for the second ball. */
        const val SECOND_BALL = 9
        /** Go and get a loose ball. */
        const val CHASE = 10
        /** Show for it short, to feet. */
        const val SHOW_SHORT = 11

        val LABEL = arrayOf("shape", "press", "cover", "mark", "recover",
            "support", "run beyond", "hold width", "attack the box",
            "second ball", "chase", "show short")
        const val COUNT = 12
    }

    /* --------------------------------------------------------- THE INPUTS */

    /**
     * Everything a decision needs, gathered once a tick instead of twenty two
     * times. Gathering it per player was measured as most of v3's cost.
     */
    class Frame {
        @JvmField var ballX = 50f
        @JvmField var ballY = 50f
        /** Where the ball will come to rest, which is what a runner aims at. */
        @JvmField var restX = 50f
        @JvmField var restY = 50f
        @JvmField var loose = true
        @JvmField var carrierSide = -1
        @JvmField var carrierKey: String? = null
        @JvmField var carrierX = 50f
        @JvmField var carrierY = 50f
        /** The deepest outfield man of each side. */
        @JvmField val lastLine = floatArrayOf(20f, 80f)
        /** How far up the pitch each side's block is sitting. */
        @JvmField val blockX = floatArrayOf(35f, 65f)
        @JvmField var inFlight = false
        @JvmField var deadBall = false
    }

    private val frame = Frame()
    private val pitch = Pitch(16, 11)
    private var sinceThink = 0f
    private var gridAge = 0f

    /* ----------------------------------------------------------- SCRATCH */

    // reused so a decision allocates nothing; twenty two players times six
    // decisions a second times ninety minutes is a lot of garbage otherwise
    private val candX = FloatArray(16)
    private val candY = FloatArray(16)
    private var candN = 0

    private fun clearCandidates() { candN = 0 }

    private fun offer(x: Float, y: Float) {
        if (candN >= candX.size) return
        candX[candN] = x.coerceIn(2.5f, 97.5f)
        candY[candN] = y.coerceIn(3f, 97f)
        candN++
    }

    /* ------------------------------------------------------------- ENTRY */

    /**
     * Advance the layer. Returns true when targets were rewritten this tick.
     *
     * [dt] is in match-visible seconds, the same clock the movers use, so the
     * cadence does not change with the speed button.
     */
    fun tick(m: MatchEngine, dt: Float): Boolean {
        if (!ENABLED) return false
        sinceThink += dt
        gridAge += dt
        if (sinceThink < THINK_HZ) { reapply(m); return false }
        sinceThink = 0f

        gather(m)
        // the grid is the expensive part: recompute it on its own, slower beat
        if (gridAge >= THINK_HZ * 2f) {
            gridAge = 0f
            pitch.compute(m.players)
        }
        for (p in m.players) {
            if (!p.onPitch) continue
            if (p.pos == Pos.GK) { keeper(m, p); continue }
            decide(m, p)
        }
        return true
    }

    /* ---------------------------------------------------------- GATHERING */

    private fun gather(m: MatchEngine) {
        val f = frame
        f.ballX = m.ball.x
        f.ballY = m.ball.y
        f.inFlight = m.ball.t < 1f
        f.deadBall = m.sceneTime > 0f && !Scene.isLive(m.scene)

        val holder = m.ball.holder
        f.carrierKey = holder
        val carrier = holder?.let { k -> m.players.firstOrNull { it.key == k && it.onPitch } }
        f.loose = carrier == null
        f.carrierSide = carrier?.side ?: -1
        f.carrierX = carrier?.x ?: m.ball.x
        f.carrierY = carrier?.y ?: m.ball.y

        /*
         * Where the ball will STOP, not where it is.
         *
         * Two attempts to make a man meet a pass failed in this project because
         * they aimed him at the delivery's aim point, and the aim point is a
         * place the ball merely passes through. Physics.restPoint answers the
         * real question. When the ball is not being flown by physics this falls
         * back to a short lead on its drift, which is the best the interpolated
         * ball can offer.
         */
        if (m.ball.phys) {
            Physics.restPoint(m.ball, restScratch)
            f.restX = restScratch[0]
            f.restY = restScratch[1]
        } else {
            f.restX = m.ball.x + m.ball.driftX * 9f
            f.restY = m.ball.y + m.ball.driftY * 9f
        }

        for (side in 0..1) {
            var deepest = if (side == 0) 100f else 0f
            var sum = 0f
            var n = 0
            for (p in m.players) {
                if (!p.onPitch || p.side != side || p.pos == Pos.GK) continue
                sum += p.x; n++
                if (side == 0) { if (p.x < deepest) deepest = p.x }
                else if (p.x > deepest) deepest = p.x
            }
            f.lastLine[side] = deepest
            f.blockX[side] = if (n == 0) 50f else sum / n
        }
    }

    private val restScratch = FloatArray(3)

    /* ------------------------------------------------------ WHAT AM I FOR */

    /**
     * The job, decided in the order a footballer decides it: the ball first,
     * then the phase, then his role.
     *
     * Read it top to bottom -- the earlier a branch is, the more it overrides,
     * and that ordering IS the football. A defender does not hold his line
     * because his role says so if the ball is loose two yards from him.
     */
    fun jobFor(m: MatchEngine, p: LivePlayer): Int {
        val f = frame
        val mine = f.carrierSide == p.side
        val dir = if (p.side == 0) 1f else -1f
        val toBall = Physics.metres(p.x, p.y, f.restX, f.restY)
        val t = (if (p.side == 0) m.home else m.away).tactics

        // 1. a loose ball close enough to be mine is everything else's senior
        if (f.loose && toBall < 16f) {
            val closest = nearestOf(m, p.side, f.restX, f.restY)
            if (closest === p) return Job.CHASE
        }

        // 2. defending
        if (!mine && f.carrierSide >= 0) {
            val ownGoal = if (p.side == 0) 0f else 100f
            val dangerNear = abs(f.carrierX - ownGoal) < 42f
            val toCarrier = Physics.metres(p.x, p.y, f.carrierX, f.carrierY)
            // caught upfield with the goal threatened: get back first
            val goalSide = (p.x - f.carrierX) * -dir > 0f
            if (dangerNear && !goalSide) return Job.RECOVER
            // the nearest man presses; how many join him is the instruction
            val rank = pressRank(m, p)
            val joiners = when (t.press) { 0 -> 1; 2 -> 3; else -> 2 }
            if (rank in 0 until joiners && toCarrier < 34f) {
                return if (rank == 0) Job.PRESS else Job.COVER
            }
            if (t.marking == 1 || (t.oppTargetId >= 0 && t.oppMode == 1)) return Job.MARK
            return Job.SHAPE
        }

        // 3. attacking
        if (mine) {
            if (p.key == f.carrierKey) return Job.SHAPE      // his own layer decides
            val fx = RoleFx.of(t.roleName(p.slot))
            val pi = t.slotInstructions.getOrElse(p.slot) { 0 }
            val group = Pos.group(p.pos)
            val ballHigh = (f.carrierX - 50f) * dir > 14f
            /*
             * GET IN THE BOX WHEN THE BALL IS UP THERE, not only when somebody
             * is standing on the touchline about to cross.
             *
             * This asked for `wideOfGoal(carrier)`, and measured over six
             * matches ATTACK_BOX fired for 0.3% of player-time while goals fell
             * from 4.00 to 1.67 -- the marking half of the layer worked and the
             * attacking half never ran. The cause is one v2 already admits to:
             * it does not play down the flanks, 1.00 cross a match, so a
             * condition that waits for a wide carrier waits forever.
             *
             * A forward gets into the area because the ball is in the final
             * third, whoever has it and wherever he is standing.
             */
            val theirGoal = if (p.side == 0) 100f else 0f
            val nearGoal = abs(f.carrierX - theirGoal) < 33f
            if (ballHigh && (nearGoal || wideOfGoal(f.carrierX, f.carrierY, p.side)) &&
                group >= 2)
                return if (group == 3 || pi and PI.GET_FORWARD != 0)
                    Job.ATTACK_BOX else Job.SECOND_BALL
            // the forward who runs the shoulder
            if (group == 3 && fx.ySpread <= 1.05f && ballHigh) return Job.RUN_BEYOND
            // width is a job, not a coordinate
            if (isWide(p) && t.width != 0) return Job.HOLD_WIDTH
            // somebody has to come and show for it
            if (Physics.metres(p.x, p.y, f.carrierX, f.carrierY) < 22f) return Job.SHOW_SHORT
            return Job.SUPPORT
        }

        // 4. nobody has it and it is not mine to chase
        return if (toBall < 26f) Job.SUPPORT else Job.SHAPE
    }

    /* ----------------------------------------------- WHERE DOES IT WANT ME */

    /**
     * Turn the job into candidate positions and pick the best against the grid.
     *
     * Candidates rather than a formula, for one reason: a formula produces a
     * point and cannot be argued with, while candidates can be SCORED, and the
     * score is where the pitch model gets to speak. It is also why this reads
     * as football rather than as a diagram -- the same job produces a different
     * answer depending on what the opposition are doing.
     */
    private fun decide(m: MatchEngine, p: LivePlayer) {
        val f = frame
        val job = jobFor(m, p)
        p.job = job
        val dir = if (p.side == 0) 1f else -1f
        val ownGoal = if (p.side == 0) 0f else 100f
        val theirGoal = if (p.side == 0) 100f else 0f
        val t = (if (p.side == 0) m.home else m.away).tactics

        clearCandidates()
        var deadline = 0f

        when (job) {
            Job.CHASE -> {
                offer(f.restX, f.restY)
                // he has exactly as long as the ball takes to get there
                deadline = max(0.25f, Physics.timeToReach(
                    p.x, p.y, p.vx, p.vy, f.restX, f.restY, topSpeed(p), accel(p)))
            }

            Job.PRESS -> {
                /*
                 * Not AT him: between him and the goal, a stride off his
                 * shoulder. A presser who runs at the ball is beaten by the
                 * first touch; one who arrives goal-side takes the option away
                 * without having to win a tackle, which is what pressing IS.
                 */
                val gx = f.carrierX + (ownGoal - f.carrierX) * 0.16f
                val gy = f.carrierY + (50f - f.carrierY) * 0.10f
                offer(gx, gy)
                offer(f.carrierX - dir * 2.2f, f.carrierY)
                deadline = 1.1f
            }

            Job.COVER -> {
                // the space behind the presser, which is where the ball goes
                // if he is beaten
                val bx = f.carrierX + (ownGoal - f.carrierX) * 0.30f
                offer(bx, f.carrierY - 8f)
                offer(bx, f.carrierY + 8f)
                offer(bx, f.carrierY)
                deadline = 1.6f
            }

            Job.MARK -> {
                val man = markTarget(m, p)
                if (man != null) {
                    offer(man.x + (ownGoal - man.x) * 0.06f, man.y - 1.4f)
                    offer(man.x + (ownGoal - man.x) * 0.06f, man.y + 1.4f)
                    deadline = 1.4f
                } else offer(p.targetX, p.targetY)
            }

            Job.RECOVER -> {
                // straight back into the block, at whatever pace that needs
                val bx = f.blockX[p.side] + (ownGoal - f.blockX[p.side]) * 0.35f
                offer(bx, p.y + (f.ballY - p.y) * 0.4f)
                offer(bx, 50f + (p.baseY - 50f) * 0.8f)
                // a defender must be back before the ball arrives, not after
                deadline = max(0.9f,
                    Physics.metres(p.x, p.y, bx, p.y) / max(3f, topSpeed(p)))
            }

            Job.SUPPORT -> {
                /*
                 * An ANGLE, not a distance. Three offers at different depths
                 * around the carrier, and the grid decides which of them is
                 * actually available -- so a marked man does not stand in the
                 * same place looking for a pass that cannot be played.
                 */
                val d = 13f
                offer(f.carrierX + dir * d, f.carrierY - 11f)
                offer(f.carrierX + dir * d, f.carrierY + 11f)
                offer(f.carrierX - dir * 7f, f.carrierY - 9f)
                offer(f.carrierX - dir * 7f, f.carrierY + 9f)
                offer(f.carrierX + dir * 4f, f.carrierY - 15f)
                offer(f.carrierX + dir * 4f, f.carrierY + 15f)
                deadline = 2.2f
            }

            Job.SHOW_SHORT -> {
                val d = 8f
                offer(f.carrierX - dir * d, f.carrierY - 6f)
                offer(f.carrierX - dir * d, f.carrierY + 6f)
                offer(f.carrierX + dir * d * 0.5f, f.carrierY - 7f)
                offer(f.carrierX + dir * d * 0.5f, f.carrierY + 7f)
                deadline = 1.5f
            }

            Job.RUN_BEYOND -> {
                /*
                 * On the shoulder, and sometimes past it. The offside law is in
                 * the engine now, so this is a genuine gamble rather than the
                 * invisible rail every attacker used to be clamped to -- and
                 * how far past he is willing to go is his POSITIONING.
                 */
                val line = f.lastLine[1 - p.side]
                val gamble = (1.6f - p.ref.att[Att.POS] / 80f).coerceIn(-0.6f, 1.6f)
                offer(line + dir * gamble, f.carrierY - 13f)
                offer(line + dir * gamble, f.carrierY + 13f)
                offer(line + dir * gamble, 50f + (p.baseY - 50f) * 0.6f)
                deadline = 1.3f
            }

            Job.HOLD_WIDTH -> {
                val edge = if (p.baseY < 50f) 8f else 92f
                val push = when (t.width) { 2 -> 0f; 0 -> 14f; else -> 7f }
                val y = if (p.baseY < 50f) edge + push else edge - push
                offer(f.carrierX + dir * 6f, y)
                offer(f.carrierX + dir * 16f, y)
                offer(f.blockX[p.side] + dir * 10f, y)
                deadline = 2.4f
            }

            Job.ATTACK_BOX -> {
                /*
                 * The box is not one place. Near post, penalty spot, far post,
                 * and they are attacked at DIFFERENT times -- which is the
                 * difference between men arriving on a cross and men standing
                 * in it waiting. The corner routine learned this already;
                 * this is the same lesson in open play.
                 */
                val gx = theirGoal - dir * 7f
                offer(gx, 50f - 6f)
                offer(gx - dir * 3f, 50f)
                offer(gx, 50f + 6f)
                offer(gx - dir * 8f, 50f + (p.baseY - 50f) * 0.35f)
                deadline = 1.5f
            }

            Job.SECOND_BALL -> {
                val gx = theirGoal - dir * 20f
                offer(gx, 50f - 10f)
                offer(gx, 50f)
                offer(gx, 50f + 10f)
                deadline = 2.0f
            }

            else -> {
                // the block: his station, slid toward the ball, as before --
                // this layer does not claim to improve on a shape that is
                // measured correct, it claims the other eleven jobs exist
                offer(p.targetX, p.targetY)
                deadline = 0f
            }
        }

        if (candN == 0) return
        var bestI = 0
        var best = -1e9f
        for (i in 0 until candN) {
            val s = score(m, p, job, candX[i], candY[i])
            if (s > best) { best = s; bestI = i }
        }
        p.targetX = candX[bestI]
        p.targetY = candY[bestI]
        if (deadline > 0f) p.arriveBy = deadline
        // and REMEMBER it -- see `reapply`, which is why this layer does
        // anything at all
        p.obX = candX[bestI]
        p.obY = candY[bestI]
        p.obLive = true
    }

    /**
     * PUT THE DECISION BACK, EVERY FRAME.
     *
     * This layer was measured on and off over six matches and the two runs were
     * identical to three significant figures -- 4.00 goals, 51.9% of men in the
     * middle fifth, the same CPU -- while `ObCheck` showed the jobs being
     * handed out normally. The work was being done and thrown away.
     *
     * `updateTargets` runs EVERY frame and assigns `targetX` from the formation
     * slot. `tick` only re-decides every THINK_HZ, which is 0.22 s, or about
     * one frame in eight. On the other seven the slot overwrote the job's
     * target and `tick` returned early without putting it back, so a man moved
     * toward his job for a single 1/36 s frame and was then pulled back into
     * the diagram. Net effect: nothing, which is exactly what the numbers said.
     *
     * This is the sixth time in this project that correct code has been found
     * on a path that discarded it. See docs/DEAD_CODE.md.
     */
    private fun reapply(m: MatchEngine) {
        for (p in m.players) {
            if (!p.onPitch || !p.obLive) continue
            // the man ON the ball is the decision layer's business, not this one
            if (p.key == m.ball.holder) continue
            p.targetX = p.obX
            p.targetY = p.obY
        }
    }

    /* --------------------------------------------------------- THE SCORE */

    /**
     * What a place is worth to this man, for this job.
     *
     * Every term is either read off the pitch-control grid or is a fact about
     * the man; none of it is a hand-weighted preference for the middle, which
     * is the term that quietly drained the flanks in v2 and survived two
     * attempts to find it.
     */
    private fun score(m: MatchEngine, p: LivePlayer, job: Int, x: Float, y: Float): Float {
        val f = frame
        val dir = if (p.side == 0) 1f else -1f
        var s = 0f

        // 1. can I get there, and is it mine when I do
        val mine = pitch.controlFor(p.side, x, y)
        s += mine * 22f

        // 2. is it worth anything -- control times danger, from the grid
        s += pitch.spaceValue(p.side, x, y) * 18f

        // 3. can the ball reach me there
        if (f.carrierSide == p.side && f.carrierKey != null) {
            val lane = pitch.laneSafety(f.carrierX, f.carrierY, x, y, 1 - p.side, 16f)
            s += lane * (if (job == Job.SUPPORT || job == Job.SHOW_SHORT) 26f else 10f)
        }

        // 4. how far I have to go for it, which is effort and also risk
        val trip = Physics.metres(p.x, p.y, x, y)
        s -= trip * 0.42f

        // 5. am I leaving my post, which the block cannot afford everywhere
        val drift = Physics.metres(x, y,
            if (p.side == 0) p.baseX else 100f - p.baseX,
            if (p.side == 0) p.baseY else 100f - p.baseY)
        s -= drift * (if (job == Job.SHAPE || job == Job.RECOVER) 0.30f else 0.10f)

        // 6. offside is a real cost, not a wall
        if (job == Job.RUN_BEYOND || job == Job.ATTACK_BOX) {
            val past = (x - f.lastLine[1 - p.side]) * dir
            if (past > 1.2f) s -= (past - 1.2f) * 3.4f
        }

        // 7. do not stand on a team mate
        var crowd = 0f
        for (o in m.players) {
            if (!o.onPitch || o.side != p.side || o.key == p.key) continue
            val d = Physics.metres(o.targetX, o.targetY, x, y)
            if (d < 7f) crowd += (7f - d)
        }
        s -= crowd * 1.1f

        return s
    }

    /* ---------------------------------------------------------- THE KEEPER */

    /**
     * The one man whose job is not a matter of opinion.
     *
     * On his line for a cross, off it when the ball is played in behind and he
     * can get there first. The sweeping is the only part that is a decision,
     * and it is the same decision as everybody else's: can I reach it before
     * they can.
     */
    private fun keeper(m: MatchEngine, p: LivePlayer) {
        val f = frame
        val ownGoal = if (p.side == 0) 0f else 100f
        val dir = if (p.side == 0) 1f else -1f
        val threat = abs(f.ballX - ownGoal) < 40f

        if (f.loose && threat) {
            val mine = Physics.timeToReach(p.x, p.y, p.vx, p.vy,
                f.restX, f.restY, topSpeed(p), accel(p))
            val theirs = nearestTime(m, 1 - p.side, f.restX, f.restY)
            if (mine < theirs - 0.15f && abs(f.restX - ownGoal) < 22f) {
                p.targetX = f.restX
                p.targetY = f.restY
                p.arriveBy = max(0.3f, mine)
                p.job = Job.CHASE
                p.obX = f.restX; p.obY = f.restY; p.obLive = true
                return
            }
        }
        // narrow the angle: on his line, on the line from the ball to the goal
        val depth = if (threat) 3.2f else 8.5f
        val bias = ((f.ballY - 50f) * 0.28f).coerceIn(-7f, 7f)
        p.targetX = ownGoal + dir * depth
        p.targetY = 50f + bias
        p.arriveBy = 1.2f
        p.job = Job.SHAPE
        p.obX = p.targetX; p.obY = p.targetY; p.obLive = true
    }

    /* ---------------------------------------------------------- UTILITIES */

    private fun topSpeed(p: LivePlayer): Float {
        val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f
        return (5.4f + pace / 24f) * (0.82f + p.effective.toFloat() / 320f)
    }

    private fun accel(p: LivePlayer): Float = 4.2f + p.ref.att[Att.ACC] / 26f

    private fun nearestOf(m: MatchEngine, side: Int, x: Float, y: Float): LivePlayer? {
        var best: LivePlayer? = null
        var bt = Float.MAX_VALUE
        for (p in m.players) {
            if (!p.onPitch || p.side != side || p.pos == Pos.GK) continue
            val t = Physics.timeToReach(p.x, p.y, p.vx, p.vy, x, y, topSpeed(p), accel(p))
            if (t < bt) { bt = t; best = p }
        }
        return best
    }

    private fun nearestTime(m: MatchEngine, side: Int, x: Float, y: Float): Float {
        var bt = Float.MAX_VALUE
        for (p in m.players) {
            if (!p.onPitch || p.side != side) continue
            val t = Physics.timeToReach(p.x, p.y, p.vx, p.vy, x, y, topSpeed(p), accel(p))
            if (t < bt) bt = t
        }
        return bt
    }

    /**
     * Where this man ranks in the queue to press, by time to the carrier.
     *
     * By TIME, not distance, because a man already running at him arrives
     * before a man standing closer with his back turned -- and pressing being
     * decided on distance is why the press in v2 was measured as one man while
     * the instruction said three.
     */
    private fun pressRank(m: MatchEngine, p: LivePlayer): Int {
        val f = frame
        val mine = Physics.timeToReach(p.x, p.y, p.vx, p.vy,
            f.carrierX, f.carrierY, topSpeed(p), accel(p))
        var rank = 0
        for (o in m.players) {
            if (!o.onPitch || o.side != p.side || o.pos == Pos.GK || o.key == p.key) continue
            val t = Physics.timeToReach(o.x, o.y, o.vx, o.vy,
                f.carrierX, f.carrierY, topSpeed(o), accel(o))
            if (t < mine) rank++
        }
        return rank
    }

    private fun markTarget(m: MatchEngine, p: LivePlayer): LivePlayer? {
        val t = (if (p.side == 0) m.home else m.away).tactics
        if (t.oppTargetId >= 0 && t.oppMode == 1) {
            val named = m.players.firstOrNull { it.ref.id == t.oppTargetId && it.onPitch }
            if (named != null && Pos.group(p.pos) == 1) return named
        }
        // otherwise the nearest opponent ahead of me, which is the man who
        // would receive if the ball came this way
        var best: LivePlayer? = null
        var bd = Float.MAX_VALUE
        val dir = if (p.side == 0) 1f else -1f
        for (o in m.players) {
            if (!o.onPitch || o.side == p.side || o.pos == Pos.GK) continue
            if ((o.x - p.x) * dir > 6f) continue
            val d = Physics.metres(o.x, o.y, p.x, p.y)
            if (d < bd) { bd = d; best = o }
        }
        return best
    }

    private fun isWide(p: LivePlayer): Boolean =
        p.baseY < 26f || p.baseY > 74f

    private fun wideOfGoal(x: Float, y: Float, side: Int): Boolean {
        val gx = if (side == 0) 100f else 0f
        return abs(y - 50f) > 16f && abs(x - gx) < 34f
    }

    /** Reset between matches, so nothing leaks from the last one. */
    fun reset() {
        sinceThink = 0f
        gridAge = 0f
        candN = 0
    }
}
