package com.dugout.career.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View

/**
 * Icons are drawn as vector paths rather than shipped as bitmaps: they stay
 * sharp at any density, tint themselves, and cost nothing to load.
 */
object Icon {
    const val INBOX = 0
    const val HUB = 1
    const val SQUAD = 2
    const val TACTICS = 3
    const val TRAINING = 4
    const val TABLE = 5
    const val WORLD = 6
    const val TRANSFERS = 7
    const val CLUB = 8
    const val SEARCH = 9
    const val WHISTLE = 10
    const val TROPHY = 11
}

/** One icon, painted into whatever box it is given. */
class IconView(ctx: Context, private val id: Int, private var tint: Int) : View(ctx) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()

    fun setTint(c: Int) { tint = c; invalidate() }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        fill.color = tint
        line.color = tint
        line.strokeWidth = s * 0.085f

        // work in a 0..1 box then scale, so every icon shares one grid
        fun x(v: Float) = ox + v * s
        fun y(v: Float) = oy + v * s

        when (id) {
            Icon.INBOX -> {
                rect.set(x(0.14f), y(0.24f), x(0.86f), y(0.74f))
                c.drawRoundRect(rect, s * 0.06f, s * 0.06f, line)
                path.reset()
                path.moveTo(x(0.14f), y(0.28f))
                path.lineTo(x(0.50f), y(0.54f))
                path.lineTo(x(0.86f), y(0.28f))
                c.drawPath(path, line)
            }

            Icon.HUB -> {   // a pitch seen from above
                rect.set(x(0.14f), y(0.18f), x(0.86f), y(0.82f))
                c.drawRoundRect(rect, s * 0.05f, s * 0.05f, line)
                c.drawLine(x(0.50f), y(0.18f), x(0.50f), y(0.82f), line)
                c.drawCircle(x(0.50f), y(0.50f), s * 0.13f, line)
            }

            Icon.SQUAD -> {  // three shirts in a row
                shirt(c, x(0.28f), y(0.50f), s * 0.30f)
                shirt(c, x(0.72f), y(0.50f), s * 0.30f)
                shirt(c, x(0.50f), y(0.40f), s * 0.34f)
            }

            Icon.TACTICS -> {  // a clipboard with a plan on it
                rect.set(x(0.20f), y(0.16f), x(0.80f), y(0.86f))
                c.drawRoundRect(rect, s * 0.06f, s * 0.06f, line)
                fill.color = tint
                c.drawCircle(x(0.36f), y(0.40f), s * 0.055f, fill)
                c.drawCircle(x(0.64f), y(0.36f), s * 0.055f, fill)
                c.drawCircle(x(0.50f), y(0.64f), s * 0.055f, fill)
                path.reset()
                path.moveTo(x(0.36f), y(0.40f))
                path.lineTo(x(0.64f), y(0.36f))
                path.lineTo(x(0.50f), y(0.64f))
                line.strokeWidth = s * 0.045f
                c.drawPath(path, line)
                line.strokeWidth = s * 0.085f
            }

            Icon.TRAINING -> {  // a cone
                path.reset()
                path.moveTo(x(0.50f), y(0.16f))
                path.lineTo(x(0.76f), y(0.72f))
                path.lineTo(x(0.24f), y(0.72f))
                path.close()
                c.drawPath(path, line)
                c.drawLine(x(0.16f), y(0.80f), x(0.84f), y(0.80f), line)
            }

            Icon.TABLE -> {  // stacked rows
                var yy = 0.26f
                while (yy < 0.80f) {
                    c.drawLine(x(0.16f), y(yy), x(0.84f), y(yy), line)
                    yy += 0.18f
                }
                fill.color = tint
                c.drawCircle(x(0.16f), y(0.26f), s * 0.055f, fill)
            }

            Icon.WORLD -> {  // globe
                c.drawCircle(x(0.50f), y(0.50f), s * 0.34f, line)
                c.drawLine(x(0.16f), y(0.50f), x(0.84f), y(0.50f), line)
                rect.set(x(0.32f), y(0.16f), x(0.68f), y(0.84f))
                c.drawOval(rect, line)
            }

            Icon.TRANSFERS -> {  // two arrows passing
                path.reset()
                path.moveTo(x(0.18f), y(0.36f)); path.lineTo(x(0.76f), y(0.36f))
                c.drawPath(path, line)
                path.reset()
                path.moveTo(x(0.62f), y(0.22f)); path.lineTo(x(0.80f), y(0.36f)); path.lineTo(x(0.62f), y(0.50f))
                c.drawPath(path, line)
                path.reset()
                path.moveTo(x(0.82f), y(0.66f)); path.lineTo(x(0.24f), y(0.66f))
                c.drawPath(path, line)
                path.reset()
                path.moveTo(x(0.38f), y(0.52f)); path.lineTo(x(0.20f), y(0.66f)); path.lineTo(x(0.38f), y(0.80f))
                c.drawPath(path, line)
            }

            Icon.CLUB -> {  // a shield
                path.reset()
                path.moveTo(x(0.50f), y(0.14f))
                path.lineTo(x(0.82f), y(0.28f))
                path.lineTo(x(0.82f), y(0.54f))
                path.quadTo(x(0.82f), y(0.78f), x(0.50f), y(0.88f))
                path.quadTo(x(0.18f), y(0.78f), x(0.18f), y(0.54f))
                path.lineTo(x(0.18f), y(0.28f))
                path.close()
                c.drawPath(path, line)
            }

            Icon.SEARCH -> {
                c.drawCircle(x(0.44f), y(0.44f), s * 0.24f, line)
                c.drawLine(x(0.62f), y(0.62f), x(0.82f), y(0.82f), line)
            }

            Icon.WHISTLE -> {
                rect.set(x(0.20f), y(0.36f), x(0.68f), y(0.70f))
                c.drawRoundRect(rect, s * 0.16f, s * 0.16f, line)
                c.drawLine(x(0.64f), y(0.44f), x(0.84f), y(0.32f), line)
            }

            Icon.TROPHY -> {
                path.reset()
                path.moveTo(x(0.30f), y(0.18f))
                path.lineTo(x(0.70f), y(0.18f))
                path.lineTo(x(0.64f), y(0.52f))
                path.lineTo(x(0.36f), y(0.52f))
                path.close()
                c.drawPath(path, line)
                c.drawLine(x(0.50f), y(0.52f), x(0.50f), y(0.72f), line)
                c.drawLine(x(0.32f), y(0.82f), x(0.68f), y(0.82f), line)
                c.drawLine(x(0.30f), y(0.24f), x(0.18f), y(0.36f), line)
                c.drawLine(x(0.70f), y(0.24f), x(0.82f), y(0.36f), line)
            }
        }
    }

    private fun shirt(c: Canvas, cx: Float, cy: Float, size: Float) {
        path.reset()
        path.moveTo(cx - size * 0.5f, cy - size * 0.30f)
        path.lineTo(cx - size * 0.24f, cy - size * 0.46f)
        path.lineTo(cx + size * 0.24f, cy - size * 0.46f)
        path.lineTo(cx + size * 0.5f, cy - size * 0.30f)
        path.lineTo(cx + size * 0.32f, cy - size * 0.10f)
        path.lineTo(cx + size * 0.32f, cy + size * 0.46f)
        path.lineTo(cx - size * 0.32f, cy + size * 0.46f)
        path.lineTo(cx - size * 0.32f, cy - size * 0.10f)
        path.close()
        c.drawPath(path, line)
    }
}

fun Context.icon(id: Int, sizeDp: Int, tint: Int): IconView {
    val v = IconView(this, id, tint)
    v.layoutParams = lp(dp(sizeDp), dp(sizeDp))
    return v
}

/* ---------------------------------------------------------------- BUTTONS */

/**
 * Buttons get a real pressed state so a tap feels like it landed, and a
 * disabled state so dead controls read as dead.
 */
fun pressableBg(fill: Int, pressedFill: Int, stroke: Int, radiusPx: Int): StateListDrawable {
    val s = StateListDrawable()
    val down = GradientDrawable().apply {
        setColor(pressedFill); cornerRadius = radiusPx.toFloat()
        if (stroke != 0) setStroke(2, stroke)
    }
    val disabled = GradientDrawable().apply {
        setColor(0xFF23253C.toInt()); cornerRadius = radiusPx.toFloat()
        setStroke(2, 0xFF2C2F52.toInt())
    }
    val normal = GradientDrawable().apply {
        setColor(fill); cornerRadius = radiusPx.toFloat()
        if (stroke != 0) setStroke(2, stroke)
    }
    s.addState(intArrayOf(-android.R.attr.state_enabled), disabled)
    s.addState(intArrayOf(android.R.attr.state_pressed), down)
    s.addState(intArrayOf(), normal)
    return s
}

fun shade(color: Int, factor: Float): Int {
    val a = (color ushr 24) and 0xFF
    val r = (((color shr 16) and 0xFF) * factor).toInt().coerceIn(0, 255)
    val g = (((color shr 8) and 0xFF) * factor).toInt().coerceIn(0, 255)
    val b = ((color and 0xFF) * factor).toInt().coerceIn(0, 255)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}
