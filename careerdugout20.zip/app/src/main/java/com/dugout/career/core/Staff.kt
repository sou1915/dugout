package com.dugout.career.core

import kotlin.math.max
import kotlin.math.roundToInt

/**
 * The people around the manager.
 *
 * Every one of these does something measurable. A good coaching staff is worth
 * real development on the training ground, a good physio gets players back
 * weeks earlier, a good head of youth changes what walks through the door each
 * summer, and a good chief scout is the difference between a report you can
 * trust and one that is half guesswork. They are also a line on the wage bill,
 * so a strong backroom has to be paid for out of the same money as the squad.
 */

object StaffRole {
    const val ASSISTANT = 0
    const val COACH = 1
    const val PHYSIO = 2
    const val SCOUT = 3
    const val YOUTH = 4
    const val COUNT = 5

    val LABEL = arrayOf(
        "Assistant Manager", "Coach", "Physiotherapist", "Chief Scout", "Head of Youth"
    )

    val WHAT_THEY_DO = arrayOf(
        "Runs the touchline and reads the opposition.",
        "Runs the sessions. Better coaching means faster improvement.",
        "Treatment room. A good one gets players back weeks earlier.",
        "Reports on targets. A poor one gives you numbers you cannot trust.",
        "The academy. Decides the quality of each summer's intake."
    )
}

class Staff(
    val id: Int,
    val name: String,
    val role: Int,
    /** 20 to 95. Everything below scales off this. */
    var quality: Int,
    var wage: Int,
    var contractYears: Int = 2
) {
    val roleName: String get() = StaffRole.LABEL[role]

    /** How a manager would describe him. */
    val standing: String
        get() = when {
            quality >= 85 -> "Outstanding"
            quality >= 72 -> "Very good"
            quality >= 58 -> "Solid"
            quality >= 44 -> "Adequate"
            else -> "Out of his depth"
        }

    /** Stars out of five, for a compact display. */
    val stars: Int get() = ((quality - 20) / 15.5).roundToInt().coerceIn(1, 5)
}

object Backroom {

    /** What a club of this reputation would expect its staff to be worth. */
    fun expectedQuality(rng: Rng, clubRep: Int): Int =
        rng.norm(28.0 + clubRep * 0.62, 9.0, 20, 95)

    /**
     * What he costs a week. The first attempt underflowed and pinned every
     * member of staff at the six hundred pound floor whatever he was worth,
     * which made the whole backroom free. Calibrated now so a poor coach is
     * about seven hundred a week and an outstanding one around twelve thousand.
     */
    fun wageFor(quality: Int): Int =
        max(400, ((170.0 * Math.pow(1.0483, quality.toDouble())) / 50.0).roundToInt() * 50)

    /**
     * Builds a backroom team for a club: one of each senior post plus a couple
     * of coaches, all pitched around what the club could realistically attract.
     */
    fun buildFor(rng: Rng, clubRep: Int, nation: Nation, nextId: () -> Int): ArrayList<Staff> {
        val out = ArrayList<Staff>(6)
        fun add(role: Int, bias: Int = 0) {
            val q = (expectedQuality(rng, clubRep) + bias).coerceIn(20, 95)
            out.add(Staff(nextId(), Names.make(rng, nation).full, role, q, wageFor(q)))
        }
        add(StaffRole.ASSISTANT, 2)
        add(StaffRole.COACH)
        add(StaffRole.COACH, -4)
        add(StaffRole.PHYSIO)
        add(StaffRole.SCOUT)
        add(StaffRole.YOUTH)
        return out
    }

    /* --------------------------------------------------------- EFFECTS */

    private fun best(staff: List<Staff>, role: Int): Int =
        staff.filter { it.role == role }.maxOfOrNull { it.quality } ?: 40

    private fun meanOf(staff: List<Staff>, role: Int): Int {
        val f = staff.filter { it.role == role }
        return if (f.isEmpty()) 40 else f.sumOf { it.quality } / f.size
    }

    /**
     * Training multiplier from the coaching staff. A full complement of good
     * coaches is worth roughly a third again on development; a skeleton staff
     * costs about a quarter of it.
     */
    fun coachingFactor(staff: List<Staff>): Double {
        val q = meanOf(staff, StaffRole.COACH)
        val count = staff.count { it.role == StaffRole.COACH }.coerceAtMost(3)
        val depth = 0.88 + count * 0.05
        return (0.72 + q / 145.0) * depth
    }

    /** Weeks off an injury, and how fast condition comes back. */
    fun physioFactor(staff: List<Staff>): Double {
        val q = best(staff, StaffRole.PHYSIO)
        // 0.70 at the very top, 1.18 with nobody worth the name
        return (1.30 - q / 155.0).coerceIn(0.68, 1.20)
    }

    /** How wrong a scout report can be, in rating points either way. */
    fun scoutError(staff: List<Staff>): Int {
        val q = best(staff, StaffRole.SCOUT)
        return ((95 - q) / 8.0).roundToInt().coerceIn(1, 11)
    }

    /** Quality multiplier on each summer's youth intake. */
    fun youthFactor(staff: List<Staff>): Double {
        val q = best(staff, StaffRole.YOUTH)
        return 0.74 + q / 170.0
    }

    /** How much of the opposition's shape the assistant can tell you. */
    fun assistantInsight(staff: List<Staff>): Int = best(staff, StaffRole.ASSISTANT)

    /** The weekly cost of the backroom. */
    fun wageBill(staff: List<Staff>): Int = staff.sumOf { it.wage }
}
