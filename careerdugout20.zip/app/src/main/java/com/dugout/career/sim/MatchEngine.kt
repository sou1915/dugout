package com.dugout.career.sim

import com.dugout.career.core.*
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ------------------------------------------------------------ LIVE PLAYER */

/** A footballer as the match sees him: a position on the pitch and a match rating. */
class LivePlayer(
    val key: String,
    val side: Int,           // 0 home, 1 away
    val slot: Int,
    val pos: Int,
    val ref: Player
) {
    var x = 50f; var y = 50f
    var targetX = 50f; var targetY = 50f
    /**
     * ENGINE V4, IDEA 1: BE THERE IN THIS MANY SECONDS.
     *
     * Zero means "no deadline, use the ordinary effort table". Anything above
     * zero is a promise: he works out for himself how fast he has to move to
     * make it, instead of being handed a multiplier that knows nothing about
     * how long he has got. Counted down by the mover.
     */
    var arriveBy = 0f

    /*
     * ENGINE V4, IDEA 4: EVERY MAN KNOWS WHAT HE IS DOING.
     *
     * Until now the match had ONE description of the situation -- ball.holder,
     * a single v2Think timer, a single v2PassTo -- and twenty two players who
     * read it. Nobody carried any state of his own, so no player could know
     * "I have the ball" or "a pass is coming to me"; he could only look at a
     * global variable and infer it. Two things follow from that and both are
     * visible on the pitch:
     *
     *  - the time on the ball was global, so a turnover handed the new man
     *    whatever was left of the old man's think;
     *  - the intended receiver of a pass did not know he was the intended
     *    receiver, so he did not move to meet it.
     *
     * Now each man carries his own mind. It is his, it is set the instant it
     * becomes true, and it is what the mover and the decision layer both read.
     */
    var mind = Mind.SHAPE
    /** Seconds of thinking left on the ball. His, not the match's. */
    var thinkLeft = 0f
    var baseX = 50f; var baseY = 50f

    var shirt = 1
    var effective = 60.0
    var fitness = 100.0

    var goals = 0; var assists = 0; var tackles = 0; var saves = 0
    var passes = 0; var shots = 0; var yellow = 0
    var dribbles = 0
    var sentOff = false
    var injured = false
    var injuryWeeks = 0
    var onPitch = true
    var minutes = 0.0
    var rating = 6.5

    /** Where he is looking, in radians. Drives which way the body is drawn. */
    var facing = 0f
    /** Advances while running so the legs and arms swing. */
    var runPhase = 0f
    var speedNow = 0f
    /** Velocity in pitch units per second. Engine v3 integrates this. */
    var vx = 0f
    var vy = 0f
    /** Current running speed, eased toward the target so he accelerates. */
    var gaitSpeed = 0f
    /** True while he is in position and standing rather than adjusting. */
    var settled = false
    /** The way he is actually travelling. Turns at a limited rate. */
    var heading = 0f
    var headingSet = false

    /**
     * A JOB: a specific place this man has been told to attack, and how long
     * the instruction lasts.
     *
     * Patterns used to shape only the ball. A cross was worked wide and swung
     * in and NOBODY WAS IN THE BOX, because every player was still standing in
     * his formation slot doing nothing about it. A job is the other half: when
     * a cross starts, somebody is sent to the near post, somebody to the
     * penalty spot, somebody to the back post — before the ball arrives.
     *
     * Jobs expire on their own, so nothing can get stuck out of position.
     */
    var jobX = 0f
    var jobY = 0f
    var jobTime = 0f

    /**
     * Whether the current job is a defensive one. An attacking job must not be
     * obeyed after the ball has been lost, and a defensive one must not be
     * obeyed after it has been won, or a man would run to the wrong end.
     */
    var jobDefensive = false

    /**
     * How hurried this man is, 0 to 1. Recomputed every tick from the opponents
     * around him. See pressureOn.
     */
    var pressure = 0f

    var action = Act.RUN
    var actionTime = 0f
    var actionDir = 0f

    val name: String get() = ref.last
    val fullName: String get() = ref.full
}

/** What a player is doing right now — the renderer draws each one differently. */
object Act {
    const val RUN = 0
    const val TACKLE = 1        // sliding in
    const val SHOOT = 2         // striking the ball
    const val DIVE = 3          // keeper going down
    const val CELEBRATE = 4     // arms up
    const val DRIBBLE = 5       // knocking it past a man
    const val DOWN = 6          // injured, on the floor
    const val HEADER = 7        // rising to meet a cross
}

/* ----------------------------------------------------------------- EVENTS */

object Ev {
    const val GOAL = 0; const val YELLOW = 1; const val RED = 2
    const val SUB = 3; const val INJURY = 4; const val PENALTY = 5
}

class MatchEvent(val minute: Int, val type: Int, val side: Int, val player: String, val extra: String = "")

class FeedLine(val minute: Int, val text: String, val kind: Int) {
    companion object {
        const val PLAIN = 0; const val GOAL = 1; const val CARD = 2
        const val CHANCE = 3; const val SUB = 4; const val WHISTLE = 5
    }
}

/* ------------------------------------------------------------------- BALL */

class Ball {
    var x = 50f; var y = 50f
    var fromX = 50f; var fromY = 50f
    var toX = 50f; var toY = 50f
    var t = 1f
    var duration = 0.4f
    /** Current height above the turf. Zero for anything played along the floor. */
    var height = 0f
    /** How high this particular delivery was struck. Most passes are flat. */
    var loft = 0f
    var rolling = false
    var holder: String? = null

    /** How fast it is still travelling, so it can roll on after it arrives. */
    var driftX = 0f
    var driftY = 0f
    /** Spin, purely so the ball visibly rotates as it runs. */
    var spin = 0f
    /** Vertical velocity once it is off the pass arc and bouncing on its own. */
    var vz = 0f
    /** Sideways bend on this delivery, so a long ball is not a straight line. */
    var curve = 0f
    /**
     * Velocity, in pitch units per second. Engine v3 integrates these instead
     * of interpolating between fromX/toX, which is what lets the ball be
     * deflected, misplaced or run out of play as a CONSEQUENCE rather than as
     * something the caller had to arrange.
     */
    var vx = 0f
    var vy = 0f
    /** Sideways acceleration from spin, applied only while it is airborne. */
    var spinRate = 0f
    /** True while this delivery is a shot rather than a pass to a team mate. */
    var struck = false

    /**
     * ENGINE V4, IDEA 5: this delivery is being flown by Physics.kt.
     *
     * The rest of the engine keeps reading `t < 1` to mean "in flight", so a
     * physics delivery still sets t to 0 when it is struck and to 1 when it
     * comes to rest or is claimed. That is what lets the interception, the
     * boundary, the claim and the goal-waiting code all carry on unchanged
     * while the ball underneath them stops being an interpolation.
     */
    var phys = false
    /** Where it will come to rest, and in how long: x, y, seconds. */
    @JvmField val rest = FloatArray(3)
}

/* --------------------------------------------------------------- SET PIECE */

/** Staged moments the renderer can frame differently: corners and penalties. */
/**
 * ENGINE V4, IDEA 4: what a single player believes about himself right now.
 *
 * Deliberately about HIM, not about the match. `Scene` says what the game is
 * doing; `Mind` says what this one man is doing and why he is moving where he
 * is moving. It is the difference between twenty two figures reading one global
 * situation and eleven footballers each with a job.
 */
object Mind {
    /** Holding his shape, nothing to do with the ball. */
    const val SHAPE = 0
    /** He has it, and he is thinking. */
    const val ON_BALL = 1
    /** A pass has been struck AT HIM and he is going to meet it. */
    const val EXPECTING = 2
    /** It is loose and he is the one going for it. */
    const val CHASING = 3
    /** He is closing down the man on the ball. */
    const val PRESSING = 4

    val LABEL = arrayOf("shape", "on the ball", "expecting", "chasing", "pressing")
}

object Scene {
    const val NONE = 0; const val CORNER = 1; const val PENALTY = 2; const val FREEKICK = 3
    const val THROW_IN = 4; const val GOAL_KICK = 5; const val KICK_OFF = 6
    const val LINEUP = 7; const val SUBSTITUTION = 8
    const val CARD = 9; const val TAKE_ON = 10
    const val SAVE = 11; const val TACKLE = 12; const val SHOT = 13
    val LABEL = arrayOf("", "CORNER", "PENALTY", "FREE KICK", "THROW-IN", "GOAL KICK",
        "KICK OFF", "TEAMS ARE OUT", "SUBSTITUTION", "BOOKING", "TAKE-ON",
        "SAVE", "TACKLE", "SHOT")

    /**
     * Live play, not a stoppage: the ball is still being contested, so none of
     * the dead-ball rules apply -- nobody freezes and nobody slows down. These
     * scenes name what is happening without interrupting it.
     */
    fun isLive(s: Int) = s == NONE || s == TAKE_ON || s == SAVE || s == TACKLE || s == SHOT
}

/* ------------------------------------------------------------------ ENGINE */

/**
 * A phase-based match. Each spell of possession is built pass by pass and
 * resolved from the two sides' attack, defence and control ratings, so the
 * scorelines match the quick simulation while still playing out on a pitch.
 */
class MatchEngine(
    val world: World,
    val season: Season,
    val fixture: Fixture
) {
    val home: Club = world.club(fixture.homeId)!!
    val away: Club = world.club(fixture.awayId)!!

    val players = ArrayList<LivePlayer>(30)
    val ball = Ball()
    val feed = ArrayList<FeedLine>(120)
    val events = ArrayList<MatchEvent>(40)

    var clock = 0.0                  // match minutes
    var addedTime = 0.0

    /**
     * Match time spent with the ball out of play for a staged set piece, added
     * back on at the end of the half the way a referee adds it on.
     */
    private var stoppage = 0.0
    /** The referee's own allowance, before stoppage is added on. Rolled once. */
    private var addedBase = 0.0
    var half = 1
    var running = false
    var finished = false
    var speed = 1f
    var kicked = false

    val score = intArrayOf(0, 0)
    val shots = intArrayOf(0, 0)
    val onTarget = intArrayOf(0, 0)
    val corners = intArrayOf(0, 0)
    val fouls = intArrayOf(0, 0)
    val yellows = intArrayOf(0, 0)
    val reds = intArrayOf(0, 0)
    val passesTotal = intArrayOf(0, 0)
    val xg = doubleArrayOf(0.0, 0.0)
    val possession = doubleArrayOf(0.0, 0.0)

    /** Successful take-ons by a side, summed from the players. */
    fun takeOns(side: Int): Int = players.filter { it.side == side }.sumOf { it.dribbles }

    val subsLeft = intArrayOf(5, 5)
    private var subsMade = intArrayOf(0, 0)
    val benchHome = ArrayList<Player>(7)
    val benchAway = ArrayList<Player>(7)

    var momentum = 0.0               // -1 away .. +1 home
    var attendance = 0
    var weatherRain = false
    var night = false

    // presentation state the renderer reads
    var flash = 0f
    var shake = 0f
    var banner: String? = null
    var bannerTime = 0f
    var celebrateKey: String? = null
    var celebrateTime = 0f
    var scene = Scene.NONE
    var sceneTime = 0f
    /**
     * A scene waiting its turn. A save is followed by a corner or a goal kick
     * in the SAME call, so the set piece overwrote the save before a single
     * frame of it was drawn -- SceneCheck measured 1.1 saves a match against
     * 5.7 shots on target. The set piece is queued behind the moment instead.
     */
    /**
     * How long the pitch stays ARRANGED for a set piece, in seconds.
     *
     * Separate from the caption on screen, and that separation is the whole
     * point. updateTargets used to hold staged positions only while
     * `scene == CORNER`, but stageCorner runs when the corner is CONCEDED --
     * at which moment the caption is still SAVE, or nothing at all -- so the
     * arrangement was wiped by the next tick's formation targets before it
     * could take effect. stageFreeKick was worse: FREEKICK was never in that
     * list, so the wall was overwritten the instant it was built.
     *
     * The arrangement now starts when the set piece is awarded and outlives the
     * caption, which is also what gives men time to walk into the box.
     */
    private var stagedUntil = 0f
    private var queuedScene = Scene.NONE
    private var queuedTime = 0f

    // the official: he only appears when he has something to do
    var refX = 50f
    var refY = 46f
    var cardedKey: String? = null   // the man being booked, for the scene
    var refCard = 0            // 0 none, 1 yellow, 2 red
    var refTime = 0f
    var freeKickX = 0f
    var freeKickY = 0f
    var wallX = 0f
    var wallY = 0f
    var wallCount = 0

    // replay: a short ring of ball positions captured before every goal
    class Frame(val ballX: Float, val ballY: Float, val xs: FloatArray, val ys: FloatArray)
    private val history = ArrayList<Frame>(160)
    var replay: List<Frame>? = null
    var replayIndex = 0

    /**
     * The replay waits for the celebration to breathe before it cuts in, then
     * runs back slower than life. History is captured once per update, so a
     * cursor step below 1 is slow motion.
     */
    /**
     * Replays are presentation. A headless run — the balance check, or simming
     * the rest of the week — has nobody to show them to, so it turns them off
     * and saves both the frame history and the pause after every goal.
     */
    var replaysEnabled = true

    private var pendingReplay: List<Frame>? = null
    var replayDelay = 0f
    private var replayCursor = 0f
    /** History is captured once per update, so this is a fraction of live speed. */
    private val REPLAY_RATE = 0.5f
    private val CAPTURES_PER_SECOND = 36f

    /**
     * Advances the replay from elapsed time and reports whether one is still
     * running. Driven from [update] so the engine is never waiting on a caller
     * to unstick it: a headless run finishes a match exactly like the UI does.
     */
    private fun advanceReplay(dtSeconds: Float): Boolean {
        val rp = replay ?: return false
        replayCursor += dtSeconds * CAPTURES_PER_SECOND * REPLAY_RATE
        replayIndex = replayCursor.toInt()
        if (replayIndex >= rp.size) {
            replay = null; replayIndex = 0; replayCursor = 0f
            crowdTarget = 0.55f
            return false
        }
        return true
    }

    /* ------------------------------------------------------------- SOUND */

    /**
     * A record of what happened and where -- NOT a noise.
     *
     * The mixer these used to feed is gone: the owner asked for the game to be
     * silent, so ui/MatchAudio.kt is deleted and core/Synth.kt is down to the
     * eleven constants that name the moments. The list stays because it is part
     * of the simulation's account of the match, not part of its presentation,
     * and about thirty harnesses read or drain it. The match screen still
     * drains it each frame; nothing listens.
     */
    class SoundCue(val kind: Int, val gain: Float, val pan: Float)

    val sound = ArrayList<SoundCue>(16)

    /** 0 quiet, 1 boiling. The bed slides toward this. */
    var crowdTarget = 0.30f

    /** True when these two do not like each other. Set once at kick off. */
    var isDerby = false


    /* ------------------------------------------------------- CELEBRATION */

    /**
     * Set when a side sent everyone up for a corner. If it does not go in, the
     * next attack the other way starts from further forward, which is the cost
     * of committing bodies.
     */
    private var cornerExposure = -1

    /**
     * Woodwork. Set when a shot comes back off the frame so the renderer can
     * flash the bar and shake the goal; the ball rebounds from it as well,
     * which it never used to do.
     */
    /** Where the corner is being taken from, for the renderer. */
    var cornerFlagX = 0f
    var cornerFlagY = 0f

    /**
     * A piece of skill: which trick, and how long is left of it. Separate from
     * a plain take-on so a flair player is visibly doing something the honest
     * runner does not.
     */
    var skill = 0f
    var skillName = ""
    var skillKey: String? = null

    /**
     * How dangerous the moment is, 0 to 1.
     *
     * The match screen watches this. Ordinary build-up play is shown from
     * above as counters on a board, which is what most of a football match
     * actually is; when this climbs the camera drops to the broadcast view and
     * you see the players properly. Cutting between the two is what makes a
     * chance feel like a chance rather than one more phase of possession.
     */
    var danger = 0f

    /** Set for a moment when something has just happened, to hold the camera in. */
    private var dangerHold = 0f

    /** Forces the close view for a spell, used by shots, set pieces and cards. */
    fun holdDanger(seconds: Float) {
        dangerHold = max(dangerHold, seconds)
    }

    private fun updateDanger(dtSeconds: Float) {
        dangerHold = max(0f, dangerHold - dtSeconds)

        // how far into the final third the ball is, from the attacking side's view
        val toGoal = if (possessionSide == 0) 100f - ball.x else ball.x
        var d = when {
            toGoal < 20f -> 1.00f      // in and around the box
            // deliberately under the cut-in level: simply being in the final
            // third is not an event, and if the camera comes in for it there is
            // nothing left to escalate to when a chance actually arrives
            toGoal < 30f -> 0.45f
            toGoal < 44f -> 0.20f
            else -> 0.02f
        }
        // The last ball of a move only matters if it is being played somewhere
        // that could hurt. Without the distance test this fired at the end of
        // every phase wherever the ball was, and the match sat in the close
        // camera for nearly all ninety minutes.
        if (phaseSeq.isNotEmpty() && phaseStep >= phaseSeq.size - 1 && toGoal < 28f) {
            d = max(d, 0.66f)
        }
        if (scene == Scene.PENALTY) d = 1f
        if (scene == Scene.CORNER || scene == Scene.FREEKICK) d = max(d, 0.85f)
        if (celebrationTime > 0f || replay != null) d = 1f
        if (refCard > 0 || woodwork > 0f || skill > 0f) d = max(d, 0.9f)
        if (dangerHold > 0f) d = 1f

        // rise quickly, fall away slowly: television does not cut away the
        // instant a chance breaks down
        val rate = if (d > danger) 6.5f else 1.1f
        danger += (d - danger) * min(1f, dtSeconds * rate)
    }

    var woodwork = 0f
    var woodworkX = 0f
    var woodworkY = 0f
    /** True for the crossbar, false for a post. */
    var woodworkBar = false

    /**
     * A goal that has been decided but not yet arrived.
     *
     * The shot roll happens the instant a phase resolves, while the ball is
     * still on its way to the net. Awarding the goal there meant the score, the
     * banner and the crowd all went up with the ball in midfield, and the replay
     * — captured at the same moment — ended a good thirty units short of the
     * goal line, so it never showed the actual goal. The goal now waits for the
     * ball to get there.
     */
    private class PendingGoal(val att: Int, val shooterKey: String, val penalty: Boolean)

    private var pendingGoal: PendingGoal? = null

    /** Seconds left of the walkout before the first whistle. */
    var lineupTime = 0f
    private var lineupDone = false

    /** Seconds left of the scene that follows a goal. */
    var celebrationTime = 0f
    private var celebrateSide = -1
    /**
     * Held separately from [celebrateKey], which the sparkle clears after 2.4s.
     * The run itself outlasts that, and without its own reference the team-mates
     * lost the man they were chasing halfway through.
     */
    private var celebrateScorer: String? = null
    private var celebrateRunX = 0f
    private var celebrateRunY = 0f

    /**
     * Cosmetic rolls come from their own stream. Sharing the match RNG would
     * mean a sound effect could change a scoreline, which is why the balance
     * figures still hold after all of this.
     */
    /**
     * Presentation only: commentary lines, the name of a skill move, which way
     * the keeper throws himself. Nothing drawn from here may move the ball or a
     * player, so draws can be added and removed freely.
     *
     * THAT USED NOT TO BE TRUE, and several comments in this file asserted it
     * anyway — "rolled on the cosmetic stream so it cannot move a result".
     * Measured: a single sfxRng draw inserted per phase and used for NOTHING
     * moved goals per game from 2.850 to 2.750 over 200 matches and changed
     * every score in the run. The path was the bend on a delivery, which is
     * drawn from this stream and physically moves the ball; the ball's position
     * sets which players chase and how hard they run, their positions decide
     * who is standing near the man on the ball, and nextMan picks the next man
     * in a move by exactly that. A "cosmetic" roll reached the scoreline in
     * four steps.
     *
     * So anything that genuinely moves something now draws from [physRng]
     * instead, and this stream is what it always claimed to be.
     * ResultFingerprint is the check: adding a draw here must leave it byte
     * identical.
     */
    private val sfxRng = Rng(fixture.id * 104729L + 17)

    /**
     * Rolls that look cosmetic and are not: the bend on a delivery, and where a
     * shot comes back off the frame. Both move the ball, so both can change who
     * ends up with it. Kept on their own stream so that adding a commentary
     * line or a skill move cannot shift them.
     */
    private val physRng = Rng(fixture.id * 96137L + 43)

    private fun cue(kind: Int, gain: Float = 1f, atX: Float = 50f) {
        if (sound.size > 24) return
        sound.add(SoundCue(kind, gain, ((atX - 50f) / 50f).coerceIn(-1f, 1f)))
    }

    var possessionSide = 0
    private var ratingHome = world.teamRating(home, true)
    private var ratingAway = world.teamRating(away, false)

    private var phaseSeq: MutableList<LivePlayer> = ArrayList()
    private var phaseStep = 0
    /** Exposed only so the harness can tell an opening ball from a pass. */
    val phaseStepPublic: Int get() = phaseStep
/** The shape of the move now being played. See PAT_* in the companion. */
    var phasePattern = 0
        private set

        private var phaseOutcome = 0
    private var phaseGap = 0.0
    private var phaseTimer = 0.0
    private var phaseDuration = 1.0
    private var pendingSide = -1
    private var pendingAt = 0.0
    private var ambientTimer = 0.0
    private var rng = Rng(world.seed + fixture.id * 7919L + world.week)

    private val usedLines = HashMap<Int, MutableList<Int>>()

    companion object {
        const val OUT_TURNOVER = 0; const val OUT_SHOT = 1
        const val OUT_FOUL = 2; const val OUT_CORNER = 3; const val OUT_THROW = 4
        /**
         * How many real seconds one match minute takes at 1x speed.
         *
         * This is the number that decides whether the ball can behave. Player
         * speeds and ball flight are in REAL seconds -- a man runs at 7 m/s, a
         * twenty-unit pass takes 1.26 s -- while the match clock runs on this
         * compression. At 1.15 a whole 90-minute match occupied 103 seconds of
         * ball time, a 52x compression, so one pass ate 82% of the match-time
         * budget of the entire move it belonged to. The engine coped by
         * striking the ball again in mid-air, which is what put a kink in 73%
         * of flights.
         *
         * Raising it does NOT change how many moves a match contains:
         * phaseDuration is in match minutes and the half is 45 match minutes,
         * so the count of phases is fixed at about 90/phaseDuration whatever
         * this is set to. It buys the ball real time inside each move, and
         * costs only how long the match takes to watch -- and there is a
         * 1x/2x/4x control for that.
         *
         * Swept by ClockCheck.
         */
        @JvmField var SECONDS_PER_MINUTE = 4.0

        /** Close enough to his station that he stops moving. */
        const val SETTLE_ENTER = 1.9f

        /** And far enough out of it that he sets off again. */
        const val SETTLE_LEAVE = 3.4f

        /** The middle of a drawn formation, in base pitch units. */
        const val SHAPE_MID = 48f

        /**
         * How much of the drawn spread a side actually keeps. The shapes span
         * about 56 units back to front; 0.62 of that is a little over 35 m,
         * which is where a compact side lives.
         */
        const val SHAPE_COMPACT = 0.62f

        /** How much faster than its average a struck ball leaves the boot. */
        const val LAUNCH_RATIO = 1.55f

        /** Hardest average speed any delivery may carry, in metres per second. */
        const val MAX_BALL_MPS = 26f

        /**
         * Beyond this many metres from goal a man is not the one who shoots;
         * the chance falls to whoever is nearest instead. Set wide on purpose —
         * this exists to rule out shots from the shooter's own half, not to
         * police shot selection.
         */
        const val SHOT_RANGE_M = 40.0

        /**
         * How often a save is parried back into play rather than held. A real
         * keeper holds most of what he reaches; this is the share that spills
         * to a striker and becomes a second chance.
         */
        const val REBOUND_CHANCE = 0.20

        /**
         * The named shapes a move can take.
         *
         * A phase used to be a shapeless run of passes: there was no such thing
         * as a cross, a counter or a ball in behind, only "the next man near
         * enough". That is why the football read as messy however well the
         * numbers behaved, and why there were no scenes to speak of — a scene
         * IS a pattern. Each one owns its own geometry, so what appears on
         * screen is a recognisable move rather than an emergent accident.
         *
         * The pattern is drawn LIVE, per phase, from the side's current
         * tactics. It is deliberately not scripted in advance: a match authored
         * at kick-off cannot respond to a shout at sixty minutes, which would
         * make the touchline permanently pointless rather than merely hard to
         * see.
         */
        const val PAT_BUILD = 0      // patient, short, through the middle
        const val PAT_CROSS = 1      // work it wide, then into the box
        const val PAT_THROUGH = 2    // a ball in behind the last man
        const val PAT_COUNTER = 3    // few touches, straight up the pitch
        const val PAT_LONGSHOT = 4   // worked to the edge and struck
        val PATTERN_NAME = arrayOf("build-up", "cross", "through ball", "counter", "long shot")

        /**
         * Quality of an ordinary chance before the phase gap and the finisher's
         * own ability move it — in effect the xG of an average shot. This is
         * THE balance lever. The on-target and conversion split below it is xG
         * neutral by construction, so moving that changes nothing at all.
         *
         * Raised from 0.086 after the seeding fix, then from 0.099 to 0.107
         * when set pieces were made visible.
         *
         * A note on the 0.099 era, because it is the more useful lesson: the
         * brief called for a retune on the grounds that the top flight read
         * 2.45 / 2.52 / 2.70 across three world seeds. Those came off 400-match
         * runs, which carry a standard error of 0.08 goals — plus or minus 0.16
         * at 95% — so the whole spread was inside the noise, and 0.099 measured
         * 2.58 +/- 0.03 over 9,120 matches. It was already centred and was left
         * alone. Measure before touching this.
         *
         * What moved it since was staging corners and free kicks so they can
         * actually be seen. That takes the ball out of play, and even with the
         * pause added back as stoppage time the match lost some of its phase
         * budget: 2.57 became 2.49. Swept again against the new timing —
         * 0.099 gives 2.49, 0.103 gives 2.55, 0.107 gives 2.61 — so 0.107 puts
         * it back where it was.
         *
         * A var, not a const, only so BalanceBig can sweep it without a rebuild
         * of the whole app between values. Nothing in the game writes to it.
         */
        // Opening up the match clock and shortening the move put the chance
        // count back, and the same number of shots then converted a little
        // better: 0.113 gave 2.80 goals a game over 9,120 matches. Trimmed by
        // exactly the ratio each measurement asked for -- 0.113 -> 0.1066 gave
        // 2.71, and 0.1066 -> 0.1038 for the last of it -- rather than moving
        // the move length again and undoing the shot count just restored.
        /*
         * THE V1 LEVER. IT DOES NOTHING UNDER THE SHIPPING ENGINE.
         *
         * Found while re-earning balance for engine v4 idea 3: moving this from
         * 0.1038 to 0.0995 -- a 4% cut -- left `BalanceBig` reading 2.71 goals,
         * 46.9% home and 0.97 cards, identical to three figures on all three.
         * A lever that changes nothing is not a lever.
         *
         * The reason is plain once looked for: this feeds `resolvePhase`, which
         * is the v1 phase engine's chance quality, and v2 scores its own shots
         * through V2_SHOT_BASE. It has been dead since ENGINE_V2 was switched
         * on, and `BalanceBig sweep` has been sweeping it ever since.
         *
         * Left at its v1 value, because v1 is still in the build as the control
         * row that makes findings provable. V2_SHOT_BASE is the live lever.
         */
        @JvmField var CHANCE_QUALITY = 0.1038

        /**
         * Build a move by advancing the ball rather than by hopping between
         * whoever is standing nearby. See buildSequenceV2 in newPhase. A var so
         * the harnesses can measure both without a rebuild between them.
         */
        @JvmField var SPATIAL_V2 = true

        /**
         * Player Jobs: a pattern sends named men to named places, so a cross
         * arrives at bodies instead of at nobody. A var so a harness can run
         * the same fixture with and without them and print the difference,
         * which is the only way to know whether they cost the team its shape.
         */
        @JvmField var JOBS = true

        /**
         * How long a job lasts, in seconds. It has to outlive the walk up the
         * pitch: a job assigned when the phase begins and expired before the
         * cross is struck puts nobody in the box, which is the bug it exists to
         * fix. Swept by BoxCheck over 200 matches a config:
         *
         *            attackers in box   box empty   block    goals
         *   jobs off       1.03           49.9%     19.9 m    2.77
         *   4.5s           1.00           48.0%     20.2 m    2.79
         *   8.0s           1.16           43.9%     20.3 m    2.65
         *   12.0s          1.16           44.8%     20.4 m    2.67
         *
         * 4.5s does nothing at all — the job expires during the walk up the
         * pitch, before the delivery. 8s and 12s are the same result, so 8 is
         * the shorter instruction that still outlives the move.
         */
        @JvmField var JOB_SECONDS = 8.0f

        /**
         * The pressure layer. A pass goes to the man in space rather than to
         * whoever happens to be nearest a geometric aim point, which is the
         * "space first, player second" rule of the V3 design. Off until it has
         * been measured against the same fixtures with it on.
         */
        @JvmField var PRESSURE = true

        /**
         * How much being marked costs a man in the receiver choice, in metres
         * of apparent extra distance at full pressure. Swept by PressureCheck.
         */
        // PressureCheck, 16 matches a row, same fixtures:
        //
        //   weight   receiver pressed   team average   went to the MOST marked
        //   off           0.353             0.277             17.8%
        //   6            0.349             0.281             17.1%
        //   12           0.336             0.280             15.7%
        //   20           0.309             0.280             13.6%
        //
        // With the layer off the receiver is MORE pressed than the average team
        // mate: the ball systematically found marked men.
        //
        // 20 was tried and put back: it finds the most space of the three but
        // BalanceBig came in at 2.47 goals over 9,120 matches, under the 2.5-2.7
        // band, because a side that always passes into space concedes fewer
        // turnovers and so creates fewer chances. 12 is the strongest setting
        // the result model accepts.
        @JvmField var PRESSURE_WEIGHT = 12.0f

        /**
         * A defender whose goal is under attack sprints back instead of jogging.
         * See the note in moveTowardTargets. A var so DefendCheck can run the
         * same fixtures with it off.
         */
        @JvmField var RECOVER = true

        /**
         * How near a side's own goal the ball has to be, in pitch units, before
         * being out of position counts as an emergency. 35 is a little beyond
         * the edge of the D. Swept by DefendCheck.
         */
        @JvmField var RECOVER_RANGE = 35f

        /**
         * The ball advances itself along its flight instead of being placed at a
         * point computed from its aim. See the long note in the flight block.
         * A var so BallJump can measure both on the same fixtures.
         */
        @JvmField var BALL_AGENT = true

        /**
         * Defenders protect zones in front of their own goal once an attack
         * reaches them. See assignDefensiveJobs.
         */
        @JvmField var DEF_JOBS = true

        /**
         * How near a side's own goal the ball must be, in pitch units, before
         * the zones are handed out. Swept by DefendCheck.
         */
        @JvmField var DEF_JOB_RANGE = 33f

        /**
         * A move waits for the ball: no pass is struck while the previous one is
         * still in the air.
         *
         * This is what stops the ball moving suddenly with nobody near it. It
         * could not be turned on until the clock was fixed, because on its own
         * it cost 1.7 goals a game -- a move that has to let every pass land
         * takes far longer, so a match held far fewer of them.
         *
         * ClockCheck, 40 matches a row, seed 20260727:
         *
         *   s/min  scale  ball    goals  shots  passes  kinks  flights kinked
         *   1.15   1.00   no       2.78   28.8   181.4  121.7       54%
         *   4.00   1.00   waits    2.20   22.7   144.0    7.9        3%
         *   4.00   0.85   waits    2.85   26.5   162.3   11.6        3%
         *   4.00   0.75   waits    2.75   28.0   178.5   14.4        4%
         *   4.00   0.65   waits    3.28   30.2   192.1   19.6        5%
         *
         * 0.75 puts the shot and pass counts back where they were -- 28.0
         * against 28.8, 178.5 against 181.4 -- while the share of flights
         * containing a kink falls from 54% to 4%.
         */
        @JvmField var WAIT_FOR_BALL = true

        /**
         * Multiplies the nominal length of a move. Below 1 a match contains
         * more of them. Swept by ClockCheck alongside SECONDS_PER_MINUTE.
         */
        @JvmField var PHASE_SCALE = 0.75

        /**
         * How near the ball a defender has to be, in metres, before a
         * dispossession is played as a slide. Beyond this he wins it standing
         * up, because a slide tackle aimed at a ball five metres away is a man
         * diving at grass. A slide is begun from a few metres out, so this is
         * not the distance he ENDS at -- SlideCheck, 20 matches:
         *
         *   reach   slides/match   mean distance   over 5 m away
         *   none         9.5           5.0 m           39%
         *   2.6 m        1.9           2.0 m            3%
         *   3.5 m        2.7           2.0 m            2%
         *   4.5 m        3.7           2.0 m            1%
         *   5.5 m        4.8           2.6 m            2%
         *
         * 5.5 lands inside the real 4-6 slides a match while all but 2% of them
         * are now made at the ball.
         */
        @JvmField var SLIDE_REACH_M = 5.5

        /**
         * Players behave differently when the ball is dead: they stop sprinting
         * at a stoppage, and a booking is staged rather than merely captioned.
         * See sceneTargets. A var so SceneCheck can measure both ways.
         */
        @JvmField var SCENE_AI = true

        /**
         * How long a corner and a free kick hold before the ball is played.
         *
         * These were 1.3 s and 2.0 s. The staging sends every attacker thirty
         * units to the penalty area and a man covers about four of them in that
         * time, so the arrangement was set, nobody arrived, and the scene ended
         * before the delivery. A caption was drawn over a set piece that had not
         * happened yet, which is why the scenes still read as missing after they
         * were given captions. Swept by StagingCheck.
         */
        // StagingCheck, measured at the moment the set piece is TAKEN, once the
        // arrangement was made to outlive the caption and men in transit were
        // allowed to travel to it:
        //
        //   corner    attackers   defenders   in position
        //   1.3 s        1.04        1.96         34%
        //   6.0 s        2.90        3.61         43%
        //   8.0 s        3.43        3.81         42%
        //   10.0 s       3.80        4.00         51%
        //
        // Against a real five or six attackers and eight defenders. 8 s is where
        // it stops being cheap: 8.7 corners a match at ten seconds each is a
        // fifth of the whole match spent watching corners be set up, and there
        // is a 1x/2x/4x control for anyone who disagrees.
        /*
         * Lowered from 8.0 now that the delivery is tied to it.
         *
         * The table above was read off StagingCheck, which samples the box at
         * the tick the CORNER CAPTION expires, on the stated assumption that
         * "the tick the corner scene ends is the tick it gets delivered". That
         * assumption was false. The delivery was booked by shootAfterScene at
         * clock + 0.60 MATCH MINUTES -- 2.4 real seconds at 1x -- while the
         * caption ran 8 s and the arrangement 9.6 s. So every figure in that
         * table was measured between three and seven seconds AFTER the ball had
         * already been swung in.
         *
         * Measured at the instant the ball actually leaves the flag, 20
         * matches: 2.23 attackers in the box, not 3.43. And because the
         * delivery was in match minutes while the hold was in raw real seconds,
         * it arrived at 2.38 s at 1x, 1.19 s at 2x and 0.59 s at 4x -- the
         * corner was struck almost immediately at the speed most people watch
         * at, into an empty box. That, and not a broken staging gate, is the
         * "corner captioned over an empty box": the gate was measured open on
         * 100% of corners with 9.32 s still on it.
         *
         * The delivery is now taken from the hold (see SET_PIECE_TAKE), so the
         * two cannot drift apart again.
         *
         * The hold itself is UNCHANGED at 8.0. Shortening it to 5.0 was tried,
         * on the reasoning that the whole of it is dead time now that something
         * actually reads it, and measured worse on both counts: 1.87 attackers
         * in the box at the delivery against 3.09 at 8.0, and goals per game
         * fell to 2.18 from a 2.90 control. The number was right all along; it
         * was the delivery that was not listening to it.
         */
        @JvmField var CORNER_SECONDS = 8.0f
        @JvmField var FREEKICK_SECONDS = 4.4f

        /**
         * How long the throw-in and goal-kick arrangements are held, in seconds.
         *
         * The throw-in was 1.4 s and that is shorter than the ball's own
         * journey. ThrowTrace, tick by tick: the ball is rolled from where the
         * move ended to the touchline -- 36 units in one case -- and takes
         * about 1.3 s to get there, arriving on the exact tick the caption
         * expires, with the nearest man still 8 m away and play restarting on
         * top of him. The viewer was shown the word THROW-IN over a ball
         * rolling across open grass, and never the throw-in itself.
         *
         * 3.0 s covers the roll and leaves the taker time to reach it. The
         * restart is moved out to match, and the extra is given back as
         * stoppage exactly as shootAfterScene does, so no playing time is lost.
         *
         * The goal kick needs no timing change at all: its restart was already
         * at 0.6 match minutes -- 2.4 real seconds -- while its scene ran 1.3,
         * so the arrangement simply has to last as long as the wait that was
         * already there.
         */
        @JvmField var THROWIN_SECONDS = 3.0f
        @JvmField var GOALKICK_SECONDS = 2.4f

        /**
         * How long the kick-off arrangement after a goal is held, in seconds.
         *
         * A conceded goal used to jump straight back to open play: the ball was
         * simply handed to the other side wherever the celebration had left
         * everybody standing. Real football restarts from the centre spot with
         * both teams in their own half, and the pause is part of the rhythm --
         * it is the beat that lets a goal land before the game resumes.
         *
         * 3.2 s is long enough for the men to walk back into their own half at
         * the speed the mover gives them, measured, and short enough that it
         * does not feel like a stoppage.
         */
        @JvmField var KICKOFF_SECONDS = 3.2f

        /*
         * HOW LONG A POSE STAYS ON SCREEN.
         *
         * The owner reported that the match contains no scenes at all -- no
         * dribbles, no tackles, no saves, no referee. AliveCensus said the
         * opposite: 26.8 take-ons, 4.1 slides, 11.0 dives a match. Both were
         * right, because a COUNT is not a DURATION, and nobody had ever
         * measured the duration.
         *
         * PoseTime, 15 matches, seconds of a 407-second match:
         *
         *   somebody taking a man on   13.8   3.4%
         *   the keeper diving          12.5   3.1%
         *   a header                    8.6   2.1%
         *   a man sliding in            2.1   0.5%
         *   a man on the floor          2.0   0.5%
         *   the referee showing a card  2.8   0.7%
         *
         * A pose that is on screen for two seconds in seven minutes is one
         * nobody will ever catch, however well it is drawn.
         *
         * I expected lengthening DRIBBLE, HEADER and SHOOT to be free -- none
         * of the three is among the actions that stop a man moving -- and
         * ResultFingerprint says otherwise, so that expectation was wrong and
         * this is a result-affecting change, earned on BalanceBig like any
         * other. 9,120 matches after it: see AUDIT.md.
         *
         * TACKLE and DOWN are left alone for now. They DO freeze a man, so the
         * slide and the foul are still 0.5% of the match each and still need a
         * measured change of their own -- as does the referee, at 0.7%.
         */
        /*
         * THE SLIDE AND THE FOUL.
         *
         * PoseTime: a man sliding in is on screen 2.1 seconds of a 407-second
         * match, and a man on the floor 2.0. Two seconds in seven minutes, for
         * the two things the owner most wants to see.
         *
         * Both are made of two numbers and both were wrong. TACKLE_POSE was
         * 0.6 s -- a slide, a body on the grass and back up, in less time than
         * it takes to look at it -- and only 0.34 of challenges showed one at
         * all, so twelve challenges a match produced four visible slides.
         * 0.62 x 0.95 s gives about seven, which is where real football sits
         * (~6 sliding tackles in ~20 challenges).
         *
         * DOWN_POSE at 0.5 s had a fouled player up off the floor before the
         * whistle had finished. A man who has been put down stays down.
         *
         * These are NOT free. TACKLE and DOWN are two of the three actions that
         * stop a man moving, so how long they last changes who is available to
         * play the next ball -- which is exactly why they were left alone last
         * time and are being done properly now, on BalanceBig.
         *
         * act() already caps the pitch at two men on the floor at once, so
         * lengthening them cannot turn a match into a hospital scene.
         */
        /**
         * How long the referee stands there with the card up.
         *
         * 2.6 s, and with 1.16 cards a match that is 2.8 seconds of a match
         * in which he is visible at all. A real booking takes the best part of
         * ten: he stops play, walks over, takes the name, and shows it.
         */
        /*
         * ENGINE V4, IDEA 1: ARRIVE BY, NOT RUN HARD.
         *
         * Every version so far answered "how fast should this man run?" with a
         * table of distance-to-ball bands times a hand-tuned urgency. CornerFilm
         * is what that costs: told to fill the box, the attacking side closes
         * 20 m of a 40 m gap in 4.4 seconds and the corner is taken with TWO
         * attackers in it against eight defenders. No value of the multiplier
         * fixes that, because the multiplier does not know the deadline.
         *
         * So a target can now carry a TIME, and the speed follows from it:
         *
         *     needed = distance / secondsLeft,  capped by what he can do
         *
         * A man 40 m from the six yard box with 8 seconds runs at 5 m/s and
         * arrives. The same man with 30 seconds walks. Nobody sprints because a
         * table said 0.95; they move at the speed the situation actually asks
         * for. Set it to false and the old table is back, unchanged, which is
         * how the two are compared.
         */
        @JvmField var ARRIVE_BY = true

        /*
         * ENGINE V4, IDEA 3: claim time instead of a control radius.
         *
         * How far ahead the ball's path is sampled, in seconds. Four points,
         * deliberately: this runs every tick for twenty two men, and v3's
         * decision layer was measured at 8.8 s of CPU a match before it was
         * taken off the per-tick path. CLAIM_SLACK is how much later than the
         * ball a man may arrive and still take it -- a genuine stretch rather
         * than a clean collection.
         */
        /*
         * ENGINE V4, IDEA 4: every man carries his own state.
         *
         * Off puts the engine back to one global description of the situation
         * that twenty two players read, which is how v1, v2 and v3 all worked.
         */
        /*
         * ENGINE V4, IDEA 5: Physics.kt owns the ball in open play.
         *
         * A struck ball gets a VELOCITY and nothing else; where it finishes is
         * whatever drag, gravity and the bounce decide. That is the whole
         * difference between a ball that can be met, deflected and misplaced
         * and one whose destination was an input.
         *
         * Set-pieces still fly on the interpolation, because their staging is
         * measured correct and timed against `duration`, and there is no reason
         * to put that at risk in the same change.
         *
         * OFF, BECAUSE IT DOES NOT WORK YET -- and the numbers say so loudly.
         * With it on, `BallAir` reads exactly what was wanted: the ball at a
         * man's feet 75.6% of the match against 59.6%, loose 10.3% against
         * 19.5%, off the ground 5.4% against 15.5%. And then `AliveCensus`:
         *
         *                    v2 ball   physics ball
         *   goals               2.60       1.00
         *   corners              5.6        1.9
         *   goal kicks          21.6        8.1
         *   free kicks           2.7        1.2
         *   cards               1.20       0.50
         *
         * A match with a third of the goals and a third of the corners is not
         * a better match, whatever the possession figures say. The cause is
         * visible in the same run: mean flight duration 5.5 seconds. A ball
         * decaying exponentially never really arrives -- it creeps the last few
         * metres for seconds -- so every possession takes longer, there are
         * fewer of them, and the whole match slows down behind the ball.
         *
         * Hitting the pass harder (PASS_SECONDS, so it arrives WITH pace rather
         * than coming to rest on the man) was the obvious answer and moved
         * nothing: 1.00 goals and 5.5 seconds again. So the fault is not the
         * strike speed, it is that `t` is driven from distance-to-rest, and
         * "the delivery is over" is not the same event as "the ball has stopped
         * rolling". The next attempt should end the flight when the ball is
         * COLLECTABLE -- slow enough and low enough for the claim model -- and
         * let it keep trickling underneath as a loose ball.
         *
         * Everything else here is kept and is sound: Physics.restPoint answers
         * the question that made two attempts at meeting a pass fail, the
         * strike path is written, and the integration step is written. It is one
         * flag away and it is the right next piece of work.
         */
        /*
         * The offside law. Off restores the old behaviour, in which attackers
         * were clamped to the last defender and the offence could not occur.
         */
        @JvmField var OFFSIDE = true
        /** How far past the last man a pass has to find him to be given. */
        @JvmField var OFFSIDE_MARGIN = 1.15f

        @JvmField var PHYS_BALL = false
        /** How long a pass should take to reach its man, in seconds. */
        @JvmField var PASS_SECONDS = 1.15f

        @JvmField var ENGINE_V4_MIND = true

        @JvmField var CLAIM_BALL = true
        @JvmField var CLAIM_SAMPLES = floatArrayOf(0.06f, 0.20f, 0.38f, 0.60f)
        @JvmField var CLAIM_SLACK = 0.10f

        @JvmField var REF_HOLD = 3.8f
        @JvmField var TACKLE_POSE = 0.95f
        @JvmField var DOWN_POSE = 1.1f
        /** Share of won challenges that are shown as a slide rather than a step in. */
        @JvmField var SLIDE_SHARE = 0.62

        @JvmField var TAKE_ON_POSE = 0.85f
        @JvmField var HEADER_POSE = 0.85f
        @JvmField var SHOOT_POSE = 0.95f

        /**
         * How far through the arrangement a set piece is struck.
         *
         * The delay used to be a magic 0.60 match minutes with no relation to
         * how long the men had been given to walk in. Deriving it from the hold
         * is what keeps "the box fills up" and "the ball is delivered" the same
         * event.
         */
        const val SET_PIECE_TAKE = 0.85f

        /*
         * Three set-piece changes, each behind its own switch so the next
         * person gets a control row instead of a claim. Rule 3 of the harness
         * README exists because PressureCheck once gated the computation behind
         * the flag it was testing and compared nothing.
         */

        /** Strike a set piece at [SET_PIECE_TAKE] of its hold, not at a fixed 0.60. */
        @JvmField var SET_PIECE_TIMING = true

        /** End the arrangement when the ball is struck instead of on a fixed timer. */
        @JvmField var RELEASE_STAGING = true

        /** Leave the defending keeper on his line at a corner. */
        @JvmField var KEEPER_ON_LINE = true

        /* ---------------- ENGINE V2: continuous play ---------------- */

        /**
         * ON. It beat v1 on the harness, which was the condition.
         *
         * BalanceBig, 9,120 matches, v2 against the v1 figures it replaces:
         *
         *              v1              v2            target
         *   goals      2.51 +/- 0.03   2.61 +/- 0.03  2.5-2.7   (v1 straddled the edge)
         *   home       42.3%           44.0%          ~45%
         *   draws      26.1%           23.4%          ~25%
         *   away       31.6%           32.6%          ~30%
         *
         * And the reason it exists, from V2Check on the same seeds:
         *
         *   ball in flight     55.4%  ->  25.0%
         *   ball at feet       25.7%  ->  52.0%
         *   carrier pressed    14.0%  ->  17.9%
         *   interceptions          0  ->  emergent
         *
         * v1 is kept in the build, not deleted. It is the control row for every
         * future measurement, and this project has already been saved twice by
         * having one. See docs/ENGINE_V2.md.
         */
        @JvmField var ENGINE_V2 = true

        /** Time on the ball before a man must do something with it. */
        @JvmField var V2_TOUCH_SECONDS = 1.05f

        /** How near a loose ball a man must be to bring it under control. */
        @JvmField var V2_CONTROL_M = 1.9f

        /** How near a travelling ball a defender must be to cut it out. */
        @JvmField var V2_INTERCEPT_M = 2.1f

        /** How near the carrier a defender must be to challenge. */
        @JvmField var V2_TACKLE_M = 2.2f

        /** Challenges attempted per second while inside that range. */
        @JvmField var V2_TACKLE_RATE = 0.62f

        /** Share of lost challenges that are fouls. */
        @JvmField var V2_FOUL_RATE = 0.46

        /** Metres from goal inside which shooting is considered at all. */
        @JvmField var V2_SHOT_RANGE = 34f

        /**
         * The master conversion lever, as CHANCE_QUALITY is for v1 -- and the
         * only one of the two that is alive under the shipping engine.
         *
         * Re-earned for engine v4 idea 3 (claim-time possession). With the ball
         * at a man's feet 60% of the match instead of 40%, sides keep it, work
         * it and get more shots away, and 9,120 matches read 2.71 goals at 0.52
         * -- over the top of the 2.5-2.7 band. That is not a reason to undo
         * better football; it is what a lever is for.
         *
         * Then earned again for the offside law, which takes goals away for the
         * same reason it does in real football: a chance that used to be a shot
         * is now a flag. 9,120 matches read 2.26 at 0.495, below the band.
         */
        @JvmField var V2_SHOT_BASE = 0.565f

        /** How long the ball stays dead at a restart v2 awards itself. */
        @JvmField var V2_DEAD_SECONDS = 2.2f

        /** How wildly a hurried pass misses. This is what puts the ball out. */
        @JvmField var V2_PASS_ERROR = 0.85f

        /**
         * The nearest defender closes down the man on the ball.
         *
         * See pickChasers. Without it nobody is assigned to a carried ball at
         * all and the defending side simply holds its shape while the ball is
         * walked through it.
         */
        @JvmField var PRESS_CARRIER = true

        /** How much room two men keep between them, in METRES. */
        @JvmField var SEPARATE_M = 1.55f

        /** Relaxation passes. One pass cannot undo a pile of ten. */
        @JvmField var SEPARATE_PASSES = 3

        /* ---------------- ENGINE V3: physics, space, roles, utility --------- */

        /**
         * Off until it beats v2 on the harness. All three engines stay in the
         * build: v1 as a control row is what made every finding in this project
         * provable, and it costs one boolean. See docs/ENGINE_V3.md.
         */
        @JvmField var ENGINE_V3 = false

        /** How often the pitch-control grid is rebuilt, in seconds. */
        @JvmField var V3_GRID_HZ = 0.16f

        /** How often intents and targets are recomputed, in seconds. */
        @JvmField var V3_PLAN_HZ = 0.16f

        /** Time on the ball before he must do something with it. */
        @JvmField var V3_TOUCH_SECONDS = 0.95f

        /** How near a loose ball a man must be to bring it under control. */
        @JvmField var V3_CONTROL_M = 1.8f

        /** The master conversion lever, as CHANCE_QUALITY is to v1. */
        @JvmField var V3_SHOT_BASE = 0.50f

        /** Metres from goal inside which shooting is considered. */
        @JvmField var V3_SHOT_RANGE = 32f

        /**
         * Hold the arrangement for a throw-in and a goal kick too.
         *
         * stageCorner and stageFreeKick both set stagedUntil, which is what
         * stops updateTargets overwriting the arrangement on the very next
         * tick. stageThrowIn never did, and the goal kick never had a stage
         * function at all -- so both set their targets and had them wiped one
         * frame later, which is precisely the fault PROJECT_STATE section 4
         * records as fixed for the free-kick wall and never applied to the
         * other two restarts.
         *
         * Measured before this, over 20 matches at the middle of each scene:
         * a THROW-IN read correctly 12% of the time, with the ball a mean
         * 6.3 m infield of the touchline it had supposedly gone out over and
         * the nearest man 9.2 m away from it; a GOAL KICK read correctly 44%,
         * with the keeper 11.0 m from his own goal kick.
         *
         * This deliberately does NOT change when play restarts, so it adds no
         * stoppage and cannot move the balance the way the set-piece delivery
         * timing does. It only makes the arrangement survive long enough to be
         * drawn.
         */
        @JvmField var STAGE_RESTARTS = true
    }

    /**
     * The delay, in match minutes, before a set piece staged for [holdSeconds]
     * is struck. Match minutes because that is what the pending-shot clock
     * runs on; [SECONDS_PER_MINUTE] converts, so the two agree at every speed.
     */
    private fun takeDelay(holdSeconds: Float, legacy: Double): Double =
        if (SET_PIECE_TIMING) holdSeconds * SET_PIECE_TAKE / SECONDS_PER_MINUTE else legacy

    init {
        if (home.tactics.lineup.all { it < 0 }) world.autoPickSquad(home)
        if (away.tactics.lineup.all { it < 0 }) world.autoPickSquad(away)
        buildSide(0, home)
        buildSide(1, away)
        benchHome.addAll(home.tactics.bench.map { world.player(it) }.filterNotNull())
        benchAway.addAll(away.tactics.bench.map { world.player(it) }.filterNotNull())

        /*
         * A derby fills the ground and the ground is louder all afternoon.
         *
         * This is the whole mechanical weight of a rivalry in the match: a
         * fuller stadium, a noisier one, and more cards. Deliberately nothing
         * that changes who is likely to win — a derby that quietly handed the
         * home side a goal would be a cheat rather than an occasion.
         */
        isDerby = world.areRivals(home.id, away.id)
        val derbyPull = if (isDerby) 0.14 else 0.0
        attendance = min(
            home.capacity,
            (home.capacity * (0.55 + derbyPull + home.reputation / 250.0 + rng.f() * 0.15)).roundToInt()
        )
        weatherRain = rng.chance(0.22)
        night = rng.chance(0.45)
        resetShape(0); resetShape(1)
        refreshRatings()
    }

    private fun buildSide(side: Int, club: Club) {
        val shape = Formations.byName(club.tactics.formation)
        for (i in shape.slots.indices) {
            val p = world.player(club.tactics.lineup.getOrElse(i) { -1 }) ?: continue
            val slot = shape.slots[i]
            val lp = LivePlayer("${side}_$i", side, i, slot.pos, p)
            lp.baseX = slot.x.toFloat()
            lp.baseY = slot.y.toFloat()
            lp.shirt = if (i == 0) 1 else i + 1
            lp.effective = p.effective(slot.pos)
            lp.fitness = p.fitness
            players.add(lp)
        }
    }

    fun onPitch(side: Int): List<LivePlayer> = players.filter { it.side == side && it.onPitch }

    private fun ownX(side: Int, v: Float) = if (side == 0) v else 100f - v
    private fun ownY(side: Int, v: Float) = if (side == 0) v else 100f - v

    private fun resetShape(side: Int) {
        for (p in onPitch(side)) {
            p.x = ownX(side, p.baseX); p.targetX = p.x
            p.y = ownY(side, p.baseY); p.targetY = p.y
        }
    }

    /* ------------------------------------------------------------ PHASES */

    private fun rating(side: Int) = if (side == 0) ratingHome else ratingAway

    private fun applyOppPlan(plan: Tactics, victim: Club, victimRating: World.TeamRating) {
        if (plan.oppTargetId < 0 || plan.oppMode == 0) return
        val target = world.player(plan.oppTargetId) ?: return
        if (target.clubId != victim.id) return
        // how much of their attack runs through him
        val xi = victim.tactics.lineup.map { world.player(it) }.filterNotNull()
        if (xi.isEmpty()) return
        val share = (target.overall().toDouble() / xi.sumOf { it.overall() }.toDouble()) * xi.size
        val bite = when (plan.oppMode) {
            1 -> 3.4; 2 -> 2.4; 3 -> 1.8; 4 -> 1.4; else -> 0.0
        } * share.coerceIn(0.6, 1.8)
        victimRating.attack -= bite
        victimRating.control -= bite * 0.5
    }

    fun refreshRatings() {
        ratingHome = world.teamRating(home, true)
        ratingAway = world.teamRating(away, false)

        // An opposition plan takes a real bite out of the side it targets:
        // how big a bite depends on how important that player is to them.
        applyOppPlan(home.tactics, away, ratingAway)
        applyOppPlan(away.tactics, home, ratingHome)
        for (p in players) {
            if (!p.onPitch) continue
            var eff = p.ref.effective(p.pos) * (0.75 + 0.25 * p.fitness / 100.0)
            // is the other manager targeting him?
            val theirTactics = (if (p.side == 0) away else home).tactics
            if (theirTactics.oppTargetId == p.ref.id) {
                eff *= when (theirTactics.oppMode) {
                    1 -> 0.86     // man-marked out of the game
                    2 -> 0.91     // hounded whenever he gets it
                    3 -> 0.93     // forced onto his weaker side
                    4 -> 0.95     // kicked, but it may cost a card
                    else -> 1.0
                }
            }
            p.effective = eff
        }
    }

    private fun newPhase() {
        val att = possessionSide
        val def = 1 - att
        val attClub = if (att == 0) home else away
        val ra = rating(att); val rd = rating(def)

        val outfield = onPitch(att).filter { it.pos != Pos.GK }
        if (outfield.isEmpty()) { possessionSide = def; return }
        val back = outfield.filter { Pos.group(it.pos) == 1 }
        val mid = outfield.filter { Pos.group(it.pos) == 2 }
        val fwd = outfield.filter { Pos.group(it.pos) == 3 }

        val t = attClub.tactics
        val passCount = when (t.passing) {
            2 -> rng.i(2, 3)
            0 -> rng.i(4, 7)
            else -> rng.i(3, 5)
        }

        // A move is built by walking up the pitch from man to man, not by
        // picking one name from each line. Choosing a random defender, then a
        // random midfielder, then a random forward meant every single pass
        // crossed a whole third: the average came out at 39 metres, when a real
        // pass is about 18. Each man now looks for someone near him who is no
        // further back than he is.
        val dir = if (att == 0) 1f else -1f
        fun nextMan(from: LivePlayer?, wantForward: Boolean): LivePlayer {
            if (from == null) return rng.pick(if (back.isNotEmpty()) back else outfield)
            val near = outfield.filter { it.key != from.key }
                .sortedBy {
                    hypot(((it.x - from.x) * 1.05).toDouble(), ((it.y - from.y) * 0.68).toDouble())
                }
                .take(5)
            // among those close by, prefer the ones who take the move forward.
            // Widening this band to allow more square balls was tried and put
            // back: it moved the forward share by two points and cost a tenth
            // of a goal a game, which is a bad trade.
            val ahead = near.filter { (it.x - from.x) * dir > -3f }
            val pool = when {
                wantForward -> {
                    // the ball into the box wants a forward on the end of it;
                    // settle for a midfielder only if there is no one up there
                    val strikers = ahead.filter { Pos.group(it.pos) == 3 }
                    val f2 = ahead.filter { Pos.group(it.pos) >= 2 }
                    when {
                        strikers.isNotEmpty() -> strikers
                        f2.isNotEmpty() -> f2
                        ahead.isNotEmpty() -> ahead
                        else -> near
                    }
                }
                ahead.size >= 2 -> ahead
                else -> near
            }
            return rng.pick(pool)
        }

        /*
         * ---------------------------------------------------------------
         * MOVE CONSTRUCTION, VERSION 2: walk the BALL, then find a receiver.
         * ---------------------------------------------------------------
         *
         * Version 1 walks the PLAYERS: each man passes to whoever happens to be
         * standing near him and no further back. Everything about the football
         * then falls out of where men happen to stand, which is why three
         * separate attempts to fix the geometry all ricocheted:
         *
         *   - pass length and direction are accidents of the formation, so they
         *     measured 24.6 m and 68% forward against a real 18 m and 45%;
         *   - a move ends wherever it ends, so a quarter of all GOALS were
         *     struck from inside the shooter's own half;
         *   - and compressing the team shape to the real 30-40 m lifted the
         *     defending line, which the offside clamp then used to hold
         *     attackers out, which pushed the median goal from 26 m to 32 m.
         *
         * Those are one bug, not three. Here the move is built by advancing the
         * BALL a realistic distance in a sampled direction and then asking who
         * is best placed to receive it, so pass geometry is a property of the
         * move rather than a side effect of the shape. The outcome model above
         * — ratings, phaseGap, the outcome roll — is untouched, because that is
         * the part that is right.
         */
        fun buildSequenceV2(): ArrayList<LivePlayer> {
            val out = ArrayList<LivePlayer>(passCount)
            var opener = nearest(outfield, ball.x, ball.y) ?: rng.pick(outfield)
            out.add(opener)
            var bx = opener.x
            var by = opener.y
            for (i in 0 until max(1, passCount - 1)) {
                // Direction split sampled directly rather than hoped for:
                // roughly 45 forward, 35 square, 20 back, which is what a real
                // side plays. The last ball of a move always goes forward.
                val last = i == passCount - 2
                val r = rng.f()
                // The pattern owns the geometry. A cross works the ball toward a
                // touchline and then swings it in; a through ball is played into
                // space beyond the last man; a counter goes straight up the
                // pitch in few touches; build-up keeps it short and central.
                val ang = when {
                    phasePattern == PAT_CROSS && last ->
                        // the delivery: from wide, back toward the middle
                        (if (by < 50f) 1f else -1f) * (0.9f + rng.f().toFloat() * 0.4f)
                    phasePattern == PAT_CROSS ->
                        // work it wide first
                        (if (by < 50f) -1f else 1f) * (0.7f + rng.f().toFloat() * 0.6f)
                    phasePattern == PAT_COUNTER -> (rng.f().toFloat() - 0.5f) * 0.7f
                    phasePattern == PAT_THROUGH && last -> (rng.f().toFloat() - 0.5f) * 0.9f
                    last || r < 0.45 -> (rng.f().toFloat() - 0.5f) * 1.5f
                    r < 0.80 -> (if (rng.chance(0.5)) 1f else -1f) *
                        (1.30f + rng.f().toFloat() * 0.5f)
                    else -> Math.PI.toFloat() + (rng.f().toFloat() - 0.5f) * 1.2f
                }
                // Length in METRES around a real mean, then converted to units
                // on each axis. Sampling in units would make every ball across
                // the pitch half the length of one up it.
                val lenM = when {
                    phasePattern == PAT_COUNTER -> (22.0 + rng.f() * 16.0).toFloat()
                    phasePattern == PAT_THROUGH && last -> (20.0 + rng.f() * 14.0).toFloat()
                    phasePattern == PAT_CROSS && last -> (24.0 + rng.f() * 14.0).toFloat()
                    phasePattern == PAT_BUILD -> (8.0 + rng.f() * 10.0).toFloat()
                    else -> (10.0 + rng.f() * 18.0).toFloat()
                }
                val dxU = (Math.cos(ang.toDouble()).toFloat() * lenM / 1.05f) * dir
                val dyU = Math.sin(ang.toDouble()).toFloat() * lenM / 0.68f
                val tx = (bx + dxU).coerceIn(4f, 96f)
                val ty = (by + dyU).coerceIn(4f, 96f)
                // whoever is best placed for that ball actually receives it
                val prev = out.last()
                val recv = outfield.filter { it.key != prev.key }
                    .minByOrNull {
                        hypot(((it.x - tx) * 1.05).toDouble(), ((it.y - ty) * 0.68).toDouble())
                    } ?: prev
                out.add(recv)
                bx = recv.x; by = recv.y
            }
            return out
        }

        // Which shape this move takes, drawn from how the side is set up.
        // Direct sides cross and go long; short sides build and play in behind;
        // a counter-attacking side breaks. Rolled on the result stream because
        // the pattern decides where the move ends and therefore who shoots.
        phasePattern = run {
            val w = DoubleArray(5)
            w[PAT_BUILD] = when (t.passing) { 1 -> 3.0; 0 -> 4.5; else -> 1.2 }
            w[PAT_CROSS] = when (t.passing) { 2 -> 3.4; else -> 1.6 } *
                (when (t.width) { 2 -> 1.9; 0 -> 0.5; else -> 1.0 })
            w[PAT_THROUGH] = when (t.passing) { 0 -> 2.6; else -> 1.4 } *
                (if (t.mentality >= 3) 1.5 else 1.0)
            w[PAT_COUNTER] = if (t.counter) 3.2 else 0.7
            w[PAT_LONGSHOT] = when (t.tempo) { 2 -> 1.3; else -> 0.8 }
            val total = w.sum()
            var r = rng.f() * total
            var pick = PAT_BUILD
            for (i in w.indices) { r -= w[i]; if (r <= 0) { pick = i; break } }
            pick
        }

        val seq = ArrayList<LivePlayer>(passCount)
        // Whoever is closest to the ball picks it up. A move used to open with
        // the ball flying back to a randomly chosen defender, which meant the
        // first delivery of every phase averaged thirty seven metres and was
        // by far the most common thing on screen: a constant stream of long
        // balls backwards. The man nearest it simply has it.
        seq.add(nearest(outfield, ball.x, ball.y) ?: rng.pick(outfield))
        for (i in 0 until max(0, passCount - 2)) {
            seq.add(nextMan(seq.lastOrNull(), false))
        }
        seq.add(nextMan(seq.lastOrNull(), true))

        if (SPATIAL_V2) { seq.clear(); seq.addAll(buildSequenceV2()) }

        phaseGap = ra.attack - rd.defence
        // Playing at home is worth a little more than the squad numbers alone
        // say, on top of the bonus the team ratings already carry. Trimmed from
        // 2.5: with the seeding fixed, home sides were winning better than half
        // their matches against a real world figure of about 45 per cent.
        if (att == 0) phaseGap += 1.1
        // breaking on a side that emptied its half for a corner
        if (cornerExposure >= 0) {
            if (cornerExposure != att) phaseGap += 6.0
            cornerExposure = -1
        }
        val pShot = (0.215 + phaseGap / 140.0).coerceIn(0.09, 0.52)
        val defClub = if (def == 0) home else away
        val pFoul = 0.10 * when (defClub.tactics.tackling) { 2 -> 1.7; 0 -> 0.6; else -> 1.0 }
        val pCorner = 0.07

        val pThrow = 0.11
        val r = rng.f()
        phaseOutcome = when {
            r < pFoul -> OUT_FOUL
            r < pFoul + pShot -> OUT_SHOT
            r < pFoul + pShot + pCorner -> OUT_CORNER
            r < pFoul + pShot + pCorner + pThrow -> OUT_THROW
            else -> OUT_TURNOVER
        }

        /*
         * PLAYER JOBS: the pattern tells men where to go, not just the ball.
         *
         * Positions are given as distance from the goal line being attacked and
         * a lateral y, so the same table serves both ends of the pitch.
         */
        if (JOBS) {
            val goalX = if (att == 0) 100f else 0f
            val toX = { d: Float -> if (att == 0) goalX - d else goalX + d }
            // the men most likely to be in the picture: nearest the goal first
            val runners = outfield.sortedBy {
                hypot(((goalX - it.x) * 1.05).toDouble(), ((50f - it.y) * 0.68).toDouble())
            }
            val jobs: List<Pair<Float, Float>> = when (phasePattern) {
                PAT_CROSS -> listOf(
                    toX(6f) to 41f,      // near post
                    toX(11f) to 50f,     // penalty spot
                    toX(7f) to 59f,      // back post
                    toX(19f) to 50f      // edge of the box, for the cut-back
                )
                PAT_THROUGH -> listOf(
                    toX(14f) to 44f,     // breaking the line
                    toX(20f) to 56f      // the support runner
                )
                PAT_COUNTER -> listOf(
                    toX(16f) to 50f,
                    toX(22f) to 36f,
                    toX(22f) to 64f
                )
                PAT_LONGSHOT -> listOf(
                    toX(8f) to 46f,      // gambling on a rebound
                    toX(8f) to 54f
                )
                else -> listOf(
                    toX(18f) to 44f,
                    toX(18f) to 56f
                )
            }
            for (i in jobs.indices) {
                val p = runners.getOrNull(i) ?: break
                p.jobX = jobs[i].first
                p.jobY = jobs[i].second
                p.jobDefensive = false
                p.jobTime = JOB_SECONDS * (0.78f + rng.f().toFloat() * 0.44f)
            }
        }

        val cut = if (phaseOutcome == OUT_TURNOVER) rng.i(1, seq.size) else seq.size
        phaseSeq = seq.subList(0, max(1, min(cut, seq.size))).toMutableList()
        phaseStep = 0
        phaseTimer = 0.0

        val tempoSpread = when (t.tempo) { 2 -> 0.7; 0 -> 1.5; else -> 1.0 }
        /*
         * PHASE_SCALE compensates for the move waiting on the ball. A move that
         * has to let each pass land consumes more MATCH minutes than its
         * nominal duration, so a 90-minute match holds fewer of them and the
         * shot count falls with it. Shortening the nominal move puts the count
         * back without touching chance quality, which would have inflated the
         * scoring rate per chance instead of restoring the number of chances.
         */
        phaseDuration = (0.35 + rng.f() * tempoSpread + phaseSeq.size * 0.12) * PHASE_SCALE
        possession[att] += phaseDuration

        ball.holder = phaseSeq[0].key
        moveBallTo(phaseSeq[0].x, phaseSeq[0].y, 0.40f, 0f)
    }

    /**
     * Sends the ball somewhere. [loft] is how high it is struck: nought keeps
     * it on the deck, which is where the great majority of passes belong.
     */
    /**
     * Sends the ball to a dead ball spot rather than snapping it there. Every
     * restart used to reposition the ball instantly, so it vanished from one
     * part of the pitch and reappeared in another: thirty nine times a match.
     * Rolling it out over a few tenths of a second is what a ball actually does
     * when it goes out of play.
     */
    private fun placeBall(x: Float, y: Float, loft: Float = 0f) {
        /*
         * V3 HAS NO INTERPOLATION TO ROLL IT THERE.
         *
         * placeBall rolls the ball to a spot by handing off to moveBallTo,
         * which sets ball.t = 0 and lets the flight loop in update() walk it
         * across. v3 owns the ball through Physics.stepBall and that loop is
         * skipped entirely -- so under v3 every one of the nine placeBall call
         * sites left the ball with t = 0, frozen exactly where it already was.
         *
         * That is why a v3 match played correctly until the first restart and
         * then fell apart: after any throw-in, goal kick, corner or free kick
         * the ball stayed put, usually OUTSIDE the pitch, and possession was
         * never recovered for the rest of the match. Measured 92% of frames
         * with a loose ball and no goals at all.
         *
         * A dead ball being placed by hand does not need a rolling animation.
         * It is put down, at rest, and the physics takes over from there.
         */
        if (ENGINE_V3) {
            ball.x = x; ball.y = y
            ball.vx = 0f; ball.vy = 0f; ball.vz = 0f
            ball.height = 0f; ball.spinRate = 0f
            ball.t = 1f
            ball.driftX = 0f; ball.driftY = 0f
            ball.holder = null
            return
        }
        val d = hypot(((x - ball.x) * 1.05).toDouble(), ((y - ball.y) * 0.68).toDouble()).toFloat()
        if (d < 1.5f) {
            ball.x = x; ball.y = y; ball.t = 1f; ball.height = 0f
            ball.driftX = 0f; ball.driftY = 0f
            return
        }
        moveBallTo(x, y, (0.28f + d / 46f).coerceIn(0.28f, 0.85f), loft)
        ball.holder = null
    }

    private fun moveBallTo(x: Float, y: Float, dur: Float, loft: Float = 0f) {
        ball.fromX = ball.x; ball.fromY = ball.y
        ball.toX = x; ball.toY = y
        ball.t = 0f
        // A ceiling on how fast anything can be struck, applied here so every
        // delivery is covered rather than each call site being tuned by hand.
        // One x-unit is about 1.05 m and one y-unit about 0.68 m; the hardest
        // strike in football is a little over 35 m/s.
        val dxm = (x - ball.fromX) * 1.05f
        val dym = (y - ball.fromY) * 0.68f
        val metres = hypot(dxm.toDouble(), dym.toDouble()).toFloat()
        val floorDur = metres / MAX_BALL_MPS
        ball.duration = max(0.10f, max(dur, floorDur))
        ball.loft = loft
        ball.rolling = loft <= 0.01f
        ball.vz = 0f
        ball.struck = false
        // a bend proportional to how far it has to travel, either way off the
        // straight line. Rolled on the cosmetic stream so it cannot move a result.
        val dist = hypot((x - ball.fromX).toDouble(), (y - ball.fromY).toDouble()).toFloat()
        ball.curve = if (dist < 12f) 0f
        else (physRng.f().toFloat() - 0.5f) * 2f * min(3.2f, dist * 0.055f)
    }

    private fun stepPhase() {
        phaseStep++
        if (phaseStep < phaseSeq.size) {
            val from = phaseSeq[phaseStep - 1]
            var to = phaseSeq[phaseStep]
            // A man taking his opponent on. Rolled on the cosmetic stream and
            // it does not alter who ends up with the ball, so this is a scene
            // rather than a new outcome and the balance figures are untouched.
            val dri = from.ref.att[Att.DRI].toDouble()
            val flair = if (from.ref.hasTrait(Traits.FLAIR)) 1.8 else 1.0
            // A take-on was attempted on 5.5% of passes, which came out at 10.3
            // a match against a real forty. Cosmetic stream, and DRIBBLE does
            // not freeze the man, so this cannot reach a result.
            // A take-on was attempted on 5.5% of passes: 10.3 a match against
            // a real forty. Free to change now that the cosmetic stream cannot
            // reach a result — see act()'s `cosmetic` flag.
            if (sfxRng.chance(0.215 * flair * (dri / 68.0))) {
                val marker = nearest(
                    onPitch(1 - possessionSide).filter { it.pos != Pos.GK }, from.x, from.y
                )
                act(from, Act.DRIBBLE, 0.62f, angleTo(from, to.x, to.y), cosmetic = true)
                from.dribbles++
                /*
                 * A TAKE-ON IS A MOMENT TOO.
                 *
                 * Men have been beating their marker several times a match since
                 * take-ons were written, with a pose, a sound and a line of
                 * commentary -- and nothing on the screen ever said so, because
                 * scenes only existed for set pieces. It is the most common piece
                 * of skill in the game and it was the least visible.
                 *
                 * Unlike every other scene this is LIVE PLAY: the ball is still
                 * being contested, so it must not freeze anybody or slow them
                 * down. Scene.isLive keeps it out of the dead-ball rules. It
                 * names the moment and nothing more, and it never overwrites a
                 * stoppage that is already on screen.
                 */
                if (scene == Scene.NONE || sceneTime <= 0f) {
                    scene = Scene.TAKE_ON
                    sceneTime = 1.1f
                }
                // the genuinely gifted do something worth watching
                val tec = from.ref.att[Att.TEC] + from.ref.att[Att.DRI]
                // 0.17 a match: the named skill moves are advertised in the
                // brief and were effectively invisible. The gate was FLAIR plus
                // a combined 130 of technique and dribbling, which very few
                // players clear.
                // 0.17 a match: the named skill moves are advertised in the
                // brief and were effectively never seen. The gate wanted FLAIR
                // and a combined 130 of technique and dribbling, which almost
                // nobody clears.
                if (from.ref.hasTrait(Traits.FLAIR) && tec > 112 && sfxRng.chance(0.50)) {
                    skill = 0.62f
                    skillKey = from.key
                    skillName = SKILL_MOVES[sfxRng.i(0, SKILL_MOVES.size - 1)]
                    cue(Synth.Sfx.APPLAUSE, 0.55f, from.x)
                    crowdTarget = max(crowdTarget, 0.84f)
                }
                if (marker != null) {
                    // beaten, and turning to chase
                    act(marker, Act.RUN, 0.45f, angleTo(marker, from.x, from.y), cosmetic = true)
                }
                sayRaw(
                    FeedLine.PLAIN,
                    DRIBBLE_LINES[sfxRng.i(0, DRIBBLE_LINES.size - 1)]
                        .replace("{a}", from.name).replace("{b}", marker?.name ?: "his man")
                )
                cue(Synth.Sfx.APPLAUSE, 0.4f, from.x)
                crowdTarget = max(crowdTarget, 0.72f)
            }

            /*
             * SPATIAL V2, STEP FOUR: THE MOVE IS NO LONGER DECIDED IN ADVANCE.
             *
             * v1 builds the whole sequence when the phase starts and then plays
             * it out over a minute or two of match time while everybody runs,
             * so the receiver of the fourth pass was picked from where men
             * stood before the first. That is why putting players into support
             * positions moved the average pass by 0.2 m (step two) — the ball
             * had been aimed long before anyone got there.
             *
             * Here the next receiver is chosen AT THE MOMENT OF THE PASS, and
             * the move GROWS: if this is meant to end in a shot and nobody is
             * yet in a shooting position, the move simply carries on rather
             * than the last man striking it from wherever he happens to be.
             * That is what ties pass geometry and shot distance to the same
             * mechanism instead of leaving them to fight each other.
             *
             * The OUTCOME is still rolled up front from the ratings, so the
             * result model — and every balance figure — is untouched. Only the
             * path the ball takes to it changes.
             */
            if (SPATIAL_V2) {
                val mates = onPitch(possessionSide)
                    .filter { it.pos != Pos.GK && it.key != from.key }
                if (mates.isNotEmpty()) {
                    val dirS = if (possessionSide == 0) 1f else -1f
                    val goalXS = if (possessionSide == 0) 100f else 0f
                    fun rng2(p: LivePlayer) = hypot(
                        ((goalXS - p.x) * 1.05).toDouble(), ((50f - p.y) * 0.68).toDouble())
                    val mustAdvance = phaseOutcome == OUT_SHOT && rng2(from) > SHOT_RANGE_M
                    val r = rng.f()
                    // a move that still has to get somewhere plays forward
                    val ang = when {
                        mustAdvance || r < 0.45 -> (rng.f().toFloat() - 0.5f) * 1.5f
                        r < 0.80 -> (if (rng.chance(0.5)) 1f else -1f) *
                            (1.30f + rng.f().toFloat() * 0.5f)
                        else -> Math.PI.toFloat() + (rng.f().toFloat() - 0.5f) * 1.2f
                    }
                    val lenM = (10.0 + rng.f() * 14.0).toFloat()
                    val aimX = from.x + (Math.cos(ang.toDouble()).toFloat() * lenM / 1.05f) * dirS
                    val aimY = from.y + Math.sin(ang.toDouble()).toFloat() * lenM / 0.68f
                    /*
                     * SPACE FIRST, PLAYER SECOND.
                     *
                     * The receiver was whoever stood nearest a geometric aim
                     * point, with no regard for whether he had a defender on his
                     * shoulder. That is why a move could be worked into trouble
                     * over and over: the ball went to the nearest man, the
                     * nearest man was marked, and possession went straight back.
                     *
                     * Pressure -- how hurried a man is, from defender distance,
                     * closing speed, angle and how many are around him -- now
                     * costs him metres of apparent distance. A man in acres two
                     * metres further away is the better pass, which is the whole
                     * of "space first, player second".
                     *
                     * The phase OUTCOME is still rolled up front from the
                     * ratings, so this changes where the ball goes and never who
                     * ends up with it.
                     */
                    val pick = mates.minByOrNull {
                        hypot(((it.x - aimX) * 1.05).toDouble(), ((it.y - aimY) * 0.68).toDouble()) +
                            (if (PRESSURE) it.pressure * PRESSURE_WEIGHT else 0f)
                    }
                    if (pick != null) { to = pick; phaseSeq[phaseStep] = pick }
                    // the move carries on until somebody is actually in range
                    if (phaseOutcome == OUT_SHOT && rng2(to) > SHOT_RANGE_M &&
                        phaseStep >= phaseSeq.size - 1 && phaseSeq.size < 12) {
                        phaseSeq.add(to)
                        phaseDuration += 0.14
                    }
                }
            }
            from.passes++
            passesTotal[possessionSide]++
            cue(Synth.Sfx.KICK, 0.42f, from.x)
            val dist = hypot((to.x - from.x).toDouble(), (to.y - from.y).toDouble()).toFloat()
            val club = if (possessionSide == 0) home else away
            // The ball spent 38% of the match in the air, which is nothing like
            // football. Only a genuinely long ball, or a side told to go direct,
            // gets lifted now, and not as high.
            // Height is in pitch units across the width, so a unit is 0.68 m.
            // The old numbers peaked at 1.9 units, which is 1.3 m: a lofted
            // ball that never got above waist height. A clipped ball over a
            // defender is three or four metres, a raking diagonal more.
            val loft = when {
                dist > 44f -> 7.4f          // about 5 m at the top of its arc
                dist > 30f && club.tactics.passing == 2 -> 4.4f   // about 3 m
                else -> 0f
            }
            // If somebody is standing in the line, the passer does what a
            // passer does: clips it over him or bends it round. One in five
            // passes used to travel straight through an opponent.
            var loftAdj = loft
            val blocker = blockerOnLine(from.x, from.y, to.x, to.y, 1 - possessionSide)
            // clipped over him: enough to clear a man, no more
            if (blocker != null && loftAdj < 0.8f) loftAdj = 3.6f

            // a better passer strikes it more firmly, so it arrives sooner
            val weight = 1.0f - (from.ref.att[Att.PAS] - 60) / 320f
            val natural = (0.52f + dist / 27f) * weight.coerceIn(0.80f, 1.20f)
            /*
             * THE BALL HAS TO ARRIVE BEFORE THE NEXT PASS IS DUE.
             *
             * A move gets phaseDuration minutes and splits it evenly between its
             * passes, so each pass owns a slice of about 0.38 of a step-second.
             * The natural flight time of a twenty-unit pass is 1.26. The ball
             * was three times slower than the rhythm the move was played at, and
             * the engine simply struck it again while it was still in the air —
             * which is what put a 120-degree kink in 40 flights a match.
             *
             * Gating the move on the ball exposed the mismatch instead of hiding
             * it: moves took three times as long and goals fell from 2.64 a game
             * to 0.97. So the flight is fitted to the slice it is given. The
             * physical ceiling in moveBallTo still applies underneath, so a
             * genuinely long ball is still allowed to take its time — and then
             * the move waits for it, which is correct and rare.
             */
            val budget = (phaseDuration / max(1, phaseSeq.size)).toFloat() *
                    SECONDS_PER_MINUTE.toFloat() * 0.92f
            moveBallTo(to.x, to.y, min(natural, budget), loftAdj)
            ball.holder = to.key
            if (rng.chance(0.10)) say(L_PASS, from.name, to.name)
            return
        }
        resolvePhase()
    }

    private fun resolvePhase() {
        val att = possessionSide
        val def = 1 - att
        val last = phaseSeq.lastOrNull() ?: return
        val defClub = if (def == 0) home else away

        when (phaseOutcome) {
            OUT_TURNOVER -> {
                val defenders = onPitch(def).filter { it.pos != Pos.GK }
                val stealer = nearest(defenders, last.x, last.y)
                if (stealer != null) {
                    stealer.tackles++
                    // a real slide, aimed at the man he is dispossessing
                    // only a genuine challenge puts anybody on the grass
                    /*
                     * YOU CANNOT SLIDE IN ON A BALL THAT IS NOT THERE.
                     *
                     * The stealer is picked as the defender nearest the last man
                     * in the move, and the slide was then played wherever he
                     * happened to be standing. SlideCheck: the mean distance
                     * from the ball at the moment a man went to ground was 5.0 m,
                     * and 39% of slides began MORE THAN FIVE METRES from it —
                     * men throwing themselves along the grass at nothing, which
                     * is what "they slide when they pass" looks like from the
                     * touchline.
                     *
                     * Both draws are taken whatever happens. They used to be
                     * nested, and skipping the inner one would shift every
                     * later roll in the match onto different numbers.
                     */
                    val slideRoll = rng.chance(0.30)
                    val downRoll = rng.chance(0.5)
                    val reach = hypot(((ball.x - stealer.x) * 1.05).toDouble(),
                                      ((ball.y - stealer.y) * 0.68).toDouble())
                    if (slideRoll && reach < SLIDE_REACH_M) {
                        act(stealer, Act.TACKLE, TACKLE_POSE, angleTo(stealer, last.x, last.y))
                        liveScene(Scene.TACKLE, 1.2f)
                        cue(Synth.Sfx.TACKLE, 0.8f, stealer.x)
                        if (downRoll) act(last, Act.DOWN, 0.55f)
                    }
                    if (rng.chance(0.22)) say(L_TACKLE, stealer.name, last.name)
                } else if (rng.chance(0.5)) {
                    act(last, Act.DRIBBLE, 0.7f)
                }
                flip(def)
            }

            OUT_FOUL -> {
                val defenders = onPitch(def).filter { it.pos != Pos.GK }
                val fouler = nearest(defenders, last.x, last.y) ?: defenders.randomOrNull(rng)
                fouls[def]++
                if (fouler != null) {
                    val inBox = if (att == 0) last.x > 83f else last.x < 17f
                    if (inBox && rng.chance(0.28)) {
                        say(L_PENALTY, fouler.name, teamName(att))
                        card(fouler, rng.chance(0.30))
                        takePenalty(att)
                        return
                    }
                    val aggressive = defClub.tactics.tackling == 2
                    val roughing = defClub.tactics.oppMode == 4 && defClub.tactics.oppTargetId == last.ref.id
                    val cardChance = 0.20 * (if (aggressive) 1.8 else 1.0) *
                            (if (fouler.ref.hasTrait(Traits.HOTHEAD)) 1.7 else 1.0) *
                            (if (roughing) 1.9 else 1.0) *
                            // a derby is a bookable afternoon
                            (if (isDerby) 1.35 else 1.0)
                    if (rng.chance(cardChance * cardRisk(fouler))) card(fouler, rng.chance(0.07))
                    else if (rng.chance(0.30)) say(L_FOUL, fouler.name, last.name)
                }
                // A foul stops play. It used to restart as a free kick only
                // 22% of the time and otherwise just handed possession over
                // with nothing on screen at all, so four fouls in five were
                // invisible: no whistle, no wall, no restart.
                if (rng.chance(0.92)) {
                    // a booking, if there was one, owns the screen instead
                    if (scene != Scene.CARD) { scene = Scene.FREEKICK; sceneTime = FREEKICK_SECONDS }
                    stageFreeKick(att, def, last)
                    // The free kick routine finally does something. It was in
                    // the model and in the save file but never read, which is
                    // worse than not offering the choice at all.
                    val fkTac = (if (att == 0) home else away).tactics
                    val range = hypot(((if (att == 0) 100f else 0f) - ball.x).toDouble(),
                        (50f - ball.y).toDouble()).toFloat()
                    when (fkTac.freeKickRoutine) {
                        0 -> {   // shoot on sight: worth more close in, wasteful from range
                            val q = if (range < 30f) 0.074 else 0.046
                            shootAfterScene(att, last, q, "free kick", takeDelay(FREEKICK_SECONDS, 0.55))
                        }
                        2 -> {   // cross into the box for the biggest man
                            val header = onPitch(att)
                                .filter { it.pos != Pos.GK && it.key != last.key }
                                .maxByOrNull { it.ref.att[Att.STR] } ?: last
                            moveBallTo(if (att == 0) 92f else 8f, 50f, 0.9f, 6.8f)
                            shootAfterScene(att, header, 0.066, "header", takeDelay(FREEKICK_SECONDS, 0.55))
                        }
                        // The default is what the engine always did: the taker
                        // strikes it himself. Kept exactly so that offering the
                        // choice does not quietly move the match balance for
                        // anybody who never touches the setting.
                        else -> shootAfterScene(att, last, 0.055, "free kick", takeDelay(FREEKICK_SECONDS, 0.55))
                    }
                    return
                }
                flip(att)
            }

            OUT_THROW -> {
                // the ball runs out for a throw: whoever put it out loses it
                val toucher = last
                val side = if (toucher.y < 50f) 2f else 98f
                // it runs out of play rather than jumping to the touchline
                val outX = toucher.x.coerceIn(6f, 94f)
                placeBall(outX, side)
                scene = Scene.THROW_IN; sceneTime = THROWIN_SECONDS
                stageThrowIn(def, outX, side)
                sayRaw(FeedLine.PLAIN, "Out for a throw-in to ${teamName(def)}.")
                // The restart waits for the ball to arrive and a man to reach
                // it. Given back as stoppage, so lengthening the moment costs
                // the match no playing time -- see shootAfterScene.
                val throwWait = if (STAGE_RESTARTS)
                    THROWIN_SECONDS / SECONDS_PER_MINUTE else 0.35
                stoppage += max(0.0, throwWait - 0.35)
                flipLater(def, throwWait)
            }

            OUT_CORNER -> {
                corners[att]++
                scene = Scene.CORNER; sceneTime = CORNER_SECONDS
                say(L_CORNER, teamName(att), "")
                stageCorner(att)
                val attClub2 = if (att == 0) home else away
                val nominatedCorner = attClub2.tactics.cornerTaker.let { slot ->
                    if (slot >= 0) onPitch(att).firstOrNull { it.slot == slot } else null
                }
                nominatedCorner?.let { it.passes++ }
                // The routine decides who it is aimed at and what sort of chance
                // it becomes. Far post is the default and is worth exactly what
                // a corner was worth before any of this, so the balance figures
                // are unchanged unless the manager actually changes something.
                val tac2 = attClub2.tactics
                val pool = onPitch(att).filter { it.pos != Pos.GK && it.key != nominatedCorner?.key }
                val heads = { p: LivePlayer ->
                    p.ref.att[Att.STR] +
                        (if (RoleFx.of(tac2.roleName(p.slot)).note.contains("headers")) 15 else 0)
                }
                var kind = "header"
                var target: LivePlayer
                var q: Double
                when (tac2.cornerRoutine) {
                    0 -> {   // near post flick: a quicker man attacking it first
                        target = pool.maxByOrNull { heads(it) + it.ref.att[Att.ACC] / 2 } ?: last
                        q = 0.108
                    }
                    2 -> {   // worked short: safer, and it becomes a shot not a header
                        target = pool.maxByOrNull { it.ref.att[Att.TEC] + it.ref.att[Att.VIS] } ?: last
                        q = 0.068
                        kind = "shot"
                    }
                    3 -> {   // pulled back to the edge
                        target = pool.maxByOrNull { it.ref.att[Att.LON] } ?: last
                        q = 0.055
                        kind = "shot"
                    }
                    else -> { // far post, as it always was
                        target = pool.maxByOrNull { heads(it) } ?: last
                        q = 0.085
                    }
                }
                // bodies in the box help, but only for a ball into it
                if (kind == "header") {
                    when (tac2.cornerMen) {
                        0 -> q *= 0.76
                        2 -> q *= 1.42
                    }
                }
                // and if everyone is up and it comes to nothing, they are exposed
                if (tac2.cornerMen == 2) cornerExposure = att
                // struck after the corner has actually been on screen; see
                // shootAfterScene for why this used to be invisible
                shootAfterScene(att, target, q, kind, takeDelay(CORNER_SECONDS, 0.60))
            }

            else -> {
                var q = CHANCE_QUALITY + phaseGap / 470.0 + (last.ref.att[Att.FIN] - 60) / 850.0
                q *= 0.80 + rng.f() * 0.50
                attemptShot(att, last, q.coerceIn(0.02, 0.66), "shot")
            }
        }
    }

    /** Ball spotted, a wall of defenders paced out in front of it. */
    private fun stageFreeKick(att: Int, def: Int, taker: LivePlayer) {
        stagedUntil = FREEKICK_SECONDS + 1.0f
        freeKickX = taker.x
        freeKickY = taker.y
        // The ball ROLLS to the spot; it does not appear there.
        //
        // This used to assign the position directly, so on every free kick the
        // ball vanished from wherever it was and reappeared at the taker's
        // feet. Measured over 20 matches: the ball jumped more than eight
        // metres in a single frame five times a game, and free kicks are 6.1 a
        // game — this was almost all of it. placeBall rolls it out over a few
        // tenths of a second, which is what a ball being placed actually does,
        // and it is the same call every other restart already uses.
        placeBall(freeKickX, freeKickY)

        val goalX = if (att == 0) 100f else 0f
        val dx = goalX - freeKickX
        val dy = 50f - freeKickY
        val len = max(1f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
        // the wall stands nine and a bit yards away, on the line to goal
        wallX = freeKickX + dx / len * 11f
        wallY = freeKickY + dy / len * 11f
        wallCount = if (kotlin.math.abs(dx) < 30f) 4 else 3

        val defenders = onPitch(def).filter { it.pos != Pos.GK }
            .sortedBy { hypot((it.x - wallX).toDouble(), (it.y - wallY).toDouble()) }
        for (i in 0 until min(wallCount, defenders.size)) {
            defenders[i].targetX = wallX + (i - wallCount / 2f) * 1.6f
            defenders[i].targetY = wallY + (i - wallCount / 2f) * 2.4f
            defenders[i].x = defenders[i].targetX
            defenders[i].y = defenders[i].targetY
            defenders[i].facing = kotlin.math.atan2((freeKickY - defenders[i].y).toDouble(),
                (freeKickX - defenders[i].x).toDouble()).toFloat()
        }
        taker.x = freeKickX - dx / len * 4f
        taker.y = freeKickY - dy / len * 4f
    }

    /**
     * The keeper collects it and everyone else stops chasing.
     *
     * This used to be four lines inline: place the ball, point the keeper at
     * it, restart. It set no hold, so updateTargets pointed him back at his
     * own line on the next tick and he never reached the ball -- measured 11.0 m
     * away from his own goal kick, with the ball sitting on the grass on its
     * own. Making him the holder is what makes it read as a goal kick rather
     * than as a loose ball nobody wants.
     */
    private fun stageGoalKick(def: Int) {
        val gkeep = onPitch(def).firstOrNull { it.pos == Pos.GK } ?: return
        val gkx = if (def == 0) 8f else 92f
        placeBall(gkx, 50f)
        gkeep.targetX = gkx; gkeep.targetY = 50f
        if (STAGE_RESTARTS) {
            stagedUntil = max(stagedUntil, GOALKICK_SECONDS + 0.4f)
            // he is standing over it, not running at it
            gkeep.x = gkx; gkeep.y = 50f
            ball.holder = gkeep.key
        }
    }

    /** One man to the touchline, the rest showing for it. */
    private fun stageThrowIn(side: Int, bx: Float, by: Float) {
        // Hold it, or the next updateTargets sends the taker back to his
        // formation slot and the throw-in is captioned over nobody.
        if (STAGE_RESTARTS) stagedUntil = max(stagedUntil, THROWIN_SECONDS + 0.4f)
        val takers = onPitch(side).filter { it.pos != Pos.GK }
        val taker = nearest(takers, bx, by) ?: return
        taker.targetX = bx; taker.targetY = if (by < 50f) 4f else 96f
        /*
         * He is standing over it, not jogging toward it.
         *
         * Measured at the restart: with only a target set, the nearest man was
         * still 6.7 m from the ball when play resumed, because he starts
         * wherever the move left him and walks at dead-ball pace. stageFreeKick
         * has always placed its taker and its wall directly for exactly this
         * reason; this is the same thing for the restart that happens seven
         * times a match instead of six.
         */
        if (STAGE_RESTARTS) { taker.x = taker.targetX; taker.y = taker.targetY }
        act(taker, Act.RUN, 0.4f, angleTo(taker, bx, 50f))
        for (p in takers) {
            if (p.key == taker.key) continue
            p.targetY += (by - p.targetY) * 0.18f
            p.targetX += (bx - p.targetX) * 0.14f
        }
    }

    /**
     * ENGINE V4, IDEA 2: A SET PIECE IS A PLAY, WITH PARTS AND DEADLINES.
     *
     * This used to send nine men to random points in a rectangle over the
     * penalty area and hope. Two things followed from that, both measured.
     *
     * First, the picture was the SAME for all four corner routines. The routine
     * chose who the ball was aimed at and what the chance was worth, and moved
     * nobody -- so "near post", "far post", "work it short" and "edge of the
     * box" were four identical arrangements with different odds attached. A
     * manager could never see his own instruction.
     *
     * Second, a scatter has no near post and no far post, so there was nothing
     * for a delivery to be aimed AT, which is why the corner has always been the
     * hardest scene in this project to make look like football.
     *
     * A real corner has parts: somebody on the ball, a short option who has to
     * be there early or the short ball is not on, a near-post runner and a
     * far-post runner who ATTACK the ball rather than stand waiting for it, a
     * man at the penalty spot, one on the edge for the cut-back, and men held
     * back against the counter. Each part is a place AND a time, and the times
     * are staggered so the runners arrive with the ball instead of before it.
     *
     * Parts go to whoever is NEAREST them, not in shirt order: a corner where
     * the left back sprints past two team mates to reach the far post is not a
     * corner, and that is what any fixed assignment produces.
     *
     * Deadlines come from ARRIVE_BY (idea 1), which is what makes this possible
     * at all -- before it, a man told to be on the far post did not get there
     * inside the life of a corner.
     *
     * The RNG stream is untouched. Every outfielder still draws exactly the two
     * numbers he drew before, in the same order, whatever part he is given;
     * skipping a draw would shift every later roll in the match onto different
     * numbers, which is the trap the slide-tackle rolls document.
     */
    private fun stageCorner(att: Int) {
        stagedUntil = CORNER_SECONDS + 1.6f
        val goalX = if (att == 0) 100f else 0f
        val cornerY = if (rng.chance(0.5)) 4f else 96f
        cornerFlagX = goalX; cornerFlagY = cornerY
        placeBall(goalX, cornerY)

        // into the pitch from the corner flag, and toward the middle from it
        val inward = if (att == 0) -1f else 1f
        val toMid = if (cornerY < 50f) 1f else -1f
        // the post nearest the flag, and the one away from it
        val nearPostY = 50f - toMid * 4.6f
        val farPostY = 50f + toMid * 4.6f
        // when the ball is actually swung in
        val strike = CORNER_SECONDS * SET_PIECE_TAKE

        val tac = (if (att == 0) home else away).tactics

        /**
         * A part of the routine: where to be, and by when.
         *
         * `by` is seconds from now. A runner attacking the ball is given LESS
         * time than the delivery takes, so he is still moving as it arrives;
         * a man who has to be set -- the short option, the edge -- is given
         * more.
         */
        class Part(val x: Float, val y: Float, val by: Float)

        val parts = ArrayList<Part>(9)
        // 1. the short option, out early: without him there the short ball is
        //    not a choice the manager actually has
        val shortClose = tac.cornerRoutine == 2
        parts.add(Part(goalX + inward * (if (shortClose) 5f else 8f),
            cornerY + toMid * (if (shortClose) 3f else 6f), 1.3f))
        // 2. near post, attacking it
        parts.add(Part(goalX + inward * 4.5f, nearPostY, strike - 0.2f))
        // 3. far post, attacking it
        parts.add(Part(goalX + inward * 6.0f, farPostY, strike - 0.2f))
        // 4. the penalty spot
        parts.add(Part(goalX + inward * 10.5f, 50f, strike - 0.35f))
        // 5. a second man central, half a stride behind him
        parts.add(Part(goalX + inward * 13.5f, 50f + toMid * 3f, strike - 0.35f))
        // 6. the edge, for the cut-back and for the second ball
        parts.add(Part(goalX + inward * 19f, 50f - toMid * 4f, strike - 0.7f))
        /*
         * The routine now MOVES people, which is the whole point of it. A near
         * post corner puts a second body on the near post; a short one puts a
         * second man over the ball; an edge one doubles up outside the area.
         */
        when (tac.cornerRoutine) {
            0 -> parts.add(Part(goalX + inward * 3.0f, nearPostY + toMid * 2.5f, strike - 0.15f))
            2 -> parts.add(Part(goalX + inward * 9f, cornerY + toMid * 9f, 1.6f))
            3 -> parts.add(Part(goalX + inward * 22f, 50f + toMid * 5f, strike - 0.7f))
            else -> parts.add(Part(goalX + inward * 7.5f, 50f + toMid * 8f, strike - 0.3f))
        }
        // 8 and 9: how many of these go up at all is the manager's other
        // corner setting, and it is the one that decides whether he is caught
        // on the break -- so it has to be visible in where the men stand.
        /*
         * Two more places to be, so that "everyone up" has somewhere to put the
         * extra men. Without these the list ran out at seven and everyone-up
         * measured IDENTICAL to normal -- the setting existed and moved nobody,
         * which is the exact defect this whole rewrite is about.
         */
        parts.add(Part(goalX + inward * 8f, 50f - toMid * 7f, strike - 0.3f))
        parts.add(Part(goalX + inward * 15f, 50f - toMid * 8f, strike - 0.5f))

        val holdBack = when (tac.cornerMen) { 0 -> 4; 2 -> 0; else -> 2 }
        val upFront = (9 - holdBack).coerceIn(2, 9)

        val taker = if (STAGE_RESTARTS)
            nearest(onPitch(att).filter { it.pos != Pos.GK }, goalX, cornerY) else null

        /*
         * Parts are handed to whoever is NEAREST to them, not in shirt order.
         * A corner in which the left back sprints past two team mates to reach
         * the far post is not a corner, and it is what any fixed assignment
         * produces.
         */
        val runners = onPitch(att).filter { it.pos != Pos.GK && it.key != taker?.key }
        val claimed = HashSet<String>(9)
        val partOf = HashMap<String, Part>(9)
        for (i in 0 until minOf(upFront, parts.size)) {
            val part = parts[i]
            val man = runners.filter { it.key !in claimed }
                .minByOrNull { hypot((it.x - part.x).toDouble(), (it.y - part.y).toDouble()) }
                ?: break
            claimed.add(man.key)
            partOf[man.key] = part
        }

        for (p in onPitch(att)) {
            if (p.pos == Pos.GK) continue
            val jx = rng.f().toFloat()
            val jy = rng.f().toFloat()
            if (taker != null && p.key == taker.key) {
                // ON the ball, not a couple of yards off it. CornerFilm had the
                // nearest attacker 2.5 m from the corner for the whole hold,
                // which is a man standing near a corner, not taking one.
                p.targetX = goalX + inward * 1.0f
                p.targetY = cornerY + toMid * 0.9f
                p.x = p.targetX; p.y = p.targetY
                p.facing = angleTo(p, goalX + inward * 12f, 50f)
                p.arriveBy = 0f
                continue
            }
            val part = partOf[p.key]
            if (part != null) {
                // a yard of jitter so nine men are not on a drawn diagram
                p.targetX = (part.x + (jx - 0.5f) * 2.4f).coerceIn(2f, 98f)
                p.targetY = (part.y + (jy - 0.5f) * 3.0f).coerceIn(4f, 96f)
                p.arriveBy = max(0.8f, part.by)
            } else {
                /*
                 * Held back, in his OWN half, ready for the counter.
                 *
                 * The sign was the wrong way round here and put the "held back"
                 * men at x 56-70 for a side attacking x=100 -- in the opposition
                 * half, twenty metres in front of where they were supposed to
                 * be. `inward` already points from the corner flag INTO the
                 * pitch, so going back is plus, not minus.
                 */
                p.targetX = (50f + inward * (6f + jx * 16f)).coerceIn(6f, 94f)
                p.targetY = 26f + jy * 48f
                p.arriveBy = strike
            }
        }

        /*
         * The defending side is a play too. Two on the posts, the keeper on his
         * line, and everybody else goal-side of a man -- which is what makes the
         * box look defended rather than occupied.
         */
        val marks = onPitch(att).filter { it.pos != Pos.GK && it.key != taker?.key }
            .sortedBy { hypot((it.targetX - goalX).toDouble(), (it.targetY - 50.0)) }
        var markIdx = 0
        var posts = 0
        for (p in onPitch(1 - att)) {
            val jitterX = rng.f().toFloat()
            val jitterY = rng.f().toFloat()
            if (p.pos == Pos.GK && KEEPER_ON_LINE) {
                p.targetX = if (att == 0) 96.5f else 3.5f
                p.targetY = 50f
                p.arriveBy = 1.2f
                continue
            }
            if (posts < 2) {
                // a man on each post, there before anything else happens
                p.targetX = goalX + inward * 1.6f
                p.targetY = if (posts == 0) nearPostY else farPostY
                p.arriveBy = 1.6f
                posts++
                continue
            }
            val mark = marks.getOrNull(markIdx++)
            if (mark != null) {
                // goal-side of him and half a stride off his shoulder
                p.targetX = (mark.targetX + inward * -1.8f + (jitterX - 0.5f) * 1.6f)
                    .coerceIn(2f, 98f)
                p.targetY = (mark.targetY + (jitterY - 0.5f) * 2.4f).coerceIn(4f, 96f)
                p.arriveBy = max(0.9f, strike - 1.2f)
            } else {
                // spare men screen the edge of the area
                p.targetX = goalX + inward * (17f + jitterX * 6f)
                p.targetY = 34f + jitterY * 32f
                p.arriveBy = max(0.9f, strike - 1.2f)
            }
        }
    }

    private fun attemptShot(att: Int, shooterIn: LivePlayer, quality: Double, kind: String) {
        val def = 1 - att
        /*
         * Nobody shoots from their own half.
         *
         * A shot arrives here down several routes — the end of a move, a corner
         * headed by whoever the routine picked, a free kick — and none of them
         * checked where the man actually was. Measured over 40 matches: 25.9%
         * of GOALS were struck from inside the shooter's own half, against a
         * real figure of about one a season in an entire league.
         *
         * This is deliberately the narrowest fix that removes the absurdity:
         * the chance simply falls to whichever attacker is nearest the goal,
         * and no attack is ever cancelled. Cancelling them, and adding a
         * distance curve to chance quality, were both tried and both wrecked
         * the result distribution — see the note in the harness README.
         */
        var shooter = shooterIn
        if (kind != "penalty") {
            val shotGoalX = if (att == 0) 100f else 0f
            fun rangeOf(p: LivePlayer) =
                hypot(((shotGoalX - p.x) * 1.05).toDouble(), ((50f - p.y) * 0.68).toDouble())
            if (rangeOf(shooter) > SHOT_RANGE_M) {
                onPitch(att).filter { it.pos != Pos.GK }.minByOrNull { rangeOf(it) }
                    ?.let { shooter = it }
            }
        }
        /*
         * THE BALL IS IN PLAY AGAIN, SO THE ARRANGEMENT IS OVER.
         *
         * stagedUntil is a fixed hold -- CORNER_SECONDS + 1.6 -- set when the
         * set piece is AWARDED, and updateTargets returns early for the whole
         * of it, so nobody is given a new target. The delivery happens partway
         * through, and the remainder was then spent with all twenty two men
         * still holding their corner positions while the ball was somewhere
         * else entirely. Measured over 20 matches: after the ball left the
         * flag the gate stayed open a further 7.20 seconds. A goal kick was
         * taken with both sides standing in the six yard box, nobody moving.
         *
         * The arrangement exists to get men into position for the delivery. The
         * delivery has now happened, so it is finished, whatever is left on the
         * clock.
         */
        if (RELEASE_STAGING) stagedUntil = 0f

        shots[att]++
        xg[att] += quality
        shooter.shots++
        captureFrame()

        val gk = onPitch(def).firstOrNull { it.pos == Pos.GK }
        val goalX = if (att == 0) 99f else 1f
        val shotDist = hypot((goalX - ball.x).toDouble(), (50f - ball.y).toDouble()).toFloat()
        // distance-aware: a flat 0.55s meant long shots travelled absurdly fast
        moveBallTo(goalX, 50f + (rng.f().toFloat() - 0.5f) * 16f,
            (0.34f + shotDist / 46f).coerceIn(0.34f, 1.15f),
            if (kind == "header") 4.2f else 1.6f)
        ball.struck = true
        ball.holder = null

        // the striker plants his foot; the keeper reacts
        act(shooter, if (kind == "header") Act.HEADER else Act.SHOOT, SHOOT_POSE,
            angleTo(shooter, goalX, 50f))
        cue(if (kind == "header") Synth.Sfx.KICK else Synth.Sfx.KICK_HARD, 1f, shooter.x)
        // Long enough to see the shot and its follow through. This was three
        // seconds, and with twenty six shots a match that alone kept the close
        // camera on for four fifths of the game.
        holdDanger(0.9f)
        crowdTarget = max(crowdTarget, 0.80f)

        val gkSkill = if (gk != null)
            gk.ref.att[Att.GKR] * 0.6 + gk.ref.att[Att.GKH] * 0.4 else 50.0

        val tOn = min(0.92, 0.33 + quality * 0.7)
        if (!rng.chance(tOn)) {
            say(L_MISS, shooter.name, teamName(att))
            // A share of the misses are woodwork. Still decided on the cosmetic
            // stream so the result is exactly what it was before, but now the
            // frame is struck and the ball comes back off it.
            // 0.18 of the misses gave 2.9 a match against a real figure
            // nearer half of one. Cosmetic stream, so this moves the picture
            // and not a single result.
            if (physRng.chance(0.04)) {
                cue(Synth.Sfx.POST, 0.95f, goalX)
                woodwork = 0.9f
                woodworkBar = physRng.chance(0.45)
                woodworkX = goalX
                woodworkY = if (woodworkBar) 50f
                else 50f + (if (physRng.chance(0.5)) -3.6f else 3.6f)
                shake = max(shake, 0.5f)
                crowdTarget = 0.92f
                sayRaw(FeedLine.CHANCE,
                    if (woodworkBar) "Off the crossbar! ${shooter.name} could not believe it."
                    else "Off the post! Inches away from ${shooter.name}.")
                // it comes back into play off the frame
                ball.x = woodworkX; ball.y = woodworkY
                ball.t = 1f
                ball.height = 0.8f
                ball.vz = -1.2f
                ball.driftX = if (att == 0) -1.1f else 1.1f
                ball.driftY = (physRng.f().toFloat() - 0.5f) * 1.4f
            }
            cue(Synth.Sfx.OOH, 0.85f)
            crowdTarget = 0.45f
            scene = Scene.GOAL_KICK; sceneTime = GOALKICK_SECONDS
            stageGoalKick(def)
            flipLater(def, 0.6)
            return
        }
        onTarget[att]++
        // He goes down for a shot that is actually going somewhere. This used
        // to fire on EVERY attempt, so the keeper threw himself full length at
        // balls flying into the stand: 26 dives a match against a real six.
        // Rolled on the cosmetic stream — which way he dives cannot change a
        // result, and it should not be able to move the RNG that does.
        if (gk != null) act(gk, Act.DIVE, 1.1f, if (sfxRng.chance(0.5)) -1.35f else 1.35f)
        val convert = ((quality / tOn) * (1.0 - (gkSkill - 62.0) / 320.0)).coerceIn(0.03, 0.95)
        if (rng.chance(convert)) {
            // decided now, given when the ball crosses the line
            pendingGoal = PendingGoal(att, shooter.key, false)
            /*
             * IT HAS TO GO IN THE NET.
             *
             * The shot was aimed at x = 99 or 1, which is the goal LINE, so a
             * scoring shot stopped dead on the line and the replay -- captured
             * the instant the goal is awarded -- ended with the ball sitting on
             * it. The net is beyond the line, and the one thing a goal replay
             * has to show is the ball going into it.
             *
             * A shot that is going in is re-aimed past the line now. A miss is
             * untouched, so shots that go wide still behave exactly as before,
             * and the conversion roll above has already happened -- this moves
             * the picture and not one result.
             *
             * 1.9 units is 2.0 m, and the renderer's net runs 2.3 m deep along
             * the ground: filmed at 3.5 units the ball finished BEHIND the
             * netting, which looks no better than stopping on the line.
             */
            ball.toX = if (att == 0) 101.9f else -1.9f
            /*
             * And BETWEEN THE POSTS. The aim above is 50 +/- 8 units, while the
             * goal is 7.32 m wide -- 5.4 units either side of centre -- so a
             * good third of the goals scored were drawn entering the net a
             * yard outside the upright.
             */
            ball.toY = ball.toY.coerceIn(45.9f, 54.1f)
            ball.duration += 0.18f
            ball.vx = if (att == 0) kotlin.math.abs(ball.vx) + 6f else -kotlin.math.abs(ball.vx) - 6f
        } else {
            if (gk != null) { gk.saves++ }
            liveScene(Scene.SAVE, 1.5f)
            cue(Synth.Sfx.OOH, 0.7f)
            cue(Synth.Sfx.APPLAUSE, 0.55f)
            crowdTarget = 0.50f
            say(L_SAVE, shooter.name, gk?.name ?: "the keeper")
            /*
             * THE BALL IS STILL LIVE.
             *
             * A save used to be the end of it: 45% a corner, otherwise a goal
             * kick, and the move was over. No spill, no follow-in, no scramble
             * — which is most of what makes a chance memorable rather than a
             * statistic. A keeper who parries into the six yard box and a
             * striker arriving on the rebound is the single most recognisable
             * moment in the football games this is trying to feel like.
             *
             * The follow-up is worth much less than the chance that created it
             * (it is struck early, off balance, with bodies in the way), and it
             * cannot itself rebound — `kind` guards the recursion so a scramble
             * is at most two strikes.
             */
            val spilled = kind != "rebound" && rng.chance(REBOUND_CHANCE)
            val follower = if (!spilled) null else {
                val gx = if (att == 0) 100f else 0f
                onPitch(att).filter { it.pos != Pos.GK }.minByOrNull {
                    hypot(((gx - it.x) * 1.05).toDouble(), ((50f - it.y) * 0.68).toDouble())
                }
            }
            if (follower != null) {
                // parried out to where he is arriving, not held
                placeBall(follower.x, follower.y)
                sayRaw(FeedLine.CHANCE, "Parried out, and ${follower.name} is onto it!")
                crowdTarget = 0.95f
                holdDanger(1.2f)
                shootAfterScene(att, follower, quality * 0.55, "rebound", 0.22)
                return
            }
            // staged at once; the CAPTION waits for the save to have its beat
            if (rng.chance(0.45)) { corners[att]++; stageCorner(att); sceneAfter(Scene.CORNER, CORNER_SECONDS) }
            else sceneAfter(Scene.GOAL_KICK, 1.2f)
            flipLater(def, 0.5)
        }
    }

    private fun takePenalty(att: Int) {
        val def = 1 - att
        scene = Scene.PENALTY; sceneTime = 2.0f
        val attClub = if (att == 0) home else away
        val takers = onPitch(att).filter { it.pos != Pos.GK }
        // the nominated penalty taker steps up if he is still on the pitch
        val nominated = attClub.tactics.penaltyTaker.let { slot ->
            if (slot >= 0) takers.firstOrNull { it.slot == slot } else null
        }
        val taker = nominated ?: takers.maxByOrNull {
            it.ref.att[Att.FIN] + (if (it.ref.hasTrait(Traits.SET_PIECE)) 20 else 0)
        } ?: return
        val gk = onPitch(def).firstOrNull { it.pos == Pos.GK }

        // Stage it properly: the taker on the spot, the keeper on his line and
        // everybody else outside the area, watching.
        val spotX = if (att == 0) 88f else 12f
        taker.x = spotX; taker.y = 50f
        taker.targetX = spotX; taker.targetY = 50f
        taker.facing = if (att == 0) 0f else Math.PI.toFloat()
        gk?.let {
            it.x = if (att == 0) 99f else 1f; it.y = 50f
            it.targetX = it.x; it.targetY = it.y
            it.facing = if (att == 0) Math.PI.toFloat() else 0f
        }
        val edge = if (att == 0) 79f else 21f
        var k = 0
        for (p in players) {
            if (!p.onPitch || p.key == taker.key || p.key == gk?.key) continue
            val spread = 26f + (k % 9) * 6f
            p.x = edge + (if (att == 0) -(k % 3) * 3.5f else (k % 3) * 3.5f)
            p.y = spread
            p.targetX = p.x; p.targetY = p.y
            p.facing = if (att == 0) 0f else Math.PI.toFloat()
            k++
        }
        ball.x = spotX; ball.y = 50f
        ball.t = 1f; ball.height = 0f
        ball.holder = null

        act(taker, Act.SHOOT, 1.0f, if (att == 0) 0f else Math.PI.toFloat())
        if (gk != null) act(gk, Act.DIVE, 1.3f, if (rng.chance(0.5)) -1.35f else 1.35f)

        shots[att]++; onTarget[att]++; xg[att] += 0.78
        ball.x = if (att == 0) 88f else 12f
        ball.y = 50f
        moveBallTo(if (att == 0) 99f else 1f, 50f + (rng.f().toFloat() - 0.5f) * 14f, 0.62f, 0.8f)
        captureFrame()

        var chance = 0.76 + (taker.ref.att[Att.FIN] - 60) / 500.0
        if (gk != null) chance -= (gk.ref.att[Att.GKR] - 60) / 700.0
        if (rng.chance(chance)) {
            // same as open play: the ball has to reach the net first, and it
            // has to end up inside it rather than stopping on the line
            pendingGoal = PendingGoal(att, taker.key, true)
            ball.toX = if (att == 0) 101.9f else -1.9f
            ball.toY = ball.toY.coerceIn(45.9f, 54.1f)
            ball.duration += 0.18f
        } else {
            if (gk != null) gk.saves++
            say(L_PENMISS, taker.name, gk?.name ?: "the keeper")
            flipLater(def, 0.6)
        }
    }

    private fun scoreGoal(att: Int, scorer: LivePlayer, penalty: Boolean) {
        score[att]++
        scorer.goals++
        var assist: LivePlayer? = null
        if (!penalty && rng.chance(0.65)) {
            val mates = onPitch(att).filter { it.key != scorer.key && it.pos != Pos.GK }
            assist = nearest(mates, scorer.x, scorer.y)
            assist?.assists++
        }
        /*
         * THE GOAL IS THE MOMENT NOW.
         *
         * scoreGoal never cleared the scene, so a penalty scored inside its own
         * two-second caption drew PENALTY, the GOAL banner and the celebration
         * starburst in the same frame -- three moments stacked on one picture,
         * measured on 100% of penalties. The set piece is over; it produced
         * this.
         */
        if (STAGE_RESTARTS) {
            scene = Scene.NONE
            sceneTime = 0f
            queuedScene = Scene.NONE
            queuedTime = 0f
            stagedUntil = 0f
        }
        momentum = (momentum + if (att == 0) 0.35 else -0.35).coerceIn(-1.0, 1.0)
        flash = 1f; shake = 1f
        celebrateKey = scorer.key
        celebrateTime = 0f
        act(scorer, Act.CELEBRATE, 2.4f)
        for (mate in onPitch(att)) if (mate.key != scorer.key && rng.chance(0.4)) act(mate, Act.CELEBRATE, 1.8f)
        banner = "GOAL!  ${scorer.fullName}"
        bannerTime = 2.4f
        // He peels away toward the near corner, but only part of the way: a
        // sprint to the flag from wherever he happened to be left the rest of
        // the team stranded in midfield with nobody to mob.
        celebrationTime = 6.0f
        celebrateSide = att
        celebrateScorer = scorer.key
        val cornerX = if (att == 0) 96f else 4f
        val cornerY = if (scorer.y < 50f) 6f else 94f
        celebrateRunX = scorer.x + (cornerX - scorer.x) * 0.45f
        celebrateRunY = scorer.y + (cornerY - scorer.y) * 0.45f
        cue(Synth.Sfx.NET, 1f, if (att == 0) 96f else 4f)
        cue(Synth.Sfx.ROAR, 1f)
        cue(Synth.Sfx.APPLAUSE, 0.8f)
        crowdTarget = 1.0f
        if (replaysEnabled) {
            // Take a frame right now, with the ball where it finished. Without
            // this the last recorded frame is from the update before the ball
            // crossed the line, and a shot covers enough ground in one frame
            // that the replay ended several units short of the goal.
            captureFrame()
            pendingReplay = history.takeLast(78).toList()
            replayDelay = 2.9f
        }
        replayIndex = 0
        replayCursor = 0f

        val scoreText = "${score[0]}-${score[1]}"
        if (assist != null) sayRaw(
            FeedLine.GOAL,
            "${assist.name} slides it through and ${scorer.fullName} finishes it off. $scoreText."
        ) else sayRaw(
            FeedLine.GOAL,
            if (penalty) "${scorer.fullName} sends the keeper the wrong way from the spot. $scoreText."
            else "${scorer.fullName} finds the net. $scoreText."
        )
        events.add(MatchEvent(clock.toInt(), Ev.GOAL, att, scorer.fullName, assist?.fullName ?: ""))

        /*
         * THE SIDE THAT CONCEDED RESTARTS FROM THE CENTRE.
         *
         * A goal just flipped possession after 1.2 match minutes and play
         * resumed from wherever the ball happened to be -- usually in the back
         * of the net. There was no kick-off: Scene.KICK_OFF fired once a match,
         * at the opening whistle, and never again. Every goal in football is
         * followed by eleven men walking back and one of them rolling it to a
         * team mate on the centre spot, and none of that existed.
         *
         * Staged here so it plays out after the celebration: the ball on the
         * spot, the two sides in their own halves, and the conceding side on
         * the ball.
         */
        kickOffSide = 1 - att
        kickOffDue = 1.4f
        /*
         * Play is held until the restart is actually taken, so the delay here
         * only has to be long enough never to fire on its own: stageKickOff
         * sets the real one. Without this the old 1.2-minute flip resumed open
         * play two and a half seconds into a six-second celebration, and the
         * kick-off then interrupted a move that had already started.
         */
        flipLater(1 - att, 999.0)
        /*
         * The old restart cost 1.2 match minutes of dead time and gave none of
         * it back. The celebration and the arrangement together are longer than
         * that, so the difference is returned as stoppage -- the same bargain
         * the throw-in makes, and the reason a longer restart does not quietly
         * cost the match goals.
         */
        stoppage += (((kickOffDue + celebrationTime + KICKOFF_SECONDS).toDouble()
                / SECONDS_PER_MINUTE) - 1.2).coerceAtLeast(0.0)
    }

    /** Which side restarts, and how long until they do. */
    private var kickOffSide = -1
    private var kickOffDue = 0f
    /** True while the pending flip is a kick-off rather than a loose turnover. */
    private var kickOffPending = false

    /**
     * The restart after a goal: ball on the spot, everyone in his own half, the
     * side that conceded standing over it.
     */
    private fun stageKickOff(side: Int) {
        placeBall(50f, 50f)
        ball.vx = 0f; ball.vy = 0f; ball.vz = 0f
        ball.height = 0f
        scene = Scene.KICK_OFF
        sceneTime = KICKOFF_SECONDS
        stagedUntil = max(stagedUntil, KICKOFF_SECONDS + 0.4f)
        possessionSide = side
        for (p in players) {
            if (!p.onPitch) continue
            // every man in his own half, in his drawn station
            val bx = ownX(p.side, p.baseX)
            val by = ownY(p.side, p.baseY)
            p.targetX = if (p.side == 0) kotlin.math.min(bx, 47f) else kotlin.math.max(bx, 53f)
            p.targetY = by
        }
        // the two who take it stand over the ball
        val takers = onPitch(side).filter { it.pos != Pos.GK }
            .sortedBy { kotlin.math.abs(it.baseX - 60f) }
        takers.getOrNull(0)?.let { it.x = 48.5f; it.y = 50f; it.targetX = 48.5f; it.targetY = 50f }
        takers.getOrNull(1)?.let { it.x = 51.5f; it.y = 52.5f; it.targetX = 51.5f; it.targetY = 52.5f }
        sayRaw(FeedLine.PLAIN, "${teamName(side)} restart from the centre circle.")
    }

    /**
     * Name a moment of live play.
     *
     * The events were all already happening -- a keeper threw himself at the
     * ball, a defender slid in, a man struck a shot -- with a pose and a sound
     * and nothing on the screen ever saying so, because scenes existed only for
     * set pieces. This is the same fix the take-on got, applied to the rest.
     *
     * It never overwrites a stoppage that is already up: a booking or a corner
     * is the bigger news and owns the screen until it is done.
     */
    /**
     * Show this scene once the live moment on screen has had its beat. If
     * nothing is up, it plays at once.
     */
    private fun sceneAfter(kind: Int, seconds: Float) {
        if (SCENE_AI && sceneTime > 0f && Scene.isLive(scene) && scene != Scene.NONE) {
            queuedScene = kind
            queuedTime = seconds
        } else {
            scene = kind
            sceneTime = seconds
        }
    }

    private fun liveScene(kind: Int, seconds: Float) {
        if (!SCENE_AI) return
        if (sceneTime > 0f && !Scene.isLive(scene)) return
        scene = kind
        sceneTime = seconds
    }

    private fun showRef(p: LivePlayer, card: Int) {
        refX = p.x - 4f
        refY = p.y + 2f
        refCard = card
        refTime = REF_HOLD
    }

    /** A hot head collects more than a model professional for the same challenge. */
    private fun cardRisk(p: LivePlayer): Double {
        var r = Personalities.of(p.ref.personality).discipline *
            (if (p.ref.hasTrait(Traits.HOTHEAD)) 1.4 else 1.0)
        // a side that knows the manager will not stand for it gives away less
        val club = if (p.side == 0) home else away
        if (club.isUser) r *= world.profile.mannerInfo.discipline
        return r
    }

    private fun card(p: LivePlayer, red: Boolean) {
        showRef(p, if (red) 2 else 1)
        /*
         * A BOOKING IS A MOMENT, NOT A FOOTNOTE.
         *
         * The referee sprite and its card were already drawn, for 2.6 s, while
         * the game carried on around them and the free kick scene overwrote the
         * moment a tick later. Nothing announced it and nothing stopped for it,
         * which is why "there is no red or yellow card scene" was true even
         * though a card was on the screen.
         *
         * The scene is set LAST here and the free kick below refuses to
         * overwrite it, so the card is what the viewer is shown; the free kick
         * is still staged underneath and taken when the moment passes.
         */
        cardedKey = p.key
        scene = Scene.CARD
        sceneTime = 2.6f
        banner = if (red) "RED CARD" else "YELLOW CARD"
        bannerTime = 2.2f
        cue(Synth.Sfx.WHISTLE_SHORT, 0.85f, p.x)
        cue(Synth.Sfx.GROAN, 0.6f)
        crowdTarget = max(crowdTarget, 0.65f)
        if (red) { sendOff(p, false); return }
        p.yellow++
        yellows[p.side]++
        if (p.yellow >= 2) { sendOff(p, true); return }
        sayRaw(FeedLine.CARD, "${p.fullName} goes into the book.")
        events.add(MatchEvent(clock.toInt(), Ev.YELLOW, p.side, p.fullName))
    }

    private fun sendOff(p: LivePlayer, second: Boolean) {
        p.sentOff = true
        p.onPitch = false
        reds[p.side]++
        banner = "RED CARD  \u2014  ${p.fullName}"
        bannerTime = 2.4f
        sayRaw(FeedLine.CARD, "${p.fullName} is off! Down to ten.")
        events.add(MatchEvent(clock.toInt(), Ev.RED, p.side, p.fullName))
        val r = rating(p.side)
        r.attack -= 2.6; r.defence -= 2.2; r.control -= 3.0
    }

    private fun injure(p: LivePlayer) {
        cue(Synth.Sfx.WHISTLE_SHORT, 0.8f, p.x)
        crowdTarget = 0.25f
        p.injured = true
        act(p, Act.DOWN, 2.2f)
        p.injuryWeeks = if (rng.chance(0.60)) rng.i(1, 3) else rng.i(4, 12)
        banner = "${p.fullName} is down"
        bannerTime = 1.8f
        sayRaw(FeedLine.PLAIN, "${p.fullName} pulls up and signals to the bench.")
        events.add(MatchEvent(clock.toInt(), Ev.INJURY, p.side, p.fullName))
    }

    private fun flip(side: Int) {
        possessionSide = nextSide(side)
        newPhase()
    }

    private fun flipLater(side: Int, delayMinutes: Double) {
        pendingSide = side
        pendingAt = clock + delayMinutes
        phaseSeq = ArrayList()
    }

    /**
     * A set piece that is struck AFTER the picture has shown it being set up.
     *
     * Corners and free kicks used to stage their scene and then call
     * attemptShot on the very same tick. attemptShot ends by setting a scene of
     * its own — a goal kick for a miss, a corner for a save — so the set piece
     * it was called from was overwritten before a single frame had been drawn
     * with it. Measured over 30 matches: 4.4 corners a match reached the screen,
     * and every one of those was the corner *won from a save*, not the corner
     * that had just been staged; free kicks reached the screen 0.1 times a
     * match. The player was never shown a corner or a free kick being taken,
     * only the goal kick afterwards. That is most of what "the match doesn't
     * feel alive" was.
     *
     * The shot is identical and so is its quality, so this moves the picture
     * and not the result — the delay is a few tenths of a match minute, which
     * is the pause the scene needs to be seen.
     */
    private class PendingShot(
        val att: Int, val takerKey: String, val quality: Double, val kind: String
    )

    private var pendingShot: PendingShot? = null
    private var pendingShotAt = 0.0

    private fun shootAfterScene(
        att: Int, taker: LivePlayer, quality: Double, kind: String, delayMinutes: Double
    ) {
        pendingShot = PendingShot(att, taker.key, quality, kind)
        pendingShotAt = clock + delayMinutes
        phaseSeq = ArrayList()
        // The pause is stoppage time, and it is given back as stoppage time.
        // Without this the fourteen or so set pieces a match ate about eight
        // minutes of the phase budget between them and goals per game fell from
        // 2.57 to 2.39 — outside the target band — purely because the ball was
        // out of play more. A referee adds this on; so does this.
        stoppage += delayMinutes
    }

    /** The better team on the ball wins it back more often — this is what moves possession %. */
    private fun nextSide(natural: Int): Int {
        val h = ratingHome.control
        val a = ratingAway.control
        val pHome = (0.5 + (h - a) / 45.0).coerceIn(0.26, 0.74)
        if (rng.chance(0.62)) return natural
        return if (rng.chance(pHome)) 0 else 1
    }

    /**
     * Puts a player into a pose for a moment. Floor poses are rationed so the
     * pitch never fills up with men lying down, and only a keeper may dive.
     */
    /**
     * Poses a player. [cosmetic] marks a call that exists only to be looked at,
     * and such a call is never allowed to cut short a man who is on the floor.
     *
     * That rule is what makes presentation safe to change. TACKLE, DOWN and
     * DIVE stop a player moving; every other action lets him run. So a cosmetic
     * act landing on a man mid-slide used to stand him straight back up, and
     * since nextMan picks the next man in a move by who is standing nearby,
     * that reached the scoreline. It is why adding a commentary flourish could
     * change a result: firing a take-on at a different moment unfroze a
     * different defender. Measured with ResultFingerprint, which must come back
     * byte identical when a purely cosmetic draw is added or removed.
     */
    private fun act(
        p: LivePlayer, action: Int, seconds: Float, dir: Float = p.facing,
        cosmetic: Boolean = false
    ) {
        if (action == Act.DIVE && p.pos != Pos.GK) return
        if (cosmetic && p.actionTime > 0f &&
            (p.action == Act.TACKLE || p.action == Act.DOWN || p.action == Act.DIVE)) return
        if (action == Act.TACKLE || action == Act.DOWN) {
            val onFloor = players.count {
                it.onPitch && (it.action == Act.TACKLE || it.action == Act.DOWN)
            }
            if (onFloor >= 2) return
        }
        p.action = action
        p.actionTime = seconds
        p.actionDir = dir
    }

    private fun angleTo(from: LivePlayer, x: Float, y: Float): Float =
        kotlin.math.atan2((y - from.y).toDouble(), (x - from.x).toDouble()).toFloat()

    private fun nearest(list: List<LivePlayer>, x: Float, y: Float): LivePlayer? {
        var best: LivePlayer? = null
        var bd = Float.MAX_VALUE
        for (p in list) {
            val d = hypot((p.x - x).toDouble(), (p.y - y).toDouble()).toFloat()
            if (d < bd) { bd = d; best = p }
        }
        return best
    }

    private fun <T> List<T>.randomOrNull(r: Rng): T? = if (isEmpty()) null else r.pick(this)

    private fun teamName(side: Int) = if (side == 0) home.name else away.name

    /* ------------------------------------------------------- COMMENTARY */

    private val L_PASS = 0; private val L_TACKLE = 1; private val L_FOUL = 2
    private val L_MISS = 3; private val L_SAVE = 4; private val L_CORNER = 5
    private val L_PENALTY = 6; private val L_PENMISS = 7; private val L_AMBIENT = 8
    private val L_DRIBBLE = 9

    /** Named tricks, shown on screen when a flair player pulls one off. */
    private val SKILL_MOVES = arrayOf(
        "STEPOVER", "NUTMEG", "CRUYFF TURN", "ROULETTE",
        "DRAG BACK", "RAINBOW FLICK", "BODY FEINT", "ELASTICO"
    )

    private val DRIBBLE_LINES = arrayOf(
        "{a} drops the shoulder and goes past {b}.",
        "Lovely turn by {a}, and {b} is left for dead.",
        "{a} nutmegs {b} and drives on.",
        "{b} cannot get near {a} there.",
        "{a} rolls him, beats {b} on the outside.",
        "Quick feet from {a}, past {b} and away.",
        "{a} checks back inside {b}.",
        "{b} dives in and {a} is gone.",
        "{a} rides the challenge from {b} and keeps going.",
        "A stepover from {a}, and {b} has bought it."
    )

    private val BANKS: Array<Array<String>> = arrayOf(
        arrayOf("{a} looks up and finds {b}.", "{a} switches it to {b}.", "Neat interchange, {a} to {b}.",
            "{a} rolls it into {b}.", "{a} clips it forward for {b}.", "Simple ball, {a} to {b}.",
            "{a} threads it between the lines to {b}.", "{a} plays it first time into {b}.",
            "{b} drops off and takes it from {a}.", "{a} spreads it wide to {b}.",
            "{a} finds the angle, and {b} is there.", "Patient stuff, {a} to {b}.",
            "{a} dinks it over the top for {b}.", "{b} shows for it and {a} obliges.",
            "A one-two between {a} and {b}."),
        arrayOf("{a} times the challenge perfectly on {b}.", "Superb tackle by {a} to dispossess {b}.",
            "{a} reads it and steals in front of {b}.", "{a} nicks it off {b}'s toe.",
            "Strong in the challenge, {a} comes away with it.", "{b} loses it, and {a} is the man who took it.",
            "{a} gets across {b} and shepherds it away.", "That is a proper tackle from {a}.",
            "{a} wins it back inside his own half.", "{b} dallied, and {a} punished him."),
        arrayOf("{a} clips {b} \u2014 free kick.", "Cynical from {a}, and the whistle goes.",
            "{a} catches {b} late."),
        arrayOf("{a} drags it wide.", "{a} skies it over the bar.", "Nowhere near for {a}.",
            "{a} takes it on and it whistles past the post.", "{a} leans back and puts it into the stand.",
            "Off target from {a}, and he knows it.", "{a} snatches at it.",
            "It comes off the outside of {a}'s boot and away.", "{a} curls it just the wrong side of the upright.",
            "A glorious chance, and {a} has put it wide.", "{a} tries the far corner and misses it by a yard.",
            "Wasteful from {a}."),
        arrayOf("{a} tries his luck \u2014 {b} pushes it away.", "Fine stop from {b} to deny {a}.",
            "{b} gets a strong hand to {a}'s effort.", "{b} is equal to it, and {a} holds his head.",
            "What a save! {b} keeps {a} out.", "{a} strikes it well but {b} is behind it.",
            "{b} parries, and the danger is cleared.", "Point-blank from {a}, and {b} somehow stops it.",
            "{b} tips {a}'s effort over the top.", "{a} thought he had scored. {b} had other ideas."),
        arrayOf("Corner to {a}.", "{a} win a corner and load the box."),
        arrayOf("Penalty! {a} brings him down inside the area \u2014 {b} have a huge chance."),
        arrayOf("{b} saves it! {a} will not sleep tonight.", "{a} strikes it poorly and {b} keeps it out."),
        arrayOf("A real edge to this one now.", "The crowd senses something.",
            "Both sides feeling their way back into it.", "A scrappy spell in midfield.",
            "The managers are on the touchline barking instructions.",
            "Territory, without the final ball.", "The tempo has dropped right off.",
            "Plenty of huff and puff, not much end product.", "It has turned into a battle in the middle.",
            "Both benches are up and shouting.", "You can feel this one turning.",
            "A lull, and the crowd has gone quiet with it.", "Neither side wants to give an inch.",
            "The referee has a word \u2014 tempers are fraying.", "End to end for a moment there.",
            "Someone needs to take hold of this game.", "A booking waiting to happen.",
            "The pitch is cutting up badly now.", "Legs are going in this heat.",
            "That is better \u2014 finally some rhythm.")
    )

    private fun say(bank: Int, a: String, b: String) {
        val used = usedLines.getOrPut(bank) { ArrayList() }
        val options = BANKS[bank]
        if (used.size >= options.size) used.clear()
        var idx = rng.i(0, options.size - 1)
        var guard = 0
        while (used.contains(idx) && guard++ < 12) idx = rng.i(0, options.size - 1)
        used.add(idx)
        val kind = when (bank) {
            L_MISS, L_SAVE, L_PENALTY, L_PENMISS -> FeedLine.CHANCE
            else -> FeedLine.PLAIN
        }
        sayRaw(kind, options[idx].replace("{a}", a).replace("{b}", b))
    }

    private fun sayRaw(kind: Int, text: String) {
        feed.add(0, FeedLine(clock.toInt(), text, kind))
        while (feed.size > 120) feed.removeAt(feed.size - 1)
    }

    /* ------------------------------------------------------------ UPDATE */

    fun start() {
        if (finished) return
        if (!kicked && lineupTime <= 0f && !lineupDone) {
            // the walkout runs first; the whistle follows it
            lineupDone = true
            lineupTime = 4.0f
            scene = Scene.LINEUP
            banner = "TEAMS ARE OUT"
            bannerTime = 3.0f
            crowdTarget = 0.62f
            cue(Synth.Sfx.APPLAUSE, 0.85f)
            running = true
            return
        }
        if (!kicked) {
            kicked = true
            sayRaw(FeedLine.WHISTLE, "We are under way at ${home.stadiumName}. ${home.name} against ${away.name}.")
            // Scene.KICK_OFF existed in the enum, had a label, and was never
            // assigned by anything: measured at 0.0 a match. Same for
            // SUBSTITUTION below.
            scene = Scene.KICK_OFF; sceneTime = 1.6f
            banner = "KICK OFF"; bannerTime = 1.8f
            cue(Synth.Sfx.WHISTLE_SHORT, 0.9f)
            cue(Synth.Sfx.APPLAUSE, 0.7f)
            crowdTarget = 0.55f
            newPhase()
        }
        running = true
    }

    fun pause() { running = false }

    /** Advance the simulation by a slice of real time. */
    fun update(dtSeconds: Float) {
        if (finished) return
        /*
         * ONE TIME BASE.
         *
         * There were three. The clock and the phase logic run on MATCH MINUTES;
         * player movement and ball flight run on dtSeconds * speed; and every
         * presentation timer below -- sceneTime, stagedUntil, refTime, the
         * banner, the woodwork flash, the camera's danger easing, the replay --
         * ran on RAW dtSeconds, ignoring the speed control entirely.
         *
         * So 2x and 4x were not the same match played faster. The men moved
         * twice or four times as fast while the captions, the set-piece
         * arrangement and the camera held real time, and a set-piece delivery
         * booked in match minutes arrived four times sooner against a staging
         * hold that had not moved. Measured over 20 matches, a corner left the
         * flag 2.38 s after it was awarded at 1x, 1.19 s at 2x and 0.59 s at 4x,
         * against a fixed 9.6 s arrangement -- the choreography came apart at
         * exactly the speed most people watch at.
         *
         * Everything cosmetic now advances on the same scaled step as the
         * players do. At 1x this is arithmetically identical (speed == 1f), so
         * ResultFingerprint is unchanged; above 1x the whole picture speeds up
         * together, which is what the button claims to do.
         */
        val vis = dtSeconds * speed
        // nothing moves on the pitch while the goal is being shown again, but
        // the replay itself is advanced here so play always resumes on its own
        if (advanceReplay(vis)) return

        if (lineupTime > 0f) {
            lineupTime -= vis
            updateTargets()
            moveTowardTargets(vis * 2.0f)
            if (lineupTime <= 0f) {
                lineupTime = 0f
                scene = Scene.NONE
                resetShape(0); resetShape(1)
                start()
            }
            return
        }
        if (replayDelay > 0f) {
            replayDelay -= vis
            if (replayDelay <= 0f) {
                replayDelay = 0f
                replay = pendingReplay
                pendingReplay = null
                replayCursor = 0f
                replayIndex = 0
            }
        }
        val step = vis
        val minutes = step / SECONDS_PER_MINUTE
        clock += minutes

        val halfEnd = if (half == 1) 45.0 else 90.0
        // A referee does not blow while a shot is on its way to the net, and
        // neither does this. Ending the half with a pendingGoal outstanding put
        // the ball on the centre spot for the restart, and the goal was then
        // awarded the moment that placement arrived — on x=50, with the replay
        // showing a kick off. The half now waits the few tenths the ball needs.
        if (clock >= halfEnd + addedTime && pendingGoal == null) {
            if (half == 1) {
                half = 2; clock = 45.0; addedTime = 0.0; stoppage = 0.0; addedBase = 0.0
                running = false
                /*
                 * A goal on the stroke of half time leaves a restart booked
                 * that the second half must not inherit.
                 *
                 * pendingSide matters more than it looks. A goal parks it at
                 * `clock + 999` so that nothing resumes until the kick-off is
                 * staged, and every engine tick is gated on `pendingSide < 0`.
                 * Carried across the interval that becomes a match with no
                 * football in the second half at all: the flip is due at minute
                 * 1044 and the whistle never comes.
                 */
                kickOffSide = -1; kickOffPending = false
                pendingSide = -1
                resetShape(0); resetShape(1)
                placeBall(50f, 50f)
                phaseSeq = ArrayList()
                sayRaw(FeedLine.WHISTLE, "Half time: ${home.name} ${score[0]} - ${score[1]} ${away.name}.")
                banner = "HALF TIME"; bannerTime = 2.4f
                cue(Synth.Sfx.WHISTLE_LONG, 1f)
                cue(Synth.Sfx.APPLAUSE, 0.6f)
                crowdTarget = 0.35f
                return
            }
            endMatch()
            return
        }
        // the restart after a goal, once the celebration has had its time
        if (kickOffSide >= 0) {
            kickOffDue -= vis
            if (kickOffDue <= 0f && celebrationTime <= 0f && replay == null) {
                val s2 = kickOffSide; kickOffSide = -1
                stageKickOff(s2)
                // the pending flip now lands when the arrangement is over, so
                // the men are in their own half before the ball is rolled
                pendingSide = s2
                pendingAt = clock + KICKOFF_SECONDS / SECONDS_PER_MINUTE
                kickOffPending = true
            }
        }

        updateCrowd(step)
        /*
         * ADDED TIME KEEPS BEING ADDED.
         *
         * This was computed ONCE, at 44.5 or 89.5 minutes, from the stoppage
         * accrued up to that instant. Every set piece taken during added time
         * then added to `stoppage` and was never given back, so the longer a
         * set piece holds the ball the more playing time the match quietly
         * loses. It cost 0.11 goals a game once the restarts were held long
         * enough to be seen -- 9,120 matches, 2.52 to 2.41, which is 4.6
         * standard errors and put the engine outside its own target band.
         *
         * The base is rolled once, as before, and the stoppage is added on
         * continuously, which is what a fourth official actually does.
         */
        if (half == 1 && clock > 44.5 && addedBase == 0.0) addedBase = 0.5 + rng.f() * 2.5
        if (half == 2 && clock > 89.5 && addedBase == 0.0) addedBase = 1.0 + rng.f() * 4.0
        if (addedBase > 0.0) addedTime = addedBase + stoppage

        // fatigue
        for (p in players) {
            if (!p.onPitch) continue
            val drain = minutes * (0.28 + (100 - p.ref.att[Att.STA]) * 0.0035) *
                    (if (p.ref.hasTrait(Traits.ENGINE)) 0.75 else 1.0)
            p.fitness = max(15.0, p.fitness - drain)
            p.effective = p.ref.effective(p.pos) * (0.75 + 0.25 * p.fitness / 100.0)
            p.minutes += minutes
        }

        if (rng.chance(minutes * 0.0022)) {
            val candidates = players.filter { it.onPitch && !it.injured }
            if (candidates.isNotEmpty()) injure(rng.pick(candidates))
        }

        // Nothing restarts while a shot is on its way in, including a delayed
        // change of possession that was booked before the shot was struck.
        if (pendingSide >= 0 && clock >= pendingAt && pendingGoal == null) {
            val s = pendingSide; pendingSide = -1
            // A kick-off is not a contested restart: the side that conceded
            // takes it. Everywhere else the natural side is only a lean.
            possessionSide = if (kickOffPending) s else nextSide(s)
            kickOffPending = false
            if (ENGINE_V3) v3Resume() else if (ENGINE_V2) v2Resume() else newPhase()
        }

        // the set piece has been on screen long enough; now it is struck
        pendingShot?.let { ps ->
            if (clock >= pendingShotAt && pendingGoal == null) {
                pendingShot = null
                val taker = players.firstOrNull { it.key == ps.takerKey && it.onPitch }
                if (taker != null) attemptShot(ps.att, taker, ps.quality, ps.kind)
                else flip(ps.att)
            }
        }

        // A shot that is going in has to be allowed to arrive. The engine used
        // to carry straight on, start the next phase and send the ball off to a
        // team mate while it was still travelling, so it never reached the net
        // and the replay ended short of the goal. Only the phase logic pauses:
        // the ball flight below still runs, or nothing would ever arrive.
        val holdForGoal = pendingGoal != null && ball.t < 1f

        if (ENGINE_V3) {
            if (!holdForGoal && pendingSide < 0 && pendingShot == null) v3Tick(step, minutes)
        } else if (ENGINE_V2) {
            // Continuous play replaces phase construction entirely. pendingShot
            // and pendingSide are still honoured because the set-piece
            // machinery above books through them.
            if (!holdForGoal && pendingSide < 0 && pendingShot == null) v2Tick(step, minutes)
        } else {

        if (!holdForGoal && phaseSeq.isEmpty() && pendingSide < 0 && pendingShot == null) newPhase()

        if (!holdForGoal && phaseSeq.isNotEmpty()) {
            phaseTimer += minutes
            val stepDuration = phaseDuration / max(1, phaseSeq.size)
            val wantStep = (phaseTimer / stepDuration).toInt()
            var guard = 0
            // pendingGoal has to be re-tested HERE, not just at the top of the
            // tick. stepPhase() ends a move by calling resolvePhase() itself,
            // so a whole phase — shot included — can resolve inside this loop,
            // and resolvePhase() can then run a second time below. That is how
            // goals were being awarded in midfield: the first shot set
            // pendingGoal with the ball in flight, the second shot resolved in
            // the SAME tick, missed, and staged a goal kick; the stale
            // pendingGoal was then satisfied the moment the goal kick arrived,
            // so the goal was given with the ball on x=92 or x=8 and the replay
            // showed a goal kick. holdForGoal above is computed once and goes
            // stale the instant the first shot goes in.
            /*
             * NOBODY PLAYS A PASS THE BALL HAS NOT ARRIVED FOR.
             *
             * The move advanced on a clock: stepDuration is phaseDuration split
             * evenly between the passes, and the ball's flight time comes from
             * how far it has to travel. Those are unrelated numbers, so the next
             * pass was routinely struck while the previous one was still in the
             * air — and moveBallTo resets the flight from wherever the ball had
             * got to, in a completely new direction.
             *
             * That is the whole of "the ball flies on the pitch, it changes path
             * suddenly". BallPath over 20 matches: 73% of flights contained a
             * turn sharper than 15 degrees in a single frame, the ball reversed
             * through more than 120 degrees 40 times a match, and 98% of those
             * kinks were the ball being struck again mid-flight at a mean speed
             * of 34 m/s.
             *
             * The ball's own state now gates the move. The clock still decides
             * WHEN a move wants to advance; the ball decides whether it may.
             */
            while (phaseSeq.isNotEmpty() && phaseStep < wantStep && phaseStep < phaseSeq.size &&
                pendingGoal == null && (!WAIT_FOR_BALL || ball.t >= 1f) && guard++ < 12) {
                stepPhase()
            }
            if (pendingGoal == null && phaseSeq.isNotEmpty() &&
                phaseTimer >= phaseDuration && phaseStep >= phaseSeq.size - 1 &&
                (!WAIT_FOR_BALL || ball.t >= 1f)) {
                resolvePhase()
            }
        }
        }

        ambientTimer += minutes
        if (ambientTimer > 7 + rng.f() * 8) { ambientTimer = 0.0; say(L_AMBIENT, "", "") }

        aiSubstitutions(minutes)
        aiManagerThink(minutes)

        // ball flight
        val prevX = ball.x
        val prevY = ball.y
        if (ENGINE_V3) {
            // Physics.stepBall in v3Move owns the ball. Nothing here.
        } else if (PHYS_BALL && ball.phys && ball.t < 1f) {
            /*
             * ENGINE V4, IDEA 5: the ball is integrated, not interpolated.
             *
             * Everything above and below still reads `t < 1` as "in flight", so
             * t is driven from the ball's own state rather than from a clock:
             * it reaches 1 when the ball comes to rest, leaves the field, or is
             * claimed. That is what lets the interception, the boundary, the
             * claim and the goal-waiting code carry on unchanged underneath a
             * ball that is no longer walking a parameter from 0 to 1.
             *
             * driftX and driftY are kept in step because a dozen readers -- the
             * chaser's lead, the loose-ball speed test, the renderer's spin --
             * were all written against them and they mean the same thing: the
             * displacement of one reference frame.
             */
            val moving = Physics.stepBall(ball, vis)
            ball.driftX = ball.vx / 36f
            ball.driftY = ball.vy / 36f
            ball.height = max(0f, ball.height)
            // how much of the flight is done, for anything that reads t as a
            // fraction rather than as a flag
            val gone = hypot((ball.x - ball.fromX).toDouble(), (ball.y - ball.fromY).toDouble()).toFloat()
            val total = max(0.5f, hypot((ball.rest[0] - ball.fromX).toDouble(),
                (ball.rest[1] - ball.fromY).toDouble()).toFloat())
            ball.t = (gone / total).coerceIn(0f, 0.999f)
            if (!moving) { ball.t = 1f; ball.phys = false }
            if (ball.x < -3f || ball.x > 103f || ball.y < -3f || ball.y > 103f) {
                ball.t = 1f; ball.phys = false
            }
            ball.spin += hypot((ball.vx * vis).toDouble(), (ball.vy * vis).toDouble()).toFloat() * 0.55f
        } else if (ball.t < 1f) {
            val prevT = ball.t
            ball.t = min(1f, ball.t + vis / ball.duration)
            // A struck ball leaves quickly and slows as friction takes hold.
            // With e = 1 - (1-t)^k the launch speed is exactly k times the
            // average, so the exponent is the one number that matters: the old
            // curve worked out at 2.35x and put shots past 100 m/s.
            val e = 1f - Math.pow((1f - ball.t).toDouble(), LAUNCH_RATIO.toDouble()).toFloat()
            val ePrev = 1f - Math.pow((1f - prevT).toDouble(), LAUNCH_RATIO.toDouble()).toFloat()

            /*
             * THE BALL MOVES ITSELF. NOTHING PUTS IT ANYWHERE.
             *
             * This used to read
             *
             *     ball.x = ball.fromX + (ball.toX - ball.fromX) * e
             *
             * so the ball's position was a FUNCTION of its aim point — and the
             * aim point is mutated while the ball is in the air, by the receiver
             * lead below and by SPATIAL_V2 choosing a different receiver. Move
             * the target and the ball is instantly somewhere else.
             *
             * BallSpike over 20 matches: 736 frames exceeded the 40.3 m/s
             * ceiling, and 48% of them were "in flight, aim point moved". The
             * worst was 2,103 m/s off a 16.7 m target shift. That is the ball
             * jumping, and it is what makes the movement look like nothing on a
             * football pitch.
             *
             * So the ball advances by a STEP along whatever remains of its
             * journey. When the aim point holds still this is exactly the old
             * curve — the fraction of the remaining distance covered in a tick
             * is (e - ePrev) / (1 - ePrev), which telescopes back to the same
             * positions. When the aim point moves, the ball bends toward the
             * new one at its current speed instead of teleporting to it.
             * Continuity stops being something to tune and becomes something
             * the arithmetic cannot violate.
             */
            if (BALL_AGENT) {
                val remain = 1f - ePrev
                val stepFrac = if (remain < 1e-4f) 1f else ((e - ePrev) / remain).coerceIn(0f, 1f)
                ball.x += (ball.toX - ball.x) * stepFrac
                ball.y += (ball.toY - ball.y) * stepFrac
            } else {
                ball.x = ball.fromX + (ball.toX - ball.fromX) * e
                ball.y = ball.fromY + (ball.toY - ball.fromY) * e
            }
            // The bend is a sideways push, greatest in mid-flight. It is applied
            // as the CHANGE in the bend since last tick, for the same reason:
            // added whole every frame on top of an assigned position it was
            // free to jump whenever the flight direction was recomputed.
            if (ball.curve != 0f) {
                val dx = ball.toX - ball.fromX
                val dy = ball.toY - ball.fromY
                val len = max(0.001f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
                val bend = if (BALL_AGENT)
                    (kotlin.math.sin(ball.t * Math.PI) -
                     kotlin.math.sin(prevT * Math.PI)).toFloat() * ball.curve
                else kotlin.math.sin(ball.t * Math.PI).toFloat() * ball.curve
                ball.x += (-dy / len) * bend
                ball.y += (dx / len) * bend
            }
            // height is a parabola under gravity, and it is zero on the floor
            ball.height = if (ball.loft <= 0.01f) 0f
            else ball.loft * 4f * ball.t * (1f - ball.t)
            // A pass is played to where the receiver is going, not where he
            // was when it left the boot. Without this the ball landed behind
            // him and then had to chase him across the grass, which is what
            // made it look like it was flying around on its own.
            //
            // Only a pass, though. A shot has no receiver, and when this was
            // allowed to run on shots it dragged the target back toward the man
            // who had struck it: the ball arrived seven units short of the goal
            // line and the goal was given there.
            val recv = if (ball.struck) null
            else ball.holder?.let { k -> players.firstOrNull { it.key == k } }
            if (recv != null && recv.onPitch) {
                val lead = min(1f, vis * 2.6f)
                ball.toX += (recv.x - ball.toX) * lead
                ball.toY += (recv.y - ball.toY) * lead
            }
            // remember how fast it was going, so it can run on
            ball.driftX = (ball.x - prevX)
            ball.driftY = (ball.y - prevY)
            // arriving from a loft, it lands with real downward speed and will
            // bounce rather than stick to the turf the instant it gets there
            if (ball.t >= 1f && ball.loft > 0.01f) {
                ball.vz = -ball.loft * 1.9f
                /*
                 * A ball dropping out of the sky is HEADED. The engine has
                 * always known which passes were lofted — anything over about
                 * forty units, and a side told to go direct — and the man it
                 * arrived at controlled it with his feet like any other pass,
                 * so the game showed 5.3 headers a match against a real forty.
                 *
                 * This costs nothing and can move nothing: act() draws no
                 * random numbers, and HEADER is not one of the three actions
                 * (TACKLE, DOWN, DIVE) that stop a man moving. That matters
                 * more than it sounds, because nextMan picks the next man in a
                 * move by who is standing nearby, so anything that freezes a
                 * player leaks into the result. ResultFingerprint is the check.
                 *
                 * The threshold is the genuinely aerial ball. A pass clipped
                 * over a defender at 3.6 comes down at shin height and is
                 * controlled, not headed.
                 */
                // 3.6 is a ball clipped over a defender, which still arrives
                // above waist height and gets headed; 4.0 excluded exactly
                // those and left headers at 5.4 a match.
                if (ball.loft >= 3.0f) {
                    ball.holder?.let { k ->
                        players.firstOrNull { it.key == k && it.onPitch }?.let { rec ->
                            act(rec, Act.HEADER, HEADER_POSE, cosmetic = true)
                        }
                    }
                }
            }
        } else if (!ENGINE_V3) {
            val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k } }
            if (carrier != null && carrier.pos == Pos.GK) {
                // in his hands
                ball.height += (0.62f - ball.height) * min(1f, vis * 6f)
            } else if (carrier != null) {
                ball.height += (0f - ball.height) * min(1f, vis * 8f)
            }
            // a loose ball bounces down under gravity, losing height each time
            if (ball.holder == null && (ball.height > 0.001f || ball.vz < -0.001f)) {
                ball.vz -= 9.0f * vis
                ball.height = max(0f, ball.height + ball.vz * vis)
                if (ball.height <= 0f) {
                    if (ball.vz < -0.55f) {
                        ball.vz = -ball.vz * 0.46f
                        cue(Synth.Sfx.KICK, 0.22f, ball.x)
                        // it skids on a little as it comes off the turf
                        ball.driftX *= 1.06f
                        ball.driftY *= 1.06f
                    } else ball.vz = 0f
                }
            } else if (carrier == null) ball.height = 0f
            val h = carrier
            if (h != null) {
                // He does not catch it dead. The ball keeps running and he
                // gathers it over the next stride, which is what makes the
                // control look like control rather than a magnet.
                // A keeper holds it at his hands; everyone else has it at their
                // feet. The old offset put the ball 1.26 m in front of the man,
                // further than his own body is wide, so it never looked like his.
                val reach = if (h.pos == Pos.GK) 0.30f else 0.48f
                val footX = h.x + kotlin.math.cos(h.facing.toDouble()).toFloat() * reach
                val footY = h.y + kotlin.math.sin(h.facing.toDouble()).toFloat() * reach + 0.18f
                /*
                 * PER SECOND, NOT PER FRAME.
                 *
                 * These three were bare per-frame constants -- 0.80, 0.38, 0.94
                 * applied once a tick regardless of how long the tick was. The
                 * harness runs at a fixed 36 Hz so nothing here ever showed up
                 * in a measurement, but the phone does not: the loop posts every
                 * 28 ms and dt comes from the wall clock, capped at 50 ms. A
                 * device holding 60 fps settled the ball at a man's feet nearly
                 * twice as fast as one dropping to 30, and a frame that arrived
                 * late moved it further than a frame that arrived early. That is
                 * exactly the ball movement that reads as wrong without any one
                 * frame looking wrong.
                 *
                 * TRIED AND REVERTED, AND THE FINDING IS WORTH KEEPING.
                 *
                 * These are bare per-frame constants: 0.80, 0.38 and 0.94
                 * applied once a tick whatever the tick is worth. So how far a
                 * ball runs on after it arrives, and how quickly a man settles
                 * it, depend on the frame rate the phone manages AND on the
                 * speed button -- at 4x the run-on is a quarter of what it
                 * should be relative to the match. That is a real defect and it
                 * is the kind that reads as wrong movement without any single
                 * frame looking wrong.
                 *
                 * Expressing them per second, with rates that are the identity
                 * at 36 Hz, was written and measured: BalanceBig went from 2.56
                 * to 2.82 goals over 9,120 matches, outside the 2.5-2.7 band.
                 * It is not a small effect and it is not noise -- BalanceBig
                 * runs at `speed = 6` and dt = 1/30, so a tick there is worth
                 * seven reference frames, and the run-on it has always measured
                 * is not the run-on the phone has ever produced.
                 *
                 * So the harness and the game have disagreed about the ball
                 * since v2 was tuned, and correcting it means earning balance a
                 * fourth time with a full CHANCE_QUALITY sweep. That is a job
                 * of its own, not a rider on a presentation pass, and shipping
                 * it half-done would put the game outside the band it took
                 * three tunings to reach.
                 */
                ball.x += ball.driftX
                ball.y += ball.driftY
                ball.driftX *= 0.80f
                ball.driftY *= 0.80f
                // firmer, so it is under control within a stride rather than
                // trailing him for half a second
                val pull = 0.38f
                ball.x += (footX - ball.x) * pull
                ball.y += (footY - ball.y) * pull
            } else {
                // nobody on it: it rolls to a stop
                ball.x += ball.driftX
                ball.y += ball.driftY
                ball.driftX *= 0.94f
                ball.driftY *= 0.94f
            }
        }
        // spin follows how far it actually moved this frame
        val moved = hypot((ball.x - prevX).toDouble(), (ball.y - prevY).toDouble()).toFloat()
        ball.spin += moved * 0.55f

        if (ENGINE_V3) {
            // v3 moves the men and the ball itself, under momentum and turn
            // limits, so the v1 target-chasing and the interpolated flight
            // above are both bypassed entirely.
            v3Move(vis)
        } else {
            updateTargets()
            moveTowardTargets(vis)
        }
        separate()
        captureFrame()

        // the ball has arrived: now it is a goal
        pendingGoal?.let { pg ->
            if (ball.t >= 1f) {
                val shooter = players.firstOrNull { it.key == pg.shooterKey }
                pendingGoal = null
                if (shooter != null) scoreGoal(pg.att, shooter, pg.penalty)
            }
        }

        updateDanger(vis)
        woodwork = max(0f, woodwork - vis)
        skill = max(0f, skill - vis)
        if (skill <= 0f) skillKey = null
        flash = max(0f, flash - vis * 2.2f)
        shake = max(0f, shake - vis * 2.6f)
        bannerTime = max(0f, bannerTime - vis)
        if (bannerTime <= 0f) banner = null
        sceneTime = max(0f, sceneTime - vis)
        stagedUntil = max(0f, stagedUntil - vis)
        if (sceneTime <= 0f) {
            if (queuedScene != Scene.NONE) {
                scene = queuedScene; sceneTime = queuedTime
                queuedScene = Scene.NONE; queuedTime = 0f
            } else scene = Scene.NONE
        }
        refTime = max(0f, refTime - vis)
        if (refTime <= 0f) refCard = 0
        if (celebrateKey != null) {
            celebrateTime += vis
            if (celebrateTime > 2.4f) celebrateKey = null
        }
        if (celebrationTime > 0f) {
            celebrationTime = max(0f, celebrationTime - vis)
            if (celebrationTime <= 0f) { celebrateSide = -1; celebrateScorer = null }
        }
        momentum *= (1 - vis * 0.08)
    }

    /**
     * The goal celebration. The scorer runs off toward the corner flag, his
     * team-mates converge on wherever he has got to, and the side that conceded
     * trudges back to its own half. It replaces the normal shape entirely for a
     * few seconds, which is why it sits ahead of the tactical targets.
     */
    /**
     * The teams out on the pitch before a ball is kicked: two lines either side
     * of halfway, everyone square to the camera. It costs four seconds and it is
     * the first thing that tells you a match is about to start.
     */
    private fun lineupTargets(): Boolean {
        if (lineupTime <= 0f) return false
        for (side in 0..1) {
            val men = onPitch(side)
            val rowY = if (side == 0) 44f else 56.5f
            for (i in men.indices) {
                val p = men[i]
                p.targetX = 27f + i * (46f / max(1, men.size - 1))
                p.targetY = rowY
                // square to the camera, arms by the sides
                p.facing = (Math.PI / 2).toFloat()
                p.action = Act.RUN
            }
        }
        return true
    }

    private fun celebrationTargets(): Boolean {
        if (celebrationTime <= 0f || celebrateSide < 0) return false
        val scorer = players.firstOrNull { it.key == celebrateScorer && it.onPitch }
        for (p in players) {
            if (!p.onPitch) continue
            if (p.side == celebrateSide) {
                if (p.pos == Pos.GK) {
                    // the keeper stays home and settles for punching the air
                    p.targetX = if (p.side == 0) 6f else 94f
                    p.targetY = 50f
                } else if (scorer != null && p.key == scorer.key) {
                    p.targetX = celebrateRunX
                    p.targetY = celebrateRunY
                } else if (scorer != null) {
                    /*
                     * Everyone used to be sent to a ring 4.5 units across around
                     * the scorer. Two things were wrong with that. A pitch unit
                     * is 1.05 m along the pitch but only 0.68 m across it, so a
                     * ring that is round in units is a flat ellipse on the
                     * grass, barely three metres deep — and ten men converging
                     * on a three metre ellipse is the reported "they united in
                     * one place on the pitch". And a whole team sprinting to
                     * one spot is not what happens: two or three reach the
                     * scorer, the rest arrive spread out behind them.
                     *
                     * Ring radii are metres here, converted to units on use.
                     */
                    val mates = onPitch(celebrateSide)
                        .filter { it.pos != Pos.GK && it.key != scorer.key }
                        .sortedBy {
                            val dx = (it.x - scorer.x) * 1.05
                            val dy = (it.y - scorer.y) * 0.68
                            dx * dx + dy * dy
                        }
                    val rank = mates.indexOfFirst { it.key == p.key }
                    // the nearest three mob him; the rest come from deeper
                    val radiusM = if (rank in 0..2) 3.0f + rank * 0.9f else 9.0f + rank * 1.6f
                    val a = p.slot * 2.39996f          // golden angle, so nobody shares a spot
                    p.targetX = (scorer.x + kotlin.math.cos(a.toDouble()).toFloat() * radiusM / 1.05f)
                        .coerceIn(3f, 97f)
                    p.targetY = (scorer.y + kotlin.math.sin(a.toDouble()).toFloat() * radiusM / 0.68f)
                        .coerceIn(5f, 95f)
                }
            } else {
                // heads down, back to the halfway line for the restart
                p.targetX = if (p.side == 0) p.baseX * 0.75f + 12f else p.baseX * 0.75f + 13f
                p.targetY = p.baseY
            }
        }
        return true
    }

    /**
     * The two men, one a side, who are going for a loose ball.
     *
     * Nobody used to chase it. Everyone held their station and let the ball run,
     * so for about a ninth of the match it was rolling around with not a soul
     * within six metres of it, which is what made it look as though it were
     * moving by itself. Recomputed only while the ball is free.
     */
    private var chaserHome: String? = null
    private var chaserAway: String? = null

    private fun pickChasers() {
        /*
         * SOMEBODY GOES AND CLOSES HIM DOWN.
         *
         * This used to read, in full: if anybody has the ball, there is no
         * chaser. Chasers existed only for a LOOSE ball -- so for the 91% of
         * open play where a man is carrying it, not one opponent was assigned
         * to him and the whole defending side just held its shape.
         *
         * Measured by ContestCheck over 15 matches, open play only:
         *
         *   nearest opponent to the ball          8.64 m
         *   an opponent within 2 m of the CARRIER  8.5% of carry time
         *   interceptions, blocks, deflections     none, ever
         *
         * Twenty two men on the pitch and eleven of them could never touch the
         * ball. That is what "the match lacks something" is: not the physics
         * and not the scenes, but that nobody is playing against you. A man
         * walks into the penalty area with the ball and the nearest defender is
         * ten metres away watching.
         *
         * The nearest defender now goes to the man on the ball. This does NOT
         * touch the phase outcome, which is still rolled up front from the
         * ratings -- it changes what the pressure looks like, not who ends up
         * with it, exactly as the pressure layer already does.
         */
        val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        if (carrier != null) {
            chaserHome = null; chaserAway = null
            if (PRESS_CARRIER && carrier.pos != Pos.GK) {
                val d = 1 - carrier.side
                val nearest = onPitch(d).filter { it.pos != Pos.GK }
                    .minByOrNull {
                        hypot(((it.x - carrier.x) * 1.05).toDouble(),
                              ((it.y - carrier.y) * 0.68).toDouble())
                    }
                if (d == 0) chaserHome = nearest?.key else chaserAway = nearest?.key
            }
            return
        }
        if (ball.holder != null) { chaserHome = null; chaserAway = null; return }
        for (side in 0..1) {
            val nearest = onPitch(side)
                .filter { it.pos != Pos.GK }
                .minByOrNull {
                    hypot(((it.x - ball.x) * 1.05).toDouble(), ((it.y - ball.y) * 0.68).toDouble())
                }
            if (side == 0) chaserHome = nearest?.key else chaserAway = nearest?.key
        }
    }

    /**
     * PRESSURE: how hurried is this man, from 0 (alone in acres) to 1 (swarmed)?
     *
     * The four things that make a player feel pressed, per the V3 design: how
     * close the nearest defender is, how fast he is closing, whether he is in
     * front or behind, and how many others are around. They are combined rather
     * than added so no single term can saturate it.
     *
     * Nothing here decides an outcome. Phase outcomes are rolled up front from
     * the ratings and this must not touch them — pressure changes WHERE the
     * ball goes, not who ends up with it, which is the same discipline the
     * cosmetic RNG stream follows.
     */
    private fun pressureOn(p: LivePlayer): Float {
        val opp = onPitch(1 - p.side).filter { it.pos != Pos.GK }
        if (opp.isEmpty()) return 0f
        var worst = 0f
        var crowd = 0
        for (d in opp) {
            val dxm = (d.x - p.x) * 1.05f
            val dym = (d.y - p.y) * 0.68f
            val dist = hypot(dxm.toDouble(), dym.toDouble()).toFloat()
            if (dist > 14f) continue
            crowd++
            // near is pressing, far is not: 1 at his shoulder, 0 at 14 m
            val near = (1f - dist / 14f).coerceIn(0f, 1f)
            // is he coming, or standing off? speedNow toward the man counts.
            val closing = if (dist < 0.01f) 1f else {
                val ux = -dxm / dist; val uy = -dym / dist
                // the defender's own heading, as a unit vector
                val hx = Math.cos(d.heading.toDouble()).toFloat()
                val hy = Math.sin(d.heading.toDouble()).toFloat()
                ((hx * ux + hy * uy) * (d.speedNow / 7f)).coerceIn(0f, 1f)
            }
            // a man in front of you is worse than one at your back
            val goalX = if (p.side == 0) 100f else 0f
            val ahead = if ((goalX - p.x) * (d.x - p.x) > 0f) 1f else 0.55f
            val v = near * (0.62f + 0.38f * closing) * ahead
            if (v > worst) worst = v
        }
        // being outnumbered adds to it without ever dominating it
        val many = ((crowd - 1).coerceAtLeast(0) * 0.10f).coerceAtMost(0.30f)
        return (worst + (1f - worst) * many).coerceIn(0f, 1f)
    }

    private fun updatePressure() {
        // Always computed, even with the layer off, so a harness can report what
        // the ball WOULD have been walking into. Gating the computation made the
        // control row of PressureCheck read 0.000 everywhere and compare nothing.
        for (p in players) {
            if (!p.onPitch) { p.pressure = 0f; continue }
            p.pressure = pressureOn(p)
        }
    }

    /**
     * DEFENDER JOBS: zones in front of your own goal, not men to chase.
     *
     * The attacking half of the job system sends men to the near post and the
     * penalty spot. Without the other half there was nobody there to meet them:
     * DefendCheck measured 0.50 of ten defenders goal-side of a ball inside
     * their own penalty area, against a real eight or nine, with their deepest
     * outfielder standing 19 m off his own line and nobody in the area at all
     * half the time.
     *
     * The cause is that the defensive shape is one rigid block translated toward
     * the ball. It is 46 m long, so with the ball on the goal line its centre
     * sits 24 m out and most of the side is nowhere. Zones break the block: the
     * men nearest their own goal are given places to protect and go there, while
     * the rest of the shape does what it did.
     *
     * Assigned every tick and expiring quickly, so the moment the ball is
     * cleared the zones lapse and the side steps back out on its own.
     */
    private fun assignDefensiveJobs() {
        if (!DEF_JOBS) return
        val def = 1 - possessionSide
        val goalX = if (def == 0) 0f else 100f
        if (abs(ball.x - goalX) > DEF_JOB_RANGE) return
        val sign = if (def == 0) 1f else -1f
        val out = { d: Float -> goalX + sign * d }
        val zones = listOf(
            out(5f) to 43f,      // near post
            out(5f) to 57f,      // back post
            out(9f) to 50f,      // in front of the goalkeeper
            out(13f) to 40f,
            out(13f) to 60f,
            out(18f) to 50f      // the edge of the area, for the cut-back
        )
        val men = onPitch(def).filter { it.pos != Pos.GK }
            .sortedBy { hypot(((goalX - it.x) * 1.05).toDouble(), ((50f - it.y) * 0.68).toDouble()) }
        for (i in zones.indices) {
            val p = men.getOrNull(i) ?: break
            p.jobX = zones[i].first
            p.jobY = zones[i].second
            p.jobDefensive = true
            // refreshed for as long as the danger lasts, rather than set once
            p.jobTime = max(p.jobTime, 1.2f)
        }
    }

    /**
     * WHAT PLAYERS DO WHEN THE BALL IS DEAD.
     *
     * A scene used to be a caption and nothing else. Corners and penalties froze
     * the shape, and for every other stoppage -- a throw-in, a goal kick, a
     * booking -- twenty-two men carried on pressing and sprinting around a ball
     * nobody was allowed to play. That is a large part of why the match reads as
     * not having scenes in it: the events happen and the pitch does not react.
     *
     * A booking is the one worth staging properly. Play is dead, so everybody
     * stops where they are; the referee has walked to the offender, so the
     * offender stands and takes it, and the nearest few drift in to complain.
     * Returns true when it has taken over the pitch.
     */
    private fun sceneTargets(): Boolean {
        if (!SCENE_AI || sceneTime <= 0f || scene != Scene.CARD) return false
        val man = cardedKey?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        // everyone holds station: the ball is not in play
        for (p in players) {
            if (!p.onPitch) continue
            p.targetX = p.x
            p.targetY = p.y
        }
        if (man != null) {
            // the three nearest close in on the referee, the way they do
            val near = onPitch(man.side).filter { it.key != man.key && it.pos != Pos.GK }
                .sortedBy { hypot(((it.x - man.x) * 1.05).toDouble(), ((it.y - man.y) * 0.68).toDouble()) }
                .take(3)
            for ((i, p) in near.withIndex()) {
                val a = (i - 1) * 0.9f
                p.targetX = (man.x + kotlin.math.cos(a.toDouble()).toFloat() * 3.4f).coerceIn(3f, 97f)
                p.targetY = (man.y + kotlin.math.sin(a.toDouble()).toFloat() * 3.4f).coerceIn(5f, 95f)
            }
        }
        return true
    }

    /**
     * The two or three nearest defenders, who converge on the ball in v2.
     *
     * One presser is not a defence. With only the single chaser assigned, the
     * nearest opponent to the ball measured 10.2 m all match -- the man on the
     * ball was closed down by exactly one player while the other nine held
     * their formation slots, so there was never a second man to play around.
     * Real pressing is a unit arriving together.
     */
    private val v2Support = HashSet<String>(4)

    private fun v2PickSupport() {
        v2Support.clear()
        if (!ENGINE_V2) return
        val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        val side = if (carrier != null) 1 - carrier.side else -1
        if (side < 0) return
        /*
         * ENGINE V4, IDEA 6: THE PRESSING INSTRUCTION REACHES THE PRESS.
         *
         * `ShoutCheck` measured "Press them" making the press WORSE: the man on
         * the ball had 5.7 m of space when nothing was said and 6.5 m after the
         * shout. The instruction existed, the toast appeared, and the football
         * went the wrong way.
         *
         * The reason is that `tactics.press` reached exactly one place --
         * `updateTargets`, so it never reached the code that actually presses.
         *
         * TRIED AND REVERTED, and BOTH halves of it are worth recording.
         *
         * The change: press size 2/3/4 men by setting, tackle reach x0.82/1.30,
         * challenge rate x0.80/1.35. It made the press WORSE -- the carrier's
         * nearest opponent went from 6.4 m to 7.2 m against a control of 6.5 --
         * and it dropped the line from +6.4 to +3.4. Four men chasing one is
         * four men out of shape, and the fourth arrives late enough to be
         * running past the ball rather than at it.
         *
         * And the measurement that motivated it was wrong. The original
         * ShoutCheck averaged the carrier's space over BOTH sides, which is a
         * confound: a side that presses well wins the ball higher and then HAS
         * it more, in the opposition half, where its own man has more room. On
         * the corrected metric -- what this side does to the OTHER side's
         * carrier -- "Press them" reads 6.4 m against 6.5 m for saying nothing.
         * Roughly neutral, not backwards as first reported.
         *
         * So the shout is not broken in the way it looked. It is weak, and
         * making it stronger by these three levers makes it worse, which points
         * at the same place as everything else in v4: pressing needs a model of
         * the space being cut off, not more men run at the ball.
         */
        onPitch(side).filter { it.pos != Pos.GK }
            .sortedBy { v2m(it.x, it.y, ball.x, ball.y) }
            .take(3)
            .forEach { v2Support.add(it.key) }
    }

    private fun updateTargets() {
        pickChasers()
        v2PickSupport()
        updatePressure()
        assignDefensiveJobs()
        if (lineupTargets()) return
        if (celebrationTargets()) return
        if (sceneTargets()) return
        if (stagedUntil > 0f || scene == Scene.PENALTY) return
        for (side in 0..1) {
            val club = if (side == 0) home else away
            val t = club.tactics
            val attacking = possessionSide == side
            val dir = if (side == 0) 1f else -1f
            // These are deliberately strong: you should be able to SEE a change
            // of instruction in where the players stand.
            val lineShift = (t.line - 1) * 13f
            val mentShift = (t.mentality - 2) * 7f
            /*
             * WIDTH, REMAPPED SO THAT "WIDE" HAS SOMEWHERE TO GO.
             *
             * These were 0.58 / 1.00 / 1.38 applied to each man's offset from
             * the centre line — and targets are then clamped with
             * ty.coerceIn(5f, 95f), while the drawn formations already stand
             * their widest men within a few units of the touchline. So wide
             * pushed the target off the pitch, the clamp ate the whole change,
             * and "Get it wide" measured +0.55 m against a do-nothing control
             * while "Through the middle" narrowed by 17 m. Narrowing worked
             * because it moves INWARD, away from the clamp; widening had
             * nowhere left.
             *
             * Normal now sits inside the band with room above it, so wide can
             * reach the touchline without being truncated:
             *   narrow  about 32-68% of the width
             *   normal  about 22-78%, which measures 49 m — inside the real
             *           45-55 m band — with headroom left above it
             *   wide    about 8-92%, which is as wide as a side can be without
             *           the touchline clamp truncating the change again
             */
            val widthMul = when (t.width) { 0 -> 0.58f; 2 -> 1.10f; else -> 0.86f }
            val pressPull = when (t.press) { 0 -> -0.10f; 2 -> 0.22f; else -> 0f }
            // Focus of play slides the whole shape toward a flank or the middle.
            val focusShift = when (t.focus) { 0 -> -11f; 2 -> 11f; else -> 0f }
            val focusSpread = if (t.focus == 3) 1.18f else 1f
            // whoever is nearest the man we are marking takes the job
            val markerSlot = if (t.oppTargetId >= 0 && t.oppMode == 1)
                onPitch(side).filter { Pos.group(it.pos) == 1 }.minByOrNull { it.baseY }?.slot ?: -1 else -1

            for (p in onPitch(side)) {
                val fx = RoleFx.of(t.roleName(p.slot))
                val pi = t.slotInstructions.getOrElse(p.slot) { 0 }

                var roleX = fx.xShift
                var roleSpread = fx.ySpread
                if (pi and PI.GET_FORWARD != 0) roleX += 7f
                if (pi and PI.STAY_BACK != 0) roleX -= 9f
                if (pi and PI.HOLD_POSITION != 0) roleX -= 2f
                if (pi and PI.STAY_WIDER != 0) roleSpread *= 1.22f
                if (pi and PI.CUT_INSIDE != 0) roleSpread *= 0.66f

                // The formations are drawn with the back line at x=20 and the
                // strikers at x=76, which is nearly sixty metres from one line
                // to the other. A real side keeps thirty to forty and slides
                // that block up and down the pitch instead of stretching it.
                // Compressing around the shape's own centre is what finally
                // makes a short pass possible: before this the nearest man
                // ahead was structurally a long ball away.
                val compactBase =
                    if (p.pos == Pos.GK) p.baseX
                    else SHAPE_MID + (p.baseX - SHAPE_MID) * SHAPE_COMPACT
                val bx0 = ownX(side, compactBase) + dir * roleX
                var by0 = ownY(side, p.baseY)
                by0 = 50f + (by0 - 50f) * widthMul * focusSpread * roleSpread + focusShift

                /*
                 * Shaping the defending side to where the ball is GOING rather
                 * than where it is was tried here and measured nothing: 0.50 of
                 * ten men goal-side either way, and 0.49 when combined with
                 * getting back, against 0.54 for getting back on its own. The
                 * lag is not the defenders being surprised by the pass, it is
                 * that they are twenty five units away and jogging.
                 */
                val pull = (ball.x - 50f) * ((if (attacking) 0.42f else 0.55f) + pressPull)
                var tx = bx0 + pull + dir * (lineShift + mentShift) * (if (attacking) 0.6f else 1f)
                if (attacking && (p.pos == Pos.ST || p.pos == Pos.AM)) tx += dir * 7f
                if (t.counter && !attacking && Pos.group(p.pos) == 3) tx -= dir * 5f
                if (pi and PI.HOLD_POSITION != 0) tx = bx0 + pull * 0.35f + dir * mentShift * 0.3f
                if (p.pos == Pos.GK) tx = ownX(side, if (attacking) 10f else 5f)

                // pressing drags the nearest men toward the ball
                var ty = by0 + (ball.y - 50f) * (if (p.pos == Pos.GK) 0.12f else 0.28f + pressPull)
                if (!attacking && (t.press == 2 || pi and PI.CLOSE_DOWN != 0) && Pos.group(p.pos) >= 2) {
                    ty += (ball.y - ty) * 0.20f
                    tx += (ball.x - tx) * 0.12f
                }
                // A man with a job goes and does it. This is what puts bodies
                // in the box for a cross instead of leaving the delivery to
                // arrive at nobody.
                if (p.jobTime > 0f && p.key != ball.holder &&
                    p.jobDefensive == !attacking) {
                    tx = p.jobX; ty = p.jobY
                }

                /*
                 * ENGINE V4, IDEA 4: A MAN WHO KNOWS A PASS IS COMING GOES TO
                 * MEET IT.
                 *
                 * This is the incorrect movement the owner described. A ball is
                 * struck at a man and he carries on walking into his formation
                 * slot, because nothing on HIM says he is the receiver -- the
                 * engine knew, through v2PassTo, and he did not. The delivery
                 * then had to chase him across the grass, which is most of what
                 * made the passing look wrong.
                 *
                 * TRIED AND REVERTED, twice, and the finding is worth more than
                 * the change. Sending the man who KNOWS a pass is coming to its
                 * aim point, with the flight time as his deadline, measured
                 * nothing: he met the ball on 14.8% of passes with it and 13.4%
                 * without, and sending the nearest man there instead made it
                 * 11.1%.
                 *
                 * The reason is that the aim point is not where the ball ends
                 * up. v2Strike jitters it by up to twenty units for a hurried
                 * pass and the ball then runs on past it under its own drift, so
                 * "where it is going" is a place the ball only passes through.
                 * Meeting a pass needs the ball's REST position, and that is
                 * something a physics ball can be asked for and an interpolated
                 * one cannot -- which makes this an argument for Physics.kt
                 * owning the ball, not for another target rule.
                 *
                 * What IS kept from this is everything above: the state itself.
                 * A man now knows he has the ball at the instant he gets it, his
                 * think is his own rather than the match's, and nobody is left
                 * believing he is about to receive a ball somebody else has won.
                 */
                // Whoever is closest goes and gets it. He runs at the ball
                // itself rather than at his station, which is the difference
                // between a loose ball being contested and one nobody wants.
                if (p.pos != Pos.GK &&
                    p.key == (if (side == 0) chaserHome else chaserAway)) {
                    // lead it slightly, the way a man running onto a ball does.
                    // For a ball at a carrier's feet the drift is nil, so this
                    // is simply "go to the ball", which is the point.
                    /*
                     * ENGINE V4, IDEA 4: HE RUNS TO WHERE IT WILL BE.
                     *
                     * `ball.driftX * 6` is a sixth of a second of lead, which is
                     * the right amount for a ball rolling across the grass and
                     * far too little for one that has been STRUCK. A pass in the
                     * air was chased to where it was rather than where it was
                     * going, so the nearest man ran at a point the ball had
                     * already left and arrived behind it. Measured with
                     * MindCheck: the intended receiver was within three metres
                     * of the ball when it arrived on 13% of passes.
                     *
                     * TRIED AND REVERTED. Sending him to ball.toX/toY with the
                     * flight time as his deadline measured WORSE on the very
                     * thing it was aimed at: he met the ball on 11.1% of passes
                     * against 14.8% for chasing its current position. The aim
                     * point is not where the ball ends up -- v2Strike jitters it
                     * by up to twenty units for a hurried pass and the ball then
                     * runs on past it -- so running to the aim point is running
                     * to a place the ball only passes through.
                     *
                     * The lead of a sixth of a second stays. Meeting a pass
                     * properly needs the ball's REST position, which is what a
                     * physics ball gives and an interpolated one cannot.
                     */
                    tx = ball.x + ball.driftX * 6f
                    ty = ball.y + ball.driftY * 6f
                    /*
                     * A man CHASING the carrier never catches him: both run at
                     * about seven metres a second, so the gap simply holds and
                     * the nearest opponent measured 9.7 m all match. He gets
                     * goal-side and cuts the angle off instead, which is what a
                     * defender actually does and what closes the distance.
                     */
                    if (ENGINE_V2 && ball.holder != null) {
                        val ownGoal = if (side == 0) 0f else 100f
                        tx += (ownGoal - tx) * 0.18f
                        ty += (50f - ty) * 0.10f
                    }
                }
                /*
                 * The press arrives as a unit. The nearest three defenders come
                 * to the ball rather than holding their slots -- the chaser
                 * goes to it, the other two take up support angles just off it,
                 * so the man on the ball has somebody to beat and somebody
                 * behind that.
                 */
                if (ENGINE_V2 && p.key in v2Support && p.pos != Pos.GK &&
                    p.key != (if (side == 0) chaserHome else chaserAway)) {
                    val ownGoalX = if (side == 0) 0f else 100f
                    tx += (ball.x + (ownGoalX - ball.x) * 0.22f - tx) * 0.75f
                    ty += (ball.y - ty) * 0.62f
                }
                // man-marking drags a defender onto the man he has been given
                if (!attacking && t.oppTargetId >= 0 && t.oppMode == 1 && p.slot == markerSlot) {
                    val mark = players.firstOrNull { it.ref.id == t.oppTargetId && it.onPitch }
                    if (mark != null) { tx = mark.x - dir * 2f; ty = mark.y }
                }
                /*
                 * OFFSIDE IS A RULE, NOT A WALL.
                 *
                 * This CLAMPED every attacker to the last defender, so nobody
                 * was ever offside -- because nobody was ever allowed to be.
                 * That is why the match has no flag, no whistle for it, and no
                 * meaning to a striker's run: he was on an invisible rail a
                 * yard and a half behind the last man for ninety minutes.
                 *
                 * He now plays on the shoulder and sometimes goes early, the
                 * way a forward does, and the referee decides. How disciplined
                 * he is about it is his POSITIONING: a clever forward times it,
                 * a poor one strays. The trap is the other side of the same
                 * coin -- a side playing one steps up harder.
                 */
                if (attacking && Pos.group(p.pos) == 3 && OFFSIDE) {
                    val theirLine = lastDefenderX(1 - side)
                    // how far past the last man he is willing to gamble
                    val gamble = (1.4f - p.ref.att[Att.POS] / 90f).coerceIn(-0.4f, 1.4f)
                    val edge = theirLine + dir * gamble
                    tx = if (side == 0) kotlin.math.min(tx, edge + 1.5f)
                    else kotlin.math.max(tx, edge - 1.5f)
                }
                p.targetX = tx.coerceIn(3f, 97f)
                p.targetY = ty.coerceIn(5f, 95f)
            }
        }
    }

    /** Where the deepest outfield defender of a side is standing. */
    private fun lastDefenderX(side: Int): Float {
        val backs = onPitch(side).filter { it.pos != Pos.GK }
        if (backs.isEmpty()) return if (side == 0) 20f else 80f
        return if (side == 0) backs.minOf { it.x } else backs.maxOf { it.x }
    }

    private fun moveTowardTargets(dt: Float) {
        for (p in players) {
            if (!p.onPitch) continue

            // a pose always runs out; nothing can get stuck on the floor
            p.actionTime -= dt
            if (p.jobTime > 0f) p.jobTime = max(0f, p.jobTime - dt)
            if (p.actionTime <= 0f) {
                p.actionTime = 0f
                if (p.action != Act.RUN) p.action = Act.RUN
            }

            // a man sliding or on the floor is not chasing anything
            if (p.action == Act.TACKLE || p.action == Act.DOWN || p.action == Act.DIVE) {
                p.speedNow *= 0.86f
                continue
            }

            val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f

            // Nobody sprints for ninety minutes. Before this, every man on the
            // pitch ran flat out the whole match, which worked out at about
            // nine and a half metres a second each — sprint pace, permanently,
            // and the main reason the movement looked wrong. Effort now falls
            // away with distance from the ball: the man on it works hardest,
            // the far side of the pitch jogs into shape.
            val dBall = hypot((ball.x - p.x).toDouble(), (ball.y - p.y).toDouble()).toFloat()
            // A match is mostly walking. Even with effort already falling away
            // with distance, players spent 68 per cent of the game jogging or
            // running against a real figure of about 37, because nobody ever
            // settled: the far side of the pitch trotted about permanently.
            val chasing = p.key == chaserHome || p.key == chaserAway
            // Effort falls away with distance from the BALL, which is right for
            // ordinary play and wrong for the one moment nobody is playing.
            // After a goal the ball is in the net and the scorer is away in the
            // corner, so every man running to him was over fifty units from it
            // and throttled to 0.15 — about a unit a second. Measured: the mob
            // closed 3.5 m of a 21 m gap in five seconds, which is why a
            // celebration read as the team standing about. They sprint to him
            // now, which is what the ring of targets was always drawn for.
            val mobbing = celebrationTime > 0f && p.side == celebrateSide
            /*
             * A DEAD BALL IS NOT A SPRINT. While a stoppage is on screen the
             * ball cannot be played, so nobody chases it; they walk into shape.
             * Without this the urgency table below still had every man within
             * fourteen units of the ball running flat out at a throw-in.
             */
            val deadBall = SCENE_AI && sceneTime > 0f && !Scene.isLive(scene) &&
                    scene != Scene.KICK_OFF && celebrationTime <= 0f
            /*
             * A MAN WALKING INTO THE BOX FOR A CORNER IS NOT LOITERING.
             *
             * The dead-ball rule above was throttling EVERYBODY to a fifth of
             * their pace, including the twenty men whose whole job at a corner
             * is to get from the halfway line into the penalty area before it is
             * swung in. StagingCheck: 0.51 attackers in the box when the corner
             * was taken, against a real five or six, and only 16% of the side
             * had reached where the staging sent them -- at any scene length,
             * because lengthening the scene only gave them longer to crawl.
             *
             * So a stoppage that ARRANGES the players lets a man who is out of
             * position travel, and slows him once he is there. A stoppage that
             * arranges nothing -- a throw-in, a goal kick, a booking -- still
             * slows everybody, which is the whole point of it.
             */
            val staging = SCENE_AI && (stagedUntil > 0f || scene == Scene.PENALTY)
            val outOfPlace = staging && hypot((p.targetX - p.x).toDouble(),
                                              (p.targetY - p.y).toDouble()) > 3.0
            /*
             * GETTING BACK.
             *
             * Effort falling away with distance from the ball is right for a man
             * in ordinary play and exactly backwards for a defender caught
             * upfield. His own goal is under attack, he is thirty units from the
             * ball, and the table above throttles him to 0.26 — a jog — for as
             * long as the danger lasts.
             *
             * Measured by DefendCheck before this: with the ball inside their own
             * penalty area a side had 0.50 of ten men goal-side of it against a
             * real eight or nine, and stood 45 m from their own line while being
             * TOLD to stand at 24 m. They were not ignoring the instruction, they
             * were obeying it at a walk.
             *
             * So a man who is defending, whose goal is genuinely threatened, and
             * who is out of position, sprints. All three conditions matter: it is
             * not a general speed-up, and once he arrives he settles like anyone
             * else.
             */
            val ownGoalX = if (p.side == 0) 0f else 100f
            val recovering = RECOVER && p.pos != Pos.GK &&
                possessionSide != p.side &&
                abs(ball.x - ownGoalX) < RECOVER_RANGE &&
                hypot((p.targetX - p.x).toDouble(), (p.targetY - p.y).toDouble()) > 6.0
            val supporting = ENGINE_V2 && p.key in v2Support
            val urgency = when {
                mobbing -> 1.00f
                supporting -> 0.95f
                outOfPlace -> 0.80f
                deadBall -> 0.22f
                /*
                 * A MAN CARRYING THE BALL IS SLOWER THAN A MAN RUNNING FREE.
                 *
                 * The carrier ran at full urgency, so a presser starting ten
                 * metres back and running at the same speed never closed a
                 * single metre: the nearest opponent to the ball sat at 9-10 m
                 * for the whole match however the pressing was tuned. He is
                 * carrying it and looking up; the man chasing him is not.
                 * This is what lets a press actually arrive.
                 */
                ENGINE_V2 && p.key == ball.holder -> 0.70f
                p.key == ball.holder -> 1.00f
                chasing -> 1.00f
                recovering -> 0.95f
                dBall < 14f -> 0.88f
                dBall < 30f -> 0.58f
                dBall < 50f -> 0.26f
                else -> 0.15f
            }
            // what he is physically capable of, before any decision about effort
            val flatOut = (if (p.pos == Pos.GK) 3.6f else 5.2f + pace / 22f) *
                    (0.8f + p.effective.toFloat() / 250f) *
                    (if (p.injured) 0.4f else 1f) * 0.86f

            /*
             * ENGINE V4, IDEA 1. If this man has a DEADLINE, the deadline sets
             * his pace and the effort table above is ignored for him.
             *
             * The whole point is that he works it out himself: how far is left,
             * how long is left, therefore how fast. He never exceeds what he can
             * physically do, and a deadline he cannot make just means flat out.
             * A tenth of a second of slack keeps a man who is nearly there from
             * asking for an infinite speed on the last frame.
             */
            var top = flatOut * urgency
            if (ARRIVE_BY && p.arriveBy > 0f) {
                p.arriveBy = max(0f, p.arriveBy - dt)
                val gap = hypot((p.targetX - p.x).toDouble(), (p.targetY - p.y).toDouble()).toFloat()
                val needed = gap / max(0.35f, p.arriveBy)
                // he does not dawdle just because he has time: the table's pace
                // is still the floor, so this can only ever make a man quicker
                top = max(top, min(flatOut, needed))
            }

            // and he has to get up to it rather than arriving at it instantly
            p.gaitSpeed += (top - p.gaitSpeed) * min(1f, dt * 3.4f)
            val speedUnits = p.gaitSpeed
            val dx = p.targetX - p.x
            val dy = p.targetY - p.y
            val d = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            // Once a man is in position he stops, and will not set off again
            // until he is properly out of it. A third of a unit was tight enough
            // that the smallest drift in the shape had everyone moving again.
            // Exempting the chaser from settling was tried and put back: it
            // measured worse, not better. He reaches the ball sooner when he
            // runs at where it is going and is allowed to stop on arrival.
            if (p.settled && d > SETTLE_LEAVE) p.settled = false
            if (!p.settled && d <= SETTLE_ENTER) p.settled = true
            if (!p.settled && d > 0.3f) {
                // He used to be pointed straight at his target every frame and
                // moved along that line, so he could reverse instantly and his
                // shoulders snapped round with him. Now he holds a heading and
                // turns it at a rate he could actually manage, which means he
                // arcs into a new direction instead of pivoting on the spot.
                val want = kotlin.math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                if (!p.headingSet) { p.heading = want; p.headingSet = true }
                var delta = want - p.heading
                while (delta > Math.PI) delta -= (Math.PI * 2).toFloat()
                while (delta < -Math.PI) delta += (Math.PI * 2).toFloat()
                // quick on his toes at a walk, heavy at a sprint
                val turnRate = 6.4f - min(4.6f, speedUnits * 0.44f)
                val maxTurn = turnRate * dt
                p.heading += delta.coerceIn(-maxTurn, maxTurn)

                // and he cannot carry full pace through a hard turn, nor arrive
                // at a standstill from a run: both are eased
                val turnCost = 1f - min(0.55f, kotlin.math.abs(delta) * 0.32f)
                val arrive = min(1f, 0.28f + d / 3.2f)
                val stepLen = min(d, speedUnits * dt * turnCost * arrive)
                p.x += kotlin.math.cos(p.heading.toDouble()).toFloat() * stepLen
                p.y += kotlin.math.sin(p.heading.toDouble()).toFloat() * stepLen
                p.facing = p.heading
                p.speedNow = stepLen / max(dt, 0.001f)
                // One full leg cycle used to cover eleven metres, so the feet
                // slid along underneath him. A running stride is nearer three
                // and a half, which is what this constant now gives.
                p.runPhase += stepLen * 3.5f
            } else {
                p.speedNow *= 0.8f
                // idle players still turn to watch the ball
                val bx = ball.x - p.x
                val by = ball.y - p.y
                if (abs(bx) + abs(by) > 0.1f) {
                    p.facing = kotlin.math.atan2(by.toDouble(), bx.toDouble()).toFloat()
                }
            }
        }
    }

    /**
     * The stand reacts to where the ball is rather than only to events: it lifts
     * as an attack reaches the final third and sinks back through midfield. A
     * goal or a chance pushes [crowdTarget] up directly; this pulls it down again.
     */
    private fun updateCrowd(stepSeconds: Float) {
        val d = min(ball.x, 100f - ball.x)          // distance to the nearer goal
        val heat = ((28f - d) / 28f).coerceIn(0f, 1f)
        // A derby ground never really goes quiet, so the floor it falls back
        // to is higher rather than the spikes being bigger. Bigger spikes
        // would just clip against the ceiling on the moments that already
        // shout; a higher floor is what is actually different about the day.
        val resting = (if (isDerby) 0.34f else 0.22f) + heat * 0.42f
        // fall back gently; the cues above are what make it spike
        if (crowdTarget > resting) {
            crowdTarget = max(resting, crowdTarget - stepSeconds * 0.28f)
        } else {
            crowdTarget += (resting - crowdTarget) * min(1f, stepSeconds * 1.2f)
        }
    }

    /**
     * Men take up room. Before this they ran through each other and would stand
     * on the same blade of grass, which is one of the things that made the
     * pitch look like counters sliding about rather than a football match.
     * A short push apart each frame is enough; it is not a physics engine.
     */
    /** The nearest opponent standing within a ball's width of a passing line. */

    /* ==================================================================== */
    /*                     ENGINE V2 -- CONTINUOUS PLAY                     */
    /* ==================================================================== */
    /*
     * See docs/ENGINE_V2.md. No pre-rolled outcome and no pre-built sequence
     * of receivers: the ball is a physical object and possession is a
     * consequence of where men are and how good they are.
     *
     * Everything outside this block -- scenes, staging, cards, subs, replay,
     * the feed, the danger model, the save format, the whole public surface
     * the renderer reads -- is untouched and shared with v1.
     */

    /** Whose feet the ball is at, or null while it is loose or travelling. */
    private var v2Think = 0f
    /** Stops the man who has just lost it from instantly taking it back. */
    private val v2Cooldown = HashMap<String, Float>()
    /** True while the current delivery is a pass that may be cut out. */
    private var v2Interceptable = false
    private var v2PassTo: String? = null
    private var v2LastTouch: String? = null

    private fun v2m(ax: Float, ay: Float, bx: Float, by: Float) =
        hypot(((ax - bx) * 1.05).toDouble(), ((ay - by) * 0.68).toDouble()).toFloat()

    private fun v2Goal(side: Int) = if (side == 0) 100f else 0f

    /*
     * THE MANAGER HAS TO REACH THE PITCH.
     *
     * v1 rolled every outcome from world.teamRating(club, home), which bakes in
     * the formation, all fifteen tactical instructions, squad familiarity,
     * morale AND the home edge (+1.9 attack, +1.2 control, +1.0 defence at
     * home). v2 decided from individual player attributes alone, so none of
     * that reached the football: measured over 9,120 matches, home wins fell to
     * 38.0% against v1's 42.6% and a ~45% target, and the tactical screens
     * stopped meaning anything at all. For a management game that is fatal --
     * it is the one thing the player actually does.
     *
     * These three route the ratings back in, at the three places where a match
     * is actually decided: whether a shot goes in, whether a challenge is won,
     * and whether a pass survives. The individual attributes still do the local
     * work; the ratings tilt it.
     */

    /** Attack against defence, as a multiplier around 1. */
    private fun v2AttackEdge(att: Int): Double {
        val ra = rating(att); val rd = rating(1 - att)
        return (1.0 + (ra.attack - rd.defence) / 44.0).coerceIn(0.48, 1.95)
    }

    /** How much better this side is at keeping the ball than that one at winning it. */
    private fun v2ControlEdge(att: Int): Double {
        val ra = rating(att); val rd = rating(1 - att)
        return ((ra.control - rd.defence) / 190.0).coerceIn(-0.26, 0.26)
    }

    /** How hurried this man is right now, from the opponents around him. */
    private fun v2Press(p: LivePlayer): Float {
        var w = 0f
        for (o in players) {
            if (!o.onPitch || o.side == p.side || o.pos == Pos.GK) continue
            val d = v2m(p.x, p.y, o.x, o.y)
            if (d < 9f) w += (9f - d) / 9f
        }
        return min(1f, w * 0.55f)
    }

    /** Give the ball to a man, ending whatever was happening to it. */
    private fun v2Give(p: LivePlayer) {
        /*
         * A BALL TAKEN ABOVE CHEST HEIGHT IS HEADED.
         *
         * AliveCensus read 0.0 headers a match under v2, against a real forty.
         * The pose existed and was correct -- it fired on the v1 path, where a
         * lofted pass named its receiver before it was struck and the arrival
         * could be dressed. v2 has no named receiver: the ball is a loose
         * object and whoever gets to it takes it, so that path was never
         * reached and no player has nodded a ball since v2 was switched on.
         *
         * Read from the height the ball is ACTUALLY at when he takes it, which
         * is the honest test and the one that also catches a clearance headed
         * out of the box, not only a long pass.
         *
         * Cosmetic: act() draws no random numbers, and HEADER is not one of the
         * three actions that stop a man moving, so this cannot reach a result.
         * ResultFingerprint is the check.
         */
        if (p.pos != Pos.GK && ball.height >= 1.25f)
            act(p, Act.HEADER, HEADER_POSE, cosmetic = true)
        ball.holder = p.key
        ball.t = 1f
        ball.struck = false
        ball.driftX = 0f; ball.driftY = 0f
        ball.vz = 0f
        v2Interceptable = false
        v2PassTo = null
        v2LastTouch = p.key
        possessionSide = p.side
        // time on the ball: a composure and vision figure, not a constant
        val comp = (p.ref.att[Att.COM] + p.ref.att[Att.VIS]) / 2.0
        val think = (V2_TOUCH_SECONDS * (0.62f + (comp / 100.0).toFloat() * 0.7f))
            .coerceIn(0.22f, 1.9f)
        v2Think = think
        /*
         * ENGINE V4, IDEA 4: HE KNOWS, AT THE MOMENT HE GETS IT.
         *
         * The think used to be one number belonging to the MATCH, so a turnover
         * handed the man who had just won the ball whatever was left of the
         * think of the man he took it from -- sometimes a full second of
         * composure he had not earned, sometimes nothing at all. It is his own
         * now, set from his own composure and vision, at the instant it becomes
         * true.
         *
         * And everybody else's belief about himself is cleared here, in one
         * place, so no two men can think they have the ball and nobody is left
         * expecting a pass that has already been won by somebody else.
         */
        for (o in players) {
            if (o.key == p.key) continue
            if (o.mind == Mind.ON_BALL || o.mind == Mind.EXPECTING) o.mind = Mind.SHAPE
            o.thinkLeft = 0f
        }
        p.mind = Mind.ON_BALL
        p.thinkLeft = think
        // taking it ends the flight, however it was being flown
        ball.phys = false

        /*
         * THE FLAG GOES UP WHEN HE TOUCHES IT.
         *
         * He was offside when the ball was played -- that was decided in
         * v2Strike, at the instant it left the passer's foot -- and it becomes
         * an OFFENCE only now, when he interferes with play by taking it. A man
         * who was offside and never touches the ball is not penalised, which is
         * the law and is also why the flag has to be raised here and not there.
         */
        if (OFFSIDE && offsideOn == p.key) {
            offsideOn = null
            offsides[p.side]++
            val def = 1 - p.side
            sayRaw(FeedLine.WHISTLE,
                "Flag up. ${p.fullName} was a yard offside.")
            cue(Synth.Sfx.WHISTLE_SHORT, 0.9f, p.x)
            ball.holder = null
            p.mind = Mind.SHAPE
            p.thinkLeft = 0f
            // a free kick to the defending side, where he was standing
            val taker = onPitch(def).filter { it.pos != Pos.GK }
                .minByOrNull { v2m(it.x, it.y, offsideX, offsideY) }
            if (taker != null) {
                taker.x = offsideX; taker.y = offsideY
                placeBall(offsideX, offsideY)
                v2FreeKick(def, p.side, taker)
            } else v2Give(p)
            return
        }
        offsideOn = null
    }

    /**
     * The loose ball. Whoever is nearest and quickest to it takes it, with a
     * cooldown so the man who just lost it cannot immediately win it back.
     */
    /**
     * ENGINE V4, IDEA 3: THE BALL BELONGS TO WHOEVER GETS THERE FIRST.
     *
     * Both previous engines decided possession with a RADIUS. v2 hands the ball
     * to anybody standing inside 1.8 m of it; v3 adds a refusal when the ball is
     * travelling too fast, and that refusal is the leading suspect for why a v3
     * match degenerates into a ball that is loose 92% of the time.
     *
     * A radius cannot express the only question that matters, which is not
     * "who is near it" but "who gets to it first". A man sprinting onto a ball
     * from six metres reaches it before a man standing four metres away who is
     * facing the wrong way, and no radius will ever say so.
     *
     * So: no radius. The ball's path is sampled a few tenths of a second ahead,
     * every player is asked how long HE would take to be at each of those
     * points -- allowing for the speed and direction he is already travelling,
     * which is the whole difference -- and the lowest claim wins it. A ball
     * nobody can reach stays loose because nobody's claim is low, not because a
     * threshold said no, and a ball already over the line is never claimable at
     * all because none of its future positions are on the pitch.
     *
     * Cost is the risk here, and it is why the samples are four and not forty:
     * v3's decision layer was measured at 8.8 seconds of CPU a match before it
     * was moved off the per-tick path, and that must not happen again.
     */
    private fun v2Claim(): LivePlayer? {
        // where the ball will be, in units per second
        var bvx: Float
        var bvy: Float
        if (ball.t < 1f && ball.duration > 0.01f) {
            val left = max(0.05f, (1f - ball.t) * ball.duration)
            bvx = (ball.toX - ball.x) / left
            bvy = (ball.toY - ball.y) / left
        } else {
            // drift is the displacement of one frame at the reference rate
            bvx = ball.driftX * 36f
            bvy = ball.driftY * 36f
        }
        var best: LivePlayer? = null
        var bestClaim = Float.MAX_VALUE
        for (i in CLAIM_SAMPLES.indices) {
            val t = CLAIM_SAMPLES[i]
            if (t >= bestClaim) break            // a later sample cannot win
            val bx = ball.x + bvx * t
            val by = ball.y + bvy * t
            // a ball that will be off the field is nobody's to claim
            if (bx < 0.4f || bx > 99.6f || by < 0.4f || by > 99.6f) break
            for (p in players) {
                if (!p.onPitch) continue
                if (p.action == Act.TACKLE || p.action == Act.DOWN) continue
                if ((v2Cooldown[p.key] ?: 0f) > 0f) continue
                val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f
                val top = (5.4f + pace / 24f) * (0.82f + p.effective.toFloat() / 320f)
                val acc = 4.2f + p.ref.att[Att.ACC] / 26f
                val vx = kotlin.math.cos(p.heading.toDouble()).toFloat() * p.speedNow
                val vy = kotlin.math.sin(p.heading.toDouble()).toFloat() * p.speedNow
                var tr = Physics.timeToReach(p.x, p.y, vx, vy, bx, by, top, acc)
                // reading it early is a skill, and a keeper has his hands
                tr -= (p.ref.att[Att.POS] / 100f) * 0.10f
                if (p.pos == Pos.GK) tr -= 0.18f
                // he has to be there when the ball is, not eventually
                if (tr > t + CLAIM_SLACK) continue
                val claim = max(tr, t)
                if (claim < bestClaim) { bestClaim = claim; best = p }
            }
        }
        return best
    }

    private fun v2LooseBall(dt: Float) {
        if (ball.holder != null) return
        var best: LivePlayer? = null
        var bestScore = Float.MAX_VALUE
        if (CLAIM_BALL) {
            best = v2Claim()
        } else for (p in players) {
            if (!p.onPitch) continue
            if (p.action == Act.TACKLE || p.action == Act.DOWN) continue
            if ((v2Cooldown[p.key] ?: 0f) > 0f) continue
            val d = v2m(p.x, p.y, ball.x, ball.y)
            val reach = if (p.pos == Pos.GK) V2_CONTROL_M * 1.5f else V2_CONTROL_M
            if (d > reach) continue
            // a quicker, more alert man gets there first
            val alert = (p.ref.att[Att.ACC] + p.ref.att[Att.POS]) / 200.0
            val score = d - alert.toFloat() * 1.4f
            if (score < bestScore) { bestScore = score; best = p }
        }
        val w = best ?: return
        /*
         * A BALL THAT IS GOING OUT IS GOING OUT.
         *
         * Targets are clamped to y 5..95 and the control radius is 1.9 m, so
         * there was always a man standing exactly where a ball crossing the
         * touchline had to pass, and he plucked it back every time. Measured:
         * the ball spent 16% of frames beyond y=95 and reached 99.2 at its most
         * extreme, yet crossed a touchline 1.4 times a match against v1's 8.
         * The throw-in was not failing to be awarded; the ball was never
         * allowed to leave.
         *
         * A delivery already aimed off the field can only be stopped by
         * somebody genuinely on top of it.
         */
        val headingOut = ball.t < 1f &&
            (ball.toY > 99f || ball.toY < 1f || ball.toX > 99f || ball.toX < 1f)
        // bestScore is a RANKING (distance minus an alertness bonus), not a
        // distance -- testing it against one made this guard a no-op and left
        // throw-ins at 1.0 a match. Use the real gap to the man.
        if (headingOut && v2m(w.x, w.y, ball.x, ball.y) > 0.8f) return

        // a ball still travelling fast is harder to bring down
        val speed = hypot(ball.driftX.toDouble(), ball.driftY.toDouble()).toFloat()
        if (ball.t < 1f && speed > 1.2f && rng.chance(0.45)) return
        if (ball.height > 2.4f) return
        v2Give(w)
        if (w.pos != Pos.GK) cue(Synth.Sfx.KICK, 0.25f, w.x)
    }

    /**
     * A pass in the air can be cut out. This is the whole of the 45
     * interceptions a match the phase engine could not produce: the ball is an
     * object with a position and anyone near it may take it.
     */
    private fun v2Interception() {
        if (!v2Interceptable || ball.t >= 1f) return
        val att = possessionSide
        for (p in players) {
            if (!p.onPitch || p.side == att) continue
            if (p.action == Act.TACKLE || p.action == Act.DOWN) continue
            val d = v2m(p.x, p.y, ball.x, ball.y)
            val reach = if (p.pos == Pos.GK) 2.6f else V2_INTERCEPT_M
            if (d > reach) continue
            // over his head is not interceptable
            if (ball.height > (if (p.pos == Pos.GK) 2.6f else 2.0f)) continue
            val skill = (p.ref.att[Att.MAR] + p.ref.att[Att.POS]) / 2.0
            if (!rng.chance((0.35 + skill / 260.0 - v2ControlEdge(att)).coerceIn(0.22, 0.85))) continue
            v2Cooldown[v2LastTouch ?: ""] = 0.7f
            v2Give(p)
            p.tackles++
            if (rng.chance(0.25)) say(L_TACKLE, p.name, "")
            liveScene(Scene.TACKLE, 0.9f)
            return
        }
    }

    /** Strike the ball from the carrier toward a point. */
    private fun v2Strike(from: LivePlayer, txIn: Float, tyIn: Float, mps: Float, loft: Float) {
        /*
         * NOBODY PASSES PERFECTLY, AND THAT IS WHERE THROW-INS COME FROM.
         *
         * Every v2 aim point was clamped inside the touchlines, so the ball
         * literally could not leave the pitch: SceneAudit measured THROW-IN as
         * "never reached" over fifteen matches. A real match has forty of them
         * and every one is a misplaced pass, a deflection or a clearance.
         *
         * The error grows with how hurried he is and shrinks with how good a
         * passer he is, so a rushed clearance from a centre half genuinely does
         * go out and a composed midfielder's ball does not.
         */
        val err = (1.0f - (from.ref.att[Att.PAS] - 40) / 90f).coerceIn(0.25f, 1.15f) *
            (0.55f + v2Press(from) * 1.75f) * V2_PASS_ERROR
        val tx = txIn + (rng.f().toFloat() - 0.5f) * 2f * err * 7f
        val ty = tyIn + (rng.f().toFloat() - 0.5f) * 2f * err * 9f
        val d = v2m(from.x, from.y, tx, ty)
        val dur = (d / max(4f, mps)).coerceIn(0.12f, 2.2f)
        ball.holder = null
        if (PHYS_BALL) {
            /*
             * ENGINE V4, IDEA 5. He hits it in a DIRECTION, at a SPEED, at an
             * ANGLE -- and never says where it should end up. The drag and the
             * bounce decide that, which is what makes a pass that is too hard
             * run out of play for a throw-in instead of politely stopping on a
             * team mate.
             *
             * The speed is set so an unobstructed ball comes to rest around the
             * point the old aim was, so this changes how the ball TRAVELS
             * without changing what the passer was trying to do.
             */
            val dx = tx - from.x
            val dy = ty - from.y
            val metres = v2m(from.x, from.y, tx, ty)
            val launch = if (loft > 0.01f) (14f + loft * 2.6f).coerceAtMost(38f) else 1.5f
            /*
             * A PASS IS HIT TO ARRIVE, NOT TO STOP.
             *
             * The first version sized the speed so the ball came to REST on the
             * target -- v = distance x drag, which is the exact inverse of the
             * roll -- and it was wrong football and measurably wrong football.
             * A ball decaying exponentially never really arrives: mean flight
             * ran to 5.7 seconds, the whole match slowed down behind it, and
             * AliveCensus read 1.20 goals, 1.6 corners and 7.6 goal kicks a
             * match against 2.6, 5.6 and 21.6.
             *
             * A real pass is struck to reach the man WITH PACE ON IT and he
             * stops it. So the speed comes from the time it should take, and a
             * ball nobody collects overruns -- which is where a throw-in comes
             * from, and is the behaviour the interpolated ball could never have.
             */
            val flat = (metres / PASS_SECONDS).coerceIn(6f, 27f)
            val speed = if (loft > 0.01f) (metres * 0.70f).coerceIn(8f, 30f) else flat
            ball.fromX = ball.x; ball.fromY = ball.y
            ball.toX = tx; ball.toY = ty
            Physics.strike(ball, dx, dy, speed, launch)
            Physics.restPoint(ball, ball.rest)
            ball.phys = true
            ball.t = 0f
            ball.duration = max(0.12f, ball.rest[2])
            ball.loft = loft
            ball.driftX = ball.vx / 36f
            ball.driftY = ball.vy / 36f
        } else moveBallTo(tx, ty, dur, loft)
        v2LastTouch = from.key
        v2Cooldown[from.key] = 0.25f
        from.passes++
        passesTotal[from.side]++
        cue(Synth.Sfx.KICK, 0.45f, from.x)
    }

    /** Is the line from a to b clear of opponents? 0 blocked, 1 clear. */
    private fun v2Lane(from: LivePlayer, tx: Float, ty: Float, side: Int): Float {
        val dx = tx - from.x; val dy = ty - from.y
        val len2 = dx * dx + dy * dy
        if (len2 < 1f) return 1f
        var worst = 1f
        for (o in players) {
            if (!o.onPitch || o.side == side || o.pos == Pos.GK) continue
            val t = (((o.x - from.x) * dx + (o.y - from.y) * dy) / len2)
            if (t < 0.05f || t > 0.95f) continue
            val cx = from.x + dx * t
            val cy = from.y + dy * t
            val d = v2m(o.x, o.y, cx, cy)
            if (d < 4.5f) worst = min(worst, d / 4.5f)
        }
        return worst
    }

    /** The shot. Quality from range, angle, pressure and finishing. */
    private fun v2Shoot(from: LivePlayer) {
        val att = from.side
        val gx = v2Goal(att)
        val range = v2m(from.x, from.y, gx, 50f)
        val offCentre = abs(from.y - 50f)
        var q = V2_SHOT_BASE *
            (1f - (range / 42f).coerceIn(0f, 0.94f)) *
            (1f - (offCentre / 52f).coerceIn(0f, 0.8f)) *
            (1f - v2Press(from) * 0.45f) *
            (0.62f + from.ref.att[Att.FIN] / 150f)
        q = (q * v2AttackEdge(att).toFloat()).coerceIn(0.012f, 0.62f)
        attemptShot(att, from, q.toDouble(), "shot")
        v2Interceptable = false
    }

    /**
     * The man on the ball decides. Options are scored rather than drawn from a
     * pattern: this is where the football comes from now.
     */
    private fun v2Decide(c: LivePlayer, dt: Float) {
        val att = c.side
        val gx = v2Goal(att)
        val dir = if (att == 0) 1f else -1f
        val press = v2Press(c)
        val range = v2m(c.x, c.y, gx, 50f)

        // forced early if he is being closed down hard
        val forced = press > 0.72f && rng.chance(0.55)
        // his own think, and the match's kept in step for anything still
        // reading it
        c.thinkLeft = max(0f, c.thinkLeft - dt)
        v2Think = c.thinkLeft
        if (c.thinkLeft > 0f && !forced) {
            // carrying: he drives into space toward the goal
            c.jobTime = 0f
            val open = v2Lane(c, c.x + dir * 12f, c.y, 1 - att)
            if (open > 0.45f && press < 0.6f) {
                val tx = (c.x + dir * 9f).coerceIn(3f, 97f)
                /*
                 * TRIED AND REVERTED: cutting inside only in the final third.
                 *
                 * Every carrier is dragged 12% toward y = 50 on each decision,
                 * and nothing pushes the other way, so this looked like the
                 * reason the ball lives in the middle of the pitch. Making it
                 * apply only within 30 m of goal moved the ball's share of the
                 * middle fifth from 60.3% to 61.4% -- nothing -- and throw-ins
                 * from 0.50 to 1.00 a match against a real forty. The
                 * centralising force is elsewhere; this is not it.
                 */
                c.targetX = tx; c.targetY = (c.y + (50f - c.y) * 0.12f).coerceIn(5f, 95f)
                if (press > 0.35f && rng.chance(dt * 0.7)) {
                    act(c, Act.DRIBBLE, TAKE_ON_POSE)
                            c.dribbles++
                }
            }
            return
        }

        /*
         * THE HURRIED CLEARANCE, which is where throw-ins come from.
         *
         * v2 scored every pass on progress and centrality, so play never went
         * near a touchline and the ball crossed goal lines only: measured 23.3
         * goal kicks a match and ZERO throw-ins, against a real 14 and 40. A
         * defender under pressure in his own third does not look for a pass, he
         * puts it long and wide and concedes the throw, and that single missing
         * behaviour was the whole of it.
         */
        val ownGoalX = v2Goal(1 - att)
        if (abs(c.x - ownGoalX) < 30f && press > 0.42f && rng.chance(0.50)) {
            val wide = if (c.y < 50f) -6f + rng.f().toFloat() * 26f
                       else 80f + rng.f().toFloat() * 26f
            v2Strike(c, (c.x + dir * 30f).coerceIn(-1f, 101f), wide, 19f, 7.2f)
            v2Interceptable = true
            return
        }

        /*
         * TRIED AND REVERTED: a man pinned on the touchline plays it out.
         *
         * `press > 0.62 && (c.y < 9 || c.y > 91)` then a strike over the line.
         * It is the commonest way a real throw-in happens and it measured
         * almost nothing -- deliveries aimed off the field went from 1.67 to
         * 1.75 a match, throw-ins from 0.50 to 0.58 -- because the condition
         * hardly ever holds. WidthCheck says the man on the ball is inside the
         * outer two fifths of the pitch for 10% of live play and within nine
         * units of a line for a fraction of that.
         *
         * That is the third measured attempt at the throw-in gap in this
         * session, after the carrier's infield drift and the pass scorer's
         * distance-to-goal term, and all three moved nothing. The conclusion
         * is the same each time and it is not a tuning one: v2 does not play
         * down the flanks, so no rule about the touchline can fire. Wide play
         * needs a model of where the space IS, which is the whole reason
         * engine v3 exists and is the thing v3 still has to be made to work.
         */

        // shoot?
        if (range < V2_SHOT_RANGE && rng.chance(
                (0.86 - range / 70.0 + c.ref.att[Att.FIN] / 320.0).coerceIn(0.10, 0.80))) {
            v2Shoot(c)
            return
        }

        // otherwise pass: score every team mate
        val mates = onPitch(att).filter { it.key != c.key && it.pos != Pos.GK }
        var bestP: LivePlayer? = null
        var bestScore = -1e9f
        for (t in mates) {
            val d = v2m(c.x, c.y, t.x, t.y)
            if (d < 2f || d > 46f) continue
            val progress = (t.x - c.x) * dir
            val lane = v2Lane(c, t.x, t.y, 1 - att)
            val recvPress = v2Press(t)
            /*
             * TRIED AND REVERTED: taking this distance to the goal LINE rather
             * than the goal CENTRE, so a wide man was not marked down twice --
             * once here and once through `progress` -- for being wide. It
             * measured 62.9% of live play in the middle fifth against 60.3%
             * before it, and throw-ins 0.58 against 0.50. Nothing, or slightly
             * worse. The pass scorer is not where the ball's centrality comes
             * from; two separate attempts on it have now said so.
             */
            val s = progress * 1.15f +
                lane * 16f -
                recvPress * 17f -
                (d / 5.5f) +
                (100f - v2m(t.x, t.y, gx, 50f)) * 0.10f
            if (s > bestScore) { bestScore = s; bestP = t }
        }
        val target = bestP
        if (target == null) {
            // nobody on: hit it long and let the contest decide
            v2Strike(c, (c.x + dir * 30f).coerceIn(-1f, 101f),
                (8f + rng.f().toFloat() * 84f), 17f, 6.5f)
            v2Interceptable = true
            return
        }
        val d = v2m(c.x, c.y, target.x, target.y)
        val lane = v2Lane(c, target.x, target.y, 1 - att)
        // a blocked lane is clipped, not teleported over: it can still be cut out
        val loft = if (lane < 0.5f) 3.4f else if (d > 34f) 6.4f else 0f
        // lead him
        val leadX = target.x + (target.targetX - target.x) * 0.30f
        val leadY = target.y + (target.targetY - target.y) * 0.30f
        val pace = 13f + c.ref.att[Att.PAS] / 8f
        v2Strike(c, leadX.coerceIn(-1f, 101f), leadY.coerceIn(-8f, 108f), pace, loft)
        v2PassTo = target.key
        /*
         * ENGINE V4, IDEA 4: THE MAN IT IS AIMED AT KNOWS IT IS COMING.
         *
         * v2PassTo existed and only the ENGINE read it; the receiver himself
         * had no idea, so he carried on walking into his formation slot while a
         * ball was played at him and the delivery had to chase him across the
         * grass. Telling him is what turns a pass into a pass and a run.
         */
        target.mind = Mind.EXPECTING
        c.mind = Mind.SHAPE
        /*
         * OFFSIDE IS JUDGED WHEN THE BALL IS PLAYED, not when it arrives, which
         * is the whole subtlety of the law and the reason it has to be recorded
         * here rather than tested later. The last defender's position at THIS
         * instant is what counts.
         */
        offsideOn = null
        if (OFFSIDE) {
            val theirLine = lastDefenderX(1 - att)
            val past = (target.x - theirLine) * dir
            // in their half, beyond the last man, and the ball played forward
            val forward = (target.x - c.x) * dir > 0f
            if (past > OFFSIDE_MARGIN && forward &&
                (if (att == 0) target.x > 50f else target.x < 50f)) {
                offsideOn = target.key
                offsideX = target.x
                offsideY = target.y
            }
        }
        v2Interceptable = true
        if (rng.chance(0.06)) say(L_PASS, c.name, target.name)
    }

    /** The presser: close him down, and challenge when near enough. */
    private fun v2Defend(dt: Float) {
        val c = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } } ?: return
        if (c.pos == Pos.GK) return
        val d = 1 - c.side
        val presser = onPitch(d).filter { it.pos != Pos.GK && it.action != Act.DOWN }
            .minByOrNull { v2m(it.x, it.y, c.x, c.y) } ?: return
        val dist = v2m(presser.x, presser.y, c.x, c.y)
        if (dist > V2_TACKLE_M) return
        if (!rng.chance((dt * V2_TACKLE_RATE).toDouble())) return

        val atk = (c.ref.att[Att.DRI] + c.ref.att[Att.PAC] + c.ref.att[Att.STR]) / 3.0
        val def = (presser.ref.att[Att.TAC] + presser.ref.att[Att.POS] + presser.ref.att[Att.STR]) / 3.0
        val pWin = (0.42 + (def - atk) / 170.0 - v2ControlEdge(c.side)).coerceIn(0.16, 0.78)
        if (rng.chance(SLIDE_SHARE)) {
            act(presser, Act.TACKLE, TACKLE_POSE, angleTo(presser, c.x, c.y))
            liveScene(Scene.TACKLE, 1.0f)
            cue(Synth.Sfx.TACKLE, 0.8f, presser.x)
        }
        if (rng.chance(pWin)) {
            presser.tackles++
            v2Cooldown[c.key] = 0.6f
            v2Give(presser)
            // won it in his own third under pressure: it goes long and wide,
            // which is the other half of where throw-ins come from
            val ownG = v2Goal(1 - presser.side)
            if (abs(presser.x - ownG) < 30f && rng.chance(0.45)) {
                val dirC = if (presser.side == 0) 1f else -1f
                val wide = if (presser.y < 50f) -5f + rng.f().toFloat() * 24f
                           else 81f + rng.f().toFloat() * 24f
                v2Strike(presser, (presser.x + dirC * 26f).coerceIn(-1f, 101f),
                    wide, 19f, 7.0f)
                v2Interceptable = true
            }
            if (rng.chance(0.20)) say(L_TACKLE, presser.name, c.name)
        } else if (rng.chance(V2_FOUL_RATE)) {
            // a foul: hand it straight to the existing set-piece machinery
            fouls[d]++
            act(c, Act.DOWN, DOWN_POSE)
            val aggressive = (if (d == 0) home else away).tactics.tackling == 2
            val cardChance = 0.23 * (if (aggressive) 1.7 else 1.0) *
                (if (presser.ref.hasTrait(Traits.HOTHEAD)) 1.6 else 1.0) *
                (if (isDerby) 1.3 else 1.0)
            if (rng.chance(cardChance * cardRisk(presser))) card(presser, rng.chance(0.06))
            ball.holder = null
            // In the box it is a penalty. v2 had no route to one at all --
            // SceneAudit reported PENALTY "never reached" over fifteen matches,
            // because every foul went to v2FreeKick wherever it happened.
            val inBox = if (c.side == 0) c.x > 83f else c.x < 17f
            if (inBox) {
                say(L_PENALTY, presser.name, teamName(c.side))
                v2Interceptable = false
                v2Restart = 0f
                takePenalty(c.side)
            } else v2FreeKick(c.side, d, c)
        } else {
            act(c, Act.DRIBBLE, TAKE_ON_POSE)
            c.dribbles++
        }
    }

    /** A foul in open play restarts through the same staging v1 uses. */
    private fun v2FreeKick(att: Int, def: Int, at: LivePlayer) {
        if (scene != Scene.CARD) { scene = Scene.FREEKICK; sceneTime = FREEKICK_SECONDS }
        stageFreeKick(att, def, at)
        possessionSide = att
        // as long as the caption, or play restarts underneath it
        v2Restart = max(V2_DEAD_SECONDS, FREEKICK_SECONDS)
        v2Interceptable = false
    }

    /** Who was offside when the ball was played, and where he was. */
    private var offsideOn: String? = null
    private var offsideX = 0f
    private var offsideY = 0f
    @JvmField var offsides = intArrayOf(0, 0)

    /** Seconds until play resumes after the ball has gone dead. */
    private var v2Restart = 0f

    /** The ball leaving the field, into the scene machinery that already works. */
    private fun v2Boundary(): Boolean {
        if (v2Restart > 0f) return false
        val bx = ball.x; val by = ball.y
        val last = v2LastTouch?.let { k -> players.firstOrNull { it.key == k } }
        val toucher = last ?: return false
        if (by in 1.2f..98.8f && bx in 1.2f..98.8f) return false

        val def = 1 - toucher.side
        if (by < 1.2f || by > 98.8f) {
            val side = if (by < 50f) 2f else 98f
            placeBall(bx.coerceIn(6f, 94f), side)
            ball.holder = null
            scene = Scene.THROW_IN; sceneTime = THROWIN_SECONDS
            stageThrowIn(def, bx.coerceIn(6f, 94f), side)
            sayRaw(FeedLine.PLAIN, "Out for a throw-in to ${teamName(def)}.")
            possessionSide = def
            v2Restart = THROWIN_SECONDS
        } else {
            // over a goal line: corner if the defending side put it out
            val ownGoal = if (toucher.side == 0) 0f else 100f
            val ownEnd = abs(bx - ownGoal) < 50f
            if (ownEnd) {
                corners[1 - toucher.side]++
                scene = Scene.CORNER; sceneTime = CORNER_SECONDS
                say(L_CORNER, teamName(1 - toucher.side), "")
                stageCorner(1 - toucher.side)
                possessionSide = 1 - toucher.side
                v2Restart = CORNER_SECONDS
            } else {
                scene = Scene.GOAL_KICK; sceneTime = GOALKICK_SECONDS
                stageGoalKick(def)
                possessionSide = def
                v2Restart = GOALKICK_SECONDS
            }
        }
        v2Interceptable = false
        return true
    }

    /** Put the ball back in play once a stoppage has had its time. */
    private fun v2Resume() {
        val side = possessionSide
        val taker = onPitch(side).filter { it.pos != Pos.GK }
            .minByOrNull { v2m(it.x, it.y, ball.x, ball.y) }
            ?: onPitch(side).firstOrNull() ?: return
        v2Give(taker)
    }

    /**
     * One tick of continuous play. Called from update() in place of the phase
     * block when ENGINE_V2 is on.
     */
    private fun v2Tick(dt: Float, minutes: Double) {
        // cooldowns
        val it = v2Cooldown.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val v = e.value - dt
            if (v <= 0f) it.remove() else e.setValue(v)
        }

        if (v2Restart > 0f) {
            v2Restart -= dt
            if (v2Restart <= 0f) v2Resume()
            return
        }
        if (pendingGoal != null) return

        possession[possessionSide] += minutes

        /*
         * THE BALL IS DEAD; NOTHING ELSE HAPPENS THIS TICK.
         *
         * v2Boundary awarded the restart and then execution simply carried on
         * into v2LooseBall, which found the taker standing 1.4 m from the ball
         * it had just placed on the touchline and gave it straight back to him.
         * ThrowTrace: holder was set on the very first frame of every throw-in
         * and the ball drifted from y 97.3 to 91.5 while the caption was still
         * up, so THROW-IN read correctly 0% of the time. Awarding a restart has
         * to end the tick.
         */
        if (v2Boundary()) return
        v2Interception()
        v2LooseBall(dt)

        // The challenge. This was written and then never called from the tick,
        // which measured as 56 tackles and ZERO fouls a match -- tackles came
        // from interceptions alone. A mechanic that is not on the call path is
        // not a mechanic.
        v2Defend(dt)

        val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        if (carrier != null) {
            if (carrier.pos == Pos.GK) {
                // the keeper does not dwell; he plays it away
                if (v2Think <= 0f) {
                    val dirG = if (carrier.side == 0) 1f else -1f
                    v2Strike(carrier, (carrier.x + dirG * 38f).coerceIn(4f, 96f),
                        (16f + rng.f().toFloat() * 68f), 18f, 6.8f)
                    v2Interceptable = true
                } else v2Think -= dt
            } else {
                v2Decide(carrier, dt)
            }
        }
    }


    /* ==================================================================== */
    /*        ENGINE V3 -- PHYSICS + SPACE + ROLES + UTILITY (adapter)      */
    /* ==================================================================== */
    /*
     * The thinking lives in Physics.kt, Pitch.kt and RoleTree.kt, which are
     * standalone and testable. This is only the adapter that drives them and
     * writes the result into the state the renderer already reads.
     *
     * See docs/ENGINE_V3.md.
     */

    private val v3Pitch = Pitch()
    private var v3GridAge = 0f
    private var v3Think = 0f
    private var v3Restart = 0f
    private val v3Cool = HashMap<String, Float>()
    private var v3LastTouch: String? = null
    private var v3Live = false
    private var v3Stall = 0f
    private var v3PlanAge = 0f

    private fun v3Top(p: LivePlayer): Float {
        val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f
        return (5.4f + pace / 24f) * (0.82f + p.effective.toFloat() / 320f)
    }

    private fun v3Give(p: LivePlayer) {
        ball.holder = p.key
        ball.vx = 0f; ball.vy = 0f; ball.vz = 0f
        ball.height = 0f
        ball.t = 1f
        v3LastTouch = p.key
        v3Live = false
        possessionSide = p.side
        val comp = (p.ref.att[Att.COM] + p.ref.att[Att.VIS]) / 2.0
        v3Think = (V3_TOUCH_SECONDS * (0.6f + (comp / 100.0).toFloat() * 0.75f))
            .coerceIn(0.2f, 1.8f)
    }

    /** Strike it. Direction and pace; where it finishes is a consequence. */
    private fun v3Strike(from: LivePlayer, tx: Float, ty: Float, mps: Float, launch: Float) {
        ball.holder = null
        ball.x = from.x + kotlin.math.cos(from.facing.toDouble()).toFloat() * 0.5f
        ball.y = from.y + kotlin.math.sin(from.facing.toDouble()).toFloat() * 0.5f
        val spin = (physRng.f().toFloat() - 0.5f) * 2.4f
        Physics.strike(ball, (tx - ball.x) * Physics.MX, (ty - ball.y) * Physics.MY,
            mps, launch, spin)
        v3LastTouch = from.key
        v3Cool[from.key] = 0.28f
        v3Live = true
        from.passes++
        passesTotal[from.side]++
        cue(Synth.Sfx.KICK, 0.45f, from.x)
    }

    /**
     * UTILITY. Every option scored against the space model rather than a
     * hand-weighted sum of distances -- which is the whole reason v3 exists.
     */
    private fun v3Decide(c: LivePlayer, dt: Float) {
        val att = c.side
        val foe = 1 - att
        val dir = if (att == 0) 1f else -1f
        val gx = if (att == 0) 100f else 0f
        val press = v3Pitch.pressureOn(c)
        val range = Physics.metres(c.x, c.y, gx, 50f)

        v3Think -= dt
        val forced = press > 0.80f && rng.chance(0.5)
        if (v3Think > 0f && !forced) {
            // carrying: drive at the best space he can reach
            val (sx, sy) = v3Pitch.bestSpace(att, c.x, c.y, 14f)
            c.targetX = sx.coerceIn(2f, 98f); c.targetY = sy.coerceIn(2f, 98f)
            if (press > 0.55f && rng.chance((dt * 0.8f).toDouble())) {
                act(c, Act.DRIBBLE, TAKE_ON_POSE); c.dribbles++
            }
            return
        }

        var bestScore = -1e9f
        var bestKind = 0            // 0 pass, 1 shoot, 2 clear
        var bestT: LivePlayer? = null
        var bestX = 0f; var bestY = 0f

        // --- shoot
        if (range < V3_SHOT_RANGE) {
            val q = v3ShotQuality(c, range, press)
            /*
             * A goal is worth vastly more than field position, and the utility
             * has to say so. At a weight of 34 a shot scored 3-10 while a
             * decent pass scored 10-20, so the model passed up almost every
             * chance: 0.5 shots and no goals a match. A 0.2 chance of scoring
             * is worth more than any pass on the pitch.
             */
            val s = q * 150f - press * 4f
            if (s > bestScore) { bestScore = s; bestKind = 1 }
        }

        // --- pass to each team mate, scored on the space it wins
        val mates = onPitch(att).filter { it.key != c.key && it.pos != Pos.GK }
        for (t in mates) {
            val d = Physics.metres(c.x, c.y, t.x, t.y)
            if (d < 2f || d > 48f) continue
            // lead him toward where he is going
            val lx = t.x + (t.targetX - t.x) * 0.35f
            val ly = t.y + (t.targetY - t.y) * 0.35f
            val mps = (13f + c.ref.att[Att.PAS] / 9f)
            val safety = v3Pitch.laneSafety(c.x, c.y, lx, ly, foe, mps)
            val gain = v3Pitch.spaceValue(att, lx, ly) - v3Pitch.spaceValue(att, c.x, c.y)
            val s = gain * 26f + safety * 20f - (d / 9f)
            if (s > bestScore) {
                bestScore = s; bestKind = 0; bestT = t; bestX = lx; bestY = ly
            }
        }

        // --- clear it: always available, and the right answer under real pressure
        run {
            val ownGoal = if (att == 0) 0f else 100f
            val ownThird = kotlin.math.abs(c.x - ownGoal) < 34f
            val toward = if (c.y < 50f) 6f else 94f
            val s = if (ownThird) 4f + press * 16f else -50f
            if (s > bestScore) {
                bestScore = s; bestKind = 2
                bestX = (c.x + dir * 34f).coerceIn(-4f, 104f); bestY = toward
            }
        }

        when (bestKind) {
            1 -> {
                val q = v3ShotQuality(c, range, press)
                attemptShot(att, c, q.toDouble(), "shot")
                v3Live = false
            }
            2 -> {
                v3Strike(c, bestX, bestY, 21f, 26f)
            }
            else -> {
                val t = bestT
                if (t == null) {
                    v3Strike(c, (c.x + dir * 30f).coerceIn(-4f, 104f),
                        (10f + rng.f().toFloat() * 80f), 19f, 22f)
                } else {
                    val d = Physics.metres(c.x, c.y, bestX, bestY)
                    val lofted = v3Pitch.laneSafety(c.x, c.y, bestX, bestY, foe, 14f) < 0.45f
                    // pace matched to the distance, plus how hurried he is
                    val err = (1.05f - c.ref.att[Att.PAS] / 130f) * (0.5f + press * 1.5f)
                    val ex = bestX + (rng.f().toFloat() - 0.5f) * err * 9f
                    val ey = bestY + (rng.f().toFloat() - 0.5f) * err * 11f
                    v3Strike(c, ex, ey, (8f + d * 0.85f).coerceIn(9f, 27f),
                        if (lofted) 17f else 4f)
                    if (rng.chance(0.05)) say(L_PASS, c.name, t.name)
                }
            }
        }
    }

    private fun v3ShotQuality(c: LivePlayer, range: Float, press: Float): Float {
        val att = c.side
        val offCentre = kotlin.math.abs(c.y - 50f)
        var q = V3_SHOT_BASE *
            (1f - (range / 40f).coerceIn(0f, 0.95f)) *
            (1f - (offCentre / 52f).coerceIn(0f, 0.8f)) *
            (1f - press * 0.5f) *
            (0.6f + c.ref.att[Att.FIN] / 150f)
        val ra = rating(att); val rd = rating(1 - att)
        q *= (1.0 + (ra.attack - rd.defence) / 44.0).coerceIn(0.48, 1.95).toFloat()
        return q.coerceIn(0.012f, 0.62f)
    }

    /** Anyone may take a loose or travelling ball if he can actually get to it. */
    private fun v3Contest(dt: Float) {
        if (ball.holder != null) return
        val speed = kotlin.math.hypot(ball.vx.toDouble(), ball.vy.toDouble()).toFloat()
        var best: LivePlayer? = null
        var bestD = Float.MAX_VALUE
        for (p in players) {
            if (!p.onPitch) continue
            if (p.action == Act.TACKLE || p.action == Act.DOWN) continue
            if ((v3Cool[p.key] ?: 0f) > 0f) continue
            val reach = if (p.pos == Pos.GK) V3_CONTROL_M * 1.7f else V3_CONTROL_M
            val d = Physics.metres(p.x, p.y, ball.x, ball.y)
            if (d > reach) continue
            if (ball.height > (if (p.pos == Pos.GK) 2.6f else 2.1f)) continue
            if (d < bestD) { bestD = d; best = p }
        }
        val w = best ?: return
        // a ball travelling hard is not simply picked up
        if (speed > 9f && !rng.chance(0.30 + w.ref.att[Att.TEC] / 300.0)) return
        val wasFoe = v3LastTouch?.let { k -> players.firstOrNull { it.key == k } }
        if (wasFoe != null && wasFoe.side != w.side && v3Live) {
            w.tackles++
            liveScene(Scene.TACKLE, 0.8f)
        }
        v3Give(w)
    }

    /** The challenge, resolved on attributes. */
    private fun v3Tackle(dt: Float) {
        val c = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } } ?: return
        if (c.pos == Pos.GK) return
        val d = 1 - c.side
        val presser = onPitch(d).filter { it.pos != Pos.GK && it.action != Act.DOWN }
            .minByOrNull { Physics.metres(it.x, it.y, c.x, c.y) } ?: return
        if (Physics.metres(presser.x, presser.y, c.x, c.y) > 2.2f) return
        if (!rng.chance((dt * 1.1f).toDouble())) return

        val atk = (c.ref.att[Att.DRI] + c.ref.att[Att.PAC] + c.ref.att[Att.STR]) / 3.0
        val def = (presser.ref.att[Att.TAC] + presser.ref.att[Att.POS] + presser.ref.att[Att.STR]) / 3.0
        val pWin = (0.42 + (def - atk) / 170.0).coerceIn(0.16, 0.78)
        if (rng.chance(SLIDE_SHARE)) {
            act(presser, Act.TACKLE, TACKLE_POSE, angleTo(presser, c.x, c.y))
            liveScene(Scene.TACKLE, 1.0f)
            cue(Synth.Sfx.TACKLE, 0.8f, presser.x)
        }
        if (rng.chance(pWin)) {
            presser.tackles++
            v3Cool[c.key] = 0.55f
            v3Give(presser)
        } else if (rng.chance(0.34)) {
            fouls[d]++
            act(c, Act.DOWN, DOWN_POSE)
            val cardChance = 0.21 * (if ((if (d == 0) home else away).tactics.tackling == 2) 1.7 else 1.0) *
                (if (presser.ref.hasTrait(Traits.HOTHEAD)) 1.6 else 1.0) * (if (isDerby) 1.3 else 1.0)
            if (rng.chance(cardChance * cardRisk(presser))) card(presser, rng.chance(0.06))
            ball.holder = null
            val inBox = if (c.side == 0) c.x > 83f else c.x < 17f
            if (inBox) { v3Restart = 0f; takePenalty(c.side) }
            else {
                if (scene != Scene.CARD) { scene = Scene.FREEKICK; sceneTime = FREEKICK_SECONDS }
                stageFreeKick(c.side, d, c)
                possessionSide = c.side
                v3Restart = FREEKICK_SECONDS
                v3Live = false
            }
        }
    }

    /** The ball leaving the field, into the scene machinery that already works. */
    private fun v3Boundary(): Boolean {
        if (v3Restart > 0f) return false
        val bx = ball.x; val by = ball.y
        if (by in 1.2f..98.8f && bx in 1.2f..98.8f) return false
        val toucher = v3LastTouch?.let { k -> players.firstOrNull { it.key == k } } ?: return false
        val def = 1 - toucher.side
        ball.vx = 0f; ball.vy = 0f; ball.vz = 0f
        if (by < 1.2f || by > 98.8f) {
            val side = if (by < 50f) 2f else 98f
            val ox = bx.coerceIn(6f, 94f)
            placeBall(ox, side); ball.holder = null
            scene = Scene.THROW_IN; sceneTime = THROWIN_SECONDS
            stageThrowIn(def, ox, side)
            sayRaw(FeedLine.PLAIN, "Out for a throw-in to ${teamName(def)}.")
            possessionSide = def
            v3Restart = THROWIN_SECONDS
        } else {
            val ownGoal = if (toucher.side == 0) 0f else 100f
            if (kotlin.math.abs(bx - ownGoal) < 50f) {
                corners[1 - toucher.side]++
                scene = Scene.CORNER; sceneTime = CORNER_SECONDS
                say(L_CORNER, teamName(1 - toucher.side), "")
                stageCorner(1 - toucher.side)
                possessionSide = 1 - toucher.side
                v3Restart = CORNER_SECONDS
            } else {
                scene = Scene.GOAL_KICK; sceneTime = GOALKICK_SECONDS
                stageGoalKick(def)
                possessionSide = def
                v3Restart = GOALKICK_SECONDS
            }
        }
        v3Live = false
        return true
    }

    private fun v3Resume() {
        val side = possessionSide
        val taker = onPitch(side).filter { it.pos != Pos.GK }
            .minByOrNull { Physics.metres(it.x, it.y, ball.x, ball.y) }
            ?: onPitch(side).firstOrNull() ?: return
        v3Give(taker)
    }

    /** Intents, and the targets they imply, for all twenty two. */
    private fun v3Targets() {
        val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        val ctx = RoleCtx(v3Pitch, ball.x, ball.y, ball.vx, ball.vy, carrier,
                possessionSide, ball.holder == null)
        for (side in 0..1) {
            val club = if (side == 0) home else away
            val men = onPitch(side)
            val nearest = men.filter { it.pos != Pos.GK }
                .minByOrNull { Physics.metres(it.x, it.y, ball.x, ball.y) }
            for (p in men) {
                val intent = RoleTree.intentOf(p, club.tactics, ctx, p.key == nearest?.key)
                p.jobTime = 0f
                if (intent == PlayIntent.CARRY) continue     // v3Decide owns him
                val (tx, ty) = RoleTree.targetFor(p, intent, club.tactics, ctx,
                    ownX(side, p.baseX), ownY(side, p.baseY))
                p.targetX = tx.coerceIn(2f, 98f)
                p.targetY = ty.coerceIn(2f, 98f)
                p.actionTime = p.actionTime      // untouched
                p.gaitSpeed = RoleTree.effortFor(intent)   // reused as the effort factor
            }
        }
    }

    /** One tick of v3. Replaces the phase block and v2Tick entirely. */
    private fun v3Tick(dt: Float, minutes: Double) {
        val it = v3Cool.entries.iterator()
        while (it.hasNext()) {
            val e = it.next(); val v = e.value - dt
            if (v <= 0f) it.remove() else e.setValue(v)
        }

        v3GridAge -= dt
        if (v3GridAge <= 0f) {
            v3Pitch.compute(players.filter { it.onPitch })
            v3GridAge = V3_GRID_HZ
        }

        if (v3Restart > 0f) {
            v3Restart -= dt
            if (v3Restart <= 0f) v3Resume()
            return
        }
        if (pendingGoal != null) return

        possession[possessionSide] += minutes

        /*
         * KICK OFF, AND ANY STALL.
         *
         * v2 got the ball into play through v2Resume off a pending restart. v3
         * has no equivalent at the first whistle, so the ball sat on the centre
         * spot with nobody inside the 1.8 m control radius and the match never
         * started: measured 99.6% of frames with a loose ball, zero shots, and
         * one match in six hitting the tick guard. A dead ball nobody is near
         * has to be given to somebody.
         */
        if (ball.holder == null &&
            kotlin.math.hypot(ball.vx.toDouble(), ball.vy.toDouble()) < 0.3) {
            v3Stall += dt
            if (v3Stall > 0.6f) { v3Stall = 0f; v3Resume() }
        } else v3Stall = 0f

        if (v3Boundary()) return
        v3Contest(dt)
        v3Tackle(dt)

        val carrier = ball.holder?.let { k -> players.firstOrNull { it.key == k && it.onPitch } }
        if (carrier != null) {
            if (carrier.pos == Pos.GK) {
                if (v3Think <= 0f) {
                    val dirG = if (carrier.side == 0) 1f else -1f
                    v3Strike(carrier, (carrier.x + dirG * 36f).coerceIn(4f, 96f),
                        (12f + rng.f().toFloat() * 76f), 21f, 24f)
                } else v3Think -= dt
            } else v3Decide(carrier, dt)
        }
        /*
         * THE DECISION LAYER RUNS AT THE GRID'S CADENCE, NOT THE TICK'S.
         *
         * v3Targets calls RoleTree.targetFor, and SUPPORT and RUN each scan the
         * whole grid for the best space. Running that for 22 men, 36 times a
         * second, over a 408-second match is tens of millions of cell
         * evaluations: it measured 8.8 seconds of CPU per match against v2's
         * 0.3, which would be unplayable on a phone.
         *
         * Intent does not change meaningfully in a sixth of a second. Targets
         * persist between recomputes and the movement layer keeps running at
         * full rate, so nothing looks stepped.
         */
        if (v3PlanAge <= 0f) { v3Targets(); v3PlanAge = V3_PLAN_HZ }
        else v3PlanAge -= dt
    }

    /** v3 moves the men itself, under acceleration and turn limits. */
    private fun v3Move(dt: Float) {
        for (p in players) {
            if (!p.onPitch) continue
            p.actionTime -= dt
            if (p.actionTime <= 0f) { p.actionTime = 0f; if (p.action != Act.RUN) p.action = Act.RUN }
            if (p.action == Act.TACKLE || p.action == Act.DOWN || p.action == Act.DIVE) {
                p.vx *= 0.82f; p.vy *= 0.82f
                p.x += p.vx * dt; p.y += p.vy * dt
                continue
            }
            val effort = p.gaitSpeed.coerceIn(0.25f, 1f)
            val top = v3Top(p) * effort * (if (p.injured) 0.45f else 1f)
            val acc = (4.2f + p.ref.att[Att.ACC] / 26f) * effort
            Physics.stepBody(p, p.targetX, p.targetY, dt, top, acc, 6.2f)
            p.x = p.x.coerceIn(1f, 99f)
            p.y = p.y.coerceIn(1f, 99f)
        }
        // the ball travels with whoever has it
        val h = ball.holder?.let { k -> players.firstOrNull { it.key == k } }
        if (h != null) {
            val reach = if (h.pos == Pos.GK) 0.30f else 0.55f
            ball.x = h.x + kotlin.math.cos(h.facing.toDouble()).toFloat() * reach
            ball.y = h.y + kotlin.math.sin(h.facing.toDouble()).toFloat() * reach
            ball.height = if (h.pos == Pos.GK) 0.6f else 0f
            ball.vx = 0f; ball.vy = 0f
        } else {
            Physics.stepBall(ball, dt)
        }
    }

    private fun blockerOnLine(x0: Float, y0: Float, x1: Float, y1: Float, side: Int): LivePlayer? {
        val dx = x1 - x0
        val dy = y1 - y0
        val len2 = dx * dx + dy * dy
        if (len2 < 1f) return null
        var best: LivePlayer? = null
        var bestT = 2f
        for (o in players) {
            if (!o.onPitch || o.side != side || o.pos == Pos.GK) continue
            val t = (((o.x - x0) * dx + (o.y - y0) * dy) / len2).coerceIn(0.08f, 0.92f)
            val cx = x0 + dx * t
            val cy = y0 + dy * t
            val d = hypot(((o.x - cx) * 1.05).toDouble(), ((o.y - cy) * 0.68).toDouble()).toFloat()
            if (d < 1.1f && t < bestT) { best = o; bestT = t }
        }
        return best
    }

    private fun separate() {
        /*
         * MEN CANNOT STAND ON EACH OTHER.
         *
         * This kept a gap of 1.15 PITCH UNITS and the comment called that "a
         * bit under a metre and a half". It is not: one x-unit is 1.05 m and
         * one y-unit is 0.68 m, so along y the gap was 0.78 m -- two sprites
         * drawn on top of one another. And it was a SINGLE pass, so a genuine
         * pile of eight or ten men could never resolve itself: each pair nudges
         * a little, the pile stays.
         *
         * CrowdCheck, measured over five matches: up to TWELVE outfielders
         * inside a five-metre circle, and about one overlapping pair on screen
         * at any instant. That is the "players bunch into one spot" the owner
         * reported, and an earlier check of mine missed it by measuring how
         * stretched a SIDE was rather than how close two MEN were.
         *
         * Now the gap is in metres, so it is the same in both directions, and
         * the relaxation runs a few passes so a pile actually comes apart.
         */
        val on = players.filter { it.onPitch }
        val minGapM = SEPARATE_M
        for (pass in 0 until SEPARATE_PASSES)
        for (i in on.indices) {
            val a = on[i]
            for (j in i + 1 until on.size) {
                val b = on[j]
                var dx = (b.x - a.x) * 1.05f
                var dy = (b.y - a.y) * 0.68f
                var d = hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (d >= minGapM) continue
                if (d < 0.001f) {
                    // exactly on top of each other: nudge them apart deterministically
                    dx = if ((a.ref.id + b.ref.id) % 2 == 0) 0.05f else -0.05f
                    dy = 0.03f
                    d = hypot(dx.toDouble(), dy.toDouble()).toFloat()
                }
                val push = (minGapM - d) * 0.5f
                // back out of metres into the units the positions are kept in
                val ux = dx / d * push / 1.05f
                val uy = dy / d * push / 0.68f
                // the man on the ball holds his ground; everyone else gives way
                val aFixed = a.key == ball.holder
                val bFixed = b.key == ball.holder
                if (aFixed && !bFixed) {
                    b.x += ux * 2f; b.y += uy * 2f
                } else if (bFixed && !aFixed) {
                    a.x -= ux * 2f; a.y -= uy * 2f
                } else if (!aFixed && !bFixed) {
                    a.x -= ux; a.y -= uy
                    b.x += ux; b.y += uy
                }
            }
        }
        for (p in on) {
            p.x = p.x.coerceIn(0.5f, 99.5f)
            p.y = p.y.coerceIn(0.5f, 99.5f)
        }
    }

    private fun captureFrame() {
        if (!replaysEnabled) return
        val live = players.filter { it.onPitch }
        val xs = FloatArray(live.size)
        val ys = FloatArray(live.size)
        for (i in live.indices) { xs[i] = live[i].x; ys[i] = live[i].y }
        history.add(Frame(ball.x, ball.y, xs, ys))
        while (history.size > 160) history.removeAt(0)
    }

    /* ------------------------------------------------------- OPPOSITION AI */

    private var aiThinkTimer = 0.0
    private var aiLastNote = ""

    /**
     * The opposing manager. He reads the scoreline, the clock and — crucially —
     * what you are doing, then changes his own shape to answer it. Beat him
     * tactically and he will try something else.
     */
    private fun aiManagerThink(minutes: Double) {
        aiThinkTimer += minutes
        if (aiThinkTimer < 9.0) return
        aiThinkTimer = 0.0

        for (side in 0..1) {
            val club = if (side == 0) home else away
            if (club.isUser) continue
            val userClub = if (side == 0) away else home
            if (!userClub.isUser) continue          // AI vs AI needs no theatre

            val t = club.tactics
            val u = userClub.tactics
            val mine = score[side]
            val theirs = score[1 - side]
            val late = clock > 65
            val veryLate = clock > 78
            var note = ""

            // 1. the scoreline
            if (mine < theirs && late) {
                if (t.mentality < 4) { t.mentality++; note = "throwing men forward" }
                if (t.press < 2 && veryLate) t.press = 2
                if (t.line < 2 && veryLate) t.line = 2
            } else if (mine > theirs && veryLate) {
                if (t.mentality > 0) { t.mentality--; note = "shutting up shop" }
                if (t.line > 0) t.line--
            }

            // 2. answering your shape
            if (note.isEmpty()) {
                when {
                    // you press high — they go long to bypass it
                    u.press == 2 && t.passing != 2 -> {
                        t.passing = 2; note = "going more direct to beat the press"
                    }
                    // you sit deep and counter — they keep the ball and squeeze up
                    u.line == 0 && t.passing != 0 -> {
                        t.passing = 0; t.line = 2; note = "taking control of the ball"
                    }
                    // you stretch the pitch — they tuck in
                    u.width == 2 && t.width != 0 -> {
                        t.width = 0; note = "narrowing up to protect the middle"
                    }
                    // you play narrow — they attack the flanks
                    u.width == 0 && t.width != 2 -> {
                        t.width = 2; note = "stretching the play wide"
                    }
                    // you are dominating the ball — they get tighter
                    possessionHome.let { ph -> (if (side == 0) ph else 100 - ph) < 40 } && t.press < 2 -> {
                        t.press++; note = "pressing higher up"
                    }
                    // you are carving them open — they drop off
                    xg[1 - side] > xg[side] + 1.0 && t.line > 0 -> {
                        t.line--; t.tackling = 2; note = "dropping deeper and getting tighter"
                    }
                }
            }

            // 3. a shape change when nothing else has worked
            if (note.isEmpty() && late && mine < theirs && rng.chance(0.45)) {
                val chasing = arrayOf("4-2-4", "3-4-3", "4-2-3-1", "4-3-3")
                val pick = rng.pick(chasing)
                if (pick != t.formation) {
                    t.formation = pick
                    world.autoPickSquad(club)
                    rebuildShape(side, club)
                    note = "switching to $pick"
                }
            }

            if (note.isNotEmpty() && note != aiLastNote) {
                aiLastNote = note
                sayRaw(FeedLine.PLAIN, "${club.name} are $note.")
                refreshRatings()
            }
        }
    }

    /** Re-seats a side after a change of shape, from either bench. */
    fun reshape(side: Int) {
        rebuildShape(side, if (side == 0) home else away)
    }

    /** Re-seats a side after its manager changes formation mid-match. */
    private fun rebuildShape(side: Int, club: Club) {
        val shape = Formations.byName(club.tactics.formation)
        val live = onPitch(side)
        for (i in live.indices) {
            val slot = shape.slots.getOrNull(i) ?: continue
            live[i].baseX = slot.x.toFloat()
            live[i].baseY = slot.y.toFloat()
        }
    }

    private fun aiSubstitutions(minutes: Double) {
        for (side in 0..1) {
            val club = if (side == 0) home else away
            if (club.isUser) continue
            if (subsLeft[side] <= 0 || clock < 55) continue
            if (!rng.chance(minutes * 0.055)) continue
            val tired = onPitch(side).filter { it.pos != Pos.GK }.minByOrNull { it.fitness } ?: continue
            val bench = (if (side == 0) benchHome else benchAway).filter { canUse(side, it) }
            if (bench.isEmpty()) continue
            val replacement = bench.firstOrNull { Pos.group(it.pos) == Pos.group(tired.pos) } ?: bench[0]
            substitute(side, tired.key, replacement.id)
        }
    }

    private val usedSubs = HashSet<Int>()
    private fun canUse(side: Int, p: Player) = !usedSubs.contains(p.id)

    fun substitute(side: Int, outKey: String, inPlayerId: Int): Boolean {
        if (subsLeft[side] <= 0) return false
        val out = players.firstOrNull { it.key == outKey && it.onPitch } ?: return false
        val bench = if (side == 0) benchHome else benchAway
        val inP = bench.firstOrNull { it.id == inPlayerId } ?: return false
        if (usedSubs.contains(inP.id)) return false

        out.onPitch = false
        usedSubs.add(inP.id)
        val lp = LivePlayer("${side}_s${subsMade[side]}", side, out.slot, out.pos, inP)
        lp.baseX = out.baseX; lp.baseY = out.baseY
        lp.x = out.x; lp.y = out.y; lp.targetX = out.targetX; lp.targetY = out.targetY
        lp.shirt = 12 + subsMade[side]
        lp.effective = inP.effective(out.pos)
        lp.fitness = inP.fitness
        players.add(lp)
        subsLeft[side]--
        subsMade[side]++
        scene = Scene.SUBSTITUTION; sceneTime = 1.8f
        banner = "${inP.last} on for ${out.name}"
        bannerTime = 1.6f
        sayRaw(FeedLine.SUB, "Substitution for ${teamName(side)}: ${inP.full} replaces ${out.fullName}.")
        events.add(MatchEvent(clock.toInt(), Ev.SUB, side, inP.full, out.fullName))
        return true
    }

    /** Fast-forward with no rendering. */
    fun skipToEnd() {
        pause()
        if (!kicked) { kicked = true; newPhase() }
        if (phaseSeq.isEmpty() && pendingSide < 0 && pendingShot == null) newPhase()
        val realSpeed = speed
        speed = 40f
        var guard = 0
        while (!finished && guard++ < 60_000) {
            update(0.05f)
            if (!running && !finished) running = true
        }
        if (!finished) endMatch()
        speed = realSpeed
    }

    var manOfTheMatch: LivePlayer? = null

    private fun endMatch() {
        cue(Synth.Sfx.WHISTLE_LONG, 1f)
        cue(Synth.Sfx.APPLAUSE, 0.9f)
        crowdTarget = 0.5f
        finished = true
        running = false
        clock = 90.0
        sayRaw(FeedLine.WHISTLE, "Full time. ${home.name} ${score[0]} - ${score[1]} ${away.name}.")
        banner = "FULL TIME"; bannerTime = 3f

        for (p in players) {
            var r = 6.3 + (p.effective - 62.0) / 40.0
            r += p.goals * 1.0 + p.assists * 0.5 + p.tackles * 0.06 +
                    p.saves * 0.14 + p.passes * 0.012
            r -= p.yellow * 0.25 + (if (p.sentOff) 1.2 else 0.0)
            r += (rng.f() - 0.5) * 0.5
            p.rating = r.coerceIn(3.5, 10.0)
        }
        manOfTheMatch = players.filter { it.minutes > 1 }.maxByOrNull { it.rating }
        manOfTheMatch?.let {
            sayRaw(FeedLine.GOAL, "Man of the Match: ${it.fullName} (${teamName(it.side)}) \u2014 ${Fmt.one(it.rating)}")
        }
    }

    val possessionHome: Int
        get() {
            val total = possession[0] + possession[1]
            return if (total <= 0) 50 else (possession[0] / total * 100).roundToInt()
        }

    /** Writes the match back into the season: stats, injuries, cards, the result. */
    fun commit() {
        for (p in players) {
            val ref = p.ref
            val mins = min(90.0, p.minutes).roundToInt()
            if (mins < 1) continue
            ref.apps++; ref.cApps++; ref.minutes += mins
            ref.goals += p.goals; ref.cGoals += p.goals
            ref.assists += p.assists; ref.cAssists += p.assists
            ref.ratingSum += p.rating; ref.ratingN++
            ref.form = ref.form * 0.7 + p.rating * 0.3
            ref.fitness = max(15.0, p.fitness)
            ref.sharpness = min(100.0, ref.sharpness + 7)
            if (p.yellow > 0) {
                ref.yellowSeason += p.yellow
                if (ref.yellowSeason % 5 == 0) ref.suspended = 1
            }
            if (p.sentOff) { ref.redSeason++; ref.suspended = 2 }
            if (p.injured) {
                ref.injuryWeeks = p.injuryWeeks
                ref.injuryType = season.injuryName(p.injuryWeeks, rng)
            }
            if (manOfTheMatch?.key == p.key) ref.motm++
        }
        onPitch(0).firstOrNull { it.pos == Pos.GK }?.let { if (score[1] == 0) it.ref.cleanSheets++ }
        onPitch(1).firstOrNull { it.pos == Pos.GK }?.let { if (score[0] == 0) it.ref.cleanSheets++ }
        fixture.attendance = attendance
        season.applyResult(fixture, score[0], score[1])
    }
}
