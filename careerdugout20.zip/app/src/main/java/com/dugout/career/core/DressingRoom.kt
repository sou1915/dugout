package com.dugout.career.core

import kotlin.math.roundToInt

/**
 * The dressing room has a pecking order.
 *
 * A squad is not twenty-five equal voices. A few men set the tone, and if one
 * of those is unhappy it spreads; if the same man is flying, it spreads too.
 * This is what makes selling a senior professional cost more than his rating,
 * and what makes the captaincy a decision rather than an armband.
 */

object Standing {
    const val TALISMAN = 0
    const val INFLUENTIAL = 1
    const val RESPECTED = 2
    const val SQUAD = 3
    const val PROSPECT = 4

    val LABEL = arrayOf("Talisman", "Influential", "Respected", "Squad member", "Prospect")

    val NOTE = arrayOf(
        "The dressing room follows him. Keep him onside.",
        "One of the senior voices in the group.",
        "Listened to, without setting the tone.",
        "Gets on with his work.",
        "Still finding his feet among them."
    )
}

object DressingRoom {

    /**
     * How much weight a player carries with the rest, 0 to 100.
     *
     * Ability matters, but so does seniority and whether the group actually
     * likes him. A quiet 30 year old with three hundred appearances outranks a
     * better player who arrived in the summer.
     */
    fun influence(p: Player, squadAverage: Int, captainId: Int): Int {
        var v = 31.0

        // standing relative to the players around him
        v += (p.overall() - squadAverage) * 1.35

        // years in the game, tailing off once he is past it
        v += when {
            p.age >= 33 -> 14.0
            p.age >= 29 -> 18.0
            p.age >= 25 -> 10.0
            p.age >= 22 -> 3.0
            else -> -6.0
        }

        // appearances for this club count for more than a career total
        v += (p.cApps / 26.0).coerceAtMost(14.0)

        if (p.hasTrait(Traits.LEADER)) v += 21
        if (p.hasTrait(Traits.LOYAL)) v += 5
        if (p.hasTrait(Traits.HOTHEAD)) v -= 4

        v += when (p.personality) {
            "Model Citizen" -> 9.0
            "Professional", "Resolute" -> 6.0
            "Determined" -> 4.0
            "Temperamental" -> -5.0
            "Casual" -> -7.0
            "Fickle" -> -6.0
            else -> 0.0
        }

        // squad status is the manager's own signal to the group
        v += when (p.squadStatus) {
            0 -> 10.0
            1 -> 5.0
            3 -> -5.0
            4 -> -9.0
            else -> 0.0
        }

        if (p.id == captainId) v += 16

        return v.roundToInt().coerceIn(1, 100)
    }

    fun standingOf(influence: Int): Int = when {
        influence >= 76 -> Standing.TALISMAN
        influence >= 62 -> Standing.INFLUENTIAL
        influence >= 46 -> Standing.RESPECTED
        influence >= 30 -> Standing.SQUAD
        else -> Standing.PROSPECT
    }

    /**
     * The mood of the room, weighted by who actually carries weight. A sulking
     * talisman drags this down far further than a reserve does.
     */
    fun roomMood(squad: List<Player>, squadAverage: Int, captainId: Int): Double {
        if (squad.isEmpty()) return 70.0
        // Weighted well above linear on purpose. A dressing room is not a
        // poll: three senior men set the tone and the rest take their lead,
        // so a talisman in a sulk has to count for far more than a reserve.
        var num = 0.0
        var den = 0.0
        for (p in squad) {
            val w = Math.pow(influence(p, squadAverage, captainId).toDouble(), 2.4) / 1000.0
            num += p.morale * w
            den += w
        }
        return if (den <= 0) 70.0 else num / den
    }

    /**
     * A week in the dressing room. Everyone drifts a little toward the mood of
     * the senior men, so one unhappy leader is a problem that spreads rather
     * than one man in a huff.
     *
     * Returns the mood the room settled at.
     */
    fun settle(squad: List<Player>, squadAverage: Int, captainId: Int,
               praise: Double, criticism: Double): Double {
        val mood = roomMood(squad, squadAverage, captainId)
        for (p in squad) {
            val inf = influence(p, squadAverage, captainId)
            // the men who set the tone are barely moved by it; everyone else is
            val pull = (1.0 - inf / 130.0).coerceIn(0.15, 0.9) * 0.26
            val delta = (mood - p.morale) * pull
            p.shiftMorale(delta, praise, criticism)
        }
        return mood
    }

    /** The obvious armband, if the manager has not picked one. */
    fun suggestedCaptain(squad: List<Player>, squadAverage: Int): Player? =
        squad.maxByOrNull { influence(it, squadAverage, -1) }

    /**
     * What losing him would do to the group, in morale points off the room.
     * Selling a talisman is not the same as selling his rating.
     */
    fun departureCost(p: Player, squadAverage: Int, captainId: Int): Double {
        val inf = influence(p, squadAverage, captainId)
        return ((inf - 40) / 8.0).coerceIn(0.0, 9.0)
    }
}
