package com.dugout.career.sim

/**
 * ENGINE V4, IDEA 6: ONE TABLE THAT OWNS EVERYTHING THE MATCH SHOWS.
 *
 * The owner's idea, and it is the right one. His words: make a tree for every
 * event that happens in a normal football match, like a trigger -- if this event
 * happens, this scene happens.
 *
 * The argument for it is already written in AUDIT.md, three times over. Three
 * separate defects found in this audit are the same defect:
 *
 *   v2Defend           written, correct, never called -- 56 tackles, zero fouls
 *   CHANCE_QUALITY     swept by BalanceBig for months while dead under v2
 *   skills, TAKE_ON    correct, and only reachable from v1 -- 0.00 a match
 *
 * Every one is presentation wired straight into one engine's decision path,
 * which then stopped being the engine that runs. Nothing anywhere declared "a
 * foul must produce a free kick, a whistle and a man on the floor", so when the
 * caller moved, the scene died IN SILENCE and nobody found out for months.
 *
 * So the engine's job becomes: say WHAT HAPPENED. This table decides what is
 * shown. Once `fire` exists, nothing outside this file may set `scene`,
 * `sceneTime`, call `act` or `cue`, or move `crowdTarget`.
 *
 * MOST OF THESE DO NOT HAPPEN YET, AND THAT IS THE POINT. This is not a
 * description of what the match currently does; it is a list of what a football
 * match CONTAINS. `EventCensus` walks it and prints how many seconds a match
 * each row is on screen for, which turns "there is nothing happening in the
 * simulation" from an argument into a column with about fifty zeroes in it --
 * each one a named, addressable job, and none of them costing a byte of assets.
 *
 * Nothing imports this yet. It is step one of five, and the other four are in
 * docs/ENGINE_V4.md section 6.
 */

/** What the referee visibly does. */
object Ref {
    const val NONE = 0
    const val WHISTLE = 1
    const val CARD = 2
    const val SPRAY = 3
    const val ADVANTAGE = 4
    const val FLAG = 5
    val LABEL = arrayOf("", "whistle", "card", "spray", "advantage", "flag")
}

/**
 * One row: what is shown when this happens.
 *
 * @param scene     the caption machinery's scene, or Scene.NONE
 * @param pose      the actor's Act, or -1 for none
 * @param onFoe     true when the pose belongs to the man it was done TO
 * @param caption   what is written; empty means the scene's own label
 * @param ref       what the referee does
 * @param crowd     crowd level to move to, or -1 to leave it alone
 * @param nudge     added to the crowd rather than replacing it
 * @param dead      true when play stops for it
 * @param seconds   how long the scene is held, 0 to use the scene's own timing
 */
class Shown(
    @JvmField val scene: Int = Scene.NONE,
    @JvmField val pose: Int = -1,
    @JvmField val onFoe: Boolean = false,
    @JvmField val caption: String = "",
    @JvmField val ref: Int = Ref.NONE,
    @JvmField val crowd: Float = -1f,
    @JvmField val nudge: Float = 0f,
    @JvmField val dead: Boolean = false,
    @JvmField val seconds: Float = 0f
)

/**
 * Seventy one events, in the nine groups a football match falls into.
 *
 * The order is deliberate and is the order they should be built in within each
 * group: the ones that already happen first, so routing them through `fire`
 * can be proved byte-identical on `ResultFingerprint` before anything new is
 * added.
 */
object Ev4 {
    /* --------------------------------------------------------- ON THE BALL */
    const val FIRST_TOUCH = 0
    const val TOUCH_HEAVY = 1
    const val SHIELD_BALL = 2
    const val TURN_AWAY = 3
    const val DRIVE_FORWARD = 4
    const val TAKE_ON_ATTEMPT = 5
    const val TAKE_ON_WON = 6
    const val TAKE_ON_LOST = 7
    const val SKILL_MOVE = 8
    const val NUTMEG = 9
    const val BACKHEEL = 10
    const val FLICK_ON = 11
    const val DISPOSSESSED = 12

    /* ------------------------------------------------------------ PASSING */
    const val PASS_SHORT = 13
    const val PASS_LONG = 14
    const val PASS_SWITCH = 15
    const val THROUGH_BALL = 16
    const val ONE_TWO = 17
    const val CROSS = 18
    const val CUT_BACK = 19
    const val PASS_MISPLACED = 20
    const val PASS_INTERCEPTED = 21

    /* ----------------------------------------------------------- SHOOTING */
    const val SHOT_STRUCK = 22
    const val SHOT_HEADER = 23
    const val SHOT_VOLLEY = 24
    const val SHOT_LONG_RANGE = 25
    const val SHOT_CHIP = 26
    const val SHOT_FREE_KICK = 27
    const val SHOT_BLOCKED = 28
    const val SHOT_DEFLECTED = 29
    const val SHOT_WIDE = 30
    const val WOODWORK = 31
    const val REBOUND = 32
    const val GOAL = 33
    const val GOAL_DISALLOWED = 34
    const val OWN_GOAL = 35

    /* -------------------------------------------------------- GOALKEEPING */
    const val SAVE_ROUTINE = 36
    const val SAVE_DIVING = 37
    const val SAVE_TIP_OVER = 38
    const val SAVE_PARRY = 39
    const val SAVE_PENALTY = 40
    const val KEEPER_CLAIM_CROSS = 41
    const val KEEPER_PUNCH = 42
    const val KEEPER_SWEEP = 43
    const val KEEPER_DISTRIBUTION = 44
    const val KEEPER_UP_FOR_CORNER = 45

    /* ---------------------------------------------------------- DEFENDING */
    const val TACKLE_WON = 46
    const val TACKLE_SLIDING = 47
    const val TACKLE_LAST_DITCH = 48
    const val INTERCEPTION = 49
    const val BLOCK = 50
    const val CLEARANCE = 51
    const val CLEARANCE_HEADED = 52
    const val RECOVERY_RUN = 53
    const val OFFSIDE_TRAP_SPRUNG = 54
    const val GOAL_LINE_CLEARANCE = 55

    /* ----------------------------------------------- FOULS AND DISCIPLINE */
    const val FOUL = 56
    const val FOUL_ADVANTAGE = 57
    const val FOUL_IN_BOX = 58
    const val HANDBALL = 59
    const val CARD_YELLOW = 60
    const val CARD_SECOND_YELLOW = 61
    const val CARD_RED = 62
    const val PROFESSIONAL_FOUL = 63
    const val DISSENT = 64
    const val MELEE = 65
    const val OFFSIDE = 66

    /* -------------------------------------------------------- SET PIECES */
    const val THROW_IN = 67
    const val THROW_LONG = 68
    const val GOAL_KICK = 69
    const val CORNER_WON = 70
    const val FREE_KICK_DIRECT = 71
    const val FREE_KICK_INDIRECT = 72
    const val PENALTY_AWARDED = 73
    const val PENALTY_SCORED = 74
    const val PENALTY_MISSED = 75
    const val KICK_OFF = 76
    const val DROP_BALL = 77

    /* ------------------------------------------ PHYSICAL AND MANAGEMENT */
    const val INJURY_KNOCK = 78
    const val INJURY_SERIOUS = 79
    const val CRAMP = 80
    const val SUBSTITUTION = 81
    const val SUBSTITUTION_FORCED = 82
    const val FORMATION_CHANGE = 83
    const val SHOUT = 84
    const val TIME_WASTING = 85

    /* --------------------------------------------------- THE MATCH ITSELF */
    const val HALF_TIME = 86
    const val SECOND_HALF = 87
    const val ADDED_TIME = 88
    const val FULL_TIME = 89

    const val COUNT = 90

    /** The name of each event, for the census and for the feed. */
    @JvmField val NAME = arrayOf(
        "first touch", "heavy touch", "shielding it", "turning away",
        "driving forward", "take-on attempted", "take-on won", "take-on lost",
        "a piece of skill", "nutmeg", "backheel", "flick-on", "dispossessed",
        "short pass", "long pass", "switch of play", "through ball", "one-two",
        "cross", "cut-back", "misplaced pass", "pass intercepted",
        "shot struck", "header at goal", "volley", "shot from distance",
        "chipped shot", "free kick at goal", "shot blocked", "shot deflected",
        "shot wide", "off the woodwork", "rebound", "goal", "goal disallowed",
        "own goal",
        "routine save", "diving save", "tipped over", "parried",
        "penalty saved", "keeper claims a cross", "keeper punches clear",
        "keeper sweeps up", "keeper distribution", "keeper up for a corner",
        "tackle won", "sliding tackle", "last-ditch tackle", "interception",
        "block", "clearance", "headed clearance", "recovery run",
        "offside trap sprung", "cleared off the line",
        "foul", "advantage played", "foul in the box", "handball",
        "yellow card", "second yellow", "red card", "professional foul",
        "dissent", "melee", "offside",
        "throw-in", "long throw", "goal kick", "corner won",
        "direct free kick", "indirect free kick", "penalty awarded",
        "penalty scored", "penalty missed", "kick-off", "drop ball",
        "knock", "serious injury", "cramp", "substitution", "forced change",
        "formation change", "shout from the touchline", "time wasting",
        "half time", "second half", "added time", "full time"
    )

    /**
     * What each event puts on screen.
     *
     * A row with everything at its default shows nothing, which is correct for
     * the events that are simply football happening -- a short pass does not
     * deserve a caption. The census still counts them, which is how "the ball
     * is never passed" would be answered.
     */
    @JvmField val SHOWN = arrayOf(
        /* ON THE BALL */
        Shown(),                                                                            // FIRST_TOUCH
        Shown(),                                                                            // TOUCH_HEAVY
        Shown(pose = Act.DRIBBLE),                                                          // SHIELD_BALL
        Shown(pose = Act.DRIBBLE),                                                          // TURN_AWAY
        Shown(nudge = 0.05f),                                                               // DRIVE_FORWARD
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "TAKE-ON", crowd = 0.55f),              // TAKE_ON_ATTEMPT
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "TAKE-ON", crowd = 0.65f),              // TAKE_ON_WON
        Shown(),                                                                            // TAKE_ON_LOST
        Shown(Scene.TAKE_ON, Act.DRIBBLE, crowd = 0.80f, seconds = 1.1f),                   // SKILL_MOVE
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "NUTMEG", crowd = 0.85f),               // NUTMEG
        Shown(pose = Act.DRIBBLE, crowd = 0.60f),                                           // BACKHEEL
        Shown(pose = Act.HEADER),                                                           // FLICK_ON
        Shown(),                                                                            // DISPOSSESSED

        /* PASSING */
        Shown(),                                                                            // PASS_SHORT
        Shown(),                                                                            // PASS_LONG
        Shown(caption = "SWITCH", nudge = 0.05f),                                           // PASS_SWITCH
        Shown(caption = "THROUGH BALL", crowd = 0.70f),                                     // THROUGH_BALL
        Shown(caption = "ONE-TWO", crowd = 0.60f),                                          // ONE_TWO
        Shown(caption = "CROSS", crowd = 0.65f),                                            // CROSS
        Shown(caption = "CUT-BACK", crowd = 0.70f),                                         // CUT_BACK
        Shown(),                                                                            // PASS_MISPLACED
        Shown(Scene.TACKLE, caption = "INTERCEPTION", crowd = 0.40f),                       // PASS_INTERCEPTED

        /* SHOOTING */
        Shown(Scene.SHOT, Act.SHOOT, caption = "SHOT", crowd = 0.80f),                      // SHOT_STRUCK
        Shown(Scene.SHOT, Act.HEADER, caption = "HEADER", crowd = 0.80f),                   // SHOT_HEADER
        Shown(Scene.SHOT, Act.SHOOT, caption = "VOLLEY", crowd = 0.88f),                    // SHOT_VOLLEY
        Shown(Scene.SHOT, Act.SHOOT, caption = "FROM DISTANCE", crowd = 0.82f),             // SHOT_LONG_RANGE
        Shown(Scene.SHOT, Act.SHOOT, caption = "CHIPPED", crowd = 0.85f),                   // SHOT_CHIP
        Shown(Scene.SHOT, Act.SHOOT, caption = "FREE KICK", crowd = 0.85f),                 // SHOT_FREE_KICK
        Shown(pose = Act.TACKLE, onFoe = true, caption = "BLOCKED", crowd = 0.55f),         // SHOT_BLOCKED
        Shown(caption = "DEFLECTED", crowd = 0.70f),                                        // SHOT_DEFLECTED
        Shown(crowd = 0.35f),                                                               // SHOT_WIDE
        Shown(Scene.SHOT, caption = "OFF THE POST", crowd = 0.95f),                         // WOODWORK
        Shown(Scene.SHOT, caption = "REBOUND", crowd = 0.90f),                              // REBOUND
        Shown(pose = Act.CELEBRATE, caption = "GOAL!", crowd = 1.00f, dead = true),         // GOAL
        Shown(caption = "NO GOAL", ref = Ref.WHISTLE, crowd = 0.20f, dead = true),          // GOAL_DISALLOWED
        Shown(pose = Act.DOWN, caption = "OWN GOAL", crowd = 0.55f, dead = true),           // OWN_GOAL

        /* GOALKEEPING */
        Shown(Scene.SAVE, caption = "SAVE", crowd = 0.50f),                                 // SAVE_ROUTINE
        Shown(Scene.SAVE, Act.DIVE, caption = "SAVE", crowd = 0.75f),                       // SAVE_DIVING
        Shown(Scene.SAVE, Act.DIVE, caption = "TIPPED OVER", crowd = 0.85f),                // SAVE_TIP_OVER
        Shown(Scene.SAVE, Act.DIVE, caption = "PARRIED", crowd = 0.75f),                    // SAVE_PARRY
        Shown(Scene.SAVE, Act.DIVE, caption = "SAVED IT!", crowd = 1.00f),                  // SAVE_PENALTY
        Shown(crowd = 0.30f),                                                               // KEEPER_CLAIM_CROSS
        Shown(pose = Act.DIVE, crowd = 0.45f),                                              // KEEPER_PUNCH
        Shown(caption = "OFF HIS LINE", crowd = 0.60f),                                     // KEEPER_SWEEP
        Shown(),                                                                            // KEEPER_DISTRIBUTION
        Shown(Scene.CORNER, caption = "KEEPER IS UP", crowd = 0.95f, dead = true),          // KEEPER_UP_FOR_CORNER

        /* DEFENDING */
        Shown(Scene.TACKLE, Act.TACKLE, caption = "TACKLE", crowd = 0.50f),                 // TACKLE_WON
        Shown(Scene.TACKLE, Act.TACKLE, caption = "SLIDING IN", crowd = 0.65f),             // TACKLE_SLIDING
        Shown(Scene.TACKLE, Act.TACKLE, caption = "LAST-DITCH", crowd = 0.90f),             // TACKLE_LAST_DITCH
        Shown(Scene.TACKLE, caption = "INTERCEPTION", crowd = 0.35f),                       // INTERCEPTION
        Shown(pose = Act.TACKLE, caption = "BLOCKED", crowd = 0.60f),                       // BLOCK
        Shown(),                                                                            // CLEARANCE
        Shown(pose = Act.HEADER),                                                           // CLEARANCE_HEADED
        Shown(),                                                                            // RECOVERY_RUN
        Shown(Scene.FREEKICK, caption = "OFFSIDE", ref = Ref.FLAG, crowd = 0.30f, dead = true),  // OFFSIDE_TRAP_SPRUNG
        Shown(pose = Act.TACKLE, caption = "OFF THE LINE!", crowd = 0.95f),                 // GOAL_LINE_CLEARANCE

        /* FOULS AND DISCIPLINE */
        Shown(Scene.FREEKICK, Act.DOWN, onFoe = true, caption = "FREE KICK",
            ref = Ref.WHISTLE, crowd = 0.40f, dead = true),                                 // FOUL
        Shown(caption = "ADVANTAGE", ref = Ref.ADVANTAGE, crowd = 0.45f),                   // FOUL_ADVANTAGE
        Shown(Scene.PENALTY, Act.DOWN, onFoe = true, caption = "PENALTY",
            ref = Ref.WHISTLE, crowd = 1.00f, dead = true),                                 // FOUL_IN_BOX
        Shown(Scene.FREEKICK, caption = "HANDBALL", ref = Ref.WHISTLE,
            crowd = 0.50f, dead = true),                                                    // HANDBALL
        Shown(Scene.CARD, caption = "BOOKED", ref = Ref.CARD, crowd = 0.65f, dead = true),  // CARD_YELLOW
        Shown(Scene.CARD, caption = "SENT OFF", ref = Ref.CARD, crowd = 0.90f, dead = true),// CARD_SECOND_YELLOW
        Shown(Scene.CARD, caption = "RED CARD", ref = Ref.CARD, crowd = 0.95f, dead = true),// CARD_RED
        Shown(Scene.CARD, Act.TACKLE, caption = "CYNICAL", ref = Ref.CARD,
            crowd = 0.80f, dead = true),                                                    // PROFESSIONAL_FOUL
        Shown(Scene.CARD, caption = "DISSENT", ref = Ref.CARD, crowd = 0.55f, dead = true), // DISSENT
        Shown(caption = "TEMPERS FRAYING", ref = Ref.WHISTLE, crowd = 0.75f, dead = true),  // MELEE
        Shown(Scene.FREEKICK, caption = "OFFSIDE", ref = Ref.FLAG, crowd = 0.30f, dead = true),  // OFFSIDE

        /* SET PIECES AND RESTARTS */
        Shown(Scene.THROW_IN, caption = "THROW-IN", dead = true),                           // THROW_IN
        Shown(Scene.THROW_IN, caption = "LONG THROW", crowd = 0.55f, dead = true),          // THROW_LONG
        Shown(Scene.GOAL_KICK, caption = "GOAL KICK", dead = true),                         // GOAL_KICK
        Shown(Scene.CORNER, caption = "CORNER", crowd = 0.55f, dead = true),                // CORNER_WON
        Shown(Scene.FREEKICK, caption = "FREE KICK", ref = Ref.SPRAY,
            crowd = 0.70f, dead = true),                                                    // FREE_KICK_DIRECT
        Shown(Scene.FREEKICK, caption = "FREE KICK", ref = Ref.WHISTLE,
            crowd = 0.45f, dead = true),                                                    // FREE_KICK_INDIRECT
        Shown(Scene.PENALTY, caption = "PENALTY", ref = Ref.WHISTLE,
            crowd = 1.00f, dead = true),                                                    // PENALTY_AWARDED
        Shown(pose = Act.CELEBRATE, caption = "GOAL!", crowd = 1.00f, dead = true),         // PENALTY_SCORED
        Shown(pose = Act.DOWN, caption = "MISSED", crowd = 0.30f, dead = true),             // PENALTY_MISSED
        Shown(Scene.KICK_OFF, caption = "KICK OFF", ref = Ref.WHISTLE,
            crowd = 0.30f, dead = true),                                                    // KICK_OFF
        Shown(caption = "DROP BALL", ref = Ref.WHISTLE, crowd = 0.20f, dead = true),        // DROP_BALL

        /* PHYSICAL AND MANAGEMENT */
        Shown(pose = Act.DOWN, crowd = 0.20f),                                              // INJURY_KNOCK
        Shown(pose = Act.DOWN, caption = "INJURY", ref = Ref.WHISTLE,
            crowd = 0.25f, dead = true),                                                    // INJURY_SERIOUS
        Shown(pose = Act.DOWN, crowd = 0.15f),                                              // CRAMP
        Shown(Scene.SUBSTITUTION, caption = "SUBSTITUTION", crowd = 0.35f, dead = true),    // SUBSTITUTION
        Shown(Scene.SUBSTITUTION, caption = "FORCED CHANGE", crowd = 0.30f, dead = true),   // SUBSTITUTION_FORCED
        Shown(crowd = 0.25f),                                                               // FORMATION_CHANGE
        Shown(nudge = 0.10f),                                                               // SHOUT
        Shown(crowd = 0.25f),                                                               // TIME_WASTING

        /* THE MATCH ITSELF */
        Shown(caption = "HALF TIME", ref = Ref.WHISTLE, crowd = 0.35f, dead = true),        // HALF_TIME
        Shown(Scene.KICK_OFF, caption = "KICK OFF", ref = Ref.WHISTLE,
            crowd = 0.40f, dead = true),                                                    // SECOND_HALF
        Shown(caption = "ADDED TIME", crowd = 0.45f),                                       // ADDED_TIME
        Shown(caption = "FULL TIME", ref = Ref.WHISTLE, crowd = 0.60f, dead = true)         // FULL_TIME
    )

    /**
     * The table has to be complete, and there is no compiler check that it is.
     *
     * Called once from a test rather than from the match, because a mismatch
     * here is the kind of thing that would otherwise be found by an index off
     * the end of an array during a game -- which is exactly how L_DRIBBLE sat
     * in this project for months waiting to crash a match.
     */
    fun selfCheck(): String {
        if (NAME.size != COUNT) return "NAME has ${NAME.size}, expected $COUNT"
        if (SHOWN.size != COUNT) return "SHOWN has ${SHOWN.size}, expected $COUNT"
        if (Ev4Say.SAY.size != COUNT) return "SAY is the wrong size"
        return "ok"
    }
}

/**
 * The commentator's lines, in their own object.
 *
 * Kept out of Ev4 because a single object initialiser carrying the names, the
 * ninety Shown rows AND sixty banks of commentary made kotlinc emit a <clinit>
 * that fails verification at run time -- VerifyError: Bad local variable type,
 * with the compiler perfectly happy. Splitting it in two is the fix, and the
 * failure mode is worth the comment: it compiles and then kills the game.
 */
object Ev4Say {
    /**
     * WHAT THE COMMENTATOR SAYS. One bank per event; empty means he says nothing.
     *
     * The owner's idea: everything the commentator says should be heard, so he
     * keeps talking. This is the other half of it -- the words. Android carries
     * TextToSpeech in the platform, so a voice costs no asset and no megabyte.
     *
     * `{a}` is the man it happened for, `{b}` the man it happened to, `{t}` his
     * club. A bank of several so the same match does not repeat itself.
     *
     * NOTE WHICH ROWS HAVE LINES. The events with no caption -- the short pass,
     * the first touch, the clearance -- are exactly the ones that SHOULD be
     * spoken and should not be written: a caption every two seconds for ninety
     * minutes is noise, but a voice filling those gaps is what a broadcast
     * sounds like. That is the whole reason the two channels are separate.
     */
    @JvmField val SAY = arrayOfNulls<Array<String>>(Ev4.COUNT)

    /**
     * How much each line matters, 0 to 1.
     *
     * A goal interrupts whatever is being said. A short pass never queues while
     * anything better is waiting. Without this the voice ends up half a minute
     * behind the football, which is worse than silence.
     */
    @JvmField val WEIGHT = FloatArray(Ev4.COUNT)

    /*
     * A member function, not a local one inside `init`.
     *
     * Written first as `init { fun say(...) ... }`, which compiles cleanly and
     * then throws VerifyError: Bad local variable type in Ev4.<clinit> the first
     * time the object is touched. A local function capturing arrays inside an
     * object initialiser is a kotlinc codegen fault, and the failure mode is the
     * worst kind -- the compiler is happy and the game dies at run time.
     */
    private fun say(ev: Int, w: Float, vararg lines: String) {
        SAY[ev] = arrayOf(*lines); WEIGHT[ev] = w
    }

    init {
        // the quiet ones: no caption, but he talks over them
        say(Ev4.PASS_SHORT, 0.05f, "{a} to {b}.", "{a} rolls it into {b}.",
            "Simple ball, {a} to {b}.", "{a} plays it first time.")
        say(Ev4.PASS_LONG, 0.12f, "{a} goes long.", "{a} clips it forward for {b}.",
            "A long ball from {a}.")
        say(Ev4.PASS_SWITCH, 0.25f, "{a} switches it to the other side.",
            "And {a} changes the point of attack.")
        say(Ev4.CLEARANCE, 0.08f, "Cleared.", "{a} hacks it away.", "Away it goes.")
        say(Ev4.CLEARANCE_HEADED, 0.10f, "{a} heads it clear.", "Headed away by {a}.")
        say(Ev4.FIRST_TOUCH, 0.03f, "{a} takes it down.", "Good touch, {a}.")
        say(Ev4.TOUCH_HEAVY, 0.08f, "Heavy touch from {a}.", "{a} lets that run away.")
        say(Ev4.SHIELD_BALL, 0.08f, "{a} shields it.", "{a} holds him off.")
        say(Ev4.DISPOSSESSED, 0.15f, "{a} loses it.", "Robbed, {a}.")
        say(Ev4.RECOVERY_RUN, 0.05f, "{a} is getting back.")
        say(Ev4.DRIVE_FORWARD, 0.10f, "{a} drives forward.", "{a} carries it.")

        // the loud ones
        say(Ev4.GOAL, 1.00f, "GOAL! {a}!", "It is in! {a} scores for {t}!",
            "{a}! And {t} have it!")
        say(Ev4.OWN_GOAL, 0.90f, "Oh, into his own net. {a}.")
        say(Ev4.CARD_RED, 0.95f, "And that is a red. {a} is off.",
            "Red card. {a} will take no further part.")
        say(Ev4.CARD_SECOND_YELLOW, 0.92f, "Second yellow, and {a} is off.")
        say(Ev4.CARD_YELLOW, 0.65f, "{a} goes into the book.", "Booked, {a}.")
        say(Ev4.FOUL_IN_BOX, 0.95f, "Penalty! {b} is brought down!")
        say(Ev4.PENALTY_AWARDED, 0.90f, "The referee points to the spot.")
        say(Ev4.PENALTY_SCORED, 1.00f, "Buried it. {a}.")
        say(Ev4.PENALTY_MISSED, 0.85f, "Missed! {a} cannot believe it.")
        say(Ev4.WOODWORK, 0.88f, "Off the woodwork! {a} was inches away.")
        say(Ev4.GOAL_LINE_CLEARANCE, 0.90f, "Off the line! {a} somehow.")
        say(Ev4.SAVE_PENALTY, 0.95f, "Saved! {a} has kept it out!")
        say(Ev4.SAVE_TIP_OVER, 0.75f, "{a} tips it over.")
        say(Ev4.SAVE_DIVING, 0.65f, "Good save, {a}.", "{a} throws himself at it.")
        say(Ev4.SAVE_PARRY, 0.60f, "{a} can only parry it.")
        say(Ev4.SAVE_ROUTINE, 0.35f, "Straight at {a}.", "Comfortable for {a}.")
        say(Ev4.SHOT_STRUCK, 0.55f, "{a} shoots.", "{a} has a go.")
        say(Ev4.SHOT_HEADER, 0.60f, "{a} rises for it.", "Header from {a}.")
        say(Ev4.SHOT_VOLLEY, 0.70f, "{a} on the volley!")
        say(Ev4.SHOT_LONG_RANGE, 0.62f, "{a} tries it from distance.")
        say(Ev4.SHOT_BLOCKED, 0.45f, "Blocked. {b} threw himself in front of it.")
        say(Ev4.SHOT_WIDE, 0.30f, "Wide. {a} will be disappointed with that.")
        say(Ev4.TAKE_ON_WON, 0.45f, "{a} goes past {b}.",
            "{a} drops the shoulder and he is away.")
        say(Ev4.SKILL_MOVE, 0.70f, "Oh, that is lovely from {a}.",
            "{a} with a piece of skill.")
        say(Ev4.NUTMEG, 0.80f, "Through his legs! {a} nutmegs {b}.")
        say(Ev4.TACKLE_SLIDING, 0.45f, "{a} slides in.", "Big tackle from {a}.")
        say(Ev4.TACKLE_LAST_DITCH, 0.80f, "Last ditch from {a}!")
        say(Ev4.INTERCEPTION, 0.20f, "{a} reads it.", "Cut out by {a}.")
        say(Ev4.FOUL, 0.40f, "Free kick. {a} caught {b}.", "That is a foul by {a}.")
        say(Ev4.FOUL_ADVANTAGE, 0.45f, "Advantage played.")
        say(Ev4.OFFSIDE, 0.35f, "Flag up. {a} was offside.", "Offside, {a}.")
        say(Ev4.THROUGH_BALL, 0.60f, "{a} threads it through for {b}!")
        say(Ev4.CROSS, 0.40f, "{a} swings it in.", "Cross from {a}.")
        say(Ev4.CUT_BACK, 0.55f, "{a} pulls it back.")
        say(Ev4.ONE_TWO, 0.50f, "One two, {a} and {b}.")
        say(Ev4.CORNER_WON, 0.35f, "Corner to {t}.")
        say(Ev4.THROW_IN, 0.10f, "Throw in.")
        say(Ev4.GOAL_KICK, 0.08f, "Goal kick.")
        say(Ev4.KICK_OFF, 0.30f, "And we are under way.")
        say(Ev4.SECOND_HALF, 0.40f, "Back under way for the second half.")
        say(Ev4.HALF_TIME, 0.50f, "That is half time.")
        say(Ev4.FULL_TIME, 0.70f, "Full time.")
        say(Ev4.ADDED_TIME, 0.45f, "There will be added time.")
        say(Ev4.SUBSTITUTION, 0.35f, "Change for {t}.")
        say(Ev4.SUBSTITUTION_FORCED, 0.45f, "A forced change for {t}.")
        say(Ev4.INJURY_SERIOUS, 0.40f, "{a} is down, and he is in trouble.")
        say(Ev4.INJURY_KNOCK, 0.15f, "{a} took a knock there.")
        say(Ev4.MELEE, 0.70f, "Tempers are fraying here.")
        say(Ev4.DISSENT, 0.50f, "{a} has too much to say.")
        say(Ev4.KEEPER_UP_FOR_CORNER, 0.85f, "The keeper is up!")
        say(Ev4.TIME_WASTING, 0.25f, "{t} are taking their time over everything.")
    }

}
