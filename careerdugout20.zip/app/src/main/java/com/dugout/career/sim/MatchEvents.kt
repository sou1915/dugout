package com.dugout.career.sim

/**
 * ENGINE V4, IDEA 6: ONE TABLE THAT OWNS EVERYTHING THE MATCH SHOWS.
 *
 * The owner's idea, and it is the right one. His words: make a tree for every
 * event that happens in a normal football match, like a trigger -- if this event
 * happens, this scene happens.
 *
 * The argument for it is already written in AUDIT.md, three times over. Three
 * separate defects found in this audit are the same defect:
 *
 *   v2Defend           written, correct, never called -- 56 tackles, zero fouls
 *   CHANCE_QUALITY     swept by BalanceBig for months while dead under v2
 *   skills, TAKE_ON    correct, and only reachable from v1 -- 0.00 a match
 *
 * Every one is presentation wired straight into one engine's decision path,
 * which then stopped being the engine that runs. Nothing anywhere declared "a
 * foul must produce a free kick, a whistle and a man on the floor", so when the
 * caller moved, the scene died IN SILENCE and nobody found out for months.
 *
 * So the engine's job becomes: say WHAT HAPPENED. This table decides what is
 * shown. Once `fire` exists, nothing outside this file may set `scene`,
 * `sceneTime`, call `act` or `cue`, or move `crowdTarget`.
 *
 * MOST OF THESE DO NOT HAPPEN YET, AND THAT IS THE POINT. This is not a
 * description of what the match currently does; it is a list of what a football
 * match CONTAINS. `EventCensus` walks it and prints how many seconds a match
 * each row is on screen for, which turns "there is nothing happening in the
 * simulation" from an argument into a column with about fifty zeroes in it --
 * each one a named, addressable job, and none of them costing a byte of assets.
 *
 * Nothing imports this yet. It is step one of five, and the other four are in
 * docs/ENGINE_V4.md section 6.
 */

/** What the referee visibly does. */
object Ref {
    const val NONE = 0
    const val WHISTLE = 1
    const val CARD = 2
    const val SPRAY = 3
    const val ADVANTAGE = 4
    const val FLAG = 5
    val LABEL = arrayOf("", "whistle", "card", "spray", "advantage", "flag")
}

/**
 * One row: what is shown when this happens.
 *
 * @param scene     the caption machinery's scene, or Scene.NONE
 * @param pose      the actor's Act, or -1 for none
 * @param onFoe     true when the pose belongs to the man it was done TO
 * @param caption   what is written; empty means the scene's own label
 * @param ref       what the referee does
 * @param crowd     crowd level to move to, or -1 to leave it alone
 * @param nudge     added to the crowd rather than replacing it
 * @param dead      true when play stops for it
 * @param seconds   how long the scene is held, 0 to use the scene's own timing
 */
class Shown(
    @JvmField val scene: Int = Scene.NONE,
    @JvmField val pose: Int = -1,
    @JvmField val onFoe: Boolean = false,
    @JvmField val caption: String = "",
    @JvmField val ref: Int = Ref.NONE,
    @JvmField val crowd: Float = -1f,
    @JvmField val nudge: Float = 0f,
    @JvmField val dead: Boolean = false,
    @JvmField val seconds: Float = 0f
)

/**
 * Seventy one events, in the nine groups a football match falls into.
 *
 * The order is deliberate and is the order they should be built in within each
 * group: the ones that already happen first, so routing them through `fire`
 * can be proved byte-identical on `ResultFingerprint` before anything new is
 * added.
 */
object Ev4 {
    /* --------------------------------------------------------- ON THE BALL */
    const val FIRST_TOUCH = 0
    const val TOUCH_HEAVY = 1
    const val SHIELD_BALL = 2
    const val TURN_AWAY = 3
    const val DRIVE_FORWARD = 4
    const val TAKE_ON_ATTEMPT = 5
    const val TAKE_ON_WON = 6
    const val TAKE_ON_LOST = 7
    const val SKILL_MOVE = 8
    const val NUTMEG = 9
    const val BACKHEEL = 10
    const val FLICK_ON = 11
    const val DISPOSSESSED = 12

    /* ------------------------------------------------------------ PASSING */
    const val PASS_SHORT = 13
    const val PASS_LONG = 14
    const val PASS_SWITCH = 15
    const val THROUGH_BALL = 16
    const val ONE_TWO = 17
    const val CROSS = 18
    const val CUT_BACK = 19
    const val PASS_MISPLACED = 20
    const val PASS_INTERCEPTED = 21

    /* ----------------------------------------------------------- SHOOTING */
    const val SHOT_STRUCK = 22
    const val SHOT_HEADER = 23
    const val SHOT_VOLLEY = 24
    const val SHOT_LONG_RANGE = 25
    const val SHOT_CHIP = 26
    const val SHOT_FREE_KICK = 27
    const val SHOT_BLOCKED = 28
    const val SHOT_DEFLECTED = 29
    const val SHOT_WIDE = 30
    const val WOODWORK = 31
    const val REBOUND = 32
    const val GOAL = 33
    const val GOAL_DISALLOWED = 34
    const val OWN_GOAL = 35

    /* -------------------------------------------------------- GOALKEEPING */
    const val SAVE_ROUTINE = 36
    const val SAVE_DIVING = 37
    const val SAVE_TIP_OVER = 38
    const val SAVE_PARRY = 39
    const val SAVE_PENALTY = 40
    const val KEEPER_CLAIM_CROSS = 41
    const val KEEPER_PUNCH = 42
    const val KEEPER_SWEEP = 43
    const val KEEPER_DISTRIBUTION = 44
    const val KEEPER_UP_FOR_CORNER = 45

    /* ---------------------------------------------------------- DEFENDING */
    const val TACKLE_WON = 46
    const val TACKLE_SLIDING = 47
    const val TACKLE_LAST_DITCH = 48
    const val INTERCEPTION = 49
    const val BLOCK = 50
    const val CLEARANCE = 51
    const val CLEARANCE_HEADED = 52
    const val RECOVERY_RUN = 53
    const val OFFSIDE_TRAP_SPRUNG = 54
    const val GOAL_LINE_CLEARANCE = 55

    /* ----------------------------------------------- FOULS AND DISCIPLINE */
    const val FOUL = 56
    const val FOUL_ADVANTAGE = 57
    const val FOUL_IN_BOX = 58
    const val HANDBALL = 59
    const val CARD_YELLOW = 60
    const val CARD_SECOND_YELLOW = 61
    const val CARD_RED = 62
    const val PROFESSIONAL_FOUL = 63
    const val DISSENT = 64
    const val MELEE = 65
    const val OFFSIDE = 66

    /* -------------------------------------------------------- SET PIECES */
    const val THROW_IN = 67
    const val THROW_LONG = 68
    const val GOAL_KICK = 69
    const val CORNER_WON = 70
    const val FREE_KICK_DIRECT = 71
    const val FREE_KICK_INDIRECT = 72
    const val PENALTY_AWARDED = 73
    const val PENALTY_SCORED = 74
    const val PENALTY_MISSED = 75
    const val KICK_OFF = 76
    const val DROP_BALL = 77

    /* ------------------------------------------ PHYSICAL AND MANAGEMENT */
    const val INJURY_KNOCK = 78
    const val INJURY_SERIOUS = 79
    const val CRAMP = 80
    const val SUBSTITUTION = 81
    const val SUBSTITUTION_FORCED = 82
    const val FORMATION_CHANGE = 83
    const val SHOUT = 84
    const val TIME_WASTING = 85

    /* --------------------------------------------------- THE MATCH ITSELF */
    const val HALF_TIME = 86
    const val SECOND_HALF = 87
    const val ADDED_TIME = 88
    const val FULL_TIME = 89

    const val COUNT = 90

    /** The name of each event, for the census and for the feed. */
    @JvmField val NAME = arrayOf(
        "first touch", "heavy touch", "shielding it", "turning away",
        "driving forward", "take-on attempted", "take-on won", "take-on lost",
        "a piece of skill", "nutmeg", "backheel", "flick-on", "dispossessed",
        "short pass", "long pass", "switch of play", "through ball", "one-two",
        "cross", "cut-back", "misplaced pass", "pass intercepted",
        "shot struck", "header at goal", "volley", "shot from distance",
        "chipped shot", "free kick at goal", "shot blocked", "shot deflected",
        "shot wide", "off the woodwork", "rebound", "goal", "goal disallowed",
        "own goal",
        "routine save", "diving save", "tipped over", "parried",
        "penalty saved", "keeper claims a cross", "keeper punches clear",
        "keeper sweeps up", "keeper distribution", "keeper up for a corner",
        "tackle won", "sliding tackle", "last-ditch tackle", "interception",
        "block", "clearance", "headed clearance", "recovery run",
        "offside trap sprung", "cleared off the line",
        "foul", "advantage played", "foul in the box", "handball",
        "yellow card", "second yellow", "red card", "professional foul",
        "dissent", "melee", "offside",
        "throw-in", "long throw", "goal kick", "corner won",
        "direct free kick", "indirect free kick", "penalty awarded",
        "penalty scored", "penalty missed", "kick-off", "drop ball",
        "knock", "serious injury", "cramp", "substitution", "forced change",
        "formation change", "shout from the touchline", "time wasting",
        "half time", "second half", "added time", "full time"
    )

    /**
     * What each event puts on screen.
     *
     * A row with everything at its default shows nothing, which is correct for
     * the events that are simply football happening -- a short pass does not
     * deserve a caption. The census still counts them, which is how "the ball
     * is never passed" would be answered.
     */
    @JvmField val SHOWN = arrayOf(
        /* ON THE BALL */
        Shown(),                                                                            // FIRST_TOUCH
        Shown(),                                                                            // TOUCH_HEAVY
        Shown(pose = Act.DRIBBLE),                                                          // SHIELD_BALL
        Shown(pose = Act.DRIBBLE),                                                          // TURN_AWAY
        Shown(nudge = 0.05f),                                                               // DRIVE_FORWARD
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "TAKE-ON", crowd = 0.55f),              // TAKE_ON_ATTEMPT
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "TAKE-ON", crowd = 0.65f),              // TAKE_ON_WON
        Shown(),                                                                            // TAKE_ON_LOST
        Shown(Scene.TAKE_ON, Act.DRIBBLE, crowd = 0.80f, seconds = 1.1f),                   // SKILL_MOVE
        Shown(Scene.TAKE_ON, Act.DRIBBLE, caption = "NUTMEG", crowd = 0.85f),               // NUTMEG
        Shown(pose = Act.DRIBBLE, crowd = 0.60f),                                           // BACKHEEL
        Shown(pose = Act.HEADER),                                                           // FLICK_ON
        Shown(),                                                                            // DISPOSSESSED

        /* PASSING */
        Shown(),                                                                            // PASS_SHORT
        Shown(),                                                                            // PASS_LONG
        Shown(caption = "SWITCH", nudge = 0.05f),                                           // PASS_SWITCH
        Shown(caption = "THROUGH BALL", crowd = 0.70f),                                     // THROUGH_BALL
        Shown(caption = "ONE-TWO", crowd = 0.60f),                                          // ONE_TWO
        Shown(caption = "CROSS", crowd = 0.65f),                                            // CROSS
        Shown(caption = "CUT-BACK", crowd = 0.70f),                                         // CUT_BACK
        Shown(),                                                                            // PASS_MISPLACED
        Shown(Scene.TACKLE, caption = "INTERCEPTION", crowd = 0.40f),                       // PASS_INTERCEPTED

        /* SHOOTING */
        Shown(Scene.SHOT, Act.SHOOT, caption = "SHOT", crowd = 0.80f),                      // SHOT_STRUCK
        Shown(Scene.SHOT, Act.HEADER, caption = "HEADER", crowd = 0.80f),                   // SHOT_HEADER
        Shown(Scene.SHOT, Act.SHOOT, caption = "VOLLEY", crowd = 0.88f),                    // SHOT_VOLLEY
        Shown(Scene.SHOT, Act.SHOOT, caption = "FROM DISTANCE", crowd = 0.82f),             // SHOT_LONG_RANGE
        Shown(Scene.SHOT, Act.SHOOT, caption = "CHIPPED", crowd = 0.85f),                   // SHOT_CHIP
        Shown(Scene.SHOT, Act.SHOOT, caption = "FREE KICK", crowd = 0.85f),                 // SHOT_FREE_KICK
        Shown(pose = Act.TACKLE, onFoe = true, caption = "BLOCKED", crowd = 0.55f),         // SHOT_BLOCKED
        Shown(caption = "DEFLECTED", crowd = 0.70f),                                        // SHOT_DEFLECTED
        Shown(crowd = 0.35f),                                                               // SHOT_WIDE
        Shown(Scene.SHOT, caption = "OFF THE POST", crowd = 0.95f),                         // WOODWORK
        Shown(Scene.SHOT, caption = "REBOUND", crowd = 0.90f),                              // REBOUND
        Shown(pose = Act.CELEBRATE, caption = "GOAL!", crowd = 1.00f, dead = true),         // GOAL
        Shown(caption = "NO GOAL", ref = Ref.WHISTLE, crowd = 0.20f, dead = true),          // GOAL_DISALLOWED
        Shown(pose = Act.DOWN, caption = "OWN GOAL", crowd = 0.55f, dead = true),           // OWN_GOAL

        /* GOALKEEPING */
        Shown(Scene.SAVE, caption = "SAVE", crowd = 0.50f),                                 // SAVE_ROUTINE
        Shown(Scene.SAVE, Act.DIVE, caption = "SAVE", crowd = 0.75f),                       // SAVE_DIVING
        Shown(Scene.SAVE, Act.DIVE, caption = "TIPPED OVER", crowd = 0.85f),                // SAVE_TIP_OVER
        Shown(Scene.SAVE, Act.DIVE, caption = "PARRIED", crowd = 0.75f),                    // SAVE_PARRY
        Shown(Scene.SAVE, Act.DIVE, caption = "SAVED IT!", crowd = 1.00f),                  // SAVE_PENALTY
        Shown(crowd = 0.30f),                                                               // KEEPER_CLAIM_CROSS
        Shown(pose = Act.DIVE, crowd = 0.45f),                                              // KEEPER_PUNCH
        Shown(caption = "OFF HIS LINE", crowd = 0.60f),                                     // KEEPER_SWEEP
        Shown(),                                                                            // KEEPER_DISTRIBUTION
        Shown(Scene.CORNER, caption = "KEEPER IS UP", crowd = 0.95f, dead = true),          // KEEPER_UP_FOR_CORNER

        /* DEFENDING */
        Shown(Scene.TACKLE, Act.TACKLE, caption = "TACKLE", crowd = 0.50f),                 // TACKLE_WON
        Shown(Scene.TACKLE, Act.TACKLE, caption = "SLIDING IN", crowd = 0.65f),             // TACKLE_SLIDING
        Shown(Scene.TACKLE, Act.TACKLE, caption = "LAST-DITCH", crowd = 0.90f),             // TACKLE_LAST_DITCH
        Shown(Scene.TACKLE, caption = "INTERCEPTION", crowd = 0.35f),                       // INTERCEPTION
        Shown(pose = Act.TACKLE, caption = "BLOCKED", crowd = 0.60f),                       // BLOCK
        Shown(),                                                                            // CLEARANCE
        Shown(pose = Act.HEADER),                                                           // CLEARANCE_HEADED
        Shown(),                                                                            // RECOVERY_RUN
        Shown(Scene.FREEKICK, caption = "OFFSIDE", ref = Ref.FLAG, crowd = 0.30f, dead = true),  // OFFSIDE_TRAP_SPRUNG
        Shown(pose = Act.TACKLE, caption = "OFF THE LINE!", crowd = 0.95f),                 // GOAL_LINE_CLEARANCE

        /* FOULS AND DISCIPLINE */
        Shown(Scene.FREEKICK, Act.DOWN, onFoe = true, caption = "FREE KICK",
            ref = Ref.WHISTLE, crowd = 0.40f, dead = true),                                 // FOUL
        Shown(caption = "ADVANTAGE", ref = Ref.ADVANTAGE, crowd = 0.45f),                   // FOUL_ADVANTAGE
        Shown(Scene.PENALTY, Act.DOWN, onFoe = true, caption = "PENALTY",
            ref = Ref.WHISTLE, crowd = 1.00f, dead = true),                                 // FOUL_IN_BOX
        Shown(Scene.FREEKICK, caption = "HANDBALL", ref = Ref.WHISTLE,
            crowd = 0.50f, dead = true),                                                    // HANDBALL
        Shown(Scene.CARD, caption = "BOOKED", ref = Ref.CARD, crowd = 0.65f, dead = true),  // CARD_YELLOW
        Shown(Scene.CARD, caption = "SENT OFF", ref = Ref.CARD, crowd = 0.90f, dead = true),// CARD_SECOND_YELLOW
        Shown(Scene.CARD, caption = "RED CARD", ref = Ref.CARD, crowd = 0.95f, dead = true),// CARD_RED
        Shown(Scene.CARD, Act.TACKLE, caption = "CYNICAL", ref = Ref.CARD,
            crowd = 0.80f, dead = true),                                                    // PROFESSIONAL_FOUL
        Shown(Scene.CARD, caption = "DISSENT", ref = Ref.CARD, crowd = 0.55f, dead = true), // DISSENT
        Shown(caption = "TEMPERS FRAYING", ref = Ref.WHISTLE, crowd = 0.75f, dead = true),  // MELEE
        Shown(Scene.FREEKICK, caption = "OFFSIDE", ref = Ref.FLAG, crowd = 0.30f, dead = true),  // OFFSIDE

        /* SET PIECES AND RESTARTS */
        Shown(Scene.THROW_IN, caption = "THROW-IN", dead = true),                           // THROW_IN
        Shown(Scene.THROW_IN, caption = "LONG THROW", crowd = 0.55f, dead = true),          // THROW_LONG
        Shown(Scene.GOAL_KICK, caption = "GOAL KICK", dead = true),                         // GOAL_KICK
        Shown(Scene.CORNER, caption = "CORNER", crowd = 0.55f, dead = true),                // CORNER_WON
        Shown(Scene.FREEKICK, caption = "FREE KICK", ref = Ref.SPRAY,
            crowd = 0.70f, dead = true),                                                    // FREE_KICK_DIRECT
        Shown(Scene.FREEKICK, caption = "FREE KICK", ref = Ref.WHISTLE,
            crowd = 0.45f, dead = true),                                                    // FREE_KICK_INDIRECT
        Shown(Scene.PENALTY, caption = "PENALTY", ref = Ref.WHISTLE,
            crowd = 1.00f, dead = true),                                                    // PENALTY_AWARDED
        Shown(pose = Act.CELEBRATE, caption = "GOAL!", crowd = 1.00f, dead = true),         // PENALTY_SCORED
        Shown(pose = Act.DOWN, caption = "MISSED", crowd = 0.30f, dead = true),             // PENALTY_MISSED
        Shown(Scene.KICK_OFF, caption = "KICK OFF", ref = Ref.WHISTLE,
            crowd = 0.30f, dead = true),                                                    // KICK_OFF
        Shown(caption = "DROP BALL", ref = Ref.WHISTLE, crowd = 0.20f, dead = true),        // DROP_BALL

        /* PHYSICAL AND MANAGEMENT */
        Shown(pose = Act.DOWN, crowd = 0.20f),                                              // INJURY_KNOCK
        Shown(pose = Act.DOWN, caption = "INJURY", ref = Ref.WHISTLE,
            crowd = 0.25f, dead = true),                                                    // INJURY_SERIOUS
        Shown(pose = Act.DOWN, crowd = 0.15f),                                              // CRAMP
        Shown(Scene.SUBSTITUTION, caption = "SUBSTITUTION", crowd = 0.35f, dead = true),    // SUBSTITUTION
        Shown(Scene.SUBSTITUTION, caption = "FORCED CHANGE", crowd = 0.30f, dead = true),   // SUBSTITUTION_FORCED
        Shown(crowd = 0.25f),                                                               // FORMATION_CHANGE
        Shown(nudge = 0.10f),                                                               // SHOUT
        Shown(crowd = 0.25f),                                                               // TIME_WASTING

        /* THE MATCH ITSELF */
        Shown(caption = "HALF TIME", ref = Ref.WHISTLE, crowd = 0.35f, dead = true),        // HALF_TIME
        Shown(Scene.KICK_OFF, caption = "KICK OFF", ref = Ref.WHISTLE,
            crowd = 0.40f, dead = true),                                                    // SECOND_HALF
        Shown(caption = "ADDED TIME", crowd = 0.45f),                                       // ADDED_TIME
        Shown(caption = "FULL TIME", ref = Ref.WHISTLE, crowd = 0.60f, dead = true)         // FULL_TIME
    )

    /**
     * The table has to be complete, and there is no compiler check that it is.
     *
     * Called once from a test rather than from the match, because a mismatch
     * here is the kind of thing that would otherwise be found by an index off
     * the end of an array during a game -- which is exactly how L_DRIBBLE sat
     * in this project for months waiting to crash a match.
     */
    fun selfCheck(): String {
        if (NAME.size != COUNT) return "NAME has ${NAME.size}, expected $COUNT"
        if (SHOWN.size != COUNT) return "SHOWN has ${SHOWN.size}, expected $COUNT"
        return "ok"
    }
}
