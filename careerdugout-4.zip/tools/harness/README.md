# Off-device measurement harness

The renderer, the engine and the sound synthesis all run on a desktop JVM here,
so a visual or audio claim can be checked by measurement instead of asserted.
Nothing in this folder ships in the APK.

## Why it exists

`core/` and the simulation are free of Android imports, so they compile as they
are. `ui/MatchView.kt` needs only a handful of graphics classes, which `shim/`
supplies over Java2D. `Theme` is stubbed to the two constants the renderer
actually reads.

## Running it

Needs a JDK and `kotlinc` on the path. From the repository root:

```sh
SRC=app/src/main/java/com/dugout/career
SIM="$SRC/core/*.kt $SRC/sim/MatchEngine.kt $SRC/sim/League.kt $SRC/sim/Career.kt"

# renderer: sprite profiles, goal sequence, match frames  -> ./out
kotlinc -nowarn $SIM $SRC/ui/MatchView.kt tools/harness/shim/*.kt \
    tools/harness/Harness.kt -include-runtime -d /tmp/harness.jar
java -Djava.awt.headless=true -jar /tmp/harness.jar sprites   # 8-direction measurement
java -Djava.awt.headless=true -jar /tmp/harness.jar goal      # celebration + replay
java -Djava.awt.headless=true -jar /tmp/harness.jar frames    # ordinary play

# sound: writes WAVs and reports level and spectrum -> ./out/audio
kotlinc -nowarn $SRC/core/*.kt tools/harness/AudioHarness.kt -include-runtime -d /tmp/audio.jar
java -jar /tmp/audio.jar

# balance: the 400-match check the brief requires after any engine edit
kotlinc -nowarn $SIM tools/harness/BalanceHarness.kt -include-runtime -d /tmp/bal.jar
java -jar /tmp/bal.jar 400
```

`BalanceBase.kt` is the same check pointed at an untouched copy of the engine,
for before-and-after comparison. `QuickSimCheck.kt` measures the quick
simulation, which should agree with the live engine.

### Balance did not need retuning, and the drift was noise

The brief asked for a retune: the top flight read 2.45 / 2.52 / 2.70 across
three world seeds against a 2.5-2.7 target, one seed under it and one at the
ceiling. Those came off 400-match runs.

Goals per game is the mean of a roughly Poisson count whose variance is near
its mean of 2.6, so 400 matches carries a standard error of `sqrt(2.6/400)` =
**0.08 goals, or plus and minus 0.16 at 95%**. The whole spread being chased
was inside the noise, and moving the lever to close it would have been tuning
the engine against the sampling error of its own test.

`BalanceBig.kt` measures the top division only — `world.week` goes into the
match seed, so replaying the same fixture list in a later week is an
independent sample of the SAME division, where raising the match count on
`BalanceHarness` instead walks off the end of the top flight into the second.
Four worlds by six seasons, 9,120 matches, chance quality unchanged at 0.099:

```
goals per game     2.58  +/- 0.03 at 95%      target 2.5 - 2.7
home / draw / away  44.9% / 24.7% / 30.4%     target 45 / 25 / 30
cards per game     2.13

seed 20260727  2.56      seed 99001   2.60
seed 5150      2.59      seed 777333  2.57
```

The four worlds sit within 0.04 of each other. **The lever was already
centred and has not been touched.** The sweep, for the next person who has to
move it:

```
quality     goals     95% interval
0.095        2.52     2.48 - 2.55
0.099        2.58     2.54 - 2.62      <- as shipped
0.103        2.66     2.62 - 2.69
0.107        2.72     2.69 - 2.76      <- out of the band
```

`BalanceHarness` printed WITHIN TOLERANCE on a tolerance of 2.4-2.8 while
quoting a target of 2.5-2.7 on the line above. It now tests the target it
prints, and every run states its own interval.

`DivisionBalance` prints intervals too, and they change the reading. At 380
games a division the Premier Division is 2.45 (2.30-2.60) and the Championship
2.47 (2.32-2.61): **the top two divisions are not distinguishable at that
sample**, though the bottom two clearly are lower at 2.10 and 2.08. The table
of per-division figures further down this file was quoted without intervals and
should be read as indicative only.

### Read the balance figure carefully

`BalanceHarness` walks the league fixture list in order, and the top flight
fills the first 380 entries. So the sample size decides which division is
being measured:

```
n = 400    almost entirely the top division
n = 2400   the whole five division pyramid
```

Goals per game differ by division, as they should:

```
Premier Division   2.56      League Two        2.11
Championship       2.28      National League   1.93
Championship       2.17      whole pyramid     2.21
```

The 2.5 to 2.7 target in the brief is a top division figure, so quote the
400 match run against it. `DivisionBalance.kt` prints the breakdown and is the
honest way to check a change has not shifted one division while flattering
another.

## Running the actual screens

`UiFlow.kt` builds a real MainActivity on the Java2D shim and drives it through
every screen: the start choice, the job hunt with no club, applying for a job,
each tab in the rail, a player card, being sacked, and applying again.

```sh
java -Djava.awt.headless=true -cp build/uf.jar UiFlowKt
```

It cannot say whether anything is laid out correctly. What it does catch is the
class of bug that had been reaching the device: a lateinit field that is only
assigned on one route, or a `userClub!!` on a path where there is no club. Both
crashes on the out of work screen were of exactly that shape. Run this before
shipping a build.

## Type checking the app layer

`MainActivity.kt`, `Theme.kt` and `Icons.kt` need the Android UI classes, so
they used to be compiled only by the CI build — about five and a half thousand
lines that could not be checked before a push. The shim now covers enough of
`android.app`, `android.view`, `android.widget`, `android.media`,
`android.graphics.drawable`, `android.os`, `android.text` and `android.util`
for the whole app to be type checked locally:

```sh
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt -d /tmp/uicheck
```

This proves the code compiles. It does not prove it lays out or draws
correctly on a device, so the CI build is still the real test of appearance.

Note the shim's `Theme` stub in `ThemeStub.kt` is only for the renderer
harness; do not pass it alongside the real `ui/Theme.kt`.

## The sixty league world

`WorldCheck` reports the shape. As measured on seed 20260727:

```
1,236 clubs, 32,136 players, built in 629 ms
60 countries with a league, 185 nationalities
0 duplicate club names, 0 duplicate player names, 0 orphan clubs
save 7.54 MB, round trip clean
faces 100% unique, closest pair 3 of 10 features apart, assigned in 895 ms
memory: world 20.7 MB, faces 3.7 MB, fixtures 0.1 MB
```

A country's shape comes from `FOREIGN_SHAPE` in `World.kt`: twenty one countries
have three divisions of twelve, thirty eight have a single division of ten, and
England keeps its five of twenty. Anything not listed falls back to one division
of ten rather than crashing, which means a country added to `FOREIGN_CODES` and
forgotten in `FOREIGN_SHAPE` will build but will be quietly wrong — `PickerCheck`
is what catches that.

`FOREIGN_CODES` is walked in order to lay out the foreign divisions, and a
division id is what a save stores against every club. **Append to it, never
insert**: inserting moves every club after the insertion point into a different
country's league on the next load.

### Harnesses added with it

```sh
java -cp build/h.jar GoalPlaceKt 60      # where is the ball when a goal is given
java -cp build/h.jar SmallLeagueKt       # a season in a one division country
java -cp build/h.jar PickerCheckKt       # continent grouping, shape table vs reality
java -cp build/h.jar FlagCheckKt         # the computed flag emoji are well formed
```

`GoalPlace` exists because `ReplayCheck` used to return after the first goal of
the first seed, so it could pass while 69% of goals in the game were being
awarded with the ball in midfield. Any check that stops at the first sample is
worth this little scrutiny.

`SmallLeague` exists because every country used to have three tiers. The
promotion ladder pairs adjacent divisions, the fixture builder has to give ten
clubs a full calendar, and neither had ever seen a pyramid with nothing above
or below it.

## Rivalries and derbies

Rivalries are **derived, not stored**: they come out of the seed and the
finished club list, so the same world always produces the same derbies, and an
old save loads with them in it rather than needing a migration. `buildRivalries`
runs at the end of `World.build` and again in `Save.read` — it has to be after
the clubs and divisions are read, because `buildStructureOnly` gives an empty
world and rivalries computed from that would be empty and would stay empty for
the rest of the career.

Three sources, in the order a real one usually arises: same town (always, and
never dropped), same division and similar standing, and the biggest club in a
country against the next two. Then a cap of four, so nobody's fixture list is
all derbies, and a floor of one.

The floor matters more than it sounds. Without it, measured, **40% of clubs had
no rival at all** — most towns hold one club and the same-division pass is a
coin toss — so for four hundred clubs the whole feature was invisible. Now
every club has at least the side nearest it in its own division.

A derby is fuller, louder and more bad tempered, and that is all. Measured over
1,800 matches (114 derbies):

```
           games      crowd    cards    goals   home w
derby        114      20416     2.80     2.42      45%
ordinary    1686      18799     2.04     2.34      43%
```

**It deliberately does not make the home side more likely to win** — that would
be a cheat rather than an occasion. An earlier run on 24 derbies showed home
wins at 58% against 46%, which looked like exactly that bug and was small-sample
noise; it took a sample seven times larger to see it was nothing. The goals
difference is a selection effect, not a mechanic: rivals are by construction
similar clubs in the same division, so derbies are played between better sides
than the average fixture.

```sh
java -cp build/h.jar DerbyCheckKt 1800   # the map, and what a derby changes
```

### A derby now costs something

It was on the hub screen and nowhere else, so it existed on the morning of the
match and never again. The result went through `applyResult` exactly like any
other, which meant a rivalry was a caption. Four things know about it now.

**The dressing room and the board.** A derby result moves the room half again
as far, and the board has a view where it had none. Measured by playing the
same score into `applyResult` twice from an identical world, once as a derby
and once not, so the difference is the mechanic and nothing else:

```
result        club morale   player morale   board confidence
win 2-0       +5.0 / +7.5    +3.0 / +4.5     +0 / +4
draw 1-1      +0.0 / +0.0    +0.0 / +0.0     +0 / +0
lose 0-2      -6.0 / -9.0    -3.0 / -4.5     +0 / -6
                   ordinary / derby
```

Deliberately one-sided: losing to them costs six where beating them earns four,
because that is how it reads from the stand. Half again rather than double,
because one fixture should not outweigh the other thirty seven.

**Selling to them.** The game would let you sell your best player to the club
up the road and say nothing whatever about it. It now costs four points of team
morale and five of board confidence, and the news feed says so.

**The fixture list, the table and the club profile.** A derby is marked on the
fixture list so the manager can see one coming and look back at how the last
one went, rivals are flagged in the league table where they sit, and the club
profile carries a Rivals panel with each rival's position and this season's
head-to-head. A rival in an abstract foreign league says "abroad" rather than
printing a position, because only the home pyramid and the country the manager
works in have a real calendar, and implying otherwise is the thing open problem
9 warns about.

The old open-problems list also named a season preview screen. There is no
season preview screen anywhere in the game — nothing matches it in
`MainActivity.kt` — so there was nothing to put a derby on. Worth saying
rather than quietly dropping.

This is still nothing that makes a derby easier to win. `DerbyCheck` at 1,800
matches remains the check on that, and it needs to be run at 1,800: a 400-match
run holds only 24 derbies and reported home wins at 58% against 46%, which is
the same small-sample mirage that was chased once already.

## Two figures in this file that were wrong

Both were quoted off a **single match**, and both were wrong because of it.
Anything measured per-frame during possession needs many matches: one match
yields under two hundred frames where a player actually has the ball at his
feet.

- **Ball stickiness.** One match said 0.50 m from the man in possession. Forty
  matches say **0.37 m** over 10,394 held frames, with 83% inside half a metre.
  The tail beyond 1.5 m is 3.6% of frames and is almost all sprinting, where the
  ball sits 1.16 m ahead — a player knocking it in front of himself.
- **Gait spread.** One match said standing 10.2%. Twenty matches say **13.9 /
  40.0 / 28.9 / 14.0 / 3.3** against a real 15/45/25/12/3. Slightly busy, not
  drifted.

`PerfCheck` had a third instance of the finished-match family of bug: it benched
four thousand `update` calls without restarting, and `update` returns
immediately once `finished` is set, so it was timing a no-op for most of them.
The engine costs **0.06 ms a frame**, not the 0.04 previously reported.

## Match engine v2: replacing the spatial layer

Three separate attempts to fix this engine's geometry each fixed one line and
broke another. That is not three bugs, it is one: **pass length, pass
direction, shot distance and team shape are all emergent side effects of where
men happen to be standing**, because a move is built by hopping between whoever
is near the man on the ball.

So the plan is to keep the outcome model — ratings, phaseGap, the outcome roll,
chance quality, which measure correctly at 2.65 goals and 45/23/31 and agree
with the quick simulation — and replace the spatial layer underneath it.
`MatchEngine.SPATIAL_V2` switches between them and `EngineCompare` runs both
through every figure at once, because a version only wins if it wins across the
board.

### Step one: walk the ball, not the players — KEPT

A move advances the BALL a sampled distance in a sampled direction, and then
asks who is best placed to receive it. Length is sampled in METRES, not pitch
units, or every ball across the pitch would be half the length of one up it;
direction is sampled to a real 45/35/20 split rather than hoped for.

```
                        v1 (players)    v2 (ball)   real
goals per game            2.65±0.04    2.63±0.04    2.5-2.7
home / draw / away     45.6/23.1/31.3 43.6/24.1/32.3  45/25/30
mean pass                    24.9 m       21.7 m    ~18 m
forward/side/back          69/19/12     62/24/14    45/35/20
median goal                  25.8 m       26.3 m    ~11 m
goals from own half            0.0%         1.5%    ~0%
block back to front          45.6 m       46.5 m    30-40 m
```

**The passing moved and the results did not.** That is the whole point of the
architecture and it is the first change in this effort that did not have to be
reverted. It is not yet a clean win — own-half goals go from 0.0% to 1.5% — so
it ships behind the flag, OFF, until the rest lands.

### Step two: players offer support — REVERTED

Nobody moved to support the man in possession, so a pass could not be shorter
than the gap between two formation slots. The nearest four now take up angles
around the ball at 13-16 m.

It changed the mean pass by 0.2 m (21.7 -> 21.5) and pushed the median goal out
from 26.3 m to 29.9 m. Reverted.

### Step three: choose the receiver at the moment of the pass — REVERTED

Step two failed for a structural reason worth writing down: **the whole move is
decided before it is played.** The sequence is built when the phase starts and
then runs over a minute or two of match time while everybody moves, so the
receiver of the fourth pass was chosen from where men stood before the first.
Support positions cannot matter to a pass that was aimed long before anyone
took one up.

So the receiver was chosen just-in-time instead, from whoever was genuinely
available. Mean pass 20.8 m — the best of the three — but the direction split
fell back to 67/19/13 and the median goal stayed at 29.9 m. Reverted.

### Where this leaves it

Step one is real and measured. Steps two and three say that support play and
just-in-time passing cannot be bolted onto a move whose length, shape and
outcome are all fixed in advance — and that the median goal distance is held up
by something neither touched, almost certainly the offside clamp against a
defending block that sits too high (see the shape section below, where the same
wall was hit from the other side).

The next thing to try is the one nobody has: make the phase itself
**incremental** — no pre-built sequence at all, the move advancing pass by pass
and ending when it reaches a shooting position or is lost, with the outcome
still drawn from the ratings. That is a genuine rewrite of `newPhase` and
`stepPhase`, and `EngineCompare` is now the harness that can tell you whether
it worked.

## The team shape is too long, and compressing it makes the football worse

`ShapeCheck` used to run one match and count every outfield player, including
the man sprinting forty metres after a loose ball. It now runs twenty and
prints the BLOCK — the span with the furthest man dropped — alongside the full
one, because "back line to front line" in football means the organised lines,
not the distance to whoever is chasing.

That distinction turned out not to matter. Over 20 matches and 11,694 samples:

```
back to front, everyone   47.8 m
back to front, the block  45.8 m     real football: 30-40 m
widest to widest          53.5 m     real: 45-55 m      ok
nearest team mate         13.7 m     real: 12-18 m      ok
```

So the side really is 6-15 m too long, and it is not one man running.

**The obvious fix works and costs more than it is worth.** `SHAPE_COMPACT`
0.62 -> 0.45 puts the block at 36.5 m, inside the real band, and shortens the
average pass from 24.6 m to 22.5 m as a bonus. But shooting gets worse, and the
reason is physical rather than a tuning accident: compressing the shape around
a fixed midpoint lifts the DEFENDING line up the pitch, the offside clamp holds
attackers behind it, and play therefore happens further from goal.

Four attempts, each measured over 40 matches:

```
                              block   median goal   goals inside 18 m   own-half goals
as shipped                    45.8 m       26.1 m               12%             0.0%
SHAPE_COMPACT 0.45            36.5 m       32.4 m                0%             3.2%
  + whole block pushed up 8   33.0 m       31.9 m                0%             1.1%
  + defenders track ball 0.80 34.9 m       29.9 m               13%             4.2%
  + attackers stay high 0.32  35.4 m       30.2 m                7%             6.0%
```

Every combination that fixes the shape puts goals back into the shooter's own
half, which is the thing the previous commit had just removed. **All of it was
reverted.** Balance was fine throughout (2.58 with the compaction), so this is
not a balance problem — it is that shape, the offside clamp and where a move
can reach are one mechanism, and moving any of them alone moves the shot
distribution.

Anyone picking this up: the shape number is genuinely wrong and worth fixing,
but it needs the offside clamp and the block's POSITION solved at the same
time, not one at a time. `ShapeCheck` and `ShotRange` together are the check —
neither alone will tell you whether you have won.

## Scoring from your own half

Reported from the device: "the players can score from before half of the
pitch". True, and badly so. `GoalPlace` had always checked where the BALL was
when a goal was given and it was always on the goal line — but that is the end
of the flight. Nobody had measured where the man who struck it was standing.

`ShotRange` measures that, taking the shooter to be the player whose own shot
counter went up (finding him by his pose picks whoever is first in the list
with a SHOOT pose, which is not reliably the striker). Over 40 matches:

```
              before    after     real football
median shot    36.1 m   27.3 m    most from 12-25 m
median goal    25.9 m   26.1 m    about 11 m
shots from own half  25.7%  0.7%
GOALS from own half  25.9%  0.0%   about one a season in a whole league
```

A shot reaches `attemptShot` down several routes — the end of a move, a corner
headed by whoever the routine picked, a free kick — and not one of them checked
where the man was. A corner could be met by a centre half who had never left
his own box. The fix is a single range test at the one place every shot passes
through: beyond 40 m the chance falls to whichever attacker is nearest the
goal.

### Two bigger fixes that were tried and thrown away

This is worth recording, because both looked obviously right and both were
worse than the problem.

**Cancelling out-of-range attacks.** If nobody at all is within range, treat it
as no chance and let the move break down. Goals per game fell from 2.65 to
2.01, and home wins went from 44% to 47% — because the breakdown restarted the
move through `flipLater`, which routes possession through `nextSide`, which is
weighted toward the better team. Rewriting it as a clean turnover made it worse
still (50.8% home, 17.9% draws), which is the opposite of what the reasoning
predicted and is why it is recorded rather than explained.

**A distance curve on chance quality.** Chance quality has no distance term at
all — a shot from the six yard box and one from thirty five metres carry the
same xG — so adding one is clearly correct football, and it did work on its own
terms: goals struck from inside 18 m went from 21% to 34% of all goals. But
combined with the range guard it needed the lever raised from 0.107 to 0.125,
and it left **home wins at 49-51% and draws at 18-20%** against real figures of
45 and 25. A league where half the matches are home wins and fewer than a fifth
are drawn is a worse simulation than one where people occasionally shoot from
too far out.

Neither is wrong in principle and both are worth another attempt with more
care. The measured lesson is that this engine's result distribution is far more
sensitive to *how possession changes hands* than to how chances are valued, and
anything touching the first needs `BalanceBig` on every iteration.

**What is still wrong and was not fixed:** the median goal is struck from 26 m
against a real 11 m. Shots are no longer absurd but they are still too long,
and correcting that properly means the distance curve, which means solving the
distribution problem above first.

## The cosmetic stream was not cosmetic

Several comments in `MatchEngine` said some version of "rolled on the cosmetic
stream so it cannot move a result". **That was false**, and it had been relied
on to justify changes.

`ResultFingerprint` is what settled it. Aggregate balance is far too blunt for
this question — goals per game has a standard error of 0.03 even at 9,000
matches, so a change that moved one result in fifty would hide inside it. The
harness hashes every score, shot count, card and corner in a run, so a change
claimed to be cosmetic must come back **byte identical**.

The experiment: insert one `sfxRng` draw per phase and use it for **nothing at
all**. Over 200 matches that moved goals per game from 2.850 to 2.750 and
changed every score in the run.

The path took four steps, and none of them are obvious from the call site:

1. a cosmetic act — a take-on, say — fires at a different moment;
2. `act()` sets that man's action, and TACKLE, DOWN and DIVE are the three
   actions that stop a player moving in `moveTowardTargets`;
3. so a cosmetic act landing on somebody mid-slide **stood him straight back
   up**;
4. and `nextMan` builds the next move by picking whoever is standing nearby,
   so where that defender ended up decided who got the ball and who shot.

A commentary flourish reached the scoreline. The fix is a `cosmetic` flag on
`act()`: a presentation call is never allowed to cut short a man who is on the
floor. With that in place the same probe leaves the fingerprint **identical**,
which is what makes the rest of the texture work safe to do at all.

Two rolls that genuinely do move something — the bend on a delivery, and where
a shot comes back off the frame — were moved to their own `physRng` while this
was being chased. That turned out not to be the leak, but it is still right:
those are not cosmetic and should not sit on a stream that presentation is
free to disturb.

**If you add anything cosmetic, run `ResultFingerprint` before and after.** A
figure that merely looks similar is not the same figure.

```sh
java -cp build/h.jar ResultFingerprintKt 200 20260727
```

### The texture, once it was safe

```
                    before   after   real football
taking a man on       10.3    35.1   ~40
named skill moves      0.17    ~1    advertised, was invisible
header                 5.4     5.9   ~40
```

All of it with a byte-identical fingerprint, so not one result moved.

**Headers stayed short and that is honest.** A man only heads a ball that
arrives from the air, and this engine lofts a pass only when it is very long or
the side is told to go direct — about 3% of passes. Getting to a realistic
forty means more aerial balls, which is a change to the flight model and moves
results, so it belongs with the passing-geometry decision rather than here.

Balance after the `act()` fix and the stream split: **2.65 +/- 0.03** over
9,120 top-flight matches, still inside the band with the lever untouched.

## The set pieces were staged and then painted over

`AliveCensus` counts every transition into every action and every scene, per
match, so "there is no corner scene" is a number rather than an opinion. It
found the largest single reason the match did not feel alive.

Corners and free kicks staged their scene and then called `attemptShot` on the
**same tick**. `attemptShot` ends by setting a scene of its own — a goal kick
for a miss, a corner for a save — so the set piece it had just been called from
was overwritten before one frame had been drawn with it. The player was never
shown a corner or a free kick being taken, only the goal kick afterwards.

On top of that, a foul restarted as a free kick only 22% of the time and
otherwise just handed possession over with nothing on screen: four fouls in
five were invisible, no whistle, no wall, no restart.

`shootAfterScene` now holds the shot until the scene has been on screen. The
shot and its quality are identical, so this moves the picture and not the
result. Per match, over 30 matches:

```
                    before   after   real football
corner                 4.4     8.3   ~10
free kick              0.1     6.1   ~28 fouls
penalty                0.1     0.2   ~0.25
kick off               0.0     1.0   ~4
substitution           0.0     3.9   ~6
keeper diving         26.0    11.1   ~6
off the woodwork       2.80    0.53  ~0.5
shots                 19.7    22.2   ~25
```

`Scene.KICK_OFF` and `Scene.SUBSTITUTION` had existed in the enum, with labels,
and **nothing had ever assigned them**. The keeper threw himself full length at
every attempt, including balls flying into the stand, so he dived 26 times a
match; he now goes down only for shots actually on target. The frame was being
hit nearly three times a match against a real figure nearer half of one — that
one is decided on the cosmetic stream, so it moved the picture and not a single
result.

### What it cost, and how it was paid back

Taking the ball out of play for fourteen set pieces a match costs about eight
minutes of the phase budget, and goals per game fell from 2.57 to **2.39** —
outside the band — purely because the ball was in play less. That pause is
stoppage time and is now added back as stoppage time, the way a referee adds it
on, which recovered most of it (2.49). The rest came from the chance-quality
lever, swept again against the new timing:

```
quality     goals     95% interval
0.099        2.49     2.45 - 2.52
0.103        2.55     2.52 - 2.59
0.107        2.61     2.57 - 2.65      <- now shipped
```

Final, 9,120 top-flight matches: **2.62 +/- 0.03**, home 43.9%, draws 24.7%,
away 31.4%. The quick simulation independently gives 2.61 over 4,000 matches,
which is the check that the two models still agree.

### Still short, and honestly so

```
                    now    real football
headers             5.3    ~40
taking a man on    10.3    ~40
throw-ins           8.4    ~40
tackles (sliding)   8.7    ~20 tackles, ~6 sliding
cards               1.63   ~4
named skill moves   0.17   the feature is advertised and is invisible
goal kicks         21.0    ~14
kick off            1.0    ~4  (only fires at the first whistle)
```

These are properties of the phase model — a move is a handful of passes and one
outcome, so there is nowhere for forty headers to come from — and fixing them
means changing what a phase is. That is a design decision and it moves balance,
so nothing here was touched.

## Nothing on the pitch was ever posed

Reported from the device: no card scene, no penalty scene, no dribble, no
tackle, no keeper diving, "the match doesn't feel alive". All of it was true,
and there were two separate causes.

**The engine's actions never reached the renderer.** `Act` has had eight values
since the beginning — RUN, TACKLE, SHOOT, DIVE, CELEBRATE, DRIBBLE, DOWN,
HEADER — and its comment says "the renderer draws each one differently".
Neither renderer mentioned `Act` anywhere. `RPlayer`, the fixed interface
between the game and `BroadcastRenderer`, carried x, y, facing, speed,
runPhase, side, isKeeper, shirt, seed and isCaptain — and no action. Every
figure on the pitch was drawn running, whatever it was doing. The engine was
narrating tackles and saves into the feed while the men jogged past each other.

`RPlayer` now carries `action` and `actionTime` (defaulted, so the documented
interface stays source-compatible) and the skeleton is posed from them. The
figure is already fully parametric — hip and knee angles, arm swing, forward
lean — so a pose is a set of target angles blended in by how far through the
action he is, easing out over the last fifth of a second so it releases rather
than snapping. Laying a body down is the existing `lean` rotation about the hip
plus a drop, or a diving keeper pivots at the waist and hangs in the air.

`PoseCheck` renders one man alone, once per action, and differences him against
the same scene with nobody in it — a fixed background sample will not do,
because the mown stripes change colour across the very window being measured:

```
action            width height   pixels    w/h   pixels vs running
run                  60     50      770   1.20            0
tackle               65     23      557   2.83          833
shoot                57     49      803   1.16          633
dive (keeper)        65     26      652   2.50          775
celebrate            55     59      742   0.93          628
dribble              63     49      775   1.29          554
on the floor         65     18      633   3.61          797
header               58     53      745   1.09          657
```

A slide is 2.8 times wider than tall, a man flat out 3.6, and a celebration is
the only pose taller than a running stride. The last column is the check that
matters: a zero there would mean the action reached the renderer and changed
nothing.

**The set-piece scenes were behind the camera that was never reached.** The
penalty, corner and free-kick overlays, the skill-move flash, the woodwork ring
and the referee brandishing a card are all drawn after the `closeUp < 0.06f`
early return — that is, only on the broadcast camera. See below for why that
camera was never arrived at. Between the two faults, a card was shown for a
fraction of the frames at a fifth of the intended zoom, which is indistinguishable
from never being shown at all.

## The celebration: two bugs, and neither was the one reported

Reported as "after scoring a goal they united in one place on the pitch". That
could not be reproduced off-device — measured over 40 matches, the mob was
*too spread out*, not too tight. What the measurement did find was two real
faults that together made a goal look like nothing much happening.

**The ring was a flat ellipse.** Mates were sent to a ring 4.5 units around the
scorer. A pitch unit is 1.05 m along the pitch and 0.68 m across it, so that
ring is barely three metres deep on the grass — ten men converging on a three
metre ellipse, which is exactly the reported complaint, and would have been
visible the moment they ever arrived. Radii are metres now, converted on use,
and the nearest three mob him while the rest come from deeper.

**They never arrived, because they were throttled to a walk.** Effort falls
away with distance from the BALL, which is right for ordinary play and wrong
for the one moment nobody is playing: after a goal the ball is in the net and
the scorer is away in the corner, so every man running to him was more than
fifty units from the ball and capped at `urgency = 0.15`, about a unit a
second. Measured, they closed 3.5 m of a 21 m gap in five seconds.

```
second   mean spread   closest pair        mean spread   closest pair
             (before)      (before)             (after)       (after)
0             21.5 m        6.7 m               20.2 m        6.0 m
2             20.4 m        5.9 m               15.0 m        3.2 m
5             18.0 m        3.5 m               11.8 m        1.8 m
```

The closest pair settles at 1.8 m, so they gather without standing inside each
other, and the whole mob is never inside a 2 m circle in any frame of any
match. `GaitSpread` had to learn about this: a celebration is not match play,
and counting six sprinting seconds a goal in with the rest pushed sprinting
from 3.3% to 6.2% with nothing about the football having changed. It skips
celebration frames and says how many. Match play is unchanged at 3.4%.

## The broadcast camera was never reached

The worst thing found this session, and the one a player would have seen every
match. `closeUp` runs from nought on the board view to one on the broadcast
camera. Measured over 40 matches, **it never once got above 0.22**.

Every perspective frame, the pan fixed the session before, the whole of
`BroadcastRenderer`: none of it had ever appeared in a live match. It had only
ever been measured by harnesses that pin `closeUp` by reflection — `CamFollow`
does exactly that, deliberately, and the note above says so — so every camera
figure in the brief was about a view the game could not arrive at on its own.
Nobody had measured the arriving.

The cause was that "which camera are we on" was inferred from the eased value
instead of being remembered:

```kotlin
val minHold = if (closeUp > 0.5f) HOLD_CLOSE else HOLD_BOARD
val wantClose = if (heldFor < minHold) (closeUp > 0.5f) else raw
if (wantClose != (closeUp > 0.5f) && heldFor >= minHold) lastCutAt = nowNanos
```

The renderer decides to cut in, resets the hold clock, and eases `closeUp` from
0 to 0.22 — one frame's worth. Next frame, `closeUp > 0.5f` is still false, so
the rule reads "we are on the board", and `heldFor` has just been reset to
nothing, so the board's three second hold applies and pins it there. It eases
back out at 6% a frame, and three seconds later does the same thing again.
Thirty three aborted cuts a match, the picture twitching a fifth of the way
toward a camera it never arrived at.

The camera we are on is now a boolean set at the moment of the cut, in
`CameraCut` in `MatchView.kt`, which `CutCheck` calls rather than copies. The
hysteresis came right with it: it used to test `closeUp > 0f` for "already
close", which is really "has ever been close", because the ease-out needs some
1,700 frames to reach a true zero.

Measured, 40 matches, frame clock:

```
                          before      after
highest closeUp reached     0.22       1.00
settled on that camera        0%        69%
cuts a match                 32.9       16.3
median gap between cuts     3.0 s      4.8 s
mean spell on the close        --      9.3 s
```

69% of the match on the broadcast camera is a large change in how the game
looks, and it is what the constants have always asked for: `danger` is 1.00
whenever the ball is within 20 units of a goal. The share is set by
`HOLD_CLOSE`, not by the thresholds — `CutCheck` sweeps `CUT_OUT` and it only
moves the share from 75% to 61% across its whole useful range, because a
minimum spell of 4.5 seconds times the number of times danger crosses `CUT_IN`
already fills most of a 113 second match. If the board view is wanted back,
`HOLD_CLOSE` and `CUT_IN` are the levers, and the sweep is in the harness.

## Passes were measured on 14% of the passes

"Mean pass 19.6 m against a real 18" was the last figure in the brief that had
not been re-measured. It is **24.6 m**.

`PassCheck` and `PassBig` both spotted a delivery with the edge test
`!wasFlying && ball.t < 1f`. That needs a frame with the ball at rest between
two passes, and this engine rarely has one: a phase steps on a match-minute
timer while the ball flies in real seconds, so the next pass is struck while
the last is still travelling and the edge never appears. The engine strikes 192
passes a match. The edge test saw 14% of them, and what it saw was weighted
toward the opening ball of a move, which is struck from a standing restart into
space and is one of the longer balls in football. The figure came out close to
real football and was believed for that reason.

`PassAudit.kt` counts a pass when the engine counts one, off `passesTotal`, and
takes the geometry from `ball.fromX/fromY -> toX/toY` at the moment
`moveBallTo` sets them. Three worlds, 40 matches each, about 5,000 passes:

```
                     old figure    measured
mean pass length        19.6 m      24.6 / 24.7 / 24.2 m
forward / side / back      --       68 / 19 / 13
real football            18 m       45 / 35 / 20
```

Re-run at four times the tick rate to prove the third of passes that collapse
into a single update are not biasing it: 24.4 m against 24.6. **The game plays
a much longer and much more direct passing game than the brief said**, and that
is now a design question rather than a measurement one. Nothing has been tuned
about it — changing pass geometry moves shape, chance creation and balance
together, and that is a decision, not a fix.

`PassBig.kt` is gone; `PassCheck.kt` keeps the stride measurement, over 20
matches instead of one man in one match. The stride is 3.18 m against a real
3.0-4.0, which was never in doubt.

## The ball, and a filter that let restarts in

`BallCheck` ran one match. Its peak of 41.8 m/s sat neatly against
`MAX_BALL_MPS` 26 times `LAUNCH_RATIO` 1.55 = 40.3, so it read as the flight
model working. Over 40 matches the peak was **181 m/s**, and the worst single
frame moved the ball 84 m — the length of the pitch in a thirty-sixth of a
second.

That was the harness, not the engine. Its filter for a restart was "not in
flight and moving faster than 25", and it missed every reposition that had a
new delivery struck in the SAME update, which is most of them: the ball off the
woodwork is placed on the frame, and the goal kick is rolled out immediately
after. A frame is only a flight frame if it is the same flight as the one
before it — same origin, and `t` moved forward. With that rule, over three
worlds and 40 matches each:

```
                      one match        40 matches, 3 worlds
mean speed             21.4 m/s        23.0 - 23.2 m/s
peak                   41.8 m/s        41.9 m/s
highest off the turf    5.0 m          5.0 m
airborne                17-18%         18-19%
```

The peak now sits on the modelled ceiling on every world, which is what a cap
looks like when it is working. `BallSpike.kt` is the diagnostic that separated
the two cases.

A bounded version of the receiver-lead was tried first, on the theory that the
aim point was being dragged across the pitch mid-flight. It changed the figures
by nothing at all and was reverted.

## The camera, and three harnesses that were lying

Three of the measurement harnesses were reporting numbers that were not true of
the live game. All three failures are worth knowing about because they are the
same shape, and this file is the place they should be recorded.

**1. Running past the final whistle.** `StickCheck` had `if (m.finished) break`
at the BOTTOM of its loop, after three `continue`s. Any frame where the ball
was loose or in flight jumped over the check, so when the match ended on one of
those — which it usually does — the loop never broke and went on counting four
thousand frames of a frozen, finished match. That is where "the ball is
airborne 59% of the match" came from. The true figure is 17%, which `BallCheck`
had been reporting all along. `CamCheck` had no `m.finished` check at all.

**2. Measuring the wrong camera.** The cut between the board view and the
broadcast camera is gated on a minimum hold measured in WALL CLOCK time. A
harness renders four thousand frames in about two seconds of real time, so the
hold never expires, the view stays on the board, and `camX` is never used.
A first attempt at measuring the pan saw the camera move on 21 frames out of
400 and nearly concluded the pan was dead. `CamFollow` now pins `closeUp` by
reflection so it measures the view it claims to.

**Anything that measures the camera off-device must force the close view.**
Setting `m.danger` is not enough.

**3. The camera really was broken, underneath all that.** With the close view
forced, the ball was off the edge of the broadcast picture **27.6% and 34.8%**
of the time on two worlds, and more than half a pitch from the camera centre at
worst. Half the match was being played off screen.

The cause was in the constants and in the comment above them. The pan ceiling
had been lowered to 0.13 units a frame to cure a camera that swept past too
fast, on the recorded reasoning that it "peaked at 8.6 pitch units a second
against players who move at under three". Players do move at under three units
a second — but the camera follows the BALL, and a struck ball travels at up to
forty. 0.13 units a frame is 4.7 units a second, so the camera could not keep
up with a firm pass, let alone a shot. (The old comment's arithmetic was wrong
too: it called that figure nine metres a second.)

Measured, both worlds, close view forced:

```
                    before          after
ball off screen     27.6 / 34.8%    4.1 / 3.2%
median lag          13.1 / 14.7     6.4 / 7.6 units
peak pan             4.7 u/s        30.6 u/s
```

`CutCheck` unchanged at 13 cuts, none under 3 s. `MotionCheck` unchanged.
`PerfCheck` worst case 10.8 ms.

```sh
java -cp build/h.jar CamFollowKt      # is the ball actually in frame
```

## Individual player conversations

Four things the manager can say to one player, on his card, one per player per
week. The design rule is that **a talk must be able to go wrong** — a
conversation that always helps is a button that adds morale, and it would make
the dressing room system pointless, because any unrest could be clicked away.

Success depends on the player's personality, the manager's manner, whether the
grievance is actually justified (good enough for the side and not playing), and
a roll. `TalkCheck` measures the spread across 1,000 players per personality:

```
personality       ENCOURAGE   CHALLENGE     EXPLAIN     PROMISE
Determined            93% +9       89% +5       78% +4       70% +8
Resolute              93% +8       94% +5       80% +3       72% +7
Temperamental         45% +4       42% -8       76% +4       70% +9
Fickle                50% +4       44% -6       74% +3       69% +9
```

Challenging a Temperamental player is a net **-8 morale** and fails more often
than it works; the same words on a Resolute one land 94% of the time. That
spread is the feature. If a change ever flattens it, the system has stopped
meaning anything.

Promises bind. A promise is six starts inside ten weeks — concrete on purpose,
because a promise that cannot be measured cannot be broken and would be free
morale. Kept: +13.1. Broken: **-32.9**, and `Player.brokenPromises` makes every
future promise to that man 28 points less likely to land.

```sh
java -cp build/h.jar TalkCheckKt      # success rates by personality, promises kept and broken
```

## The Continental Cup

Qualification was the eight best domestic clubs plus `.take(8)` off an ordered
list of foreign first divisions. Measured across three worlds, the entrants
were **always** eight English clubs plus exactly ESP, ITA, GER, FRA, NED, POR,
BEL and CRO — the first eight entries of `FOREIGN_CODES` — every season of
every career. Fifty one league nations could never qualify for anything.

Now places are allocated to *countries* by nation strength, then filled from
that country's table: the four strongest leagues in the continent send two
clubs, the next four send one, and the last four places go to the best
champions left anywhere in the continent. Those last four are genuinely
contested and move world to world.

Two mistakes worth not repeating, both of which looked right until measured:

- **Ranking the sixteen best clubs directly.** Reputation is generated per
  country, so the strongest two or three leagues own the whole top of the list
  — England sent one club to its own continental cup while Spain sent four.
- **Giving every country one place.** Europe has 32 first divisions and 16
  places, so every entrant came from a different country and league strength
  counted for nothing at all.

A thin continent fills from its own leagues before looking outside — a South
American cup with a Swedish club in it is worse than one where Brazil sends
four. Oceania has a single league, so it genuinely cannot fill sixteen and
falls back to the world's best; that fallback is deliberate, not a bug.

```sh
java -cp build/h.jar ContiCheckKt     # who qualifies, from six home countries, played to a winner
```

## Loans

A loaned player's `clubId` becomes the **borrowing** club and he moves into
their squad. `loanFromId` is the only thing that remembers who owns him. That
is the whole design: selection, tactics, the match engine, ratings and morale
all treat him as one of the borrowing club's players with no special case
anywhere, so there is nothing to keep in sync.

Two things do know about it, and both are easy to get wrong:

- **Wages.** The borrowing club pays `loanWageShare` percent; the rest stays
  with the parent as `Club.loanWageOut`, because a player who has left the
  squad is not free. `LoanCheck` asserts the two clubs together always pay
  exactly one wage, which catches a leak in either direction.
- **Development.** `applyTraining` runs over the user club's squad *plus*
  `loanedOut(c)`. Before that it ran over the squad alone, so a loaned player
  stopped developing entirely — measured at +0.00 overall across a season
  against +4.00 for the ones kept in the reserves, making a loan strictly worse
  than doing nothing.

```sh
java -cp build/h.jar LoanCheckKt      # a spell start to finish, development, save round trip
```

`LoanCheck` measures the claim the feature exists to make — that a loaned
youngster plays and improves — rather than only that the code runs. Currently
21.5 apps and +7.50 overall on loan against 17.0 apps and +4.00 in the
reserves.

`UiFlow` renders the market screen twice, once with a loan in flight and an
enquiry pending. The "out on loan" panel and the enquiry list are both behind
`isNotEmpty` checks, so an empty world walks straight past them and the screen
would pass while being broken for anyone who had actually used the feature.

## Measuring sprites honestly

The figure is isolated by rendering the same scene twice, once with the player
and once without, and differencing. A fixed background sample does not work:
the pitch has mown stripes, so the background colour changes across the very
window being measured, and every pixel reads as "figure". That is what made an
earlier measurement report a 1.04x variation.
