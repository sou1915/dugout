import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How long and how wide a side keeps itself.
 *
 * This ran ONE match and reported a single span, and it counted every outfield
 * player including the man sprinting after a loose ball forty metres from his
 * station. "Back line to front line" in football means the block — the distance
 * between the organised lines — not the distance to whoever is currently
 * chasing. Both figures are printed now, over many matches, because the gap
 * between them is the whole question: if the block is right and the full span
 * is not, the shape is fine and it is one man running.
 *
 * Real football: 30-40 m between the lines, 45-55 m wide, nearest team mate
 * usually 12-18 m away. The pitch is 105 m by 68 m.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val worldSeed = args.getOrNull(1)?.toLongOrNull() ?: 20260727L
    val world = World.build(worldSeed)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    val dt = 1f / 36f

    var full = 0.0; var block = 0.0; var wide = 0.0
    var nearestSum = 0.0; var nearestN = 0
    var samples = 0

    for (match in 0 until matches) {
        val m = MatchEngine(world, season, league[match % league.size])
        m.replaysEnabled = false
        m.start()
        var i = 0
        var guard = 0
        while (!m.finished && guard++ < 300_000) {
            m.update(dt)
            if (m.finished) break
            i++
            if (i < 300) continue
            if (i % 12 != 0) continue
            // a celebration is not a shape
            if (m.celebrationTime > 0f) continue
            for (side in 0..1) {
                val on = m.players.filter { it.onPitch && it.side == side && it.pos != Pos.GK }
                if (on.size < 8) continue
                val xs = on.map { it.x }
                full += (xs.max() - xs.min()) * 1.05
                // the block: drop the man furthest from his own group, which is
                // the one who has gone chasing
                val cx = xs.average()
                val trimmed = on.sortedBy { Math.abs(it.x - cx) }.dropLast(1).map { it.x }
                block += (trimmed.max() - trimmed.min()) * 1.05
                val ys = on.map { it.y }
                wide += (ys.max() - ys.min()) * 0.68
                samples++
                for (p in on) {
                    val d = on.filter { it.key != p.key }.minOf { q ->
                        Math.hypot(((q.x - p.x) * 1.05).toDouble(), ((q.y - p.y) * 0.68).toDouble())
                    }
                    nearestSum += d; nearestN++
                }
            }
        }
    }

    println("=== team shape: $matches matches, $samples samples ===")
    println(String.format("back to front, everyone     %.1f m", full / samples))
    println(String.format("back to front, the block    %.1f m   (furthest man dropped)", block / samples))
    println(String.format("widest to widest            %.1f m", wide / samples))
    println(String.format("nearest team mate           %.1f m", nearestSum / nearestN))
    println()
    println("a real side keeps 30-40 m between its lines and 45-55 m wide;")
    println("the nearest team mate is usually 12-18 m away")
}
