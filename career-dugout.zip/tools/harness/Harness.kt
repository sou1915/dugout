import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.World
import com.dugout.career.sim.Act
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * Drives the real renderer on a desktop JVM and writes PNGs, so visual claims
 * can be checked by measurement rather than asserted. Nothing here ships.
 */

const val W = 1280
const val H = 720

fun newEngine(seed: Long = 20260727L): MatchEngine {
    val world = World.build(seed)
    val season = Season(world)
    season.buildCalendar()
    val fx = season.fixtures.first { it.comp == 0 }
    return MatchEngine(world, season, fx)
}

/**
 * [warm] paint passes are run on the same view before the one that is kept.
 * The match camera eases between the board and the broadcast view over several
 * frames, and a view created fresh starts on the board, so anything measuring
 * the close view has to let it settle first. Warming a different instance does
 * not work: the easing is held on the view itself.
 */
fun render(m: MatchEngine, warm: Int = 0, tune: (MatchView) -> Unit = {}): Bitmap {
    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(Context(), m)
    tune(v)
    repeat(warm) { v.renderAt(c, W, H) }
    v.renderAt(c, W, H)
    return bmp
}

fun save(b: Bitmap, path: String) {
    val f = File(path)
    f.parentFile?.mkdirs()
    ImageIO.write(b.image, "png", f)
}

/* ------------------------------------------------------ SPRITE PROFILING */

/**
 * Puts one player alone on the pitch facing a given compass direction and
 * reports, for every scanline of his figure, how wide he is. A direction that
 * genuinely changes the sprite should change the torso rows a great deal and
 * the head and shadow rows hardly at all — which is exactly what the summary
 * below is there to expose.
 */
class Profile(val rows: IntArray, val top: Int, val bottom: Int) {
    val height get() = bottom - top + 1
    fun maxWidth() = rows.max()
    /** Widest row inside a fractional band of the figure, measured from the top. */
    fun bandWidth(a: Float, b: Float): Int {
        val lo = top + (height * a).toInt()
        val hi = top + (height * b).toInt()
        var w = 0
        for (y in lo..minOf(hi, bottom)) w = maxOf(w, rows[y])
        return w
    }
}

fun profileFigure(m: MatchEngine, dirIndex: Int, running: Boolean, out: String?): Profile {
    // one man, centre pitch, everyone else off
    for (p in m.players) p.onPitch = false
    val p = m.players.first { it.side == 0 && it.pos != 0 }
    p.onPitch = true
    p.x = 50f; p.y = 50f
    p.action = Act.RUN
    p.speedNow = if (running) 4f else 0f
    // full stride when running, so the leg scissor is actually under test
    p.runPhase = if (running) 3.02f else 0f
    p.facing = (dirIndex * 45f - 90f) * (Math.PI.toFloat() / 180f)
    m.ball.holder = null
    m.ball.x = 20f; m.ball.y = 90f
    m.refCard = 0
    m.celebrateKey = null
    m.banner = null
    m.flash = 0f; m.shake = 0f

    m.danger = 1f
    m.shake = 0f
    // The camera eases into the close view over several frames. Measuring
    // before it has settled compares two renders taken at different zoom
    // levels, and then the whole pitch reads as "figure".
    val withMan = render(m, 40) { it.followBall = false }
    if (out != null) save(withMan, out)

    // The identical scene with nobody on it. Differencing the two isolates the
    // figure exactly, which a fixed background sample cannot do on a striped
    // pitch: the mown bands change colour across the very window being measured.
    p.onPitch = false
    val empty = render(m, 40) { it.followBall = false }
    if (out != null) save(empty, "out/_empty.png")
    p.onPitch = true

    val a = withMan.image
    val b = empty.image
    val cx = W / 2
    val cy = (H * 0.46f).toInt()
    val halfW = 90
    val yTop = maxOf(0, cy - 130)
    val yBot = minOf(H, cy + 40)

    val rows = IntArray(H)
    var top = -1
    var bottom = -1
    for (y in yTop until yBot) {
        var count = 0
        for (x in cx - halfW until cx + halfW) {
            if (colourDist(a.getRGB(x, y), b.getRGB(x, y)) > 24) count++
        }
        rows[y] = count
        if (count > 0) { if (top < 0) top = y; bottom = y }
    }
    return Profile(rows, if (top < 0) yTop else top, if (bottom < 0) yBot else bottom)
}

fun colourDist(a: Int, b: Int): Int {
    val dr = ((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)
    val dg = ((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)
    val db = (a and 0xFF) - (b and 0xFF)
    return maxOf(Math.abs(dr), Math.abs(dg), Math.abs(db))
}

fun spriteReport(running: Boolean) {
    val label = if (running) "RUNNING" else "STANDING"
    println("=== 8-direction sprite profile ($label) ===")
    println("dir  facing        whole   head-band  torso-band  legs-band")
    val whole = ArrayList<Int>()
    val torso = ArrayList<Int>()
    val head = ArrayList<Int>()
    val legs = ArrayList<Int>()
    val hgt = ArrayList<Int>()
    for (d in 0 until 8) {
        val m = newEngine()
        val pr = profileFigure(m, d, running, "out/sprite_${label.lowercase()}_$d.png")
        // the figure runs head at the top, boots at the bottom
        val h = pr.bandWidth(0.05f, 0.25f)
        val t = pr.bandWidth(0.32f, 0.62f)
        val l = pr.bandWidth(0.70f, 0.95f)
        whole.add(pr.maxWidth()); torso.add(t); head.add(h); legs.add(l); hgt.add(pr.height)
        println(String.format("%2d   %-12s  %4d    %4d       %4d        %4d", d, COMPASS[d], pr.maxWidth(), h, t, l))
    }
    println()
    println(String.format("figure height     %d px = %.2f%% of view width  (reference 4.10%%)",
        hgt.max(), hgt.max() * 100f / W))
    println(String.format("whole-figure width varies %.2fx  (max %d / min %d)",
        whole.max().toFloat() / whole.min(), whole.max(), whole.min()))
    println(String.format("torso width       varies %.2fx  (max %d / min %d)",
        torso.max().toFloat() / torso.min(), torso.max(), torso.min()))
    println(String.format("head width        varies %.2fx  (max %d / min %d)",
        head.max().toFloat() / head.min(), head.max(), head.min()))
    println(String.format("leg spread        varies %.2fx  (max %d / min %d)",
        legs.max().toFloat() / legs.min(), legs.max(), legs.min()))
    println()
}

val COMPASS = arrayOf("away", "away-right", "right", "toward-right", "toward", "toward-left", "left", "away-left")

/* --------------------------------------------------------- MATCH FRAMES */

fun frames() {
    val m = newEngine()
    m.start()
    var shots = 0
    for (i in 0 until 4000) {
        m.update(1f / 30f)
        if (i % 900 == 0) {
            save(render(m), "out/frame_${i / 900}.png")
            shots++
        }
        if (m.finished) break
    }
    println("wrote $shots match frames, final score ${m.score[0]}-${m.score[1]}, clock ${m.clock.toInt()}'")
}

/**
 * Runs until a goal goes in, then captures the replay and the celebration that
 * follows, so both can be checked as pictures rather than taken on trust.
 */
fun goalScene() {
    val m = newEngine()
    m.start()
    var ticks = 0
    while (!m.finished && m.replay == null && ticks < 400_000) {
        m.sound.clear()
        m.update(1f / 30f)
        if (!m.running && !m.finished) m.start()
        ticks++
    }
    val rep = m.replay
    if (rep == null) { println("no goal found"); return }
    println("goal at ${m.clock.toInt()}' -> ${m.score[0]}-${m.score[1]}")
    println("replay frames captured: ${rep.size}")
    println("celebration seconds: ${m.celebrationTime}")

    // the replay itself
    var shot = 0
    for (i in rep.indices step (maxOf(1, rep.size / 6))) {
        m.replayIndex = i
        save(render(m), "out/replay_${shot}.png")
        shot++
    }
    println("wrote $shot replay frames")

    // then let the celebration run, with the replay cleared
    m.replay = null
    m.replayIndex = 0
    val scorerKey = m.celebrateKey
    var c = 0
    for (step in 0 until 7) {
        for (k in 0 until 22) { m.sound.clear(); m.update(1f / 30f) }
        save(render(m), "out/celebrate_$c.png")
        c++
    }
    println("wrote $c celebration frames")

    // did the team actually converge on him?
    val scorer = m.players.firstOrNull { it.key == scorerKey }
    if (scorer != null) {
        val mates = m.players.filter { it.onPitch && it.side == scorer.side && it.key != scorer.key && it.pos != 0 }
        val d = mates.map { Math.hypot((it.x - scorer.x).toDouble(), (it.y - scorer.y).toDouble()) }.sorted()
        println(String.format("scorer at (%.0f, %.0f)", scorer.x, scorer.y))
        println(String.format("nearest 5 team-mates average %.1f units away", d.take(5).average()))
        println(String.format("all %d outfield team-mates average %.1f units away", d.size, d.average()))
        println("closest: " + d.take(5).joinToString(", ") { String.format("%.0f", it) })
    }
}

/**
 * Sweeps a side-on runner through a full stride and reports how far apart the
 * boots get and how much the body rises and falls. A splayed, robotic gait
 * shows up as a huge constant spread with no vertical movement at all.
 */
fun gaitReport() {
    println("=== stride cycle, side-on runner ===")
    println("phase   boot-span  figure-top  (boot extent in px, top edge in px)")
    val spreads = ArrayList<Int>()
    val tops = ArrayList<Int>()
    for (k in 0 until 8) {
        val m = newEngine()
        for (pp in m.players) pp.onPitch = false
        val p = m.players.first { it.side == 0 && it.pos != 0 }
        p.onPitch = true
        p.x = 50f; p.y = 50f
        p.action = Act.RUN
        p.speedNow = 4f
        p.runPhase = (k / 8f) * (2f * Math.PI.toFloat()) / 0.52f
        p.facing = 0f                       // straight across the camera
        m.ball.holder = null; m.ball.x = 20f; m.ball.y = 90f
        m.refCard = 0; m.celebrateKey = null; m.banner = null

        m.danger = 1f
        m.shake = 0f
        // The camera eases into the close view over several frames. Measuring
        // before it has settled compares two renders taken at different zoom
        // levels, and then the whole pitch reads as "figure".
        val a = render(m, 40) { it.followBall = false }
        save(a, "out/gait_$k.png")
        p.onPitch = false
        val b = render(m, 40) { it.followBall = false }
        p.onPitch = true
        val cx = W / 2; val cy = (H * 0.46f).toInt()

        // The boots are the only near-black thing on the figure, so find those
        // rather than any changed pixel: the ground shadow is much wider than
        // the stride and would otherwise be what got measured.
        var bootL = Int.MAX_VALUE; var bootR = Int.MIN_VALUE
        var top = -1
        for (y in maxOf(0, cy - 150) until minOf(H, cy + 45)) {
            for (x in cx - 110 until cx + 110) {
                val q = a.image.getRGB(x, y)
                if (colourDist(q, b.image.getRGB(x, y)) <= 24) continue
                if (top < 0) top = y
                val rr = (q shr 16) and 0xFF
                val gg = (q shr 8) and 0xFF
                val bb = q and 0xFF
                if (rr < 55 && gg < 55 && bb < 70) {
                    if (x < bootL) bootL = x
                    if (x > bootR) bootR = x
                }
            }
        }
        val legs = if (bootR < bootL) 0 else bootR - bootL + 1
        spreads.add(legs); tops.add(top)
        println(String.format("%3d deg %8d %11d", k * 45, legs, top))
    }
    println()
    println(String.format("boot span    min %d  max %d  (varies %.2fx through the stride)",
        spreads.min(), spreads.max(), spreads.max().toFloat() / spreads.min()))
    println(String.format("body bob     %d px between highest and lowest point",
        tops.max() - tops.min()))
}

fun main(args: Array<String>) {
    when (args.firstOrNull() ?: "sprites") {
        "sprites" -> { spriteReport(false); spriteReport(true) }
        "goal" -> goalScene()
        "frames" -> frames()
        "gait" -> gaitReport()
        "views" -> {
            // play on until the two views can both be caught in the act
            val m = newEngine()
            m.start()
            var board = 0; var close = 0
            var lowSeen = 0; var highSeen = 0
            var frames = 0
            for (i in 0 until 40000) {
                m.update(1f / 36f)
                frames++
                if (m.danger < 0.30f) {
                    lowSeen++
                    if (board < 2 && lowSeen % 40 == 0) { save(render(m), "out/view_board_$board.png"); board++ }
                }
                if (m.danger > 0.85f) {
                    highSeen++
                    if (close < 2 && highSeen % 12 == 0) { save(render(m), "out/view_close_$close.png"); close++ }
                }
                if (board >= 2 && close >= 2) break
                if (m.finished) break
            }
            println("wrote $board board frames and $close close frames over $frames ticks")
        }
        "danger" -> {
            val m = newEngine()
            m.start()
            var lo = 0; var mid = 0; var hi = 0; var n = 0
            var cuts = 0; var wasClose = false
            for (i in 0 until 60000) {
                m.update(1f / 36f)
                n++
                when {
                    m.danger < 0.30f -> lo++
                    m.danger < 0.55f -> mid++
                    else -> hi++
                }
                val close = m.danger >= 0.55f
                if (close != wasClose) { cuts++; wasClose = close }
                if (m.finished) break
            }
            println(String.format("board view %.0f%% of the match, between %.0f%%, broadcast %.0f%%",
                lo * 100.0 / n, mid * 100.0 / n, hi * 100.0 / n))
            println("cuts between the two: $cuts over ${m.clock.toInt()} minutes")
        }
        "scenes" -> {
            // force the set pieces so they can be looked at, rather than
            // waiting for a match to produce one by chance
            val m = newEngine()
            m.start()
            for (i in 0 until 300) m.update(1f / 36f)

            m.scene = com.dugout.career.sim.Scene.PENALTY
            m.sceneTime = 2f
            m.ball.x = 88f; m.ball.y = 50f; m.ball.t = 1f
            save(render(m), "out/scene_penalty.png")

            m.scene = com.dugout.career.sim.Scene.NONE
            m.woodwork = 0.9f; m.woodworkBar = true
            m.woodworkX = 99f; m.woodworkY = 50f
            save(render(m), "out/scene_crossbar.png")
            m.woodwork = 0.55f; m.woodworkBar = false
            m.woodworkY = 46.4f
            save(render(m), "out/scene_post.png")

            m.woodwork = 0f
            // showRef() normally sets these; the capture has to as well or the
            // referee is stood at the origin and the card never comes on screen
            m.refX = 54f; m.refY = 47f
            m.refCard = 1
            save(render(m), "out/scene_yellow.png")
            m.refCard = 2
            save(render(m), "out/scene_red.png")

            m.refCard = 0
            m.scene = com.dugout.career.sim.Scene.CORNER
            m.sceneTime = 1.5f
            m.cornerFlagX = 100f; m.cornerFlagY = 4f
            m.ball.x = 100f; m.ball.y = 4f; m.ball.t = 1f
            save(render(m), "out/scene_corner.png")

            m.scene = com.dugout.career.sim.Scene.NONE
            val star = m.players.first { it.onPitch && it.side == 0 && it.pos != 0 }
            m.skill = 0.5f; m.skillKey = star.key; m.skillName = "ELASTICO"
            m.ball.x = star.x; m.ball.y = star.y
            save(render(m), "out/scene_skill.png")
            println("wrote 7 scene frames")
        }
        "lineup" -> {
            val m = newEngine()
            m.start()
            var shot = 0
            for (i in 0 until 400) {
                m.update(1f / 36f)
                if (i % 22 == 0 && shot < 4) { save(render(m), "out/lineup_$shot.png"); shot++ }
                if (m.lineupTime <= 0f && shot >= 4) break
            }
            println("walkout frames: $shot, lineupTime now ${m.lineupTime}, clock ${m.clock}")
        }
        else -> println("modes: sprites | frames")
    }
}
