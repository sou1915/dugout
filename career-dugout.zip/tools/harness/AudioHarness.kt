import com.dugout.career.core.Synth
import java.io.File
import java.io.DataOutputStream
import java.io.BufferedOutputStream
import java.io.FileOutputStream

/** Writes 16-bit PCM WAVs so the generated sounds can be listened to and measured. */
fun writeWav(path: String, data: ShortArray, channels: Int) {
    val f = File(path); f.parentFile?.mkdirs()
    val bytes = data.size * 2
    val out = DataOutputStream(BufferedOutputStream(FileOutputStream(f)))
    fun le16(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
    fun le32(v: Int) { le16(v and 0xFFFF); le16((v ushr 16) and 0xFFFF) }
    out.writeBytes("RIFF"); le32(36 + bytes); out.writeBytes("WAVE")
    out.writeBytes("fmt "); le32(16); le16(1); le16(channels)
    le32(Synth.RATE); le32(Synth.RATE * channels * 2); le16(channels * 2); le16(16)
    out.writeBytes("data"); le32(bytes)
    for (s in data) le16(s.toInt() and 0xFFFF)
    out.close()
}

fun rms(d: ShortArray): Double {
    var a = 0.0
    for (s in d) a += (s.toDouble() / 32768.0) * (s.toDouble() / 32768.0)
    return Math.sqrt(a / d.size)
}

fun peak(d: ShortArray): Double {
    var p = 0
    for (s in d) p = maxOf(p, Math.abs(s.toInt()))
    return p / 32768.0
}

/** Coarse spectral centroid via a slow DFT over a handful of bands. */
fun centroid(d: ShortArray): Double {
    val bands = doubleArrayOf(80.0, 160.0, 320.0, 640.0, 1280.0, 2560.0, 5120.0, 9000.0)
    var num = 0.0; var den = 0.0
    val n = minOf(d.size, Synth.RATE)
    for (f in bands) {
        var re = 0.0; var im = 0.0
        val w = 2 * Math.PI * f / Synth.RATE
        for (i in 0 until n step 2) {
            val v = d[i].toDouble()
            re += v * Math.cos(w * i); im += v * Math.sin(w * i)
        }
        val mag = Math.sqrt(re * re + im * im)
        num += mag * f; den += mag
    }
    return if (den == 0.0) 0.0 else num / den
}

val NAMES = arrayOf(
    "whistle_short", "whistle_long", "kick", "kick_hard", "net",
    "post", "roar_goal", "groan", "applause", "ooh", "tackle"
)

fun main() {
    val t0 = System.nanoTime()
    val bank = Synth.bank(20260727L)
    val genMs = (System.nanoTime() - t0) / 1e6

    println("=== procedural sound bank ===")
    println(String.format("generated %d sounds in %.0f ms", bank.size, genMs))
    var bytes = 0
    for (b in bank) bytes += b.size * 2
    println(String.format("resident size %.2f MB  (no audio assets shipped)", bytes / 1048576.0))
    println()
    println(String.format("%-14s %7s %7s %7s %9s", "sound", "secs", "rms", "peak", "centroid"))
    for (i in bank.indices) {
        val b = bank[i]
        writeWav("out/audio/${NAMES[i]}.wav", b, 1)
        println(String.format("%-14s %7.2f %7.3f %7.3f %8.0fHz",
            NAMES[i], b.size.toDouble() / Synth.RATE, rms(b), peak(b), centroid(b)))
    }

    // the live mixer: a stretch of crowd with events fired into it
    val mix = Synth.Mixer(20260727L)
    val seconds = 12
    val frames = Synth.RATE * seconds
    val out = ShortArray(frames * 2)
    val chunk = 1024
    var done = 0
    val tmp = ShortArray(chunk * 2)
    var fired = 0
    val t1 = System.nanoTime()
    while (done < frames) {
        val n = minOf(chunk, frames - done)
        val sec = done.toDouble() / Synth.RATE
        when {
            fired == 0 && sec > 0.5 -> { mix.play(Synth.Sfx.WHISTLE_SHORT); fired++ }
            fired == 1 && sec > 2.0 -> { mix.crowd.target = 0.55f; mix.play(Synth.Sfx.KICK, 0.9f, -0.4f); fired++ }
            fired == 2 && sec > 3.2 -> { mix.play(Synth.Sfx.OOH, 1f); fired++ }
            fired == 3 && sec > 5.0 -> { mix.play(Synth.Sfx.KICK_HARD, 1f, 0.3f); fired++ }
            fired == 4 && sec > 5.3 -> { mix.play(Synth.Sfx.POST); fired++ }
            fired == 5 && sec > 7.0 -> {
                mix.play(Synth.Sfx.KICK_HARD, 1f); fired++
            }
            fired == 6 && sec > 7.25 -> {
                mix.play(Synth.Sfx.NET); mix.play(Synth.Sfx.ROAR)
                mix.crowd.target = 1.0f; fired++
            }
            fired == 7 && sec > 10.0 -> { mix.play(Synth.Sfx.APPLAUSE, 0.8f); fired++ }
        }
        mix.render(tmp, n)
        System.arraycopy(tmp, 0, out, done * 2, n * 2)
        done += n
    }
    val mixMs = (System.nanoTime() - t1) / 1e6
    writeWav("out/audio/match_mix.wav", out, 2)

    println()
    println(String.format("live mix: %d s of stereo rendered in %.0f ms  (%.1fx realtime)",
        seconds, mixMs, seconds * 1000.0 / mixMs))
    println(String.format("mix rms %.3f  peak %.3f  (peak < 1.000 means nothing clipped)",
        rms(out), peak(out)))

    // silence check: the bed must actually be audible on its own
    val bedOnly = Synth.Mixer(99L)
    val bedBuf = ShortArray(Synth.RATE * 2)
    bedOnly.render(bedBuf, Synth.RATE)
    println(String.format("crowd bed alone: rms %.4f  peak %.4f", rms(bedBuf), peak(bedBuf)))
}
