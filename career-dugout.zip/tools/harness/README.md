# Off-device measurement harness

The renderer, the engine and the sound synthesis all run on a desktop JVM here,
so a visual or audio claim can be checked by measurement instead of asserted.
Nothing in this folder ships in the APK.

## Why it exists

`core/` and the simulation are free of Android imports, so they compile as they
are. `ui/MatchView.kt` needs only a handful of graphics classes, which `shim/`
supplies over Java2D. `Theme` is stubbed to the two constants the renderer
actually reads.

## Running it

Needs a JDK and `kotlinc` on the path. From the repository root:

```sh
SRC=app/src/main/java/com/dugout/career
SIM="$SRC/core/*.kt $SRC/sim/MatchEngine.kt $SRC/sim/League.kt $SRC/sim/Career.kt"

# renderer: sprite profiles, goal sequence, match frames  -> ./out
kotlinc -nowarn $SIM $SRC/ui/MatchView.kt tools/harness/shim/*.kt \
    tools/harness/Harness.kt -include-runtime -d /tmp/harness.jar
java -Djava.awt.headless=true -jar /tmp/harness.jar sprites   # 8-direction measurement
java -Djava.awt.headless=true -jar /tmp/harness.jar goal      # celebration + replay
java -Djava.awt.headless=true -jar /tmp/harness.jar frames    # ordinary play

# sound: writes WAVs and reports level and spectrum -> ./out/audio
kotlinc -nowarn $SRC/core/*.kt tools/harness/AudioHarness.kt -include-runtime -d /tmp/audio.jar
java -jar /tmp/audio.jar

# balance: the 400-match check the brief requires after any engine edit
kotlinc -nowarn $SIM tools/harness/BalanceHarness.kt -include-runtime -d /tmp/bal.jar
java -jar /tmp/bal.jar 400
```

`BalanceBase.kt` is the same check pointed at an untouched copy of the engine,
for before-and-after comparison. `QuickSimCheck.kt` measures the quick
simulation, which should agree with the live engine.

### Read the balance figure carefully

`BalanceHarness` walks the league fixture list in order, and the top flight
fills the first 380 entries. So the sample size decides which division is
being measured:

```
n = 400    almost entirely the top division
n = 2400   the whole five division pyramid
```

Goals per game differ by division, as they should:

```
Premier Division   2.56      League Two        2.11
Championship       2.28      National League   1.93
Championship       2.17      whole pyramid     2.21
```

The 2.5 to 2.7 target in the brief is a top division figure, so quote the
400 match run against it. `DivisionBalance.kt` prints the breakdown and is the
honest way to check a change has not shifted one division while flattering
another.

## Running the actual screens

`UiFlow.kt` builds a real MainActivity on the Java2D shim and drives it through
every screen: the start choice, the job hunt with no club, applying for a job,
each tab in the rail, a player card, being sacked, and applying again.

```sh
java -Djava.awt.headless=true -cp build/uf.jar UiFlowKt
```

It cannot say whether anything is laid out correctly. What it does catch is the
class of bug that had been reaching the device: a lateinit field that is only
assigned on one route, or a `userClub!!` on a path where there is no club. Both
crashes on the out of work screen were of exactly that shape. Run this before
shipping a build.

## Type checking the app layer

`MainActivity.kt`, `Theme.kt` and `Icons.kt` need the Android UI classes, so
they used to be compiled only by the CI build — about five and a half thousand
lines that could not be checked before a push. The shim now covers enough of
`android.app`, `android.view`, `android.widget`, `android.media`,
`android.graphics.drawable`, `android.os`, `android.text` and `android.util`
for the whole app to be type checked locally:

```sh
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt -d /tmp/uicheck
```

This proves the code compiles. It does not prove it lays out or draws
correctly on a device, so the CI build is still the real test of appearance.

Note the shim's `Theme` stub in `ThemeStub.kt` is only for the renderer
harness; do not pass it alongside the real `ui/Theme.kt`.

## The sixty league world

`WorldCheck` reports the shape. As measured on seed 20260727:

```
1,236 clubs, 32,136 players, built in 629 ms
60 countries with a league, 185 nationalities
0 duplicate club names, 0 duplicate player names, 0 orphan clubs
save 7.54 MB, round trip clean
faces 100% unique, closest pair 3 of 10 features apart, assigned in 895 ms
memory: world 20.7 MB, faces 3.7 MB, fixtures 0.1 MB
```

A country's shape comes from `FOREIGN_SHAPE` in `World.kt`: twenty one countries
have three divisions of twelve, thirty eight have a single division of ten, and
England keeps its five of twenty. Anything not listed falls back to one division
of ten rather than crashing, which means a country added to `FOREIGN_CODES` and
forgotten in `FOREIGN_SHAPE` will build but will be quietly wrong — `PickerCheck`
is what catches that.

`FOREIGN_CODES` is walked in order to lay out the foreign divisions, and a
division id is what a save stores against every club. **Append to it, never
insert**: inserting moves every club after the insertion point into a different
country's league on the next load.

### Harnesses added with it

```sh
java -cp build/h.jar GoalPlaceKt 60      # where is the ball when a goal is given
java -cp build/h.jar SmallLeagueKt       # a season in a one division country
java -cp build/h.jar PickerCheckKt       # continent grouping, shape table vs reality
java -cp build/h.jar FlagCheckKt         # the computed flag emoji are well formed
```

`GoalPlace` exists because `ReplayCheck` used to return after the first goal of
the first seed, so it could pass while 69% of goals in the game were being
awarded with the ball in midfield. Any check that stops at the first sample is
worth this little scrutiny.

`SmallLeague` exists because every country used to have three tiers. The
promotion ladder pairs adjacent divisions, the fixture builder has to give ten
clubs a full calendar, and neither had ever seen a pyramid with nothing above
or below it.

## Loans

A loaned player's `clubId` becomes the **borrowing** club and he moves into
their squad. `loanFromId` is the only thing that remembers who owns him. That
is the whole design: selection, tactics, the match engine, ratings and morale
all treat him as one of the borrowing club's players with no special case
anywhere, so there is nothing to keep in sync.

Two things do know about it, and both are easy to get wrong:

- **Wages.** The borrowing club pays `loanWageShare` percent; the rest stays
  with the parent as `Club.loanWageOut`, because a player who has left the
  squad is not free. `LoanCheck` asserts the two clubs together always pay
  exactly one wage, which catches a leak in either direction.
- **Development.** `applyTraining` runs over the user club's squad *plus*
  `loanedOut(c)`. Before that it ran over the squad alone, so a loaned player
  stopped developing entirely — measured at +0.00 overall across a season
  against +4.00 for the ones kept in the reserves, making a loan strictly worse
  than doing nothing.

```sh
java -cp build/h.jar LoanCheckKt      # a spell start to finish, development, save round trip
```

`LoanCheck` measures the claim the feature exists to make — that a loaned
youngster plays and improves — rather than only that the code runs. Currently
21.5 apps and +7.50 overall on loan against 17.0 apps and +4.00 in the
reserves.

`UiFlow` renders the market screen twice, once with a loan in flight and an
enquiry pending. The "out on loan" panel and the enquiry list are both behind
`isNotEmpty` checks, so an empty world walks straight past them and the screen
would pass while being broken for anyone who had actually used the feature.

## Measuring sprites honestly

The figure is isolated by rendering the same scene twice, once with the player
and once without, and differencing. A fixed background sample does not work:
the pitch has mown stripes, so the background colour changes across the very
window being measured, and every pixel reads as "figure". That is what made an
earlier measurement report a 1.04x variation.
