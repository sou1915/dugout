# Off-device measurement harness

The renderer, the engine and the sound synthesis all run on a desktop JVM here,
so a visual or audio claim can be checked by measurement instead of asserted.
Nothing in this folder ships in the APK.

## Why it exists

`core/` and the simulation are free of Android imports, so they compile as they
are. `ui/MatchView.kt` needs only a handful of graphics classes, which `shim/`
supplies over Java2D. `Theme` is stubbed to the two constants the renderer
actually reads.

## Running it

Needs a JDK and `kotlinc` on the path. From the repository root:

```sh
SRC=app/src/main/java/com/dugout/career
SIM="$SRC/core/*.kt $SRC/sim/MatchEngine.kt $SRC/sim/League.kt $SRC/sim/Career.kt"

# renderer: sprite profiles, goal sequence, match frames  -> ./out
kotlinc -nowarn $SIM $SRC/ui/MatchView.kt tools/harness/shim/*.kt \
    tools/harness/Harness.kt -include-runtime -d /tmp/harness.jar
java -Djava.awt.headless=true -jar /tmp/harness.jar sprites   # 8-direction measurement
java -Djava.awt.headless=true -jar /tmp/harness.jar goal      # celebration + replay
java -Djava.awt.headless=true -jar /tmp/harness.jar frames    # ordinary play

# sound: writes WAVs and reports level and spectrum -> ./out/audio
kotlinc -nowarn $SRC/core/*.kt tools/harness/AudioHarness.kt -include-runtime -d /tmp/audio.jar
java -jar /tmp/audio.jar

# balance: the 400-match check the brief requires after any engine edit
kotlinc -nowarn $SIM tools/harness/BalanceHarness.kt -include-runtime -d /tmp/bal.jar
java -jar /tmp/bal.jar 400
```

`BalanceBase.kt` is the same check pointed at an untouched copy of the engine,
for before-and-after comparison. `QuickSimCheck.kt` measures the quick
simulation, which should agree with the live engine.

### Read the balance figure carefully

`BalanceHarness` walks the league fixture list in order, and the top flight
fills the first 380 entries. So the sample size decides which division is
being measured:

```
n = 400    almost entirely the top division
n = 2400   the whole five division pyramid
```

Goals per game differ by division, as they should:

```
Premier Division   2.56      League Two        2.11
Championship       2.28      National League   1.93
Championship       2.17      whole pyramid     2.21
```

The 2.5 to 2.7 target in the brief is a top division figure, so quote the
400 match run against it. `DivisionBalance.kt` prints the breakdown and is the
honest way to check a change has not shifted one division while flattering
another.

## Type checking the app layer

`MainActivity.kt`, `Theme.kt` and `Icons.kt` need the Android UI classes, so
they used to be compiled only by the CI build — about five and a half thousand
lines that could not be checked before a push. The shim now covers enough of
`android.app`, `android.view`, `android.widget`, `android.media`,
`android.graphics.drawable`, `android.os`, `android.text` and `android.util`
for the whole app to be type checked locally:

```sh
SRC=app/src/main/java/com/dugout/career
kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
    tools/harness/shim/Android*.kt -d /tmp/uicheck
```

This proves the code compiles. It does not prove it lays out or draws
correctly on a device, so the CI build is still the real test of appearance.

Note the shim's `Theme` stub in `ThemeStub.kt` is only for the renderer
harness; do not pass it alongside the real `ui/Theme.kt`.

## Measuring sprites honestly

The figure is isolated by rendering the same scene twice, once with the player
and once without, and differencing. A fixed background sample does not work:
the pitch has mown stripes, so the background colour changes across the very
window being measured, and every pixel reads as "figure". That is what made an
earlier measurement report a 1.04x variation.
