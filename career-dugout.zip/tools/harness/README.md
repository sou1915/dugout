# Off-device measurement harness

The renderer, the engine and the sound synthesis all run on a desktop JVM here,
so a visual or audio claim can be checked by measurement instead of asserted.
Nothing in this folder ships in the APK.

## Why it exists

`core/` and the simulation are free of Android imports, so they compile as they
are. `ui/MatchView.kt` needs only a handful of graphics classes, which `shim/`
supplies over Java2D. `Theme` is stubbed to the two constants the renderer
actually reads.

## Running it

Needs a JDK and `kotlinc` on the path. From the repository root:

```sh
SRC=app/src/main/java/com/dugout/career
SIM="$SRC/core/*.kt $SRC/sim/MatchEngine.kt $SRC/sim/League.kt $SRC/sim/Career.kt"

# renderer: sprite profiles, goal sequence, match frames  -> ./out
kotlinc -nowarn $SIM $SRC/ui/MatchView.kt tools/harness/shim/*.kt \
    tools/harness/Harness.kt -include-runtime -d /tmp/harness.jar
java -Djava.awt.headless=true -jar /tmp/harness.jar sprites   # 8-direction measurement
java -Djava.awt.headless=true -jar /tmp/harness.jar goal      # celebration + replay
java -Djava.awt.headless=true -jar /tmp/harness.jar frames    # ordinary play

# sound: writes WAVs and reports level and spectrum -> ./out/audio
kotlinc -nowarn $SRC/core/*.kt tools/harness/AudioHarness.kt -include-runtime -d /tmp/audio.jar
java -jar /tmp/audio.jar

# balance: the 400-match check the brief requires after any engine edit
kotlinc -nowarn $SIM tools/harness/BalanceHarness.kt -include-runtime -d /tmp/bal.jar
java -jar /tmp/bal.jar 400
```

`BalanceBase.kt` is the same check pointed at an untouched copy of the engine,
for before-and-after comparison. `QuickSimCheck.kt` measures the quick
simulation, which should agree with the live engine.

## Measuring sprites honestly

The figure is isolated by rendering the same scene twice, once with the player
and once without, and differencing. A fixed background sample does not work:
the pitch has mown stripes, so the background colour changes across the very
window being measured, and every pixel reads as "figure". That is what made an
earlier measurement report a 1.04x variation.
