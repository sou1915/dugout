import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How spread out a team actually is. If the shape spans the whole pitch then
 * long passes are structural: no amount of choosing a nearer receiver can help
 * when the nearest man is forty metres away.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f

    var samples = 0
    var lenSum = 0.0      // back line to front line, metres
    var widSum = 0.0
    var nearestSum = 0.0
    var nearestN = 0
    var bothTeamsSpan = 0.0

    for (i in 0 until 6000) {
        m.update(dt)
        if (i < 300) continue
        if (i % 12 != 0) continue
        for (side in 0..1) {
            val on = m.players.filter { it.onPitch && it.side == side && it.pos != Pos.GK }
            if (on.size < 8) continue
            val xs = on.map { it.x }
            val ys = on.map { it.y }
            lenSum += (xs.max() - xs.min()) * 1.05
            widSum += (ys.max() - ys.min()) * 0.68
            samples++
            for (p in on) {
                val d = on.filter { it.key != p.key }.minOf { q ->
                    Math.hypot(((q.x - p.x) * 1.05).toDouble(), ((q.y - p.y) * 0.68).toDouble())
                }
                nearestSum += d; nearestN++
            }
        }
        val all = m.players.filter { it.onPitch && it.pos != Pos.GK }
        bothTeamsSpan += (all.maxOf { it.x } - all.minOf { it.x }) * 1.05
        if (m.finished) break
    }
    println("=== team shape, averaged over a match ===")
    println(String.format("back line to front line   %.1f m", lenSum / samples))
    println(String.format("widest to widest          %.1f m", widSum / samples))
    println(String.format("nearest team mate         %.1f m", nearestSum / nearestN))
    println(String.format("both teams, end to end    %.1f m", bothTeamsSpan / (samples / 2.0)))
    println()
    println("a real side keeps 30-40 m between its lines and 45-55 m wide;")
    println("the nearest team mate is usually 12-18 m away")
    println("the pitch itself is 105 m by 68 m")
}
