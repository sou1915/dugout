import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Pass geometry over many matches, so the direction split can be trusted. */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 60
    var fwd = 0; var side = 0; var back = 0
    val lens = ArrayList<Double>()
    val speeds = ArrayList<Double>()
    var opening = 0; var within = 0

    for (seed in 0 until matches) {
        val world = World.build(7000L + seed)
        val season = Season(world); season.buildCalendar()
        val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
        m.replaysEnabled = false
        m.speed = 4f
        m.start()
        var wasFlying = false
        var guard = 0
        while (!m.finished && guard++ < 120_000) {
            val bx = m.ball.x; val by = m.ball.y
            m.update(1f / 36f)
            if (!wasFlying && m.ball.t < 1f && m.ball.holder != null) {
                val dx = (m.ball.toX - bx) * 1.05
                val dy = (m.ball.toY - by) * 0.68
                val len = Math.sqrt(dx * dx + dy * dy)
                if (len > 1.5) {
                    lens.add(len); speeds.add(len / m.ball.duration)
                    if (m.phaseStepPublic <= 1) opening++ else within++
                    val toGoal = if (m.possessionSide == 0) dx else -dx
                    when {
                        toGoal > len * 0.35 -> fwd++
                        toGoal < -len * 0.35 -> back++
                        else -> side++
                    }
                }
            }
            wasFlying = m.ball.t < 1f
        }
    }
    val n = lens.size
    println("=== $matches matches, $n passes ===")
    println(String.format("mean %.1f m   median %.1f m   mean speed %.1f m/s",
        lens.average(), lens.sorted()[n / 2], speeds.average()))
    println(String.format("under 10 m %.0f%%   10-25 m %.0f%%   25-40 m %.0f%%   over 40 m %.0f%%",
        lens.count { it < 10 } * 100.0 / n, lens.count { it in 10.0..25.0 } * 100.0 / n,
        lens.count { it in 25.0..40.0 } * 100.0 / n, lens.count { it > 40 } * 100.0 / n))
    println(String.format("forward %.0f%%   sideways %.0f%%   backward %.0f%%",
        fwd * 100.0 / n, side * 100.0 / n, back * 100.0 / n))
    println(String.format("opening balls %d, passes within a move %d", opening, within))
    println()
    println("real football: mean about 18 m, roughly 45 forward / 35 side / 20 back")
}
