import android.content.Context
import com.dugout.career.core.World
import com.dugout.career.sim.Career
import com.dugout.career.sim.Save
import com.dugout.career.sim.Season

/** A career run in Italy must come back out of the file still in Italy. */
fun main() {
    val ctx = Context()
    val world = World.build(20260727L)
    world.playerCountry = "ITA"
    val pyramid = world.pyramidOf("ITA")
    val club = world.club(pyramid[0].clubIds.first())!!
    club.isUser = true
    world.userClubId = club.id
    val season = Season(world); season.buildCalendar()
    val career = Career(world, season)

    // play a chunk of the season so there is real state to compare
    for (wk in 1..12) { world.week = wk; season.simWeek(wk, -1) }
    val beforeTable = season.table(pyramid[0].id).map { "${it.name}:${it.points}" }
    val beforeFixtures = season.fixtures.size
    val beforePlayed = season.fixtures.count { it.played }
    val beforeBal = club.balance

    val ok = Save.write(ctx, world, season, career)
    val f = java.io.File(ctx.filesDir, "career.sav")
    println("written: $ok, ${String.format("%.2f", f.length() / 1048576.0)} MB")

    val snap = Save.read(ctx)
    if (snap == null) { println("FAILED to read back"); return }
    val w2 = snap.world; val s2 = snap.season
    val py2 = w2.pyramidOf("ITA")
    val club2 = w2.club(club.id)!!

    println()
    println("country          ${world.playerCountry} -> ${w2.playerCountry}   ${if (w2.playerCountry == "ITA") "ok" else "WRONG"}")
    println("italian tiers    ${pyramid.size} -> ${py2.size}")
    println("clubs in tier 1  ${pyramid[0].clubIds.size} -> ${py2.getOrNull(0)?.clubIds?.size}")
    println("fixtures         $beforeFixtures -> ${s2.fixtures.size}")
    println("played           $beforePlayed -> ${s2.fixtures.count { it.played }}")
    println("user club        ${club.name} -> ${club2.name}")
    println("balance          $beforeBal -> ${club2.balance}")

    val afterTable = s2.table(py2[0].id).map { "${it.name}:${it.points}" }
    println("table identical  ${beforeTable == afterTable}")
    val orphans = w2.clubs.count { w2.division(it.divisionId) == null }
    println("orphan clubs     $orphans")
    val dupes = w2.allDivisions().sumOf { d -> d.clubIds.size - d.clubIds.toSet().size }
    println("duplicated club entries in divisions: $dupes")
}
