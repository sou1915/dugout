import com.dugout.career.sim.Career
import com.dugout.career.MainActivity
import java.lang.reflect.Method

/**
 * Drives the real Activity through the screens, on the Java2D shim.
 *
 * Every crash on the out of work path so far has been the same shape: a field
 * or a club that does not exist on that route, found only by running it on a
 * phone. This runs it here instead. It cannot prove anything about layout, but
 * a null pointer or an uninitialised field will show up.
 */
private fun call(a: MainActivity, name: String, vararg args: Any?): Any? {
    val m: Method = a.javaClass.declaredMethods.first {
        it.name == name || it.name.startsWith("$name\$")
    }
    m.isAccessible = true
    return if (args.isEmpty()) m.invoke(a) else m.invoke(a, *args)
}

private fun field(a: MainActivity, name: String): Any? {
    val f = a.javaClass.getDeclaredField(name)
    f.isAccessible = true
    return f.get(a)
}

private fun setField(a: MainActivity, name: String, v: Any?) {
    val f = a.javaClass.getDeclaredField(name)
    f.isAccessible = true
    f.set(a, v)
}

fun main() {
    var ok = 0; var bad = 0
    fun step(label: String, body: () -> Unit) {
        try { body(); ok++; println("  ok    $label") }
        catch (e: Throwable) {
            val cause = generateSequence(e) { it.cause }.last()
            bad++
            println("  CRASH $label")
            println("        ${cause::class.simpleName}: ${cause.message}")
            cause.stackTrace.take(3).forEach { println("        at $it") }
        }
    }

    val a = MainActivity()
    println("=== driving the real screens ===")
    step("onCreate") { a.onCreate(null) }

    // build a world without going through the splash timers
    step("build world and season") {
        val w = com.dugout.career.core.World.build(20260727L)
        com.dugout.career.ui.Face.assignAll(w.players.values)
        setField(a, "world", w)
        setField(a, "season", com.dugout.career.sim.Season(w))
    }

    step("show the start choice") { call(a, "showStartChoice") }

    step("start with nothing") {
        val w = field(a, "world") as com.dugout.career.core.World
        val s = field(a, "season") as com.dugout.career.sim.Season
        val car = com.dugout.career.sim.Career(w, s)
        w.managerName = "A Manager"; w.managerNation = "ENG"
        w.userClubId = -1
        w.managerRep = w.profile.ageInfo.startingRep
        setField(a, "career", car)
    }

    step("render the shell while out of work") { call(a, "renderShell") }
    step("open the career record") { call(a, "showCVStandalone") }
    step("back to the job hunt") { call(a, "renderShell") }
    step("wait a week") {
        val car = field(a, "career") as com.dugout.career.sim.Career
        car.unemployedWeek()
        call(a, "renderShell")
    }

    step("apply for a job") {
        val car = field(a, "career") as com.dugout.career.sim.Career
        val v = car.vacancies().first()
        call(a, "confirmJob", v)
    }

    step("render the shell now he has a club") { call(a, "renderShell") }
    step("open the squad") {
        setField(a, "screen", 1)
        call(a, "renderShell")
    }
    step("open tactics") { setField(a, "screen", 2); call(a, "renderShell") }
    step("open the record from in a job") { setField(a, "screen", 14); call(a, "renderShell") }
    // every screen in the rail, in a job
    val screens = listOf(
        0 to "hub", 1 to "squad", 2 to "tactics", 3 to "table", 4 to "club",
        5 to "training", 6 to "world", 7 to "market", 8 to "scouting",
        9 to "inbox", 11 to "scout", 12 to "staff", 14 to "career record"
    )
    for ((id, name) in screens) {
        step("screen: $name") { setField(a, "screen", id); call(a, "renderShell") }
    }

    /*
     * The market screen with loans actually in flight.
     *
     * Rendering it with nobody out on loan exercises none of the new code: the
     * "out on loan" panel and the enquiry list are both behind isNotEmpty
     * checks, so an empty world walks straight past them and the screen would
     * pass while being broken for anyone who had used the feature. So put a
     * player out, raise an enquiry, and render it again.
     */
    step("market with a loan out") {
        val w = field(a, "world") as com.dugout.career.core.World
        val car = field(a, "career") as com.dugout.career.sim.Career
        val c = w.userClub!!
        val p = w.squadOf(c).firstOrNull { car.loanEligible(it) }
        val to = p?.let { car.loanSuitors(it).firstOrNull() }
        if (p != null && to != null) car.loanOut(p, to, 20, car.loanWageOffer(p, to))
        val other = w.squadOf(c).firstOrNull { car.loanEligible(it) }
        val from = other?.let { car.loanSuitors(it).firstOrNull() }
        if (other != null && from != null) {
            car.loanRequests.add(Career.LoanRequest(from.id, other.id, 16, 50))
        }
        setField(a, "screen", 7)
        call(a, "renderShell")
    }

    step("the loan dialog itself") {
        val w = field(a, "world") as com.dugout.career.core.World
        val car = field(a, "career") as com.dugout.career.sim.Career
        val c = w.userClub!!
        val p = w.squadOf(c).firstOrNull { car.loanEligible(it) }
        if (p != null) call(a, "loanDialog", p)
    }

    // and a player card, which every name now links to
    step("player card") {
        val w = field(a, "world") as com.dugout.career.core.World
        val c = w.userClub!!
        setField(a, "selectedPlayer", c.squad.first())
        setField(a, "screen", 10)
        call(a, "renderShell")
    }

    // being sacked drops him back out of work
    step("get sacked") {
        val car = field(a, "career") as com.dugout.career.sim.Career
        car.leaveJob(true)
        call(a, "renderShell")
    }
    step("apply again from scratch") {
        val car = field(a, "career") as com.dugout.career.sim.Career
        val v = car.vacancies().firstOrNull()
        if (v != null) call(a, "confirmJob", v)
    }

    println()
    println("$ok steps passed, $bad crashed")
}
