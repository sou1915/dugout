import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Does the replay actually contain the goal? And where does the ball go when one
 * is scored — does it cross the line and reach the net, or stop short?
 */
fun main() {
    for (seed in 0 until 40) {
        val w = World.build(3000L + seed)
        val s = Season(w); s.buildCalendar()
        val m = MatchEngine(w, s, s.fixtures.first { it.comp == 0 })
        m.start()
        var goalAt = -1
        val ballTrack = ArrayList<Triple<Float, Float, Float>>()
        var reported = false

        for (i in 0 until 60000) {
            val before = m.score[0] + m.score[1]
            m.update(1f / 36f)
            val after = m.score[0] + m.score[1]
            if (after > before) goalAt = i
            if (goalAt >= 0 && i - goalAt < 140) {
                ballTrack.add(Triple(m.ball.x, m.ball.y, m.ball.height))
            }
            // the moment the replay starts, look at what it holds
            val rp = m.replay
            if (rp != null && !reported) {
                reported = true
                val xs = rp.map { it.ballX }
                val att = if (m.score[0] > m.score[1]) 0 else 1
                val goalLine = if (att == 0) 100f else 0f
                val closest = xs.minByOrNull { Math.abs(it - goalLine) } ?: 0f
                println("=== goal at tick $goalAt, replay of ${rp.size} frames ===")
                println("last six frames of the replay, ball x:")
                println("   " + rp.takeLast(6).joinToString("  ") { String.format("%.1f", it.ballX) })
                println(String.format("ball x over the replay: first %.1f, last %.1f", xs.first(), xs.last()))
                println(String.format("closest the ball gets to the goal line (%.0f): %.1f", goalLine, closest))
                println(String.format("does the replay reach the line? %s",
                    if (Math.abs(closest - goalLine) < 3f) "yes" else "NO - it stops " +
                        String.format("%.1f units short", Math.abs(closest - goalLine))))
                println()
                println("what the ball did after the goal was given, in the live match:")
                for ((k, t) in ballTrack.withIndex()) {
                    if (k % 8 != 0 || k > 60) continue
                    println(String.format("   +%3d ticks  x %6.1f  y %5.1f  height %4.2f", k, t.first, t.second, t.third))
                }
                return
            }
            if (m.finished) break
        }
    }
    println("no goal found")
}
