@file:Suppress("unused", "UNUSED_PARAMETER", "MemberVisibilityCanBePrivate")

package android.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable

object Gravity {
    const val NO_GRAVITY = 0
    const val TOP = 48
    const val BOTTOM = 80
    const val LEFT = 3
    const val RIGHT = 5
    const val CENTER_VERTICAL = 16
    const val CENTER_HORIZONTAL = 1
    const val CENTER = 17
    const val START = 8388611
    const val END = 8388613
    const val FILL = 119
}

/**
 * Just enough of View for a custom-drawn class to compile and be told to
 * paint itself into a canvas of a chosen size.
 */
open class View(val context: Context?) {
    companion object {
        const val VISIBLE = 0
        const val INVISIBLE = 4
        const val GONE = 8
        const val FOCUS_DOWN = 130
        const val FOCUS_UP = 33
        const val FOCUS_LEFT = 17
        const val FOCUS_RIGHT = 66
    }

    var width: Int = 0
    var height: Int = 0
    var visibility: Int = VISIBLE
    var alpha: Float = 1f
    var background: Drawable? = null
    var layoutParams: ViewGroup.LayoutParams? = null
    var isEnabled: Boolean = true
    var isClickable: Boolean = false
    var isSelected: Boolean = false
    var translationX: Float = 0f
    var translationY: Float = 0f
    var scaleX: Float = 1f
    var scaleY: Float = 1f
    var rotation: Float = 0f
    var elevation: Float = 0f
    var tag: Any? = null
    var isHorizontalScrollBarEnabled: Boolean = true
    var isVerticalScrollBarEnabled: Boolean = true
    var isFocusable: Boolean = true
    var isFocusableInTouchMode: Boolean = false

    var paddingLeft: Int = 0; private set
    var paddingTop: Int = 0; private set
    var paddingRight: Int = 0; private set
    var paddingBottom: Int = 0; private set

    fun interface OnClickListener { fun onClick(v: View?) }
    fun interface OnLongClickListener { fun onLongClick(v: View?): Boolean }

    private var clickListener: OnClickListener? = null

    fun setOnClickListener(l: OnClickListener?) { clickListener = l; isClickable = l != null }
    fun setOnLongClickListener(l: OnLongClickListener?) {}
    fun performClick(): Boolean { clickListener?.onClick(this); return true }

    fun setPadding(l: Int, t: Int, r: Int, b: Int) {
        paddingLeft = l; paddingTop = t; paddingRight = r; paddingBottom = b
    }

    fun setBackgroundColor(c: Int) {}

    /** Runs the end action straight away; nothing is actually animated here. */
    fun animate(): ViewPropertyAnimator = ViewPropertyAnimator()
    fun setBackgroundDrawable(d: Drawable?) { background = d }
    fun post(r: Runnable): Boolean { r.run(); return true }
    fun postDelayed(r: Runnable, ms: Long): Boolean = true
    fun requestFocus(): Boolean = true
    fun requestLayout() {}
    fun bringToFront() {}

    open fun onDraw(c: Canvas) {}
    open fun invalidate() {}
    open fun postInvalidate() {}
    open fun setWillNotDraw(b: Boolean) {}
    open fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {}

    /** Drives a paint pass at a given size, standing in for the platform. */
    fun renderAt(c: Canvas, w: Int, h: Int) {
        width = w
        height = h
        onDraw(c)
    }
}

class ViewPropertyAnimator {
    fun alpha(v: Float): ViewPropertyAnimator = this
    fun translationX(v: Float): ViewPropertyAnimator = this
    fun translationY(v: Float): ViewPropertyAnimator = this
    fun scaleX(v: Float): ViewPropertyAnimator = this
    fun scaleY(v: Float): ViewPropertyAnimator = this
    fun rotation(v: Float): ViewPropertyAnimator = this
    fun setDuration(ms: Long): ViewPropertyAnimator = this
    fun setStartDelay(ms: Long): ViewPropertyAnimator = this
    fun withEndAction(r: Runnable): ViewPropertyAnimator { r.run(); return this }
    fun start() {}
    fun cancel() {}
}

open class ViewGroup(context: Context?) : View(context) {
    open class LayoutParams(@JvmField var width: Int, @JvmField var height: Int) {
        companion object {
            const val MATCH_PARENT = -1
            const val WRAP_CONTENT = -2
            const val FILL_PARENT = -1
        }
        @JvmField var leftMargin: Int = 0
        @JvmField var topMargin: Int = 0
        @JvmField var rightMargin: Int = 0
        @JvmField var bottomMargin: Int = 0
        fun setMargins(l: Int, t: Int, r: Int, b: Int) {
            leftMargin = l; topMargin = t; rightMargin = r; bottomMargin = b
        }
    }

    open class MarginLayoutParams(w: Int, h: Int) : LayoutParams(w, h)

    private val children = ArrayList<View>()

    val childCount: Int get() = children.size
    fun getChildAt(i: Int): View? = children.getOrNull(i)
    open fun addView(v: View?) { if (v != null) children.add(v) }
    open fun addView(v: View?, lp: LayoutParams?) { if (v != null) { v.layoutParams = lp; children.add(v) } }
    open fun addView(v: View?, index: Int) { if (v != null) children.add(index.coerceIn(0, children.size), v) }
    open fun removeAllViews() { children.clear() }
    open fun removeView(v: View?) { children.remove(v) }
    fun setClipChildren(b: Boolean) {}
}
