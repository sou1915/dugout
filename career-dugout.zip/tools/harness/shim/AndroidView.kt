@file:Suppress("unused", "UNUSED_PARAMETER")

package android.view

import android.content.Context
import android.graphics.Canvas

/**
 * Just enough of View for a custom-drawn class to compile and be told to
 * paint itself into a canvas of a chosen size.
 */
open class View(val context: Context?) {
    var width: Int = 0
    var height: Int = 0

    open fun onDraw(c: Canvas) {}
    open fun invalidate() {}
    open fun postInvalidate() {}
    open fun setWillNotDraw(b: Boolean) {}

    /** Drives a paint pass at a given size, standing in for the platform. */
    fun renderAt(c: Canvas, w: Int, h: Int) {
        width = w
        height = h
        onDraw(c)
    }
}
