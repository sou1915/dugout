import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How a match is actually spent. A real footballer walks for most of it, jogs a
 * good deal, runs sometimes and sprints rarely. If everyone sits in one band the
 * pitch looks mechanical however correct the average is.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    val last = HashMap<String, Pair<Float, Float>>()
    // metres per second bands
    var still = 0; var walk = 0; var jog = 0; var run = 0; var sprint = 0
    var n = 0
    for (i in 0 until 9000) {
        for (p in m.players) if (p.onPitch) last[p.key] = Pair(p.x, p.y)
        m.update(dt)
        if (i < 200) continue
        for (p in m.players) {
            if (!p.onPitch || p.pos == Pos.GK) continue
            val prev = last[p.key] ?: continue
            val dx = (p.x - prev.first) * 1.05
            val dy = (p.y - prev.second) * 0.68
            val mps = Math.sqrt(dx * dx + dy * dy) / dt
            if (mps > 30) continue
            n++
            when {
                mps < 0.4 -> still++
                mps < 2.0 -> walk++
                mps < 4.0 -> jog++
                mps < 6.0 -> run++
                else -> sprint++
            }
        }
        if (m.finished) break
    }
    fun pct(x: Int) = x * 100.0 / n
    println("=== how the outfield players spend a match ===")
    println(String.format("standing      %5.1f%%   (real football is around 15)", pct(still)))
    println(String.format("walking       %5.1f%%   (around 45)", pct(walk)))
    println(String.format("jogging       %5.1f%%   (around 25)", pct(jog)))
    println(String.format("running       %5.1f%%   (around 12)", pct(run)))
    println(String.format("sprinting     %5.1f%%   (around 3)", pct(sprint)))
}
