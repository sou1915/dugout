import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/** Ball speed and flight height in real units, to compare against a real match. */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var px = m.ball.x; var py = m.ball.y
    var sum = 0.0; var n = 0; var peak = 0.0
    var airborne = 0; var total = 0
    var maxH = 0.0
    var inFlight = 0; var flightN = 0
    for (i in 0 until 8000) {
        m.update(dt)
        val dx = (m.ball.x - px) * 1.05
        val dy = (m.ball.y - py) * 0.68
        val mps = Math.sqrt(dx * dx + dy * dy) / dt
        px = m.ball.x; py = m.ball.y
        // a restart repositions the ball instantly; that is not a flight
        val teleport = m.ball.t >= 1f && mps > 25
        if (i > 200 && mps < 200 && !teleport) {
            total++
            if (mps > 0.4) { sum += mps; n++; if (mps > peak) peak = mps }
            if (m.ball.height > 0.05f) {
                airborne++
                // height is in pitch units on the short axis
                val h = m.ball.height * 0.68
                if (h > maxH) maxH = h
            }
            if (m.ball.t < 1f) { inFlight += 1; flightN++ }
        }
        if (m.finished) break
    }
    println("=== ball ===")
    println(String.format("mean speed while moving   %.1f m/s", sum / n))
    println(String.format("fastest                   %.1f m/s", peak))
    println(String.format("highest off the turf      %.1f m", maxH))
    println(String.format("share of time airborne    %.0f%%", airborne * 100.0 / total))
    println()
    println("real football: a firm pass is 15-25 m/s, a hard shot 25-35 m/s,")
    println("and the ball is on the grass for most of a match.")
}
