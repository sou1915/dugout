import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Goals per game by division. The headline balance figure walks the fixture
 * list in order, and the top flight fills the first 380 of them, so a short run
 * measures the top division and a long one averages the whole pyramid. Worth
 * knowing which number is being quoted.
 */
fun main(args: Array<String>) {
    val per = args.firstOrNull()?.toIntOrNull() ?: 260
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()

    println(String.format("%-22s %6s %8s %8s %8s %7s", "division", "games", "goals", "home", "draw", "away"))
    var allG = 0; var allN = 0
    for (d in world.divisions) {
        val fx = season.fixtures.filter { it.comp == 0 && it.divisionId == d.id }
        if (fx.isEmpty()) continue
        var goals = 0; var hw = 0; var dr = 0; var aw = 0; var n = 0
        for (i in 0 until minOf(per, fx.size)) {
            val m = MatchEngine(world, season, fx[i])
            m.speed = 6f; m.replaysEnabled = false
            m.start()
            var guard = 0
            while (!m.finished && guard++ < 200_000) {
                m.update(1f / 30f)
                if (!m.running && !m.finished) m.start()
                m.sound.clear()
            }
            goals += m.score[0] + m.score[1]
            when {
                m.score[0] > m.score[1] -> hw++
                m.score[0] == m.score[1] -> dr++
                else -> aw++
            }
            n++
        }
        allG += goals; allN += n
        println(String.format("%-22s %6d %8.2f %7.0f%% %7.0f%% %6.0f%%",
            d.name, n, goals.toDouble() / n, hw * 100.0 / n, dr * 100.0 / n, aw * 100.0 / n))
    }
    println()
    println(String.format("whole pyramid: %.2f goals over %d games", allG.toDouble() / allN, allN))
    println("a real top division runs about 2.7; lower leagues score fewer")
}
