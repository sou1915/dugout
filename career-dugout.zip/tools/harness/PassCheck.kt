import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Pass geometry and stride length: the two things never yet measured, and the
 * likeliest reasons the football still does not read right.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f

    var fwd = 0; var side = 0; var back = 0
    val opening = ArrayList<Double>()
    val within = ArrayList<Double>()
    var lastStep = -1
    val lens = ArrayList<Double>()
    val speeds = ArrayList<Double>()
    var wasFlying = false

    // stride: distance covered against gait phase advanced
    var phase0 = -1f
    var dist = 0.0
    var strideSamples = 0
    var strideTotal = 0.0
    var px = 0f; var py = 0f
    val watch = m.players.first { it.side == 0 && it.pos != 0 }

    for (i in 0 until 9000) {
        val bx = m.ball.x; val by = m.ball.y
        val ph0 = watch.runPhase
        px = watch.x; py = watch.y
        m.update(dt)
        if (i < 200) continue

        // a new delivery just started
        if (!wasFlying && m.ball.t < 1f) {
            val dx = (m.ball.toX - bx) * 1.05
            val dy = (m.ball.toY - by) * 0.68
            val len = Math.sqrt(dx * dx + dy * dy)
            // a pass has a designated receiver; a shot, clearance or goal kick
            // does not, and counting those was inflating the average badly
            val isPass = m.ball.holder != null
            // the ball going to the first man of a new move is a reset, not a
            // pass between team mates; measure the two separately
            if (len > 1.5 && m.phaseStepPublic <= 1) opening.add(len)
            else if (len > 1.5 && isPass) within.add(len)
            if (len > 1.5 && isPass) {
                lens.add(len)
                speeds.add(len / m.ball.duration)
                // forward means toward the goal the side in possession attacks
                val toGoal = if (m.possessionSide == 0) dx else -dx
                when {
                    toGoal > len * 0.35 -> fwd++
                    toGoal < -len * 0.35 -> back++
                    else -> side++
                }
            }
        }
        wasFlying = m.ball.t < 1f

        // how far he travelled for the gait phase he burned
        val dph = watch.runPhase - ph0
        if (dph > 0.0001f) {
            val dd = Math.hypot(((watch.x - px) * 1.05).toDouble(), ((watch.y - py) * 0.68).toDouble())
            strideTotal += dd
            dist += dph.toDouble()
            strideSamples++
        }
        if (m.finished) break
    }

    val n = lens.size
    println(String.format("opening ball of a move: %d, mean %.1f m", opening.size,
        if (opening.isEmpty()) 0.0 else opening.average()))
    println(String.format("passes inside a move:  %d, mean %.1f m", within.size,
        if (within.isEmpty()) 0.0 else within.average()))
    println()
    println("=== passes ===")
    println(String.format("count %d   mean length %.1f m   median %.1f m",
        n, lens.average(), lens.sorted()[n / 2]))
    println(String.format("under 10 m %.0f%%   10-25 m %.0f%%   25-40 m %.0f%%   over 40 m %.0f%%",
        lens.count { it < 10 } * 100.0 / n, lens.count { it in 10.0..25.0 } * 100.0 / n,
        lens.count { it in 25.0..40.0 } * 100.0 / n, lens.count { it > 40 } * 100.0 / n))
    println(String.format("forward %.0f%%   sideways %.0f%%   backward %.0f%%",
        fwd * 100.0 / n, side * 100.0 / n, back * 100.0 / n))
    println(String.format("mean delivery speed %.1f m/s", speeds.average()))
    println()
    println("real football: mean pass about 18 m, roughly 45/35/20 forward/side/back,")
    println("a firm pass travels 12-20 m/s")
    println()

    // one full gait cycle is 2*PI of `gait`, and gait = runPhase * 0.52
    val cycleRunPhase = (2 * Math.PI) / 0.52
    val metresPerRunPhase = strideTotal / dist
    println("=== stride ===")
    println(String.format("one full leg cycle covers %.2f m", cycleRunPhase * metresPerRunPhase))
    println("a running stride cycle (left then right) is about 3.0-4.0 m;")
    println("if this is far larger the legs are cycling too slowly and he skates")
}
