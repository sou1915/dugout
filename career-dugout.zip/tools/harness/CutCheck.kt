import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How the cuts between the board and the broadcast camera are spaced. One every
 * couple of minutes reads as television. Several within a few seconds reads as
 * the picture jumping about.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var close = false
    var lastCut = 0
    val gaps = ArrayList<Double>()
    var frames = 0
    // mirrors MatchView: cut in at 0.55, back out at 0.30
    for (i in 0 until 20000) {
        m.update(dt)
        frames++
        // mirrors MatchView, including the minimum hold on each camera
        val heldFor = (i - lastCut) / 36.0f
        val minHold = if (close) 4.5f else 3.0f
        val raw = if (close) m.danger >= 0.22f else m.danger >= 0.58f
        val want = if (heldFor < minHold) close else raw
        if (want != close) {
            close = want
            if (lastCut > 0) gaps.add((i - lastCut) / 36.0)
            lastCut = i
        }
        if (m.finished) break
    }
    val mins = frames / 36.0 / 1.15 / 60.0 * 90.0
    println("=== cuts between the two cameras ===")
    println(String.format("cuts in a match          %d", gaps.size + 1))
    if (gaps.isNotEmpty()) {
        val sorted = gaps.sorted()
        println(String.format("shortest gap             %.1f seconds", sorted.first()))
        println(String.format("median gap               %.1f seconds", sorted[sorted.size / 2]))
        println(String.format("gaps under 2 seconds     %d  (%.0f%% of cuts)",
            gaps.count { it < 2.0 }, gaps.count { it < 2.0 } * 100.0 / gaps.size))
        println(String.format("gaps under 5 seconds     %d", gaps.count { it < 5.0 }))
    }
    println()
    println("a cut every couple of seconds is not a camera, it is a strobe.")
}
