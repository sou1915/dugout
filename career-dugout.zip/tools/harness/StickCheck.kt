import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * How close the ball actually sits to whoever is supposed to have it, and how
 * often it is off the ground. A ball that looks like a drone is one that hangs
 * a body width away from the man in possession.
 */
fun main() {
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val m = MatchEngine(world, season, season.fixtures.first { it.comp == 0 })
    m.replaysEnabled = false
    m.start()
    val dt = 1f / 36f
    var held = 0
    var sumD = 0.0
    var worst = 0.0
    var air = 0
    var airHeld = 0
    var total = 0
    for (i in 0 until 8000) {
        m.update(dt)
        if (i < 200) continue
        total++
        if (m.ball.height > 0.05f) air++
        val h = m.ball.holder ?: continue
        if (m.ball.t < 1f) continue                 // still in flight to him
        val p = m.players.firstOrNull { it.key == h } ?: continue
        val dx = (m.ball.x - p.x) * 1.05
        val dy = (m.ball.y - p.y) * 0.68
        val d = Math.sqrt(dx * dx + dy * dy)
        held++; sumD += d
        if (d > worst) worst = d
        if (m.ball.height > 0.05f) airHeld++
        if (m.finished) break
    }
    println("=== ball against the man in possession ===")
    println(String.format("mean distance from his body   %.2f m", sumD / held))
    println(String.format("worst                         %.2f m", worst))
    println(String.format("airborne while held           %.0f%%", airHeld * 100.0 / held))
    println()
    println(String.format("airborne overall              %.0f%% of the match", air * 100.0 / total))
    println()
    println("a ball at a player's feet is within about 0.6 m of him")
}
