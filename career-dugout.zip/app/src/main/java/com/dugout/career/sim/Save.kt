package com.dugout.career.sim

import android.content.Context
import com.dugout.career.core.*
import java.io.File
import kotlin.math.roundToInt

/**
 * The whole career, written to a single file and read back exactly.
 *
 * Everything is stored as delimited text rather than a library format: it
 * keeps the save readable, avoids any dependency, and a career of nine
 * thousand players still writes in well under a second.
 */
object Save {

    private const val FILE = "career.sav"
    // 2 added the nation the manager is working in, so a career abroad reloads
    // in the right country. Version 1 files still load and default to home.
    private const val VERSION = 2
    private const val SEP = "\u0001"     // field separator, never appears in a name
    private const val ROW = "\n"

    class Snapshot(val world: World, val season: Season, val career: Career)

    fun exists(ctx: Context): Boolean = File(ctx.filesDir, FILE).let { it.exists() && it.length() > 64 }

    fun delete(ctx: Context) { File(ctx.filesDir, FILE).delete() }

    /* --------------------------------------------------------- WRITING */

    fun write(ctx: Context, world: World, season: Season, career: Career): Boolean {
        return try {
            val b = StringBuilder(1 shl 22)
            b.append(VERSION).append(SEP).append(world.seed).append(SEP)
                .append(world.season).append(SEP).append(world.week).append(SEP)
                .append(world.userClubId).append(SEP).append(world.managerName).append(SEP)
                .append(world.managerNation).append(SEP).append(world.managerRep).append(SEP)
                .append(world.managerP).append(SEP).append(world.managerW).append(SEP)
                .append(world.managerD).append(SEP).append(world.managerL).append(SEP)
                .append(world.seasonsManaged).append(SEP)
                .append(world.playerCountry).append(ROW)

            // clubs
            b.append("C").append(SEP).append(world.clubs.size).append(ROW)
            for (c in world.clubs) {
                b.append(c.id).append(SEP).append(c.name).append(SEP).append(c.shortName).append(SEP)
                    .append(c.city).append(SEP).append(c.nation).append(SEP).append(c.crestSeed).append(SEP)
                    .append(c.primary).append(SEP).append(c.secondary).append(SEP).append(c.kitPattern).append(SEP)
                    .append(c.divisionId).append(SEP).append(c.foreignLeague).append(SEP).append(c.tier).append(SEP)
                    .append(c.reputation).append(SEP).append(if (c.isUser) 1 else 0).append(SEP)
                    .append(c.stadiumName).append(SEP).append(c.capacity).append(SEP)
                    .append(c.balance).append(SEP).append(c.transferBudget).append(SEP)
                    .append(c.wageBudget).append(SEP).append(c.sponsor).append(SEP)
                    .append(c.played).append(SEP).append(c.won).append(SEP).append(c.drawn).append(SEP)
                    .append(c.lost).append(SEP).append(c.goalsFor).append(SEP).append(c.goalsAgainst).append(SEP)
                    .append(c.points).append(SEP).append(c.morale).append(SEP).append(c.boardConfidence).append(SEP)
                    .append(c.form.joinToString("")).append(SEP)
                    .append(c.squad.joinToString(",")).append(SEP)
                    .append(c.honours.joinToString("|")).append(SEP)
                    .append(tacticsOf(c)).append(ROW)
            }

            // players
            b.append("P").append(SEP).append(world.players.size).append(ROW)
            for (p in world.players.values) {
                b.append(p.id).append(SEP).append(p.first).append(SEP).append(p.last).append(SEP)
                    .append(p.full).append(SEP).append(p.nation).append(SEP).append(p.age).append(SEP)
                    .append(p.pos).append(SEP).append(p.altPos).append(SEP).append(p.role).append(SEP)
                for (a in 0 until Att.COUNT) b.append(p.att[a]).append(",")
                b.append(SEP).append(p.potential).append(SEP).append(p.clubId).append(SEP)
                    .append(p.shirt).append(SEP).append(p.fitness).append(SEP).append(p.sharpness).append(SEP)
                    .append(p.morale).append(SEP).append(p.form).append(SEP)
                    .append(p.injuryType ?: "").append(SEP).append(p.injuryWeeks).append(SEP)
                    .append(p.suspended).append(SEP).append(p.yellowSeason).append(SEP).append(p.redSeason).append(SEP)
                    .append(p.wage).append(SEP).append(p.contractYears).append(SEP).append(p.squadStatus).append(SEP)
                    .append(if (p.listed) 1 else 0).append(SEP).append(p.scouted).append(SEP)
                    .append(p.traits.joinToString(",")).append(SEP).append(p.personality).append(SEP)
                    .append(p.apps).append(SEP).append(p.goals).append(SEP).append(p.assists).append(SEP)
                    .append(p.cleanSheets).append(SEP).append(p.motm).append(SEP).append(p.minutes).append(SEP)
                    .append(p.ratingSum).append(SEP).append(p.ratingN).append(SEP)
                    .append(p.cApps).append(SEP).append(p.cGoals).append(SEP).append(p.cAssists).append(SEP)
                    .append(p.cTrophies).append(ROW)
            }

            // fixtures
            b.append("F").append(SEP).append(season.fixtures.size).append(ROW)
            for (f in season.fixtures) {
                b.append(f.id).append(SEP).append(f.comp).append(SEP).append(f.divisionId).append(SEP)
                    .append(f.round).append(SEP).append(f.week).append(SEP).append(f.homeId).append(SEP)
                    .append(f.awayId).append(SEP).append(if (f.played) 1 else 0).append(SEP)
                    .append(f.homeGoals).append(SEP).append(f.awayGoals).append(SEP)
                    .append(f.attendance).append(SEP).append(f.winnerId).append(ROW)
            }

            // the manager's own state
            b.append("M").append(SEP).append(career.trainingFocus).append(SEP)
                .append(career.intensity).append(SEP)
                .append(career.shortlist.joinToString(",")).append(SEP)
                .append(career.scoutFinds.joinToString(",")).append(ROW)

            b.append("N").append(SEP).append(career.news.size).append(ROW)
            for (n in career.news) {
                b.append(n.icon).append(SEP).append(n.text).append(SEP)
                    .append(n.season).append(SEP).append(n.week).append(SEP).append(n.kind).append(ROW)
            }

            b.append("I").append(SEP).append(career.inbox.size).append(ROW)
            for (m in career.inbox) {
                b.append(m.id).append(SEP).append(m.from).append(SEP).append(m.subject).append(SEP)
                    .append(m.body.replace(ROW, " ")).append(SEP).append(m.icon).append(SEP)
                    .append(m.season).append(SEP).append(m.week).append(SEP)
                    .append(if (m.read) 1 else 0).append(SEP).append(m.offerId).append(ROW)
            }

            b.append("D").append(SEP).append(career.transferLog.size).append(ROW)
            for (d in career.transferLog) {
                b.append(d.player).append(SEP).append(d.pos).append(SEP).append(d.age).append(SEP)
                    .append(d.rating).append(SEP).append(d.from).append(SEP).append(d.to).append(SEP)
                    .append(d.fee).append(SEP).append(d.season).append(SEP).append(d.week).append(ROW)
            }

            val tmp = File(ctx.filesDir, "$FILE.tmp")
            tmp.writeText(b.toString())
            val target = File(ctx.filesDir, FILE)
            if (target.exists()) target.delete()
            tmp.renameTo(target)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun tacticsOf(c: Club): String {
        val t = c.tactics
        val sb = StringBuilder()
        sb.append(t.formation).append(",").append(t.mentality).append(",").append(t.tempo).append(",")
            .append(t.passing).append(",").append(t.width).append(",").append(t.line).append(",")
            .append(t.press).append(",").append(t.tackling).append(",")
            .append(if (t.counter) 1 else 0).append(",").append(if (t.offsideTrap) 1 else 0).append(",")
            .append(t.focus).append(",").append(t.marking).append(",").append(t.timeWasting).append(",")
            .append(if (t.playOut) 1 else 0).append(",")
            .append(t.cornerTaker).append(",").append(t.freeKickTaker).append(",")
            .append(t.penaltyTaker).append(",").append(t.captain).append(",")
            .append(t.oppTargetId).append(",").append(t.oppMode).append(",")
            .append(t.lineup.joinToString("+")).append(",")
            .append(t.bench.joinToString("+")).append(",")
            .append(t.slotRoles.joinToString("+")).append(",")
            .append(t.slotInstructions.joinToString("+")).append(",")
            .append(t.familiarity.roundToInt()).append(",").append(t.familiarWith).append(",")
            .append(t.cornerRoutine).append(",").append(t.cornerMen).append(",")
            .append(t.freeKickRoutine)
        return sb.toString()
    }

    private fun readTactics(c: Club, s: String) {
        val v = s.split(",")
        if (v.size < 24) return
        val t = c.tactics
        t.formation = v[0]; t.mentality = v[1].toInt(); t.tempo = v[2].toInt()
        t.passing = v[3].toInt(); t.width = v[4].toInt(); t.line = v[5].toInt()
        t.press = v[6].toInt(); t.tackling = v[7].toInt()
        t.counter = v[8] == "1"; t.offsideTrap = v[9] == "1"
        t.focus = v[10].toInt(); t.marking = v[11].toInt(); t.timeWasting = v[12].toInt()
        t.playOut = v[13] == "1"
        t.cornerTaker = v[14].toInt(); t.freeKickTaker = v[15].toInt()
        t.penaltyTaker = v[16].toInt(); t.captain = v[17].toInt()
        t.oppTargetId = v[18].toInt(); t.oppMode = v[19].toInt()
        t.lineup = v[20].split("+").map { it.toInt() }.toIntArray()
        t.bench = v[21].split("+").map { it.toInt() }.toIntArray()
        t.slotRoles = v[22].split("+").map { it.toInt() }.toIntArray()
        t.slotInstructions = v[23].split("+").map { it.toInt() }.toIntArray()
        // added later; a version 1 file simply has not learnt a shape yet
        if (v.size > 28) {
            t.cornerRoutine = v[26].toInt(); t.cornerMen = v[27].toInt()
            t.freeKickRoutine = v[28].toInt()
        }
        if (v.size > 25) {
            t.familiarity = v[24].toDouble()
            t.familiarWith = v[25]
        } else {
            t.familiarity = 65.0
            t.familiarWith = t.formation
        }
    }

    /* --------------------------------------------------------- READING */

    fun read(ctx: Context): Snapshot? {
        return try {
            val f = File(ctx.filesDir, FILE)
            if (!f.exists()) return null
            val lines = f.readText().split(ROW)
            var i = 0

            val head = lines[i++].split(SEP)
            if (head[0].toInt() != VERSION) return null
            val world = World(head[1].toLong())
            world.season = head[2].toInt()
            world.week = head[3].toInt()
            world.userClubId = head[4].toInt()
            world.managerName = head[5]
            world.managerNation = head[6]
            world.managerRep = head[7].toInt()
            world.managerP = head[8].toInt(); world.managerW = head[9].toInt()
            world.managerD = head[10].toInt(); world.managerL = head[11].toInt()
            world.seasonsManaged = head[12].toInt()
            world.playerCountry = if (head.size > 13) head[13] else "ENG"
            world.buildStructureOnly()

            // clubs
            var h = lines[i++].split(SEP)
            val clubCount = h[1].toInt()
            world.clubs.clear()
            for (d in world.allDivisions()) d.clubIds.clear()
            world.foreignClubIds.clear()
            repeat(clubCount) {
                val v = lines[i++].split(SEP)
                val c = Club(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(),
                    v[6].toInt(), v[7].toInt(), v[8].toInt())
                c.divisionId = v[9].toInt(); c.foreignLeague = v[10].toInt(); c.tier = v[11].toInt()
                c.reputation = v[12].toInt(); c.isUser = v[13] == "1"
                c.stadiumName = v[14]; c.capacity = v[15].toInt()
                c.balance = v[16].toLong(); c.transferBudget = v[17].toLong()
                c.wageBudget = v[18].toInt(); c.sponsor = v[19].toLong()
                c.played = v[20].toInt(); c.won = v[21].toInt(); c.drawn = v[22].toInt()
                c.lost = v[23].toInt(); c.goalsFor = v[24].toInt(); c.goalsAgainst = v[25].toInt()
                c.points = v[26].toInt(); c.morale = v[27].toDouble(); c.boardConfidence = v[28].toInt()
                for (ch in v[29]) c.form.add(ch)
                if (v[30].isNotEmpty()) for (id in v[30].split(",")) c.squad.add(id.toInt())
                if (v[31].isNotEmpty()) c.honours.addAll(v[31].split("|"))
                readTactics(c, v[32])
                world.clubs.add(c)
                if (c.divisionId >= 0) world.division(c.divisionId)?.clubIds?.add(c.id)
                else world.foreignClubIds.add(c.id)
            }

            // players
            h = lines[i++].split(SEP)
            val playerCount = h[1].toInt()
            world.players.clear()
            repeat(playerCount) {
                val v = lines[i++].split(SEP)
                val att = IntArray(Att.COUNT)
                val nums = v[9].split(",")
                for (a in 0 until Att.COUNT) att[a] = nums[a].toInt()
                val p = Player(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(),
                    v[6].toInt(), v[7].toInt(), v[8], att, v[10].toInt())
                p.clubId = v[11].toInt(); p.shirt = v[12].toInt()
                p.fitness = v[13].toDouble(); p.sharpness = v[14].toDouble()
                p.morale = v[15].toDouble(); p.form = v[16].toDouble()
                p.injuryType = v[17].ifEmpty { null }; p.injuryWeeks = v[18].toInt()
                p.suspended = v[19].toInt(); p.yellowSeason = v[20].toInt(); p.redSeason = v[21].toInt()
                p.wage = v[22].toInt(); p.contractYears = v[23].toInt(); p.squadStatus = v[24].toInt()
                p.listed = v[25] == "1"; p.scouted = v[26].toInt()
                p.traits = if (v[27].isEmpty()) IntArray(0) else v[27].split(",").map { it.toInt() }.toIntArray()
                p.personality = v[28]
                p.apps = v[29].toInt(); p.goals = v[30].toInt(); p.assists = v[31].toInt()
                p.cleanSheets = v[32].toInt(); p.motm = v[33].toInt(); p.minutes = v[34].toInt()
                p.ratingSum = v[35].toDouble(); p.ratingN = v[36].toInt()
                p.cApps = v[37].toInt(); p.cGoals = v[38].toInt(); p.cAssists = v[39].toInt()
                p.cTrophies = v[40].toInt()
                world.players[p.id] = p
                Names.register(p.full)
            }

            val season = Season(world)
            h = lines[i++].split(SEP)
            val fixtureCount = h[1].toInt()
            season.fixtures.clear()
            repeat(fixtureCount) {
                val v = lines[i++].split(SEP)
                val fx = Fixture(v[0].toInt(), v[1].toInt(), v[2].toInt(), v[3].toInt(),
                    v[4].toInt(), v[5].toInt(), v[6].toInt())
                fx.played = v[7] == "1"
                fx.homeGoals = v[8].toInt(); fx.awayGoals = v[9].toInt()
                fx.attendance = v[10].toInt(); fx.winnerId = v[11].toInt()
                season.fixtures.add(fx)
            }
            season.rebuildCups()

            val career = Career(world, season)
            val mv = lines[i++].split(SEP)
            career.trainingFocus = mv[1].toInt()
            career.intensity = mv[2].toInt()
            if (mv[3].isNotEmpty()) for (id in mv[3].split(",")) career.shortlist.add(id.toInt())
            if (mv[4].isNotEmpty()) for (id in mv[4].split(",")) career.scoutFinds.add(id.toInt())

            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                career.news.add(NewsItem(v[0], v[1], v[2].toInt(), v[3].toInt(), v[4].toInt()))
            }
            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                val m = InboxItem(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(), v[6].toInt())
                m.read = v[7] == "1"; m.offerId = v[8].toInt()
                career.inbox.add(m)
            }
            h = lines[i++].split(SEP)
            repeat(h[1].toInt()) {
                val v = lines[i++].split(SEP)
                career.transferLog.add(
                    Deal(v[0], v[1].toInt(), v[2].toInt(), v[3].toInt(), v[4], v[5],
                        v[6].toLong(), v[7].toInt(), v[8].toInt())
                )
            }
            career.setObjectives()
            Snapshot(world, season, career)
        } catch (e: Exception) {
            null
        }
    }
}
