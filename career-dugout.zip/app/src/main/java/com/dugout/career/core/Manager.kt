package com.dugout.career.core

/**
 * Who the manager is.
 *
 * These replace the world seed on the setup screen. A seed is a debugging
 * convenience; none of it says anything about the man in the dugout. Every
 * choice here changes how the job actually goes: what the board expects, how
 * quickly a squad takes to your ideas, whose side the dressing room is on, and
 * which players your staff bring to you.
 */

/* ------------------------------------------------------------------- AGE */

class ManagerAge(
    val id: Int,
    val label: String,
    val years: IntRange,
    val blurb: String,
    /** Where reputation starts. A known name walks in with credit. */
    val startingRep: Int,
    /** How fast a squad picks up your system. */
    val familiarityRate: Double,
    /** Pull on the dressing room when things go badly. */
    val authority: Double,
    /** How readily young players buy into you. */
    val youthAffinity: Double
)

object ManagerAges {
    val ALL = listOf(
        ManagerAge(
            0, "Young", 29..35,
            "New to it, and the dressing room will want convincing. Modern ideas, " +
                "and the young players listen to you.",
            startingRep = 22, familiarityRate = 1.22, authority = 0.82, youthAffinity = 1.25
        ),
        ManagerAge(
            1, "Established", 36..49,
            "Enough behind you to be taken seriously, young enough to still be learning.",
            startingRep = 38, familiarityRate = 1.06, authority = 1.00, youthAffinity = 1.05
        ),
        ManagerAge(
            2, "Experienced", 50..64,
            "A name. Players do as they are told and boards give you longer, " +
                "but your ideas take a while to land.",
            startingRep = 55, familiarityRate = 0.88, authority = 1.22, youthAffinity = 0.86
        )
    )

    fun of(id: Int): ManagerAge = ALL.getOrElse(id) { ALL[1] }
}

/* --------------------------------------------------------------- TACTICS */

class ManagerSchool(
    val id: Int,
    val label: String,
    val blurb: String,
    /** The preset a new job is set up with. */
    val presetName: String,
    /** Systems in this school are learned faster; anything else is slower. */
    val homeGround: List<String>
) {
    /** How quickly a squad settles into a given style under this manager. */
    fun affinity(preset: String): Double =
        if (homeGround.any { it.equals(preset, true) }) 1.30 else 0.86
}

object ManagerSchools {
    val ALL = listOf(
        ManagerSchool(
            0, "Attacking",
            "Go and win it. Two up, full backs high, and take the risk.",
            "Wing Play", listOf("Wing Play", "Control", "Gegenpress")
        ),
        ManagerSchool(
            1, "Possession",
            "Keep the ball and the game comes to you. Patient, short, everybody involved.",
            "Tiki-Taka", listOf("Tiki-Taka", "Control")
        ),
        ManagerSchool(
            2, "Counter-attack",
            "Sit in, win it back, and hurt them in the space behind.",
            "Counter-Attack", listOf("Counter-Attack", "Route One")
        ),
        ManagerSchool(
            3, "Defensive",
            "Concede nothing. Shape first, and take what comes at the other end.",
            "Catenaccio", listOf("Catenaccio", "Park the Bus")
        ),
        ManagerSchool(
            4, "Pressing",
            "Win it back inside six seconds and go again. Demands legs and fitness.",
            "Gegenpress", listOf("Gegenpress", "Wing Play")
        )
    )

    fun of(id: Int): ManagerSchool = ALL.getOrElse(id) { ALL[0] }
}

/* ------------------------------------------------------------ PHILOSOPHY */

class ManagerPhilosophy(
    val id: Int,
    val label: String,
    val blurb: String,
    /** Development rate for players under 23. */
    val youthGrowth: Double,
    /** How well players over 30 hold their level. */
    val veteranHold: Double,
    /** What the academy turns out each summer. */
    val intakeQuality: Double,
    /** The age your scouts bring you. Negative is younger. */
    val scoutAgeBias: Int
)

object ManagerPhilosophies {
    val ALL = listOf(
        ManagerPhilosophy(
            0, "Build from within",
            "The academy is the point. Give a teenager the shirt and live with the mistakes.",
            youthGrowth = 1.28, veteranHold = 0.92, intakeQuality = 1.22, scoutAgeBias = -3
        ),
        ManagerPhilosophy(
            1, "Balanced",
            "Best available, whoever he is and whatever age.",
            youthGrowth = 1.0, veteranHold = 1.0, intakeQuality = 1.0, scoutAgeBias = 0
        ),
        ManagerPhilosophy(
            2, "Proven quality",
            "Win now. Men who have done it before, and no time spent waiting.",
            youthGrowth = 0.84, veteranHold = 1.15, intakeQuality = 0.86, scoutAgeBias = 4
        )
    )

    fun of(id: Int): ManagerPhilosophy = ALL.getOrElse(id) { ALL[1] }
}

/* ---------------------------------------------------------- MAN MANAGEMENT */

class ManagerManner(
    val id: Int,
    val label: String,
    val blurb: String,
    /** Multiplier on morale a player gains from good news. */
    val praise: Double,
    /** Multiplier on morale lost to bad news. */
    val criticism: Double,
    /** Discipline: below 1 means fewer cards. */
    val discipline: Double
)

object ManagerManners {
    val ALL = listOf(
        ManagerManner(
            0, "Arm round the shoulder",
            "Confidence first. They play for you, though the standards can slip.",
            praise = 1.25, criticism = 0.78, discipline = 1.10
        ),
        ManagerManner(
            1, "Even handed",
            "Say what needs saying, no more.",
            praise = 1.0, criticism = 1.0, discipline = 1.0
        ),
        ManagerManner(
            2, "Hard line",
            "Standards are not negotiable. Nobody coasts, and nobody enjoys it much either.",
            praise = 0.80, criticism = 1.22, discipline = 0.82
        )
    )

    fun of(id: Int): ManagerManner = ALL.getOrElse(id) { ALL[1] }
}

/* ------------------------------------------------------------- THE PROFILE */

class ManagerProfile {
    var ageBand: Int = 1
    var age: Int = 42
    var school: Int = 0
    var philosophy: Int = 1
    var manner: Int = 1

    val ageInfo: ManagerAge get() = ManagerAges.of(ageBand)
    val schoolInfo: ManagerSchool get() = ManagerSchools.of(school)
    val philosophyInfo: ManagerPhilosophy get() = ManagerPhilosophies.of(philosophy)
    val mannerInfo: ManagerManner get() = ManagerManners.of(manner)

    /** One line for the club to put out when you are appointed. */
    fun summary(): String =
        "${ageInfo.label.lowercase()}, ${schoolInfo.label.lowercase()} coach who " +
            when (philosophy) {
                0 -> "believes in the academy"
                2 -> "wants proven players"
                else -> "takes the best available"
            }
}
