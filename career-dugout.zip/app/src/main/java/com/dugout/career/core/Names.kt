package com.dugout.career.core

/**
 * Deterministic xorshift RNG. The same seed always rebuilds the same world,
 * so a save only has to store the seed plus whatever the manager changed.
 */
class Rng(seed: Long) {
    private var s: Long = if (seed == 0L) 88172645463325252L else seed

    fun next(): Long {
        s = s xor (s shl 13)
        s = s xor (s ushr 7)
        s = s xor (s shl 17)
        return s
    }

    /** 0.0 until 1.0 */
    fun f(): Double = ((next() ushr 11).toDouble()) / (1L shl 53).toDouble()

    /** inclusive on both ends */
    fun i(a: Int, b: Int): Int = if (b <= a) a else a + (f() * (b - a + 1)).toInt().coerceAtMost(b - a)

    fun chance(p: Double): Boolean = f() < p

    fun <T> pick(list: List<T>): T = list[i(0, list.size - 1)]
    fun <T> pick(arr: Array<T>): T = arr[i(0, arr.size - 1)]

    /** Bell-shaped roll: most results land near [mean]. */
    fun norm(mean: Double, spread: Double, min: Int, max: Int): Int {
        val v = mean + (f() + f() + f() - 1.5) * spread
        return v.toInt().coerceIn(min, max)
    }

    fun <T> shuffle(src: List<T>): MutableList<T> {
        val a = src.toMutableList()
        for (k in a.indices.reversed()) {
            val j = i(0, k)
            val t = a[k]; a[k] = a[j]; a[j] = t
        }
        return a
    }
}

/** A footballing nation: name pools, flag, and how strong its clubs are. */
class Nation(
    val code: String,
    val label: String,
    val flag: String,
    first: String,
    last: String,
    val strength: Int
) {
    val first: List<String> = first.split(",")
    val last: List<String> = last.split(",")
    val combos: Int get() = this.first.size * this.last.size
}

/**
 * Every footballer in the game is invented here. Nobody real, no photographs,
 * and the registry guarantees a name is never issued twice in a save.
 */
object Names {

    val NATIONS: List<Nation> = listOf(
        Nation("ENG", "England", "\uD83C\uDFF4", 
            "Jack,Harry,Callum,Reece,Mason,Tyler,Kieran,Declan,Ollie,Marcus,Alfie,Jude,Cole,Ryan,Lewis,Connor,Dean,Nathan,Josh,Curtis,Elliot,Bailey,Rhys,Charlie,Freddie,Archie,Louie,Finley,Rory,Toby,Miles,Spencer,Warren,Ashton,Ellis,Jarrod,Kane,Lyle,Morgan,Neville,Perry,Quinn,Reuben,Sonny,Trent,Vince,Wesley,Zack,Aaron,Brandon,Casey,Dexter,Emmett,Fraser,Gethin,Hugo,Isaac,Jonty,Kelvin,Lomax,Marlow,Nolan,Oakley,Paxton,Rowan,Sterling,Teddy,Vaughn,Wilbur,Yates,Alby,Bram,Cass,Dane,Edwin,Flynn,Grady,Hale,Ivor,Jarvis,Keane,Linden,Merrick,Ned,Osric,Piers,Ronan,Stanley,Tobias,Ulric",
            "Whitlock,Sanderson,Brackley,Hendry,Ashworth,Norris,Ravenhill,Tunstall,Feather,Colgrave,Marsden,Ardley,Winstone,Bellwood,Hargate,Pemberton,Radcliffe,Quill,Standen,Verrall,Aldridge,Barlow,Cadwell,Dunmore,Ellery,Fairbrother,Garrick,Hollis,Ingram,Jessop,Kirkbride,Larkham,Mowbray,Newbold,Oldacre,Prescott,Quinnell,Rutherford,Selby,Thackeray,Underhill,Vickery,Wrenshall,Yardley,Ambrose,Blakeney,Croft,Dearden,Ewart,Fenwick,Goodwin,Hartnell,Isley,Jardine,Kelsall,Lindley,Marchant,Nightingale,Ormerod,Peveril,Rainford,Stapleton,Trelawney,Vance,Wexford,Yelland,Ashby,Bidwell,Chadwick,Dalrymple,Everard,Foxcroft,Grimshaw,Halloway,Ingleby,Jocelyn,Kingsford,Lyddon,Merriweather,Norcross,Ottway,Pinnock,Redfern,Southwell,Tresham,Vosper,Waverley",
            88),
        Nation("ESP", "Spain", "\uD83C\uDDEA\uD83C\uDDF8",
            "Iker,Nacho,Álvaro,Sergi,Unai,Pau,Aitor,Rodri,Marcos,Iñaki,Borja,Dani,Gerard,Adrián,Hugo,Javi,Mateo,Bruno,Óscar,Raúl,Aleix,Beñat,Carles,Diego,Enric,Fran,Gonzalo,Héctor,Ignacio,Jorge,Koke,Lucas,Manu,Nico,Oriol,Pablo,Quique,Rubén,Samu,Tomás,Ander,Bernat,Cristian,David,Eric,Fabián,Guillem,Hugo,Isco,Joan,Kike,Lluís,Marc,Nil,Odei,Pedri,Roque,Saúl,Toni,Vicente,Xabi,Yeray,Álex,Biel,César,Dídac,Eneko,Ferrán,Gaizka,Iago,Jon,Luka,Mikel,Nahuel,Óliver,Paco,Ramón,Sergio,Tico,Urko,Víctor,Xavi",
            "Beltrán,Corominas,Escalante,Valverde,Zurita,Olmedo,Miralles,Sáenz,Ferrer,Aranda,Quintana,Berrocal,Herrán,Lozano,Casilla,Peralta,Nogueira,Valdivia,Aguirre,Rivas,Amarante,Bustamante,Cifuentes,Domínguez,Echeverría,Fuentes,Galindo,Hidalgo,Iglesias,Jimeno,Larrea,Maldonado,Navarrete,Ocaña,Pedraza,Quiroga,Rebollo,Salcedo,Tejada,Ugarte,Vergara,Zabala,Arrieta,Bermejo,Cabrera,Delgado,Espinosa,Frías,Gallardo,Hurtado,Izaguirre,Jáuregui,Lastra,Mendoza,Nieves,Orozco,Padilla,Requena,Sanabria,Tellado,Uriarte,Vidal,Yáñez,Arteaga,Bonilla,Carranza,Duarte,Elizalde,Fandiño,Garzón,Herrera,Ibarra,Jurado,Leiva,Mansilla,Novoa,Olarte,Prieto,Rueda,Sarabia,Torrent,Ulloa,Villena",
            94),
        Nation("FRA", "France", "\uD83C\uDDEB\uD83C\uDDF7",
            "Théo,Lucas,Enzo,Maxence,Yanis,Kylian,Amine,Malo,Noam,Ilan,Gaël,Rayan,Corentin,Baptiste,Ousmane,Loïc,Sacha,Nolan,Élias,Warren,Adrien,Bastien,Clément,Damien,Étienne,Florian,Gaspard,Hugo,Ismaël,Jules,Kenzo,Léo,Mathis,Nathan,Olivier,Paul,Quentin,Rémi,Samuel,Thibaut,Ulysse,Valentin,Wilfried,Yohan,Zacharie,Aurélien,Benjamin,Cédric,Dorian,Émile,Fabien,Grégoire,Hakim,Ibrahim,Joris,Karim,Lilian,Marius,Naïm,Octave,Pierrick,Raphaël,Simon,Tanguy,Ugo,Victorien,Wandrille,Yacine,Zaïd,Antoine,Bilal,Charly,Diego,Eliott,Ferdinand,Gauthier,Hicham,Idriss,Jibril",
            "Delaunay,Marchand,Brossard,Vasseur,Chastain,Lemoine,Perrot,Guilbert,Fourcade,Renaudin,Tavernier,Coulibaly,Béranger,Dassault,Nkolo,Sirieix,Mahé,Prévost,Vidal,Corbeau,Aubertin,Bonnaire,Charrier,Delcourt,Estève,Fournier,Gauthier,Hébert,Imbert,Jourdain,Lacombe,Mercier,Noiret,Ollivier,Pasquier,Quérin,Rossignol,Sauvage,Thibault,Urbain,Vaillant,Weber,Yvon,Arnoux,Bellamy,Cazenave,Duguay,Eyraud,Faivre,Gaudin,Hulot,Isnard,Joubert,Kervella,Lasalle,Monnier,Nadeau,Orsini,Pelletier,Ravel,Sablé,Teyssier,Vachon,Wattier,Aubry,Beaulieu,Clavier,Descamps,Escoffier,Fressange,Gilbert,Harcourt,Ivanoff,Janvier,Lacroix,Maréchal,Naudin,Ozanne,Poirier,Rambert,Soulier",
            93),
        Nation("ITA", "Italy", "\uD83C\uDDEE\uD83C\uDDF9",
            "Matteo,Lorenzo,Andrea,Gianluca,Nicolò,Federico,Samuele,Riccardo,Davide,Tommaso,Alessio,Manuel,Simone,Edoardo,Cristian,Giacomo,Fabio,Emanuele,Leonardo,Pietro,Alberto,Bruno,Carlo,Diego,Enrico,Filippo,Gabriele,Ivan,Jacopo,Luca,Marco,Nicola,Ottavio,Paolo,Raffaele,Stefano,Tiziano,Umberto,Valerio,Antonio,Christian,Domenico,Elia,Francesco,Giulio,Ignazio,Leandro,Massimo,Nino,Orlando,Pasquale,Roberto,Salvatore,Sandro,Vittorio,Adriano,Benedetto,Corrado,Dario,Ermanno,Flavio,Giorgio,Lapo,Michele,Nunzio,Osvaldo,Piero,Renzo,Sergio,Tullio",
            "Ricciardi,Bellandi,Trevisan,Marchetti,Sacchetti,Vitiello,Zenoni,Cangiano,Perrone,Fiorini,Loreto,Balestra,Mancuso,Grillo,Renzetti,Turrini,Sabbatini,Delfino,Pagano,Corradi,Ambrosini,Bertolini,Casadei,D'Amico,Esposito,Ferraris,Gattuso,Iachini,Lombardi,Mazzola,Nocerino,Orsolini,Pellegatti,Quagliarella,Ravaglia,Scalvini,Terracciano,Ubaldi,Venturi,Zaccagni,Alberico,Bonucci,Carboni,Dossena,Fagioli,Gabbia,Impallomeni,Locatelli,Miretti,Nardi,Odoardi,Piccoli,Ranocchia,Serpe,Tonali,Vergani,Zampano,Altobelli,Bramante,Ceccarelli,Dellavalle,Frattesi,Gilardino,Isernia,Luvumbo,Montipò,Nasti,Ottaviani,Palladino,Ripamonti,Sottil",
            92),
        Nation("GER", "Germany", "\uD83C\uDDE9\uD83C\uDDEA",
            "Jonas,Luca,Nico,Fynn,Marvin,Tim,Leon,Elias,Maik,Kai,Jannik,Malte,Sven,Bastian,Torben,Ole,Hendrik,Marlon,Florian,Justus,Andreas,Benedikt,Christoph,Dominik,Erik,Felix,Gregor,Hannes,Ingo,Jakob,Konstantin,Lennart,Moritz,Niklas,Oskar,Philipp,Quirin,Robin,Simon,Thilo,Uwe,Valentin,Wolfram,Yannick,Arne,Bjarne,Claas,Detlef,Emil,Frederik,Gunnar,Henning,Ilja,Jörn,Kilian,Lasse,Mattes,Nils,Ove,Piet,Rasmus,Steffen,Tammo,Ulrich,Vincent,Wilko",
            "Brandt,Sieber,Hollmann,Kraushaar,Wendt,Nolte,Fischbach,Rehberg,Zorn,Külzer,Bergmann,Steinmetz,Ohlrich,Vogtland,Dahlke,Reinke,Sattler,Möricke,Bauwens,Gehrke,Achterberg,Bültmann,Clausnitzer,Dettmar,Ehrhardt,Feldkamp,Gerlach,Hasselmann,Iserlohn,Jankowski,Kettner,Lindemann,Maiwald,Niederhoff,Oestreich,Pflüger,Quandt,Riedel,Schwerdt,Thormählen,Uhlenbrock,Vollmer,Wiegand,Zeitler,Ahlers,Bickel,Christiansen,Drewes,Emmerich,Freitag,Gundlach,Heitmann,Illner,Jessen,Kammerer,Lehnhoff,Möbius,Nettelbeck,Ortmann,Petersen,Rothe,Stollberg,Tiedemann,Ummel,Vetter,Wehrmann",
            91),
        Nation("BRA", "Brazil", "\uD83C\uDDE7\uD83C\uDDF7",
            "Rafael,Vinícius,Gabriel,Endrick,Wesley,Matheus,Caio,Douglas,Éverton,Luan,Rodrygo,Kaique,Igor,Yuri,Danilo,Pedrinho,Talles,Bruninho,Ronald,Jhon,Alisson,Bernardo,Carlinhos,Deyverson,Emerson,Fabinho,Gerson,Hulk,Ítalo,Juninho,Kevin,Lucas,Murilo,Nathan,Otávio,Paulinho,Quaresma,Richarlison,Samuel,Thiago,Ueslei,Vitor,Weverton,Yago,Alan,Breno,Cauã,Diego,Erick,Felipe,Guilherme,Heitor,Ivan,João,Kauê,Léo,Marlon,Nícolas,Otoniel,Pablo,Ramon,Sandro,Tales,Vagner,Wanderson",
            "Nascimento,Vasconcelos,Andrade,Bittencourt,Furtado,Queiroz,Marinho,Sampaio,Bezerra,Cavalcanti,Peixoto,Gonçalves,Rezende,Aguiar,Tavares,Simões,Machado,Brandão,Vieira,Coutinho,Albuquerque,Barbosa,Camargo,Dantas,Esteves,Fagundes,Guimarães,Hollanda,Isidoro,Jucá,Lacerda,Monteiro,Negrão,Oliveira,Portela,Quaresma,Ribeiro,Siqueira,Teixeira,Uchôa,Valadares,Xavier,Assunção,Bomfim,Carneiro,Drummond,Escobar,Ferraz,Godoy,Henrique,Ipiranga,Jardim,Loureiro,Medeiros,Novaes,Paiva,Rangel,Salgado,Trindade,Verissimo",
            95),
        Nation("ARG", "Argentina", "\uD83C\uDDE6\uD83C\uDDF7",
            "Facundo,Lautaro,Thiago,Valentín,Santino,Julián,Nehuén,Enzo,Máximo,Agustín,Franco,Tomás,Benjamín,Alan,Ezequiel,Joaquín,Bautista,Nicolás,Lisandro,Gonzalo,Alejo,Braian,Ciro,Dylan,Emiliano,Federico,Gastón,Hernán,Ignacio,Juan,Kevin,Lucas,Matías,Nahuel,Octavio,Patricio,Ramiro,Santiago,Tobías,Ulises,Valentino,Wilson,Yamil,Ariel,Bruno,Cristian,Damián,Elías,Fabricio,Germán,Hugo,Iván,Jeremías,Leandro,Marcos,Nicanor,Osvaldo,Pedro,Rodrigo,Sebastián",
            "Insaurralde,Villalba,Zerpa,Barrientos,Ocampo,Cardozo,Migliore,Frascarelli,Bustos,Almirón,Retegui,Sosa,Quiroga,Palacios,Colombo,Ferreyra,Lanzini,Baldassi,Moyano,Escudero,Aimar,Benedetto,Correa,Dybala,Enrique,Fernández,Gaitán,Heredia,Iturbe,Juárez,Krause,Lamela,Medina,Núñez,Otamendi,Peredo,Quintero,Rojas,Salvio,Tagliafico,Urzúa,Vega,Yedlin,Zabaleta,Arruabarrena,Bianchi,Cambiasso,Domínguez,Estigarribia,Funes,Godoy,Hauche,Ibarra,Jara",
            94),
        Nation("NED", "Netherlands", "\uD83C\uDDF3\uD83C\uDDF1",
            "Sem,Daan,Jurriën,Sven,Bram,Ruben,Tijmen,Mees,Cody,Quinten,Joep,Jorrel,Xavi,Thijs,Stijn,Kick,Milan,Wout,Guus,Lars,Bas,Cas,Dirk,Emiel,Floris,Gijs,Hidde,Ivo,Jelle,Koen,Luuk,Maarten,Niek,Olivier,Pepijn,Rens,Siem,Teun,Vince,Wessel,Youri,Arjen,Boaz,Chris,Dean,Ernst,Frank,Geert,Hein,Ids,Joost,Kees,Lucas,Menno,Noud,Otto,Pim,Roel,Sander,Tycho",
            "van Aerde,Verduijn,de Roon,Klaassen,Boersma,van Rhijn,Groenveld,Steijn,Bosveld,de Vrieze,Hoogland,Vermeulen,Kuipers,van Doorn,Zwart,Dekker,Bakhuis,Nieuwkoop,Ramselaar,Oosting,Aardema,Beukema,Cillessen,Doekhi,Everts,Frimpong,Geertruida,Hartman,Idzes,Janssen,Koopmeiners,Lang,Meerdink,Nijhuis,Olij,Pierie,Rensch,Schuurs,Timber,Veerman,Wieffer,Zirkzee,Aerts,Blokzijl,Cuypers,Diemers,Engels,Faber,Goudmijn,Heitinga",
            90),
        Nation("POR", "Portugal", "\uD83C\uDDF5\uD83C\uDDF9",
            "Gonçalo,Diogo,Tomás,Rúben,Vitinha,Fábio,Afonso,Nuno,Rodrigo,Duarte,Hélder,João,Bernardo,Otávio,Ivan,Salvador,Martim,Dinis,Xavier,Guilherme,André,Bruno,César,Daniel,Eduardo,Filipe,Gil,Henrique,Isaac,Jota,Luís,Miguel,Nélson,Óscar,Pedro,Quim,Ricardo,Sérgio,Tiago,Vasco,Zé,Alexandre,Beto,Carlos,Domingos,Emanuel,Francisco,Gabriel,Hugo,Ilídio",
            "Trincão,Bragança,Esteves,Neves,Carmo,Loureiro,Bastos,Amorim,Coentrão,Beto,Semedo,Rebelo,Palhinha,Ramos,Dâmaso,Cancelo,Varela,Pinheiro,Estrela,Mendonça,Abreu,Baptista,Cardoso,Domingues,Fonseca,Gomes,Horta,Inácio,Jota,Leitão,Marques,Nunes,Oliveira,Pereira,Queirós,Rocha,Sarmento,Teixeira,Vinagre,Azevedo,Botelho,Cunha,Dias,Faria,Guedes,Henriques,Lourenço,Moutinho",
            91),
        Nation("MAR", "Morocco", "\uD83C\uDDF2\uD83C\uDDE6",
            "Youssef,Anass,Bilal,Ayoub,Zakaria,Ilyas,Reda,Oussama,Mehdi,Achraf,Nayef,Amine,Soufiane,Hamza,Walid,Ismail,Yassine,Adam,Marouane,Karim,Abdelilah,Badr,Chakib,Driss,Elmehdi,Fouad,Ghali,Hicham,Imad,Jamal,Khalid,Larbi,Mounir,Nabil,Omar,Rachid,Saad,Tarik,Wassim,Yahya,Zouhair,Anir,Bachir,Charaf,Daoud,Elias,Farouk,Ghassan,Haitam,Idriss,Jawad,Kamal,Lotfi,Mustapha,Nordin,Othmane,Rayane,Samir,Taha,Younes",
            "El Kadiri,Benhaddou,Ouazzani,Zerouali,Lahlou,Bennani,Chraibi,El Idrissi,Mansouri,Sbai,Tazi,Berrada,Hajji,Nabil,El Amrani,Rachidi,Ghanem,Bouzid,Serrar,Alaoui,Amrani,Belkhayat,Cherkaoui,Dahbi,El Fassi,Fikri,Guerrouj,Hammouti,Ibrahimi,Jebli,Kabbaj,Lamrani,Moujahid,Naciri,Ouhadi,Qadiri,Regragui,Sekkat,Tahiri,Wahbi,Yousfi,Zniber,Ait Ali,Bouchta,Chafik,Drissi,El Haddaoui,Fahmi,Gharbi,Hilali",
            84),
        Nation("SEN", "Senegal", "\uD83C\uDDF8\uD83C\uDDF3",
            "Ibrahima,Moussa,Cheikh,Pape,Lamine,Abdoulaye,Habib,Mamadou,Ousseynou,Krépin,Boulaye,Nampalys,Formose,Assane,Seydou,Iliman,Idrissa,Amara,Bamba,Youssouph,Alioune,Baba,Demba,El Hadji,Fallou,Gana,Hamidou,Insa,Joseph,Khadim,Mbaye,Ndiaga,Omar,Pathé,Saliou,Tapha,Waly,Yankuba,Abdou,Birane,Cherif,Daouda,Elimane,Fodé,Gorgui,Ismaila,Jules,Kalidou,Malick,Nicolas",
            "Diatta,Ndiaye,Sarr,Gueye,Faye,Cissé,Diallo,Mbaye,Ba,Sow,Kouyaté,Diedhiou,Thiam,Camara,Seck,Dieng,Boye,Niang,Sylla,Badji,Diagne,Fall,Gassama,Konaté,Lo,Mendy,Ndoye,Samb,Touré,Wade,Barry,Coly,Diaby,Ka,Mané,Ngom,Sagna,Tine,Diakhaté,Guirassy,Jatta,Kanté,Loum,Ndour,Sané,Traoré",
            83),
        Nation("JPN", "Japan", "\uD83C\uDDEF\uD83C\uDDF5",
            "Kaoru,Takumi,Ritsu,Ayase,Daichi,Yuki,Sota,Reo,Kyogo,Hiroki,Junya,Shuto,Koki,Ao,Yuta,Ren,Kota,Naoki,Riku,Takuma,Akihiro,Daisuke,Eiji,Fuma,Genki,Haruto,Isamu,Jun,Kenta,Masaya,Nobuaki,Osamu,Ryota,Shinji,Tatsuya,Wataru,Yamato,Zen,Asahi,Chikara,Hayato,Itsuki,Kazuki,Makoto,Noboru,Rikuto,Shohei,Tomoki,Yudai",
            "Mitoma,Kubo,Endo,Tomiyasu,Doan,Hatate,Morita,Nakamura,Kamada,Ito,Suzuki,Ogawa,Sugawara,Machida,Hashioka,Fujita,Osako,Watanabe,Sakai,Uchida,Asano,Furuhashi,Hara,Inoue,Kaneko,Maeda,Nishikawa,Okazaki,Sano,Takahashi,Ueda,Yamada,Aoki,Fukuda,Hasegawa,Ikeda,Kimura,Matsuda,Nakajima,Ono,Saito,Tanaka,Yoshida",
            80),
        Nation("CRO", "Croatia", "\uD83C\uDDED\uD83C\uDDF7",
            "Luka,Josip,Marko,Ivan,Mateo,Borna,Domagoj,Nikola,Filip,Ante,Lovro,Petar,Duje,Stipe,Roko,Toma,Karlo,Fran,Bruno,Jakov,Andrej,Dario,Emil,Goran,Hrvoje,Igor,Jure,Krešimir,Leon,Matej,Niko,Ozren,Rino,Šime,Tin,Vedran,Zoran,Antonio,Damir,Frane,Gabrijel",
            "Kovačević,Modrić,Perišić,Vlašić,Sosa,Juranović,Petković,Barišić,Erlić,Šutalo,Baturina,Ivanušec,Livaja,Majer,Moro,Pašalić,Brekalo,Halilović,Sučić,Ljubičić,Babić,Čolak,Dilaver,Franjić,Gvardiol,Horvat,Jakić,Kramarić,Lauritsen,Mišić,Nevistić,Oršić,Pjaca,Rebić,Stanišić,Tolić,Uremović,Vida",
            86),
        Nation("SWE", "Sweden", "\uD83C\uDDF8\uD83C\uDDEA",
            "Alexander,Viktor,Emil,Anton,Gustav,Jesper,Hugo,Oscar,Elias,Lucas,Isak,Filip,Måns,Nils,Axel,Melker,Sebastian,Dejan,Linus,Theo,Albin,Benjamin,Casper,Douglas,Edvin,Fredrik,Gabriel,Hampus,Ivar,Joel,Kalle,Ludvig,Marcus,Noel,Olle,Pontus,Rasmus,Simon,Tobias,Vilhelm",
            "Lindqvist,Bergström,Nordfeldt,Åkesson,Sandberg,Hjelm,Wahlström,Ekdal,Öberg,Falk,Svensson,Holmberg,Rydström,Almqvist,Lundgren,Dahlin,Selin,Norling,Vikström,Hult,Anderberg,Blomqvist,Cederholm,Dahlberg,Engström,Forsberg,Gunnarsson,Hedlund,Isaksson,Jonsson,Karlström,Lagerbäck,Malmberg,Nyström,Olofsson,Persson,Rosén,Ström,Thorsell,Wallin",
            82),
        Nation("BEL", "Belgium", "\uD83C\uDDE7\uD83C\uDDEA",
            "Jarne,Senne,Wout,Arthur,Lander,Vic,Milan,Stan,Ferre,Noah,Mathis,Rune,Jasper,Toon,Elias,Kobe,Seppe,Lucas,Warre,Basil,Cedric,Dries,Emile,Gilles,Hendrik,Ilias,Jonas,Korneel,Lowie,Maxim,Nand,Olivier,Pieter,Robbe,Siebe,Thibaud,Viktor,Wannes,Yorbe",
            "Vermeeren,Openda,Trossard,Doku,Onana,Vanaken,Debast,Theate,Faes,Lukebakio,Bakayoko,Vranckx,Casteels,Meunier,Sels,Deman,Balikwisha,Stroeykens,Vanhoutte,Claes,Dendoncker,Engels,Foket,Geraerts,Heynen,Ivanov,Janssens,Keersmaecker,Lammens,Mechele,Nielsen,Odoi,Praet,Raskin,Smets,Tielemans,Vertonghen,Wesley",
            89),
        Nation("NOR", "Norway", "\uD83C\uDDF3\uD83C\uDDF4",
            "Erling,Martin,Sander,Jørgen,Kristian,Håkon,Sondre,Emil,Ola,Tobias,Andreas,Bjørn,Casper,Daniel,Eivind,Fredrik,Gard,Henrik,Isak,Jonas,Kasper,Lars,Magnus,Nikolai,Odin,Petter,Ruben,Sindre,Torstein,Vetle",
            "Haaland,Ødegaard,Berge,Sørloth,Nusa,Ryerson,Strand,Bobb,Aursnes,Thorsby,Hanche-Olsen,Meling,Elyounoussi,Solbakken,Nyland,Østigård,Pedersen,Larsen,Johansen,Andersen,Bakken,Dahle,Engebretsen,Fossum,Gundersen,Haugen,Iversen,Jacobsen,Kristoffersen,Lundberg",
            81)
    )

    private val used = HashSet<String>(8192)
    private val INITIALS = "ABCDEFGHIJKLMNOPRSTUVW"

    /** Total base combinations available across every nation. */
    val capacity: Int get() = NATIONS.sumOf { it.combos }

    fun reset() = used.clear()
    fun register(full: String) { used.add(full) }
    val issued: Int get() = used.size

    /**
     * Issues a name that has never been used in this save. Four escalating
     * tiers mean the pool is effectively bottomless.
     */
    fun make(rng: Rng, nation: Nation): PlayerName {
        // Tier 1 — plain first + last
        for (t in 0 until 14) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val full = "$f $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 2 — middle initial
        for (t in 0 until 14) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val m = INITIALS[rng.i(0, INITIALS.length - 1)]
            val full = "$f $m. $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 3 — double-barrelled surname
        for (t in 0 until 20) {
            val f = rng.pick(nation.first)
            val l = rng.pick(nation.last) + "-" + rng.pick(nation.last)
            val full = "$f $l"
            if (used.add(full)) return PlayerName(f, l, full)
        }
        // Tier 4 — never expected to be reached
        var n = 2
        while (true) {
            val f = rng.pick(nation.first); val l = rng.pick(nation.last)
            val full = "$f $l ${roman(n)}"
            if (used.add(full)) return PlayerName(f, "$l ${roman(n)}", full)
            n++
        }
    }

    private fun roman(n: Int): String = when (n) {
        2 -> "II"; 3 -> "III"; 4 -> "IV"; 5 -> "V"; 6 -> "VI"; 7 -> "VII"
        else -> n.toString()
    }

    fun byCode(code: String): Nation = NATIONS.firstOrNull { it.code == code } ?: NATIONS[0]
}

class PlayerName(val first: String, val last: String, val full: String)
