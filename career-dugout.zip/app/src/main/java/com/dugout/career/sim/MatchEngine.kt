package com.dugout.career.sim

import com.dugout.career.core.*
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ------------------------------------------------------------ LIVE PLAYER */

/** A footballer as the match sees him: a position on the pitch and a match rating. */
class LivePlayer(
    val key: String,
    val side: Int,           // 0 home, 1 away
    val slot: Int,
    val pos: Int,
    val ref: Player
) {
    var x = 50f; var y = 50f
    var targetX = 50f; var targetY = 50f
    var baseX = 50f; var baseY = 50f

    var shirt = 1
    var effective = 60.0
    var fitness = 100.0

    var goals = 0; var assists = 0; var tackles = 0; var saves = 0
    var passes = 0; var shots = 0; var yellow = 0
    var sentOff = false
    var injured = false
    var injuryWeeks = 0
    var onPitch = true
    var minutes = 0.0
    var rating = 6.5

    /** Where he is looking, in radians. Drives which way the body is drawn. */
    var facing = 0f
    /** Advances while running so the legs and arms swing. */
    var runPhase = 0f
    var speedNow = 0f
    /** Current running speed, eased toward the target so he accelerates. */
    var gaitSpeed = 0f

    var action = Act.RUN
    var actionTime = 0f
    var actionDir = 0f

    val name: String get() = ref.last
    val fullName: String get() = ref.full
}

/** What a player is doing right now — the renderer draws each one differently. */
object Act {
    const val RUN = 0
    const val TACKLE = 1        // sliding in
    const val SHOOT = 2         // striking the ball
    const val DIVE = 3          // keeper going down
    const val CELEBRATE = 4     // arms up
    const val DRIBBLE = 5       // knocking it past a man
    const val DOWN = 6          // injured, on the floor
    const val HEADER = 7        // rising to meet a cross
}

/* ----------------------------------------------------------------- EVENTS */

object Ev {
    const val GOAL = 0; const val YELLOW = 1; const val RED = 2
    const val SUB = 3; const val INJURY = 4; const val PENALTY = 5
}

class MatchEvent(val minute: Int, val type: Int, val side: Int, val player: String, val extra: String = "")

class FeedLine(val minute: Int, val text: String, val kind: Int) {
    companion object {
        const val PLAIN = 0; const val GOAL = 1; const val CARD = 2
        const val CHANCE = 3; const val SUB = 4; const val WHISTLE = 5
    }
}

/* ------------------------------------------------------------------- BALL */

class Ball {
    var x = 50f; var y = 50f
    var fromX = 50f; var fromY = 50f
    var toX = 50f; var toY = 50f
    var t = 1f
    var duration = 0.4f
    /** Current height above the turf. Zero for anything played along the floor. */
    var height = 0f
    /** How high this particular delivery was struck. Most passes are flat. */
    var loft = 0f
    var rolling = false
    var holder: String? = null

    /** How fast it is still travelling, so it can roll on after it arrives. */
    var driftX = 0f
    var driftY = 0f
    /** Spin, purely so the ball visibly rotates as it runs. */
    var spin = 0f
    /** Vertical velocity once it is off the pass arc and bouncing on its own. */
    var vz = 0f
    /** Sideways bend on this delivery, so a long ball is not a straight line. */
    var curve = 0f
}

/* --------------------------------------------------------------- SET PIECE */

/** Staged moments the renderer can frame differently: corners and penalties. */
object Scene {
    const val NONE = 0; const val CORNER = 1; const val PENALTY = 2; const val FREEKICK = 3
    const val THROW_IN = 4; const val GOAL_KICK = 5; const val KICK_OFF = 6
    const val LINEUP = 7; const val SUBSTITUTION = 8
    val LABEL = arrayOf("", "CORNER", "PENALTY", "FREE KICK", "THROW-IN", "GOAL KICK",
        "KICK OFF", "TEAMS ARE OUT", "SUBSTITUTION")
}

/* ------------------------------------------------------------------ ENGINE */

/**
 * A phase-based match. Each spell of possession is built pass by pass and
 * resolved from the two sides' attack, defence and control ratings, so the
 * scorelines match the quick simulation while still playing out on a pitch.
 */
class MatchEngine(
    val world: World,
    val season: Season,
    val fixture: Fixture
) {
    val home: Club = world.club(fixture.homeId)!!
    val away: Club = world.club(fixture.awayId)!!

    val players = ArrayList<LivePlayer>(30)
    val ball = Ball()
    val feed = ArrayList<FeedLine>(120)
    val events = ArrayList<MatchEvent>(40)

    var clock = 0.0                  // match minutes
    var addedTime = 0.0
    var half = 1
    var running = false
    var finished = false
    var speed = 1f
    var kicked = false

    val score = intArrayOf(0, 0)
    val shots = intArrayOf(0, 0)
    val onTarget = intArrayOf(0, 0)
    val corners = intArrayOf(0, 0)
    val fouls = intArrayOf(0, 0)
    val yellows = intArrayOf(0, 0)
    val reds = intArrayOf(0, 0)
    val passesTotal = intArrayOf(0, 0)
    val xg = doubleArrayOf(0.0, 0.0)
    val possession = doubleArrayOf(0.0, 0.0)

    val subsLeft = intArrayOf(5, 5)
    private var subsMade = intArrayOf(0, 0)
    val benchHome = ArrayList<Player>(7)
    val benchAway = ArrayList<Player>(7)

    var momentum = 0.0               // -1 away .. +1 home
    var attendance = 0
    var weatherRain = false
    var night = false

    // presentation state the renderer reads
    var flash = 0f
    var shake = 0f
    var banner: String? = null
    var bannerTime = 0f
    var celebrateKey: String? = null
    var celebrateTime = 0f
    var scene = Scene.NONE
    var sceneTime = 0f

    // the official: he only appears when he has something to do
    var refX = 50f
    var refY = 46f
    var refCard = 0            // 0 none, 1 yellow, 2 red
    var refTime = 0f
    var freeKickX = 0f
    var freeKickY = 0f
    var wallX = 0f
    var wallY = 0f
    var wallCount = 0

    // replay: a short ring of ball positions captured before every goal
    class Frame(val ballX: Float, val ballY: Float, val xs: FloatArray, val ys: FloatArray)
    private val history = ArrayList<Frame>(160)
    var replay: List<Frame>? = null
    var replayIndex = 0

    /**
     * The replay waits for the celebration to breathe before it cuts in, then
     * runs back slower than life. History is captured once per update, so a
     * cursor step below 1 is slow motion.
     */
    /**
     * Replays are presentation. A headless run — the balance check, or simming
     * the rest of the week — has nobody to show them to, so it turns them off
     * and saves both the frame history and the pause after every goal.
     */
    var replaysEnabled = true

    private var pendingReplay: List<Frame>? = null
    var replayDelay = 0f
    private var replayCursor = 0f
    /** History is captured once per update, so this is a fraction of live speed. */
    private val REPLAY_RATE = 0.5f
    private val CAPTURES_PER_SECOND = 36f

    /**
     * Advances the replay from elapsed time and reports whether one is still
     * running. Driven from [update] so the engine is never waiting on a caller
     * to unstick it: a headless run finishes a match exactly like the UI does.
     */
    private fun advanceReplay(dtSeconds: Float): Boolean {
        val rp = replay ?: return false
        replayCursor += dtSeconds * CAPTURES_PER_SECOND * REPLAY_RATE
        replayIndex = replayCursor.toInt()
        if (replayIndex >= rp.size) {
            replay = null; replayIndex = 0; replayCursor = 0f
            crowdTarget = 0.55f
            return false
        }
        return true
    }

    /* ------------------------------------------------------------- SOUND */

    /**
     * The engine never touches the audio device; it only says what happened and
     * where. The match screen drains this each frame and hands it to the mixer,
     * which keeps this file free of Android and keeps sound out of the sim.
     */
    class SoundCue(val kind: Int, val gain: Float, val pan: Float)

    val sound = ArrayList<SoundCue>(16)

    /** 0 quiet, 1 boiling. The bed slides toward this. */
    var crowdTarget = 0.30f

    /* ------------------------------------------------------- CELEBRATION */

    /** Seconds left of the walkout before the first whistle. */
    var lineupTime = 0f
    private var lineupDone = false

    /** Seconds left of the scene that follows a goal. */
    var celebrationTime = 0f
    private var celebrateSide = -1
    /**
     * Held separately from [celebrateKey], which the sparkle clears after 2.4s.
     * The run itself outlasts that, and without its own reference the team-mates
     * lost the man they were chasing halfway through.
     */
    private var celebrateScorer: String? = null
    private var celebrateRunX = 0f
    private var celebrateRunY = 0f

    /**
     * Cosmetic rolls come from their own stream. Sharing the match RNG would
     * mean a sound effect could change a scoreline, which is why the balance
     * figures still hold after all of this.
     */
    private val sfxRng = Rng(fixture.id * 104729L + 17)

    private fun cue(kind: Int, gain: Float = 1f, atX: Float = 50f) {
        if (sound.size > 24) return
        sound.add(SoundCue(kind, gain, ((atX - 50f) / 50f).coerceIn(-1f, 1f)))
    }

    var possessionSide = 0
    private var ratingHome = world.teamRating(home, true)
    private var ratingAway = world.teamRating(away, false)

    private var phaseSeq: MutableList<LivePlayer> = ArrayList()
    private var phaseStep = 0
    private var phaseOutcome = 0
    private var phaseGap = 0.0
    private var phaseTimer = 0.0
    private var phaseDuration = 1.0
    private var pendingSide = -1
    private var pendingAt = 0.0
    private var ambientTimer = 0.0
    private var rng = Rng(world.seed + fixture.id * 7919L + world.week)

    private val usedLines = HashMap<Int, MutableList<Int>>()

    companion object {
        const val OUT_TURNOVER = 0; const val OUT_SHOT = 1
        const val OUT_FOUL = 2; const val OUT_CORNER = 3; const val OUT_THROW = 4
        const val SECONDS_PER_MINUTE = 1.15

        /** How much faster than its average a struck ball leaves the boot. */
        const val LAUNCH_RATIO = 1.55f

        /** Hardest average speed any delivery may carry, in metres per second. */
        const val MAX_BALL_MPS = 26f
    }

    init {
        if (home.tactics.lineup.all { it < 0 }) world.autoPickSquad(home)
        if (away.tactics.lineup.all { it < 0 }) world.autoPickSquad(away)
        buildSide(0, home)
        buildSide(1, away)
        benchHome.addAll(home.tactics.bench.map { world.player(it) }.filterNotNull())
        benchAway.addAll(away.tactics.bench.map { world.player(it) }.filterNotNull())

        attendance = min(
            home.capacity,
            (home.capacity * (0.55 + home.reputation / 250.0 + rng.f() * 0.15)).roundToInt()
        )
        weatherRain = rng.chance(0.22)
        night = rng.chance(0.45)
        resetShape(0); resetShape(1)
        refreshRatings()
    }

    private fun buildSide(side: Int, club: Club) {
        val shape = Formations.byName(club.tactics.formation)
        for (i in shape.slots.indices) {
            val p = world.player(club.tactics.lineup.getOrElse(i) { -1 }) ?: continue
            val slot = shape.slots[i]
            val lp = LivePlayer("${side}_$i", side, i, slot.pos, p)
            lp.baseX = slot.x.toFloat()
            lp.baseY = slot.y.toFloat()
            lp.shirt = if (i == 0) 1 else i + 1
            lp.effective = p.effective(slot.pos)
            lp.fitness = p.fitness
            players.add(lp)
        }
    }

    fun onPitch(side: Int): List<LivePlayer> = players.filter { it.side == side && it.onPitch }

    private fun ownX(side: Int, v: Float) = if (side == 0) v else 100f - v
    private fun ownY(side: Int, v: Float) = if (side == 0) v else 100f - v

    private fun resetShape(side: Int) {
        for (p in onPitch(side)) {
            p.x = ownX(side, p.baseX); p.targetX = p.x
            p.y = ownY(side, p.baseY); p.targetY = p.y
        }
    }

    /* ------------------------------------------------------------ PHASES */

    private fun rating(side: Int) = if (side == 0) ratingHome else ratingAway

    private fun applyOppPlan(plan: Tactics, victim: Club, victimRating: World.TeamRating) {
        if (plan.oppTargetId < 0 || plan.oppMode == 0) return
        val target = world.player(plan.oppTargetId) ?: return
        if (target.clubId != victim.id) return
        // how much of their attack runs through him
        val xi = victim.tactics.lineup.map { world.player(it) }.filterNotNull()
        if (xi.isEmpty()) return
        val share = (target.overall().toDouble() / xi.sumOf { it.overall() }.toDouble()) * xi.size
        val bite = when (plan.oppMode) {
            1 -> 3.4; 2 -> 2.4; 3 -> 1.8; 4 -> 1.4; else -> 0.0
        } * share.coerceIn(0.6, 1.8)
        victimRating.attack -= bite
        victimRating.control -= bite * 0.5
    }

    fun refreshRatings() {
        ratingHome = world.teamRating(home, true)
        ratingAway = world.teamRating(away, false)

        // An opposition plan takes a real bite out of the side it targets:
        // how big a bite depends on how important that player is to them.
        applyOppPlan(home.tactics, away, ratingAway)
        applyOppPlan(away.tactics, home, ratingHome)
        for (p in players) {
            if (!p.onPitch) continue
            var eff = p.ref.effective(p.pos) * (0.75 + 0.25 * p.fitness / 100.0)
            // is the other manager targeting him?
            val theirTactics = (if (p.side == 0) away else home).tactics
            if (theirTactics.oppTargetId == p.ref.id) {
                eff *= when (theirTactics.oppMode) {
                    1 -> 0.86     // man-marked out of the game
                    2 -> 0.91     // hounded whenever he gets it
                    3 -> 0.93     // forced onto his weaker side
                    4 -> 0.95     // kicked, but it may cost a card
                    else -> 1.0
                }
            }
            p.effective = eff
        }
    }

    private fun newPhase() {
        val att = possessionSide
        val def = 1 - att
        val attClub = if (att == 0) home else away
        val ra = rating(att); val rd = rating(def)

        val outfield = onPitch(att).filter { it.pos != Pos.GK }
        if (outfield.isEmpty()) { possessionSide = def; return }
        val back = outfield.filter { Pos.group(it.pos) == 1 }
        val mid = outfield.filter { Pos.group(it.pos) == 2 }
        val fwd = outfield.filter { Pos.group(it.pos) == 3 }

        val t = attClub.tactics
        val passCount = when (t.passing) {
            2 -> rng.i(2, 3)
            0 -> rng.i(4, 7)
            else -> rng.i(3, 5)
        }

        val seq = ArrayList<LivePlayer>(passCount)
        if (back.isNotEmpty()) seq.add(rng.pick(back))
        for (i in 0 until max(0, passCount - 2)) {
            val pool = if (i < (passCount - 2) / 2) (if (mid.isNotEmpty()) mid else outfield)
            else (if (fwd.isNotEmpty()) fwd + mid else outfield)
            if (pool.isNotEmpty()) seq.add(rng.pick(pool))
        }
        seq.add(if (fwd.isNotEmpty()) rng.pick(fwd) else rng.pick(outfield))

        phaseGap = ra.attack - rd.defence
        // Playing at home is worth a little more than the squad numbers alone say.
        if (att == 0) phaseGap += 2.5
        val pShot = (0.215 + phaseGap / 140.0).coerceIn(0.09, 0.52)
        val defClub = if (def == 0) home else away
        val pFoul = 0.10 * when (defClub.tactics.tackling) { 2 -> 1.7; 0 -> 0.6; else -> 1.0 }
        val pCorner = 0.07

        val pThrow = 0.11
        val r = rng.f()
        phaseOutcome = when {
            r < pFoul -> OUT_FOUL
            r < pFoul + pShot -> OUT_SHOT
            r < pFoul + pShot + pCorner -> OUT_CORNER
            r < pFoul + pShot + pCorner + pThrow -> OUT_THROW
            else -> OUT_TURNOVER
        }

        val cut = if (phaseOutcome == OUT_TURNOVER) rng.i(1, seq.size) else seq.size
        phaseSeq = seq.subList(0, max(1, min(cut, seq.size))).toMutableList()
        phaseStep = 0
        phaseTimer = 0.0

        val tempoSpread = when (t.tempo) { 2 -> 0.7; 0 -> 1.5; else -> 1.0 }
        phaseDuration = 0.35 + rng.f() * tempoSpread + phaseSeq.size * 0.12
        possession[att] += phaseDuration

        ball.holder = phaseSeq[0].key
        moveBallTo(phaseSeq[0].x, phaseSeq[0].y, 0.40f, 0f)
    }

    /**
     * Sends the ball somewhere. [loft] is how high it is struck: nought keeps
     * it on the deck, which is where the great majority of passes belong.
     */
    private fun moveBallTo(x: Float, y: Float, dur: Float, loft: Float = 0f) {
        ball.fromX = ball.x; ball.fromY = ball.y
        ball.toX = x; ball.toY = y
        ball.t = 0f
        // A ceiling on how fast anything can be struck, applied here so every
        // delivery is covered rather than each call site being tuned by hand.
        // One x-unit is about 1.05 m and one y-unit about 0.68 m; the hardest
        // strike in football is a little over 35 m/s.
        val dxm = (x - ball.fromX) * 1.05f
        val dym = (y - ball.fromY) * 0.68f
        val metres = hypot(dxm.toDouble(), dym.toDouble()).toFloat()
        val floorDur = metres / MAX_BALL_MPS
        ball.duration = max(0.10f, max(dur, floorDur))
        ball.loft = loft
        ball.rolling = loft <= 0.01f
        ball.vz = 0f
        // a bend proportional to how far it has to travel, either way off the
        // straight line. Rolled on the cosmetic stream so it cannot move a result.
        val dist = hypot((x - ball.fromX).toDouble(), (y - ball.fromY).toDouble()).toFloat()
        ball.curve = if (dist < 12f) 0f
        else (sfxRng.f().toFloat() - 0.5f) * 2f * min(3.2f, dist * 0.055f)
    }

    private fun stepPhase() {
        phaseStep++
        if (phaseStep < phaseSeq.size) {
            val from = phaseSeq[phaseStep - 1]
            val to = phaseSeq[phaseStep]
            from.passes++
            passesTotal[possessionSide]++
            cue(Synth.Sfx.KICK, 0.42f, from.x)
            val dist = hypot((to.x - from.x).toDouble(), (to.y - from.y).toDouble()).toFloat()
            val club = if (possessionSide == 0) home else away
            // The ball spent 38% of the match in the air, which is nothing like
            // football. Only a genuinely long ball, or a side told to go direct,
            // gets lifted now, and not as high.
            val loft = when {
                dist > 44f -> 1.9f
                dist > 30f && club.tactics.passing == 2 -> 1.2f
                else -> 0f
            }
            // a better passer strikes it more firmly, so it arrives sooner
            val weight = 1.0f - (from.ref.att[Att.PAS] - 60) / 320f
            moveBallTo(to.x, to.y, (0.52f + dist / 27f) * weight.coerceIn(0.80f, 1.20f), loft)
            ball.holder = to.key
            if (rng.chance(0.10)) say(L_PASS, from.name, to.name)
            return
        }
        resolvePhase()
    }

    private fun resolvePhase() {
        val att = possessionSide
        val def = 1 - att
        val last = phaseSeq.lastOrNull() ?: return
        val defClub = if (def == 0) home else away

        when (phaseOutcome) {
            OUT_TURNOVER -> {
                val defenders = onPitch(def).filter { it.pos != Pos.GK }
                val stealer = nearest(defenders, last.x, last.y)
                if (stealer != null) {
                    stealer.tackles++
                    // a real slide, aimed at the man he is dispossessing
                    // only a genuine challenge puts anybody on the grass
                    if (rng.chance(0.30)) {
                        act(stealer, Act.TACKLE, 0.65f, angleTo(stealer, last.x, last.y))
                        cue(Synth.Sfx.TACKLE, 0.8f, stealer.x)
                        if (rng.chance(0.5)) act(last, Act.DOWN, 0.55f)
                    }
                    if (rng.chance(0.22)) say(L_TACKLE, stealer.name, last.name)
                } else if (rng.chance(0.5)) {
                    act(last, Act.DRIBBLE, 0.7f)
                }
                flip(def)
            }

            OUT_FOUL -> {
                val defenders = onPitch(def).filter { it.pos != Pos.GK }
                val fouler = nearest(defenders, last.x, last.y) ?: defenders.randomOrNull(rng)
                fouls[def]++
                if (fouler != null) {
                    val inBox = if (att == 0) last.x > 83f else last.x < 17f
                    if (inBox && rng.chance(0.28)) {
                        say(L_PENALTY, fouler.name, teamName(att))
                        card(fouler, rng.chance(0.30))
                        takePenalty(att)
                        return
                    }
                    val aggressive = defClub.tactics.tackling == 2
                    val roughing = defClub.tactics.oppMode == 4 && defClub.tactics.oppTargetId == last.ref.id
                    val cardChance = 0.20 * (if (aggressive) 1.8 else 1.0) *
                            (if (fouler.ref.hasTrait(Traits.HOTHEAD)) 1.7 else 1.0) *
                            (if (roughing) 1.9 else 1.0)
                    if (rng.chance(cardChance)) card(fouler, rng.chance(0.07))
                    else if (rng.chance(0.30)) say(L_FOUL, fouler.name, last.name)
                }
                if (rng.chance(0.22)) {
                    scene = Scene.FREEKICK; sceneTime = 2.0f
                    stageFreeKick(att, def, last)
                    attemptShot(att, last, 0.055, "free kick")
                    return
                }
                flip(att)
            }

            OUT_THROW -> {
                // the ball runs out for a throw: whoever put it out loses it
                val toucher = last
                val side = if (toucher.y < 50f) 2f else 98f
                ball.x = toucher.x.coerceIn(6f, 94f)
                ball.y = side
                ball.t = 1f
                ball.holder = null
                scene = Scene.THROW_IN; sceneTime = 1.4f
                stageThrowIn(def, ball.x, side)
                sayRaw(FeedLine.PLAIN, "Out for a throw-in to ${teamName(def)}.")
                flipLater(def, 0.35)
            }

            OUT_CORNER -> {
                corners[att]++
                scene = Scene.CORNER; sceneTime = 1.6f
                say(L_CORNER, teamName(att), "")
                stageCorner(att)
                val attClub2 = if (att == 0) home else away
                val nominatedCorner = attClub2.tactics.cornerTaker.let { slot ->
                    if (slot >= 0) onPitch(att).firstOrNull { it.slot == slot } else null
                }
                nominatedCorner?.let { it.passes++ }
                val target = onPitch(att).filter { it.pos != Pos.GK && it.key != nominatedCorner?.key }
                    .maxByOrNull {
                        it.ref.att[Att.STR] + (if (RoleFx.of(attClub2.tactics.roleName(it.slot)).note.contains("headers")) 15 else 0)
                    } ?: last
                attemptShot(att, target, 0.085, "header")
            }

            else -> {
                var q = 0.086 + phaseGap / 470.0 + (last.ref.att[Att.FIN] - 60) / 850.0
                q *= 0.80 + rng.f() * 0.50
                attemptShot(att, last, q.coerceIn(0.02, 0.66), "shot")
            }
        }
    }

    /** Ball spotted, a wall of defenders paced out in front of it. */
    private fun stageFreeKick(att: Int, def: Int, taker: LivePlayer) {
        freeKickX = taker.x
        freeKickY = taker.y
        ball.x = freeKickX; ball.y = freeKickY; ball.t = 1f; ball.holder = null

        val goalX = if (att == 0) 100f else 0f
        val dx = goalX - freeKickX
        val dy = 50f - freeKickY
        val len = max(1f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
        // the wall stands nine and a bit yards away, on the line to goal
        wallX = freeKickX + dx / len * 11f
        wallY = freeKickY + dy / len * 11f
        wallCount = if (kotlin.math.abs(dx) < 30f) 4 else 3

        val defenders = onPitch(def).filter { it.pos != Pos.GK }
            .sortedBy { hypot((it.x - wallX).toDouble(), (it.y - wallY).toDouble()) }
        for (i in 0 until min(wallCount, defenders.size)) {
            defenders[i].targetX = wallX + (i - wallCount / 2f) * 1.6f
            defenders[i].targetY = wallY + (i - wallCount / 2f) * 2.4f
            defenders[i].x = defenders[i].targetX
            defenders[i].y = defenders[i].targetY
            defenders[i].facing = kotlin.math.atan2((freeKickY - defenders[i].y).toDouble(),
                (freeKickX - defenders[i].x).toDouble()).toFloat()
        }
        taker.x = freeKickX - dx / len * 4f
        taker.y = freeKickY - dy / len * 4f
    }

    /** One man to the touchline, the rest showing for it. */
    private fun stageThrowIn(side: Int, bx: Float, by: Float) {
        val takers = onPitch(side).filter { it.pos != Pos.GK }
        val taker = nearest(takers, bx, by) ?: return
        taker.targetX = bx; taker.targetY = if (by < 50f) 4f else 96f
        act(taker, Act.RUN, 0.4f, angleTo(taker, bx, 50f))
        for (p in takers) {
            if (p.key == taker.key) continue
            p.targetY += (by - p.targetY) * 0.18f
            p.targetX += (bx - p.targetX) * 0.14f
        }
    }

    /** Pull everyone into the box so a corner reads as a corner. */
    private fun stageCorner(att: Int) {
        val goalX = if (att == 0) 100f else 0f
        val cornerY = if (rng.chance(0.5)) 4f else 96f
        ball.x = goalX; ball.y = cornerY
        for (p in onPitch(att)) {
            if (p.pos == Pos.GK) continue
            p.targetX = if (att == 0) 86f + rng.f().toFloat() * 10f else 4f + rng.f().toFloat() * 10f
            p.targetY = 32f + rng.f().toFloat() * 36f
        }
        for (p in onPitch(1 - att)) {
            p.targetX = if (att == 0) 88f + rng.f().toFloat() * 9f else 3f + rng.f().toFloat() * 9f
            p.targetY = 30f + rng.f().toFloat() * 40f
        }
    }

    private fun attemptShot(att: Int, shooter: LivePlayer, quality: Double, kind: String) {
        val def = 1 - att
        shots[att]++
        xg[att] += quality
        shooter.shots++
        captureFrame()

        val gk = onPitch(def).firstOrNull { it.pos == Pos.GK }
        val goalX = if (att == 0) 99f else 1f
        val shotDist = hypot((goalX - ball.x).toDouble(), (50f - ball.y).toDouble()).toFloat()
        // distance-aware: a flat 0.55s meant long shots travelled absurdly fast
        moveBallTo(goalX, 50f + (rng.f().toFloat() - 0.5f) * 16f,
            (0.34f + shotDist / 46f).coerceIn(0.34f, 1.15f),
            if (kind == "header") 1.5f else 0.8f)
        ball.holder = null

        // the striker plants his foot; the keeper reacts
        if (kind == "header") corners.let { }
        act(shooter, if (kind == "header") Act.HEADER else Act.SHOOT, 0.75f,
            angleTo(shooter, goalX, 50f))
        cue(if (kind == "header") Synth.Sfx.KICK else Synth.Sfx.KICK_HARD, 1f, shooter.x)
        crowdTarget = max(crowdTarget, 0.80f)
        if (gk != null) act(gk, Act.DIVE, 1.1f, if (rng.chance(0.5)) -1.35f else 1.35f)

        val gkSkill = if (gk != null)
            gk.ref.att[Att.GKR] * 0.6 + gk.ref.att[Att.GKH] * 0.4 else 50.0

        val tOn = min(0.92, 0.33 + quality * 0.7)
        if (!rng.chance(tOn)) {
            say(L_MISS, shooter.name, teamName(att))
            // a share of the misses are woodwork; it is only a sound, decided on
            // the cosmetic stream, so the result is exactly what it was before
            if (sfxRng.chance(0.16)) cue(Synth.Sfx.POST, 0.95f, goalX)
            cue(Synth.Sfx.OOH, 0.85f)
            crowdTarget = 0.45f
            scene = Scene.GOAL_KICK; sceneTime = 1.3f
            val gkeep = onPitch(def).firstOrNull { it.pos == Pos.GK }
            if (gkeep != null) {
                ball.x = if (def == 0) 8f else 92f
                ball.y = 50f
                ball.t = 1f
                ball.holder = null
                gkeep.targetX = ball.x; gkeep.targetY = 50f
            }
            flipLater(def, 0.6)
            return
        }
        onTarget[att]++
        val convert = ((quality / tOn) * (1.0 - (gkSkill - 62.0) / 320.0)).coerceIn(0.03, 0.95)
        if (rng.chance(convert)) {
            scoreGoal(att, shooter, false)
        } else {
            if (gk != null) { gk.saves++ }
            cue(Synth.Sfx.OOH, 0.7f)
            cue(Synth.Sfx.APPLAUSE, 0.55f)
            crowdTarget = 0.50f
            say(L_SAVE, shooter.name, gk?.name ?: "the keeper")
            if (rng.chance(0.45)) { corners[att]++; scene = Scene.CORNER; sceneTime = 1.3f; stageCorner(att) }
            else scene = Scene.GOAL_KICK
            sceneTime = 1.2f
            flipLater(def, 0.5)
        }
    }

    private fun takePenalty(att: Int) {
        val def = 1 - att
        scene = Scene.PENALTY; sceneTime = 2.0f
        val attClub = if (att == 0) home else away
        val takers = onPitch(att).filter { it.pos != Pos.GK }
        // the nominated penalty taker steps up if he is still on the pitch
        val nominated = attClub.tactics.penaltyTaker.let { slot ->
            if (slot >= 0) takers.firstOrNull { it.slot == slot } else null
        }
        val taker = nominated ?: takers.maxByOrNull {
            it.ref.att[Att.FIN] + (if (it.ref.hasTrait(Traits.SET_PIECE)) 20 else 0)
        } ?: return
        val gk = onPitch(def).firstOrNull { it.pos == Pos.GK }
        act(taker, Act.SHOOT, 1.0f, if (att == 0) 0f else Math.PI.toFloat())
        if (gk != null) act(gk, Act.DIVE, 1.3f, if (rng.chance(0.5)) -1.35f else 1.35f)

        shots[att]++; onTarget[att]++; xg[att] += 0.78
        ball.x = if (att == 0) 88f else 12f
        ball.y = 50f
        moveBallTo(if (att == 0) 99f else 1f, 50f + (rng.f().toFloat() - 0.5f) * 14f, 0.62f, 0.8f)
        captureFrame()

        var chance = 0.76 + (taker.ref.att[Att.FIN] - 60) / 500.0
        if (gk != null) chance -= (gk.ref.att[Att.GKR] - 60) / 700.0
        if (rng.chance(chance)) {
            scoreGoal(att, taker, true)
        } else {
            if (gk != null) gk.saves++
            say(L_PENMISS, taker.name, gk?.name ?: "the keeper")
            flipLater(def, 0.6)
        }
    }

    private fun scoreGoal(att: Int, scorer: LivePlayer, penalty: Boolean) {
        score[att]++
        scorer.goals++
        var assist: LivePlayer? = null
        if (!penalty && rng.chance(0.65)) {
            val mates = onPitch(att).filter { it.key != scorer.key && it.pos != Pos.GK }
            assist = nearest(mates, scorer.x, scorer.y)
            assist?.assists++
        }
        momentum = (momentum + if (att == 0) 0.35 else -0.35).coerceIn(-1.0, 1.0)
        flash = 1f; shake = 1f
        celebrateKey = scorer.key
        celebrateTime = 0f
        act(scorer, Act.CELEBRATE, 2.4f)
        for (mate in onPitch(att)) if (mate.key != scorer.key && rng.chance(0.4)) act(mate, Act.CELEBRATE, 1.8f)
        banner = "GOAL!  ${scorer.fullName}"
        bannerTime = 2.4f
        // He peels away toward the near corner, but only part of the way: a
        // sprint to the flag from wherever he happened to be left the rest of
        // the team stranded in midfield with nobody to mob.
        celebrationTime = 6.0f
        celebrateSide = att
        celebrateScorer = scorer.key
        val cornerX = if (att == 0) 96f else 4f
        val cornerY = if (scorer.y < 50f) 6f else 94f
        celebrateRunX = scorer.x + (cornerX - scorer.x) * 0.45f
        celebrateRunY = scorer.y + (cornerY - scorer.y) * 0.45f
        cue(Synth.Sfx.NET, 1f, if (att == 0) 96f else 4f)
        cue(Synth.Sfx.ROAR, 1f)
        cue(Synth.Sfx.APPLAUSE, 0.8f)
        crowdTarget = 1.0f
        if (replaysEnabled) {
            pendingReplay = history.takeLast(78).toList()
            replayDelay = 2.9f
        }
        replayIndex = 0
        replayCursor = 0f

        val scoreText = "${score[0]}-${score[1]}"
        if (assist != null) sayRaw(
            FeedLine.GOAL,
            "${assist.name} slides it through and ${scorer.fullName} finishes it off. $scoreText."
        ) else sayRaw(
            FeedLine.GOAL,
            if (penalty) "${scorer.fullName} sends the keeper the wrong way from the spot. $scoreText."
            else "${scorer.fullName} finds the net. $scoreText."
        )
        events.add(MatchEvent(clock.toInt(), Ev.GOAL, att, scorer.fullName, assist?.fullName ?: ""))
        flipLater(1 - att, 1.2)
    }

    private fun showRef(p: LivePlayer, card: Int) {
        refX = p.x - 4f
        refY = p.y + 2f
        refCard = card
        refTime = 2.6f
    }

    private fun card(p: LivePlayer, red: Boolean) {
        showRef(p, if (red) 2 else 1)
        cue(Synth.Sfx.WHISTLE_SHORT, 0.85f, p.x)
        cue(Synth.Sfx.GROAN, 0.6f)
        crowdTarget = max(crowdTarget, 0.65f)
        if (red) { sendOff(p, false); return }
        p.yellow++
        yellows[p.side]++
        if (p.yellow >= 2) { sendOff(p, true); return }
        sayRaw(FeedLine.CARD, "${p.fullName} goes into the book.")
        events.add(MatchEvent(clock.toInt(), Ev.YELLOW, p.side, p.fullName))
    }

    private fun sendOff(p: LivePlayer, second: Boolean) {
        p.sentOff = true
        p.onPitch = false
        reds[p.side]++
        banner = "RED CARD  \u2014  ${p.fullName}"
        bannerTime = 2.4f
        sayRaw(FeedLine.CARD, "${p.fullName} is off! Down to ten.")
        events.add(MatchEvent(clock.toInt(), Ev.RED, p.side, p.fullName))
        val r = rating(p.side)
        r.attack -= 2.6; r.defence -= 2.2; r.control -= 3.0
    }

    private fun injure(p: LivePlayer) {
        cue(Synth.Sfx.WHISTLE_SHORT, 0.8f, p.x)
        crowdTarget = 0.25f
        p.injured = true
        act(p, Act.DOWN, 2.2f)
        p.injuryWeeks = if (rng.chance(0.60)) rng.i(1, 3) else rng.i(4, 12)
        banner = "${p.fullName} is down"
        bannerTime = 1.8f
        sayRaw(FeedLine.PLAIN, "${p.fullName} pulls up and signals to the bench.")
        events.add(MatchEvent(clock.toInt(), Ev.INJURY, p.side, p.fullName))
    }

    private fun flip(side: Int) {
        possessionSide = nextSide(side)
        newPhase()
    }

    private fun flipLater(side: Int, delayMinutes: Double) {
        pendingSide = side
        pendingAt = clock + delayMinutes
        phaseSeq = ArrayList()
    }

    /** The better team on the ball wins it back more often — this is what moves possession %. */
    private fun nextSide(natural: Int): Int {
        val h = ratingHome.control
        val a = ratingAway.control
        val pHome = (0.5 + (h - a) / 45.0).coerceIn(0.26, 0.74)
        if (rng.chance(0.62)) return natural
        return if (rng.chance(pHome)) 0 else 1
    }

    /**
     * Puts a player into a pose for a moment. Floor poses are rationed so the
     * pitch never fills up with men lying down, and only a keeper may dive.
     */
    private fun act(p: LivePlayer, action: Int, seconds: Float, dir: Float = p.facing) {
        if (action == Act.DIVE && p.pos != Pos.GK) return
        if (action == Act.TACKLE || action == Act.DOWN) {
            val onFloor = players.count {
                it.onPitch && (it.action == Act.TACKLE || it.action == Act.DOWN)
            }
            if (onFloor >= 2) return
        }
        p.action = action
        p.actionTime = seconds
        p.actionDir = dir
    }

    private fun angleTo(from: LivePlayer, x: Float, y: Float): Float =
        kotlin.math.atan2((y - from.y).toDouble(), (x - from.x).toDouble()).toFloat()

    private fun nearest(list: List<LivePlayer>, x: Float, y: Float): LivePlayer? {
        var best: LivePlayer? = null
        var bd = Float.MAX_VALUE
        for (p in list) {
            val d = hypot((p.x - x).toDouble(), (p.y - y).toDouble()).toFloat()
            if (d < bd) { bd = d; best = p }
        }
        return best
    }

    private fun <T> List<T>.randomOrNull(r: Rng): T? = if (isEmpty()) null else r.pick(this)

    private fun teamName(side: Int) = if (side == 0) home.name else away.name

    /* ------------------------------------------------------- COMMENTARY */

    private val L_PASS = 0; private val L_TACKLE = 1; private val L_FOUL = 2
    private val L_MISS = 3; private val L_SAVE = 4; private val L_CORNER = 5
    private val L_PENALTY = 6; private val L_PENMISS = 7; private val L_AMBIENT = 8

    private val BANKS: Array<Array<String>> = arrayOf(
        arrayOf("{a} looks up and finds {b}.", "{a} switches it to {b}.", "Neat interchange, {a} to {b}.",
            "{a} rolls it into {b}.", "{a} clips it forward for {b}.", "Simple ball, {a} to {b}.",
            "{a} threads it between the lines to {b}.", "{a} plays it first time into {b}.",
            "{b} drops off and takes it from {a}.", "{a} spreads it wide to {b}.",
            "{a} finds the angle, and {b} is there.", "Patient stuff, {a} to {b}.",
            "{a} dinks it over the top for {b}.", "{b} shows for it and {a} obliges.",
            "A one-two between {a} and {b}."),
        arrayOf("{a} times the challenge perfectly on {b}.", "Superb tackle by {a} to dispossess {b}.",
            "{a} reads it and steals in front of {b}.", "{a} nicks it off {b}'s toe.",
            "Strong in the challenge, {a} comes away with it.", "{b} loses it, and {a} is the man who took it.",
            "{a} gets across {b} and shepherds it away.", "That is a proper tackle from {a}.",
            "{a} wins it back inside his own half.", "{b} dallied, and {a} punished him."),
        arrayOf("{a} clips {b} \u2014 free kick.", "Cynical from {a}, and the whistle goes.",
            "{a} catches {b} late."),
        arrayOf("{a} drags it wide.", "{a} skies it over the bar.", "Nowhere near for {a}.",
            "{a} takes it on and it whistles past the post.", "{a} leans back and puts it into the stand.",
            "Off target from {a}, and he knows it.", "{a} snatches at it.",
            "It comes off the outside of {a}'s boot and away.", "{a} curls it just the wrong side of the upright.",
            "A glorious chance, and {a} has put it wide.", "{a} tries the far corner and misses it by a yard.",
            "Wasteful from {a}."),
        arrayOf("{a} tries his luck \u2014 {b} pushes it away.", "Fine stop from {b} to deny {a}.",
            "{b} gets a strong hand to {a}'s effort.", "{b} is equal to it, and {a} holds his head.",
            "What a save! {b} keeps {a} out.", "{a} strikes it well but {b} is behind it.",
            "{b} parries, and the danger is cleared.", "Point-blank from {a}, and {b} somehow stops it.",
            "{b} tips {a}'s effort over the top.", "{a} thought he had scored. {b} had other ideas."),
        arrayOf("Corner to {a}.", "{a} win a corner and load the box."),
        arrayOf("Penalty! {a} brings him down inside the area \u2014 {b} have a huge chance."),
        arrayOf("{b} saves it! {a} will not sleep tonight.", "{a} strikes it poorly and {b} keeps it out."),
        arrayOf("A real edge to this one now.", "The crowd senses something.",
            "Both sides feeling their way back into it.", "A scrappy spell in midfield.",
            "The managers are on the touchline barking instructions.",
            "Territory, without the final ball.", "The tempo has dropped right off.",
            "Plenty of huff and puff, not much end product.", "It has turned into a battle in the middle.",
            "Both benches are up and shouting.", "You can feel this one turning.",
            "A lull, and the crowd has gone quiet with it.", "Neither side wants to give an inch.",
            "The referee has a word \u2014 tempers are fraying.", "End to end for a moment there.",
            "Someone needs to take hold of this game.", "A booking waiting to happen.",
            "The pitch is cutting up badly now.", "Legs are going in this heat.",
            "That is better \u2014 finally some rhythm.")
    )

    private fun say(bank: Int, a: String, b: String) {
        val used = usedLines.getOrPut(bank) { ArrayList() }
        val options = BANKS[bank]
        if (used.size >= options.size) used.clear()
        var idx = rng.i(0, options.size - 1)
        var guard = 0
        while (used.contains(idx) && guard++ < 12) idx = rng.i(0, options.size - 1)
        used.add(idx)
        val kind = when (bank) {
            L_MISS, L_SAVE, L_PENALTY, L_PENMISS -> FeedLine.CHANCE
            else -> FeedLine.PLAIN
        }
        sayRaw(kind, options[idx].replace("{a}", a).replace("{b}", b))
    }

    private fun sayRaw(kind: Int, text: String) {
        feed.add(0, FeedLine(clock.toInt(), text, kind))
        while (feed.size > 120) feed.removeAt(feed.size - 1)
    }

    /* ------------------------------------------------------------ UPDATE */

    fun start() {
        if (finished) return
        if (!kicked && lineupTime <= 0f && !lineupDone) {
            // the walkout runs first; the whistle follows it
            lineupDone = true
            lineupTime = 4.0f
            scene = Scene.LINEUP
            banner = "TEAMS ARE OUT"
            bannerTime = 3.0f
            crowdTarget = 0.62f
            cue(Synth.Sfx.APPLAUSE, 0.85f)
            running = true
            return
        }
        if (!kicked) {
            kicked = true
            sayRaw(FeedLine.WHISTLE, "We are under way at ${home.stadiumName}. ${home.name} against ${away.name}.")
            banner = "KICK OFF"; bannerTime = 1.8f
            cue(Synth.Sfx.WHISTLE_SHORT, 0.9f)
            cue(Synth.Sfx.APPLAUSE, 0.7f)
            crowdTarget = 0.55f
            newPhase()
        }
        running = true
    }

    fun pause() { running = false }

    /** Advance the simulation by a slice of real time. */
    fun update(dtSeconds: Float) {
        if (finished) return
        // nothing moves on the pitch while the goal is being shown again, but
        // the replay itself is advanced here so play always resumes on its own
        if (advanceReplay(dtSeconds)) return

        if (lineupTime > 0f) {
            lineupTime -= dtSeconds
            updateTargets()
            moveTowardTargets(dtSeconds * 2.0f)
            if (lineupTime <= 0f) {
                lineupTime = 0f
                scene = Scene.NONE
                resetShape(0); resetShape(1)
                start()
            }
            return
        }
        if (replayDelay > 0f) {
            replayDelay -= dtSeconds
            if (replayDelay <= 0f) {
                replayDelay = 0f
                replay = pendingReplay
                pendingReplay = null
                replayCursor = 0f
                replayIndex = 0
            }
        }
        val step = dtSeconds * speed
        val minutes = step / SECONDS_PER_MINUTE
        clock += minutes

        val halfEnd = if (half == 1) 45.0 else 90.0
        if (clock >= halfEnd + addedTime) {
            if (half == 1) {
                half = 2; clock = 45.0; addedTime = 0.0
                running = false
                resetShape(0); resetShape(1)
                ball.x = 50f; ball.y = 50f; ball.holder = null
                phaseSeq = ArrayList()
                sayRaw(FeedLine.WHISTLE, "Half time: ${home.name} ${score[0]} - ${score[1]} ${away.name}.")
                banner = "HALF TIME"; bannerTime = 2.4f
                cue(Synth.Sfx.WHISTLE_LONG, 1f)
                cue(Synth.Sfx.APPLAUSE, 0.6f)
                crowdTarget = 0.35f
                return
            }
            endMatch()
            return
        }
        updateCrowd(step)
        if (half == 1 && clock > 44.5 && addedTime == 0.0) addedTime = 0.5 + rng.f() * 2.5
        if (half == 2 && clock > 89.5 && addedTime == 0.0) addedTime = 1.0 + rng.f() * 4.0

        // fatigue
        for (p in players) {
            if (!p.onPitch) continue
            val drain = minutes * (0.28 + (100 - p.ref.att[Att.STA]) * 0.0035) *
                    (if (p.ref.hasTrait(Traits.ENGINE)) 0.75 else 1.0)
            p.fitness = max(15.0, p.fitness - drain)
            p.effective = p.ref.effective(p.pos) * (0.75 + 0.25 * p.fitness / 100.0)
            p.minutes += minutes
        }

        if (rng.chance(minutes * 0.0022)) {
            val candidates = players.filter { it.onPitch && !it.injured }
            if (candidates.isNotEmpty()) injure(rng.pick(candidates))
        }

        if (pendingSide >= 0 && clock >= pendingAt) {
            val s = pendingSide; pendingSide = -1
            possessionSide = nextSide(s)
            newPhase()
        }

        if (phaseSeq.isEmpty() && pendingSide < 0) newPhase()

        if (phaseSeq.isNotEmpty()) {
            phaseTimer += minutes
            val stepDuration = phaseDuration / max(1, phaseSeq.size)
            val wantStep = (phaseTimer / stepDuration).toInt()
            var guard = 0
            while (phaseSeq.isNotEmpty() && phaseStep < wantStep && phaseStep < phaseSeq.size && guard++ < 12) {
                stepPhase()
            }
            if (phaseSeq.isNotEmpty() && phaseTimer >= phaseDuration && phaseStep >= phaseSeq.size - 1) {
                resolvePhase()
            }
        }

        ambientTimer += minutes
        if (ambientTimer > 7 + rng.f() * 8) { ambientTimer = 0.0; say(L_AMBIENT, "", "") }

        aiSubstitutions(minutes)
        aiManagerThink(minutes)

        // ball flight
        val prevX = ball.x
        val prevY = ball.y
        if (ball.t < 1f) {
            ball.t = min(1f, ball.t + dtSeconds * speed / ball.duration)
            // A struck ball leaves quickly and slows as friction takes hold.
            // With e = 1 - (1-t)^k the launch speed is exactly k times the
            // average, so the exponent is the one number that matters: the old
            // curve worked out at 2.35x and put shots past 100 m/s.
            val e = 1f - Math.pow((1f - ball.t).toDouble(), LAUNCH_RATIO.toDouble()).toFloat()
            ball.x = ball.fromX + (ball.toX - ball.fromX) * e
            ball.y = ball.fromY + (ball.toY - ball.fromY) * e
            // the bend is a sideways push, greatest in mid-flight
            if (ball.curve != 0f) {
                val dx = ball.toX - ball.fromX
                val dy = ball.toY - ball.fromY
                val len = max(0.001f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
                val bend = kotlin.math.sin(ball.t * Math.PI).toFloat() * ball.curve
                ball.x += (-dy / len) * bend
                ball.y += (dx / len) * bend
            }
            // height is a parabola under gravity, and it is zero on the floor
            ball.height = if (ball.loft <= 0.01f) 0f
            else ball.loft * 4f * ball.t * (1f - ball.t)
            // remember how fast it was going, so it can run on
            ball.driftX = (ball.x - prevX)
            ball.driftY = (ball.y - prevY)
            // arriving from a loft, it lands with real downward speed and will
            // bounce rather than stick to the turf the instant it gets there
            if (ball.t >= 1f && ball.loft > 0.01f) ball.vz = -ball.loft * 1.9f
        } else {
            // a loose ball bounces down under gravity, losing height each time
            if (ball.holder == null && (ball.height > 0.001f || ball.vz < -0.001f)) {
                ball.vz -= 9.0f * dtSeconds * speed
                ball.height = max(0f, ball.height + ball.vz * dtSeconds * speed)
                if (ball.height <= 0f) {
                    if (ball.vz < -0.55f) {
                        ball.vz = -ball.vz * 0.46f
                        cue(Synth.Sfx.KICK, 0.22f, ball.x)
                        // it skids on a little as it comes off the turf
                        ball.driftX *= 1.06f
                        ball.driftY *= 1.06f
                    } else ball.vz = 0f
                }
            } else ball.height = 0f
            val h = players.firstOrNull { it.key == ball.holder }
            if (h != null) {
                // He does not catch it dead. The ball keeps running and he
                // gathers it over the next stride, which is what makes the
                // control look like control rather than a magnet.
                val footX = h.x + kotlin.math.cos(h.facing.toDouble()).toFloat() * 1.2f
                val footY = h.y + kotlin.math.sin(h.facing.toDouble()).toFloat() * 1.2f + 0.4f
                ball.x += ball.driftX
                ball.y += ball.driftY
                ball.driftX *= 0.80f
                ball.driftY *= 0.80f
                val pull = 0.22f
                ball.x += (footX - ball.x) * pull
                ball.y += (footY - ball.y) * pull
            } else {
                // nobody on it: it rolls to a stop
                ball.x += ball.driftX
                ball.y += ball.driftY
                ball.driftX *= 0.94f
                ball.driftY *= 0.94f
            }
        }
        // spin follows how far it actually moved this frame
        val moved = hypot((ball.x - prevX).toDouble(), (ball.y - prevY).toDouble()).toFloat()
        ball.spin += moved * 0.55f

        updateTargets()
        moveTowardTargets(dtSeconds * speed)
        captureFrame()

        flash = max(0f, flash - dtSeconds * 2.2f)
        shake = max(0f, shake - dtSeconds * 2.6f)
        bannerTime = max(0f, bannerTime - dtSeconds)
        if (bannerTime <= 0f) banner = null
        sceneTime = max(0f, sceneTime - dtSeconds)
        if (sceneTime <= 0f) scene = Scene.NONE
        refTime = max(0f, refTime - dtSeconds)
        if (refTime <= 0f) refCard = 0
        if (celebrateKey != null) {
            celebrateTime += dtSeconds * speed
            if (celebrateTime > 2.4f) celebrateKey = null
        }
        if (celebrationTime > 0f) {
            celebrationTime = max(0f, celebrationTime - dtSeconds * speed)
            if (celebrationTime <= 0f) { celebrateSide = -1; celebrateScorer = null }
        }
        momentum *= (1 - dtSeconds * 0.08)
    }

    /**
     * The goal celebration. The scorer runs off toward the corner flag, his
     * team-mates converge on wherever he has got to, and the side that conceded
     * trudges back to its own half. It replaces the normal shape entirely for a
     * few seconds, which is why it sits ahead of the tactical targets.
     */
    /**
     * The teams out on the pitch before a ball is kicked: two lines either side
     * of halfway, everyone square to the camera. It costs four seconds and it is
     * the first thing that tells you a match is about to start.
     */
    private fun lineupTargets(): Boolean {
        if (lineupTime <= 0f) return false
        for (side in 0..1) {
            val men = onPitch(side)
            val rowY = if (side == 0) 44f else 56.5f
            for (i in men.indices) {
                val p = men[i]
                p.targetX = 27f + i * (46f / max(1, men.size - 1))
                p.targetY = rowY
                // square to the camera, arms by the sides
                p.facing = (Math.PI / 2).toFloat()
                p.action = Act.RUN
            }
        }
        return true
    }

    private fun celebrationTargets(): Boolean {
        if (celebrationTime <= 0f || celebrateSide < 0) return false
        val scorer = players.firstOrNull { it.key == celebrateScorer && it.onPitch }
        for (p in players) {
            if (!p.onPitch) continue
            if (p.side == celebrateSide) {
                if (p.pos == Pos.GK) {
                    // the keeper stays home and settles for punching the air
                    p.targetX = if (p.side == 0) 6f else 94f
                    p.targetY = 50f
                } else if (scorer != null && p.key == scorer.key) {
                    p.targetX = celebrateRunX
                    p.targetY = celebrateRunY
                } else if (scorer != null) {
                    // fan out around him rather than stacking on the same spot
                    val a = (p.slot * 1.31f)
                    p.targetX = (scorer.x - 4f + kotlin.math.cos(a.toDouble()).toFloat() * 4.5f)
                        .coerceIn(3f, 97f)
                    p.targetY = (scorer.y + kotlin.math.sin(a.toDouble()).toFloat() * 4.5f)
                        .coerceIn(5f, 95f)
                }
            } else {
                // heads down, back to the halfway line for the restart
                p.targetX = if (p.side == 0) p.baseX * 0.75f + 12f else p.baseX * 0.75f + 13f
                p.targetY = p.baseY
            }
        }
        return true
    }

    private fun updateTargets() {
        if (lineupTargets()) return
        if (celebrationTargets()) return
        if (scene == Scene.CORNER || scene == Scene.PENALTY) return
        for (side in 0..1) {
            val club = if (side == 0) home else away
            val t = club.tactics
            val attacking = possessionSide == side
            val dir = if (side == 0) 1f else -1f
            // These are deliberately strong: you should be able to SEE a change
            // of instruction in where the players stand.
            val lineShift = (t.line - 1) * 13f
            val mentShift = (t.mentality - 2) * 7f
            val widthMul = when (t.width) { 0 -> 0.58f; 2 -> 1.38f; else -> 1.0f }
            val pressPull = when (t.press) { 0 -> -0.10f; 2 -> 0.22f; else -> 0f }
            // Focus of play slides the whole shape toward a flank or the middle.
            val focusShift = when (t.focus) { 0 -> -11f; 2 -> 11f; else -> 0f }
            val focusSpread = if (t.focus == 3) 1.18f else 1f
            // whoever is nearest the man we are marking takes the job
            val markerSlot = if (t.oppTargetId >= 0 && t.oppMode == 1)
                onPitch(side).filter { Pos.group(it.pos) == 1 }.minByOrNull { it.baseY }?.slot ?: -1 else -1

            for (p in onPitch(side)) {
                val fx = RoleFx.of(t.roleName(p.slot))
                val pi = t.slotInstructions.getOrElse(p.slot) { 0 }

                var roleX = fx.xShift
                var roleSpread = fx.ySpread
                if (pi and PI.GET_FORWARD != 0) roleX += 7f
                if (pi and PI.STAY_BACK != 0) roleX -= 9f
                if (pi and PI.HOLD_POSITION != 0) roleX -= 2f
                if (pi and PI.STAY_WIDER != 0) roleSpread *= 1.22f
                if (pi and PI.CUT_INSIDE != 0) roleSpread *= 0.66f

                val bx0 = ownX(side, p.baseX + dir * 0f) + dir * roleX
                var by0 = ownY(side, p.baseY)
                by0 = 50f + (by0 - 50f) * widthMul * focusSpread * roleSpread + focusShift

                val pull = (ball.x - 50f) * ((if (attacking) 0.42f else 0.55f) + pressPull)
                var tx = bx0 + pull + dir * (lineShift + mentShift) * (if (attacking) 0.6f else 1f)
                if (attacking && (p.pos == Pos.ST || p.pos == Pos.AM)) tx += dir * 7f
                if (t.counter && !attacking && Pos.group(p.pos) == 3) tx -= dir * 5f
                if (pi and PI.HOLD_POSITION != 0) tx = bx0 + pull * 0.35f + dir * mentShift * 0.3f
                if (p.pos == Pos.GK) tx = ownX(side, if (attacking) 10f else 5f)

                // pressing drags the nearest men toward the ball
                var ty = by0 + (ball.y - 50f) * (if (p.pos == Pos.GK) 0.12f else 0.28f + pressPull)
                if (!attacking && (t.press == 2 || pi and PI.CLOSE_DOWN != 0) && Pos.group(p.pos) >= 2) {
                    ty += (ball.y - ty) * 0.20f
                    tx += (ball.x - tx) * 0.12f
                }
                // man-marking drags a defender onto the man he has been given
                if (!attacking && t.oppTargetId >= 0 && t.oppMode == 1 && p.slot == markerSlot) {
                    val mark = players.firstOrNull { it.ref.id == t.oppTargetId && it.onPitch }
                    if (mark != null) { tx = mark.x - dir * 2f; ty = mark.y }
                }
                // Nobody strays beyond the last defender: an attacker who did
                // would simply be offside, and it looked wrong on the pitch.
                if (attacking && Pos.group(p.pos) == 3) {
                    val theirLine = lastDefenderX(1 - side)
                    tx = if (side == 0) kotlin.math.min(tx, theirLine + 1.5f)
                    else kotlin.math.max(tx, theirLine - 1.5f)
                }
                p.targetX = tx.coerceIn(3f, 97f)
                p.targetY = ty.coerceIn(5f, 95f)
            }
        }
    }

    /** Where the deepest outfield defender of a side is standing. */
    private fun lastDefenderX(side: Int): Float {
        val backs = onPitch(side).filter { it.pos != Pos.GK }
        if (backs.isEmpty()) return if (side == 0) 20f else 80f
        return if (side == 0) backs.minOf { it.x } else backs.maxOf { it.x }
    }

    private fun moveTowardTargets(dt: Float) {
        for (p in players) {
            if (!p.onPitch) continue

            // a pose always runs out; nothing can get stuck on the floor
            p.actionTime -= dt
            if (p.actionTime <= 0f) {
                p.actionTime = 0f
                if (p.action != Act.RUN) p.action = Act.RUN
            }

            // a man sliding or on the floor is not chasing anything
            if (p.action == Act.TACKLE || p.action == Act.DOWN || p.action == Act.DIVE) {
                p.speedNow *= 0.86f
                continue
            }

            val pace = (p.ref.att[Att.PAC] + p.ref.att[Att.ACC]) / 2f

            // Nobody sprints for ninety minutes. Before this, every man on the
            // pitch ran flat out the whole match, which worked out at about
            // nine and a half metres a second each — sprint pace, permanently,
            // and the main reason the movement looked wrong. Effort now falls
            // away with distance from the ball: the man on it works hardest,
            // the far side of the pitch jogs into shape.
            val dBall = hypot((ball.x - p.x).toDouble(), (ball.y - p.y).toDouble()).toFloat()
            val urgency = when {
                p.key == ball.holder -> 1.00f
                dBall < 14f -> 0.88f
                dBall < 30f -> 0.62f
                dBall < 50f -> 0.46f
                else -> 0.36f
            }
            val top = (if (p.pos == Pos.GK) 3.6f else 5.2f + pace / 22f) *
                    (0.8f + p.effective.toFloat() / 250f) *
                    (if (p.injured) 0.4f else 1f) *
                    urgency * 0.86f
            // and he has to get up to it rather than arriving at it instantly
            p.gaitSpeed += (top - p.gaitSpeed) * min(1f, dt * 3.4f)
            val speedUnits = p.gaitSpeed
            val dx = p.targetX - p.x
            val dy = p.targetY - p.y
            val d = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (d > 0.3f) {
                val stepLen = min(d, speedUnits * dt)
                p.x += dx / d * stepLen
                p.y += dy / d * stepLen
                p.facing = kotlin.math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                p.speedNow = stepLen / max(dt, 0.001f)
                p.runPhase += stepLen * 1.1f
            } else {
                p.speedNow *= 0.8f
                // idle players still turn to watch the ball
                val bx = ball.x - p.x
                val by = ball.y - p.y
                if (abs(bx) + abs(by) > 0.1f) {
                    p.facing = kotlin.math.atan2(by.toDouble(), bx.toDouble()).toFloat()
                }
            }
        }
    }

    /**
     * The stand reacts to where the ball is rather than only to events: it lifts
     * as an attack reaches the final third and sinks back through midfield. A
     * goal or a chance pushes [crowdTarget] up directly; this pulls it down again.
     */
    private fun updateCrowd(stepSeconds: Float) {
        val d = min(ball.x, 100f - ball.x)          // distance to the nearer goal
        val heat = ((28f - d) / 28f).coerceIn(0f, 1f)
        val resting = 0.22f + heat * 0.42f
        // fall back gently; the cues above are what make it spike
        if (crowdTarget > resting) {
            crowdTarget = max(resting, crowdTarget - stepSeconds * 0.28f)
        } else {
            crowdTarget += (resting - crowdTarget) * min(1f, stepSeconds * 1.2f)
        }
    }

    private fun captureFrame() {
        if (!replaysEnabled) return
        val live = players.filter { it.onPitch }
        val xs = FloatArray(live.size)
        val ys = FloatArray(live.size)
        for (i in live.indices) { xs[i] = live[i].x; ys[i] = live[i].y }
        history.add(Frame(ball.x, ball.y, xs, ys))
        while (history.size > 160) history.removeAt(0)
    }

    /* ------------------------------------------------------- OPPOSITION AI */

    private var aiThinkTimer = 0.0
    private var aiLastNote = ""

    /**
     * The opposing manager. He reads the scoreline, the clock and — crucially —
     * what you are doing, then changes his own shape to answer it. Beat him
     * tactically and he will try something else.
     */
    private fun aiManagerThink(minutes: Double) {
        aiThinkTimer += minutes
        if (aiThinkTimer < 9.0) return
        aiThinkTimer = 0.0

        for (side in 0..1) {
            val club = if (side == 0) home else away
            if (club.isUser) continue
            val userClub = if (side == 0) away else home
            if (!userClub.isUser) continue          // AI vs AI needs no theatre

            val t = club.tactics
            val u = userClub.tactics
            val mine = score[side]
            val theirs = score[1 - side]
            val late = clock > 65
            val veryLate = clock > 78
            var note = ""

            // 1. the scoreline
            if (mine < theirs && late) {
                if (t.mentality < 4) { t.mentality++; note = "throwing men forward" }
                if (t.press < 2 && veryLate) t.press = 2
                if (t.line < 2 && veryLate) t.line = 2
            } else if (mine > theirs && veryLate) {
                if (t.mentality > 0) { t.mentality--; note = "shutting up shop" }
                if (t.line > 0) t.line--
            }

            // 2. answering your shape
            if (note.isEmpty()) {
                when {
                    // you press high — they go long to bypass it
                    u.press == 2 && t.passing != 2 -> {
                        t.passing = 2; note = "going more direct to beat the press"
                    }
                    // you sit deep and counter — they keep the ball and squeeze up
                    u.line == 0 && t.passing != 0 -> {
                        t.passing = 0; t.line = 2; note = "taking control of the ball"
                    }
                    // you stretch the pitch — they tuck in
                    u.width == 2 && t.width != 0 -> {
                        t.width = 0; note = "narrowing up to protect the middle"
                    }
                    // you play narrow — they attack the flanks
                    u.width == 0 && t.width != 2 -> {
                        t.width = 2; note = "stretching the play wide"
                    }
                    // you are dominating the ball — they get tighter
                    possessionHome.let { ph -> (if (side == 0) ph else 100 - ph) < 40 } && t.press < 2 -> {
                        t.press++; note = "pressing higher up"
                    }
                    // you are carving them open — they drop off
                    xg[1 - side] > xg[side] + 1.0 && t.line > 0 -> {
                        t.line--; t.tackling = 2; note = "dropping deeper and getting tighter"
                    }
                }
            }

            // 3. a shape change when nothing else has worked
            if (note.isEmpty() && late && mine < theirs && rng.chance(0.45)) {
                val chasing = arrayOf("4-2-4", "3-4-3", "4-2-3-1", "4-3-3")
                val pick = rng.pick(chasing)
                if (pick != t.formation) {
                    t.formation = pick
                    world.autoPickSquad(club)
                    rebuildShape(side, club)
                    note = "switching to $pick"
                }
            }

            if (note.isNotEmpty() && note != aiLastNote) {
                aiLastNote = note
                sayRaw(FeedLine.PLAIN, "${club.name} are $note.")
                refreshRatings()
            }
        }
    }

    /** Re-seats a side after a change of shape, from either bench. */
    fun reshape(side: Int) {
        rebuildShape(side, if (side == 0) home else away)
    }

    /** Re-seats a side after its manager changes formation mid-match. */
    private fun rebuildShape(side: Int, club: Club) {
        val shape = Formations.byName(club.tactics.formation)
        val live = onPitch(side)
        for (i in live.indices) {
            val slot = shape.slots.getOrNull(i) ?: continue
            live[i].baseX = slot.x.toFloat()
            live[i].baseY = slot.y.toFloat()
        }
    }

    private fun aiSubstitutions(minutes: Double) {
        for (side in 0..1) {
            val club = if (side == 0) home else away
            if (club.isUser) continue
            if (subsLeft[side] <= 0 || clock < 55) continue
            if (!rng.chance(minutes * 0.055)) continue
            val tired = onPitch(side).filter { it.pos != Pos.GK }.minByOrNull { it.fitness } ?: continue
            val bench = (if (side == 0) benchHome else benchAway).filter { canUse(side, it) }
            if (bench.isEmpty()) continue
            val replacement = bench.firstOrNull { Pos.group(it.pos) == Pos.group(tired.pos) } ?: bench[0]
            substitute(side, tired.key, replacement.id)
        }
    }

    private val usedSubs = HashSet<Int>()
    private fun canUse(side: Int, p: Player) = !usedSubs.contains(p.id)

    fun substitute(side: Int, outKey: String, inPlayerId: Int): Boolean {
        if (subsLeft[side] <= 0) return false
        val out = players.firstOrNull { it.key == outKey && it.onPitch } ?: return false
        val bench = if (side == 0) benchHome else benchAway
        val inP = bench.firstOrNull { it.id == inPlayerId } ?: return false
        if (usedSubs.contains(inP.id)) return false

        out.onPitch = false
        usedSubs.add(inP.id)
        val lp = LivePlayer("${side}_s${subsMade[side]}", side, out.slot, out.pos, inP)
        lp.baseX = out.baseX; lp.baseY = out.baseY
        lp.x = out.x; lp.y = out.y; lp.targetX = out.targetX; lp.targetY = out.targetY
        lp.shirt = 12 + subsMade[side]
        lp.effective = inP.effective(out.pos)
        lp.fitness = inP.fitness
        players.add(lp)
        subsLeft[side]--
        subsMade[side]++
        banner = "${inP.last} on for ${out.name}"
        bannerTime = 1.6f
        sayRaw(FeedLine.SUB, "Substitution for ${teamName(side)}: ${inP.full} replaces ${out.fullName}.")
        events.add(MatchEvent(clock.toInt(), Ev.SUB, side, inP.full, out.fullName))
        return true
    }

    /** Fast-forward with no rendering. */
    fun skipToEnd() {
        pause()
        if (!kicked) { kicked = true; newPhase() }
        if (phaseSeq.isEmpty() && pendingSide < 0) newPhase()
        val realSpeed = speed
        speed = 40f
        var guard = 0
        while (!finished && guard++ < 60_000) {
            update(0.05f)
            if (!running && !finished) running = true
        }
        if (!finished) endMatch()
        speed = realSpeed
    }

    var manOfTheMatch: LivePlayer? = null

    private fun endMatch() {
        cue(Synth.Sfx.WHISTLE_LONG, 1f)
        cue(Synth.Sfx.APPLAUSE, 0.9f)
        crowdTarget = 0.5f
        finished = true
        running = false
        clock = 90.0
        sayRaw(FeedLine.WHISTLE, "Full time. ${home.name} ${score[0]} - ${score[1]} ${away.name}.")
        banner = "FULL TIME"; bannerTime = 3f

        for (p in players) {
            var r = 6.3 + (p.effective - 62.0) / 40.0
            r += p.goals * 1.0 + p.assists * 0.5 + p.tackles * 0.06 +
                    p.saves * 0.14 + p.passes * 0.012
            r -= p.yellow * 0.25 + (if (p.sentOff) 1.2 else 0.0)
            r += (rng.f() - 0.5) * 0.5
            p.rating = r.coerceIn(3.5, 10.0)
        }
        manOfTheMatch = players.filter { it.minutes > 1 }.maxByOrNull { it.rating }
        manOfTheMatch?.let {
            sayRaw(FeedLine.GOAL, "Man of the Match: ${it.fullName} (${teamName(it.side)}) \u2014 ${Fmt.one(it.rating)}")
        }
    }

    val possessionHome: Int
        get() {
            val total = possession[0] + possession[1]
            return if (total <= 0) 50 else (possession[0] / total * 100).roundToInt()
        }

    /** Writes the match back into the season: stats, injuries, cards, the result. */
    fun commit() {
        for (p in players) {
            val ref = p.ref
            val mins = min(90.0, p.minutes).roundToInt()
            if (mins < 1) continue
            ref.apps++; ref.cApps++; ref.minutes += mins
            ref.goals += p.goals; ref.cGoals += p.goals
            ref.assists += p.assists; ref.cAssists += p.assists
            ref.ratingSum += p.rating; ref.ratingN++
            ref.form = ref.form * 0.7 + p.rating * 0.3
            ref.fitness = max(15.0, p.fitness)
            ref.sharpness = min(100.0, ref.sharpness + 7)
            if (p.yellow > 0) {
                ref.yellowSeason += p.yellow
                if (ref.yellowSeason % 5 == 0) ref.suspended = 1
            }
            if (p.sentOff) { ref.redSeason++; ref.suspended = 2 }
            if (p.injured) {
                ref.injuryWeeks = p.injuryWeeks
                ref.injuryType = season.injuryName(p.injuryWeeks, rng)
            }
            if (manOfTheMatch?.key == p.key) ref.motm++
        }
        onPitch(0).firstOrNull { it.pos == Pos.GK }?.let { if (score[1] == 0) it.ref.cleanSheets++ }
        onPitch(1).firstOrNull { it.pos == Pos.GK }?.let { if (score[0] == 0) it.ref.cleanSheets++ }
        fixture.attendance = attendance
        season.applyResult(fixture, score[0], score[1])
    }
}
