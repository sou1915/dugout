package com.dugout.career.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.dugout.career.core.Club
import com.dugout.career.core.Formations
import com.dugout.career.core.Pos
import com.dugout.career.core.Rng

/**
 * The management-sim look: deep navy ground, panels a shade lighter, every
 * block introduced by a centred uppercase header on its own strip, and one
 * violet action colour that only ever means "move forward".
 */
object Theme {
    const val GROUND = 0xFF12142A.toInt()
    const val PANEL = 0xFF1E2039.toInt()
    const val PANEL_HEAD = 0xFF2A2D4E.toInt()
    const val PANEL_ALT = 0xFF252843.toInt()
    const val BORDER = 0xFF383B63.toInt()
    const val BORDER_SOFT = 0xFF2C2F52.toInt()

    const val TEXT = 0xFFE9EBF5.toInt()
    const val MUTED = 0xFF9295BC.toInt()
    const val FAINT = 0xFF61648F.toInt()

    const val ACCENT = 0xFF8B5CF6.toInt()
    const val ACCENT_DARK = 0xFF6D3FD4.toInt()
    const val HILITE = 0xFFE0447C.toInt()
    const val GOLD = 0xFFFBBF24.toInt()

    const val GREEN = 0xFF4ADE80.toInt()
    const val RED = 0xFFF87171.toInt()
    const val AMBER = 0xFFFBBF24.toInt()
    const val BLUE = 0xFF60A5FA.toInt()

    val DISPLAY: Typeface by lazy { Typeface.create("sans-serif-condensed", Typeface.BOLD) }
    val BODY: Typeface by lazy { Typeface.create("sans-serif", Typeface.NORMAL) }
    val BODY_MED: Typeface by lazy { Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    val DATA: Typeface by lazy { Typeface.MONOSPACE }

    fun ratingColor(v: Int): Int = when {
        v >= 80 -> GREEN
        v >= 68 -> 0xFFA3E635.toInt()
        v >= 55 -> AMBER
        v >= 42 -> 0xFFFB923C.toInt()
        else -> RED
    }

    fun posColor(group: Int): Int = when (group) {
        0 -> 0xFF16A34A.toInt()
        1 -> 0xFF6D3FD4.toInt()
        2 -> 0xFF2563EB.toInt()
        else -> 0xFFDC2626.toInt()
    }
}

/* -------------------------------------------------------------- BUILDERS */

fun Context.dp(v: Int): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun boxBg(fill: Int, stroke: Int, radiusPx: Int, strokeWidth: Int = 2): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = radiusPx.toFloat()
    if (stroke != 0) g.setStroke(strokeWidth, stroke)
    return g
}

fun Context.column(pad: Int = 0): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    if (pad > 0) l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    return l
}

fun Context.row(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.text(
    s: String,
    size: Float = 13f,
    color: Int = Theme.TEXT,
    face: Typeface = Theme.BODY,
    spacing: Float = 0f,
    align: Int = Gravity.START
): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    t.setTextColor(color)
    t.typeface = face
    if (spacing != 0f) t.letterSpacing = spacing
    t.gravity = align
    t.includeFontPadding = false
    return t
}

fun Context.spacer(h: Int): View {
    val v = View(this)
    v.layoutParams = lp(MATCH, dp(h))
    return v
}

fun Context.hairline(): View {
    val v = View(this)
    v.setBackgroundColor(Theme.BORDER_SOFT)
    v.layoutParams = lp(MATCH, 1)
    return v
}

/**
 * The building block of every screen: a bordered box whose title sits centred
 * and uppercase on its own strip.
 */
class Panel(ctx: Context, title: String) : LinearLayout(ctx) {
    val body: LinearLayout = ctx.column()
    private val header: TextView

    init {
        orientation = VERTICAL
        background = boxBg(Theme.PANEL, Theme.BORDER, ctx.dp(4))

        header = ctx.text(title.uppercase(), 12f, Theme.TEXT, Theme.DISPLAY, 0.10f, Gravity.CENTER)
        header.setBackgroundColor(Theme.PANEL_HEAD)
        header.setPadding(ctx.dp(8), ctx.dp(7), ctx.dp(8), ctx.dp(7))
        addView(header, lp(MATCH, WRAP))
        addView(body, lp(MATCH, WRAP))
    }

    fun setTitle(s: String) { header.text = s.uppercase() }
    fun add(v: View): Panel { body.addView(v, lp(MATCH, WRAP)); return this }
}

fun Context.panel(title: String): Panel = Panel(this, title)

fun Context.kv(key: String, value: String, valueColor: Int = Theme.TEXT): LinearLayout {
    val r = row()
    r.setPadding(dp(10), dp(6), dp(10), dp(6))
    r.addView(text(key, 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
    r.addView(text(value, 12.5f, valueColor, Theme.BODY_MED))
    return r
}

fun Context.stat(label: String, value: String, color: Int = Theme.TEXT): LinearLayout {
    val c = column()
    c.gravity = Gravity.CENTER_HORIZONTAL
    c.addView(text(value, 16f, color, Theme.DATA, 0f, Gravity.CENTER), lp(MATCH, WRAP))
    c.addView(text(label.uppercase(), 9f, Theme.FAINT, Theme.DISPLAY, 0.10f, Gravity.CENTER), lp(MATCH, WRAP))
    return c
}

fun Context.actionButton(s: String, wide: Boolean = false): TextView {
    val t = text(s.uppercase(), 14f, 0xFFFFFFFF.toInt(), Theme.DISPLAY, 0.08f, Gravity.CENTER)
    t.background = pressableBg(Theme.ACCENT, shade(Theme.ACCENT, 0.72f), Theme.ACCENT_DARK, dp(5))
    t.setPadding(dp(if (wide) 26 else 16), dp(11), dp(if (wide) 26 else 16), dp(11))
    t.isClickable = true
    t.elevation = dp(2).toFloat()
    return t
}

fun Context.subtleButton(s: String): TextView {
    val t = text(s, 12.5f, Theme.TEXT, Theme.BODY_MED, 0f, Gravity.CENTER)
    t.background = pressableBg(Theme.PANEL_HEAD, shade(Theme.PANEL_HEAD, 1.45f), Theme.BORDER, dp(5))
    t.setPadding(dp(14), dp(9), dp(14), dp(9))
    t.isClickable = true
    return t
}

fun Context.tag(s: String, bg: Int, fg: Int): TextView {
    val t = text(s, 10.5f, fg, Theme.DISPLAY, 0.06f, Gravity.CENTER)
    t.background = boxBg(bg, 0, dp(3))
    t.setPadding(dp(6), dp(3), dp(6), dp(3))
    t.minWidth = dp(30)
    return t
}

fun Context.posTag(pos: Int): TextView =
    tag(Pos.name(pos), Theme.posColor(Pos.group(pos)), 0xFFFFFFFF.toInt())

fun Context.chip(s: String, on: Boolean): TextView {
    val t = text(
        s, 12f, if (on) 0xFFFFFFFF.toInt() else Theme.MUTED,
        if (on) Theme.BODY_MED else Theme.BODY, 0f, Gravity.CENTER
    )
    t.background = pressableBg(
        if (on) Theme.ACCENT else Theme.PANEL_HEAD,
        if (on) shade(Theme.ACCENT, 0.72f) else shade(Theme.PANEL_HEAD, 1.45f),
        if (on) Theme.ACCENT_DARK else Theme.BORDER, dp(4)
    )
    t.setPadding(dp(12), dp(7), dp(12), dp(7))
    t.isClickable = true
    return t
}

/* ------------------------------------------------------------ STAR RATING */

class StarsView(ctx: Context, private val halves: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private fun star(cx: Float, cy: Float, r: Float) {
        path.reset()
        for (i in 0 until 10) {
            val ang = Math.PI / 5 * i - Math.PI / 2
            val rad = if (i % 2 == 0) r.toDouble() else r * 0.45
            val x = cx + (Math.cos(ang) * rad).toFloat()
            val y = cy + (Math.sin(ang) * rad).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val r = h * 0.46f
        val step = r * 2.25f
        for (i in 0 until 5) {
            val cx = r + i * step
            val cy = h / 2f
            star(cx, cy, r)
            p.color = Theme.FAINT
            c.drawPath(path, p)
            val filled = halves - i * 2
            if (filled > 0) {
                val saved = c.save()
                val w = if (filled >= 2) r * 2 else r
                c.clipRect(cx - r, 0f, cx - r + w, h)
                p.color = Theme.GOLD
                c.drawPath(path, p)
                c.restoreToCount(saved)
            }
        }
    }
}

fun Context.stars(halves: Int, heightDp: Int = 14): StarsView {
    val v = StarsView(this, halves.coerceIn(0, 10))
    v.layoutParams = lp(dp(heightDp * 6), dp(heightDp))
    return v
}

fun ratingToHalves(rating: Int): Int = ((rating - 30).coerceIn(0, 65) * 10 / 65)

/* -------------------------------------------------------------- FORM ROW */

class FormView(ctx: Context, private val form: List<Char>) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val n = minOf(form.size, 5)
        if (n == 0) return
        val h = height.toFloat()
        val box = minOf(h, width.toFloat() / n - 4f)
        for (i in 0 until n) {
            val ch = form[i]
            val x = i * (box + 4f)
            rect.set(x, (h - box) / 2f, x + box, (h + box) / 2f)
            p.color = when (ch) {
                'W' -> 0xFF15803D.toInt(); 'D' -> 0xFFA16207.toInt(); else -> 0xFF991B1B.toInt()
            }
            c.drawRoundRect(rect, box * 0.20f, box * 0.20f, p)
            t.color = 0xFFFFFFFF.toInt()
            t.textSize = box * 0.60f
            c.drawText(ch.toString(), rect.centerX(), rect.centerY() + box * 0.21f, t)
        }
    }
}

fun Context.formRow(form: List<Char>, h: Int = 20): FormView {
    val v = FormView(this, form.take(5))
    v.layoutParams = lp(dp(h * 5 + 20), dp(h))
    return v
}

/* ----------------------------------------------------------------- CREST */

/**
 * A club badge built from a shape, a device and a charge. Eight outlines by
 * seven devices by a handful of charges gives well over forty distinct
 * crests, and each club keeps the same one for the life of the save.
 */
class CrestView(ctx: Context, private val club: Club) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val star = Path()
    private val rect = RectF()

    private val shape: Int
    private val device: Int
    private val charge: Int

    init {
        val r = Rng(club.crestSeed.toLong())
        shape = r.i(0, 7)
        device = r.i(0, 6)
        charge = r.i(0, 3)
    }

    private fun outline(ox: Float, oy: Float, s: Float) {
        fun px(v: Float) = ox + v / 100f * s
        fun py(v: Float) = oy + v / 100f * s
        path.reset()
        when (shape) {
            0 -> {  // classic shield
                path.moveTo(px(50f), py(4f)); path.lineTo(px(94f), py(20f))
                path.lineTo(px(94f), py(54f))
                path.quadTo(px(94f), py(88f), px(50f), py(97f))
                path.quadTo(px(6f), py(88f), px(6f), py(54f))
                path.lineTo(px(6f), py(20f)); path.close()
            }
            1 -> {  // hexagon
                path.moveTo(px(50f), py(3f)); path.lineTo(px(93f), py(27f))
                path.lineTo(px(93f), py(73f)); path.lineTo(px(50f), py(97f))
                path.lineTo(px(7f), py(73f)); path.lineTo(px(7f), py(27f)); path.close()
            }
            2 -> {  // square shield
                path.moveTo(px(9f), py(8f)); path.lineTo(px(91f), py(8f))
                path.lineTo(px(91f), py(68f))
                path.quadTo(px(91f), py(92f), px(50f), py(97f))
                path.quadTo(px(9f), py(92f), px(9f), py(68f)); path.close()
            }
            3 -> path.addCircle(px(50f), py(50f), s * 0.46f, Path.Direction.CW)
            4 -> {  // pointed spade
                path.moveTo(px(50f), py(3f)); path.lineTo(px(92f), py(34f))
                path.lineTo(px(72f), py(96f)); path.lineTo(px(28f), py(96f))
                path.lineTo(px(8f), py(34f)); path.close()
            }
            5 -> {  // rounded square
                rect.set(px(8f), py(8f), px(92f), py(92f))
                path.addRoundRect(rect, s * 0.16f, s * 0.16f, Path.Direction.CW)
            }
            6 -> {  // diamond
                path.moveTo(px(50f), py(2f)); path.lineTo(px(96f), py(50f))
                path.lineTo(px(50f), py(98f)); path.lineTo(px(4f), py(50f)); path.close()
            }
            else -> {  // scroll banner
                path.moveTo(px(6f), py(16f)); path.lineTo(px(94f), py(16f))
                path.lineTo(px(94f), py(72f))
                path.quadTo(px(50f), py(98f), px(6f), py(72f)); path.close()
            }
        }
    }

    private fun makeStar(cx: Float, cy: Float, r: Float) {
        star.reset()
        for (i in 0 until 10) {
            val a = Math.PI / 5 * i - Math.PI / 2
            val rad = if (i % 2 == 0) r.toDouble() else r * 0.44
            val x = cx + (Math.cos(a) * rad).toFloat()
            val y = cy + (Math.sin(a) * rad).toFloat()
            if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
        }
        star.close()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h)
        val ox = (w - s) / 2f; val oy = (h - s) / 2f
        fun px(v: Float) = ox + v / 100f * s
        fun py(v: Float) = oy + v / 100f * s
        val cx = ox + s / 2f

        outline(ox, oy, s)
        val saved = c.save()
        c.clipPath(path)

        fill.color = club.primary
        c.drawRect(0f, 0f, w, h, fill)
        fill.color = club.secondary
        stroke.color = club.secondary

        when (device) {
            0 -> {}                                                    // plain
            1 -> { stroke.strokeWidth = s * 0.17f; c.drawLine(cx, oy, cx, oy + s, stroke) }
            2 -> { stroke.strokeWidth = s * 0.15f; c.drawLine(ox, py(50f), ox + s, py(50f), stroke) }
            3 -> { stroke.strokeWidth = s * 0.20f; c.drawLine(ox, oy + s, ox + s, oy, stroke) }
            4 -> {                                                     // quarters
                c.drawRect(ox, oy, cx, py(50f), fill)
                c.drawRect(cx, py(50f), ox + s, oy + s, fill)
            }
            5 -> {                                                     // vertical stripes
                var x = ox; var i = 0
                while (x < ox + s) {
                    if (i % 2 == 0) c.drawRect(x, oy, x + s * 0.14f, oy + s, fill)
                    x += s * 0.14f; i++
                }
            }
            else -> {                                                  // chief across the top
                c.drawRect(ox, oy, ox + s, py(34f), fill)
            }
        }
        c.restoreToCount(saved)

        stroke.color = club.secondary
        stroke.strokeWidth = s * 0.05f
        c.drawPath(path, stroke)

        // the charge in the middle
        when (charge) {
            0 -> {                                                     // initials
                label.color = club.secondary
                label.textSize = s * 0.30f
                c.drawText(club.shortName, cx, py(62f), label)
            }
            1 -> {                                                     // a star over the initials
                fill.color = club.secondary
                makeStar(cx, py(34f), s * 0.15f)
                c.drawPath(star, fill)
                label.color = club.secondary
                label.textSize = s * 0.24f
                c.drawText(club.shortName, cx, py(78f), label)
            }
            2 -> {                                                     // a ball
                fill.color = club.secondary
                c.drawCircle(cx, py(42f), s * 0.16f, fill)
                fill.color = club.primary
                c.drawCircle(cx, py(42f), s * 0.07f, fill)
                label.color = club.secondary
                label.textSize = s * 0.22f
                c.drawText(club.shortName, cx, py(82f), label)
            }
            else -> {                                                  // ringed initials
                stroke.color = club.secondary
                stroke.strokeWidth = s * 0.045f
                c.drawCircle(cx, py(48f), s * 0.27f, stroke)
                label.color = club.secondary
                label.textSize = s * 0.24f
                c.drawText(club.shortName, cx, py(57f), label)
            }
        }
    }
}

fun Context.crest(club: Club, sizeDp: Int): CrestView {
    val v = CrestView(this, club)
    v.layoutParams = lp(dp(sizeDp), dp(sizeDp))
    return v
}

/* ------------------------------------------------------------ PITCH VIEW */

/** A formation drawn as position boxes on a pitch, attacking up the screen. */
class PitchView(ctx: Context, private val formationName: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x40FFFFFF
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER; color = 0xFFFFFFFF.toInt()
    }
    private val rect = RectF()

    var highlightSlot = -1

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()

        p.color = 0xFF303252.toInt()
        c.drawRect(0f, 0f, w, h, p)

        line.strokeWidth = maxOf(1f, w * 0.004f)
        c.drawRect(w * 0.03f, h * 0.03f, w * 0.97f, h * 0.97f, line)
        c.drawLine(w * 0.03f, h * 0.5f, w * 0.97f, h * 0.5f, line)
        c.drawCircle(w / 2f, h / 2f, w * 0.11f, line)
        val bw = w * 0.40f
        c.drawRect(w / 2 - bw / 2, h * 0.03f, w / 2 + bw / 2, h * 0.18f, line)
        c.drawRect(w / 2 - bw / 2, h * 0.82f, w / 2 + bw / 2, h * 0.97f, line)

        val shape = Formations.byName(formationName)
        val boxW = w * 0.17f
        val boxH = h * 0.085f
        label.textSize = boxH * 0.56f

        for (i in shape.slots.indices) {
            val s = shape.slots[i]
            val cx = w * (s.y / 100f)
            val cy = h * (1f - s.x / 100f)
            rect.set(cx - boxW / 2, cy - boxH / 2, cx + boxW / 2, cy + boxH / 2)
            p.color = if (i == highlightSlot) Theme.HILITE else Theme.posColor(Pos.group(s.pos))
            c.drawRoundRect(rect, boxH * 0.22f, boxH * 0.22f, p)
            c.drawText(Pos.name(s.pos), cx, cy + boxH * 0.20f, label)
        }
    }
}

fun Context.pitch(formation: String, wDp: Int, hDp: Int): PitchView {
    val v = PitchView(this, formation)
    v.layoutParams = lp(dp(wDp), dp(hDp))
    return v
}

/* -------------------------------------------------------------- BAR VIEW */

class BarView(ctx: Context, private val value: Int, private val max: Int = 99) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        p.color = Theme.BORDER_SOFT
        c.drawRoundRect(0f, 0f, width.toFloat(), h, h / 2f, h / 2f, p)
        p.color = Theme.ratingColor(value * 99 / maxOf(1, max))
        val fw = width.toFloat() * (value.toFloat() / max).coerceIn(0f, 1f)
        c.drawRoundRect(0f, 0f, fw, h, h / 2f, h / 2f, p)
    }
}
