package com.dugout.career.sim

import com.dugout.career.core.*
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ------------------------------------------------------------------ NEWS */

class NewsItem(val icon: String, val text: String, val season: Int, val week: Int, val kind: Int) {
    companion object {
        const val CLUB = 0; const val TRANSFER = 1; const val BOARD = 2
        const val TROPHY = 3; const val INJURY = 4
        const val YOUTH = 5
    }
}

class InboxItem(
    val id: Int, val from: String, val subject: String, val body: String,
    val icon: String, val season: Int, val week: Int
) {
    var read = false
    var offerId = -1
}

class TransferOffer(val id: Int, val playerId: Int, val buyerId: Int, val fee: Long, val week: Int)

/** A completed deal anywhere in the world, for the transfer wire. */
class Deal(
    val player: String, val pos: Int, val age: Int, val rating: Int,
    val from: String, val to: String, val fee: Long,
    val season: Int, val week: Int
)

/** Something that happened elsewhere and is worth knowing about. */
class WorldEvent(val icon: String, val headline: String, val detail: String, val season: Int, val week: Int)

/* ---------------------------------------------------------- PRESS ROOM */

/**
 * One answer the manager can give, and what it costs him. Talking a signing up
 * pleases the player and the supporters but raises what the board expects;
 * playing it down is safe but flat.
 */
class PressOption(
    val text: String,
    val reply: String,
    /** Applied to everyone in the squad. */
    val squadMorale: Double = 0.0,
    /** Applied to the player the question is about, if there is one. */
    val subjectMorale: Double = 0.0,
    /** Standing with the board and the press. */
    val repDelta: Int = 0
)

class PressQuestion(
    val from: String,
    val text: String,
    val options: List<PressOption>,
    /** The player being asked about, or -1. */
    val subjectId: Int = -1
) {
    var answered = false
    var chosen: PressOption? = null
}

/* -------------------------------------------------------------- TRAINING */

class TrainingFocus(val id: Int, val label: String, val desc: String, val attrs: IntArray, val fatigue: Double)

object Training {
    val ALL = listOf(
        TrainingFocus(0, "Balanced", "Steady progress everywhere", IntArray(0), 1.0),
        TrainingFocus(1, "Attacking", "Finishing, dribbling and technique",
            intArrayOf(Att.FIN, Att.LON, Att.DRI, Att.TEC), 1.10),
        TrainingFocus(2, "Defending", "Tackling, marking and positioning",
            intArrayOf(Att.TAC, Att.MAR, Att.POS), 1.05),
        TrainingFocus(3, "Physical", "Pace, strength and stamina",
            intArrayOf(Att.PAC, Att.ACC, Att.STR, Att.STA), 1.35),
        TrainingFocus(4, "Possession", "Passing, vision and composure",
            intArrayOf(Att.PAS, Att.VIS, Att.TEC, Att.COM), 0.95),
        TrainingFocus(5, "Recovery", "No development, fitness restored fast", intArrayOf(-1), 0.30),
        TrainingFocus(6, "Tactical", "Drilling the shape, so the system beds in quickly",
            IntArray(0), 0.85)
    )
    val INTENSITY = arrayOf("Light", "Normal", "Intense")
}

/* ------------------------------------------------------------- OBJECTIVES */

class Objective(val label: String, val kind: Int, val target: Int) {
    companion object { const val POSITION = 0; const val CUP_ROUND = 1; const val BALANCE = 2 }
    var met = false
    var detail = ""
}

/* ----------------------------------------------------------------- CAREER */

/**
 * Everything that happens between matches: the training ground, the bank,
 * the academy, the boardroom and the inbox.
 */
class Career(val world: World, val season: Season) {

    var trainingFocus = 0
    var intensity = 1
    val news = ArrayList<NewsItem>(140)
    val inbox = ArrayList<InboxItem>(80)
    val offers = ArrayList<TransferOffer>(24)
    val transferLog = ArrayList<Deal>(140)
    val worldNews = ArrayList<WorldEvent>(90)
    /** Players you are watching. Survives windows and seasons. */
    val shortlist = HashSet<Int>(40)
    val scoutFinds = ArrayList<Int>(30)
    var objectives = ArrayList<Objective>(3)

    /** Players already linked away this season, so the story is not retold. */
    private val watched = HashSet<Int>(16)

    /** Questions the manager still owes the media. */
    val press = ArrayList<PressQuestion>(4)

    val pressWaiting: Int get() = press.count { !it.answered }

    private var nextInboxId = 1
    private var nextOfferId = 1
    var sackWarned = false

    val unread: Int get() = inbox.count { !it.read }

    fun news(icon: String, text: String, kind: Int) {
        news.add(0, NewsItem(icon, text, world.season, world.week, kind))
        while (news.size > 140) news.removeAt(news.size - 1)
    }

    fun inbox(from: String, subject: String, body: String, icon: String): InboxItem {
        val m = InboxItem(nextInboxId++, from, subject, body, icon, world.season, world.week)
        inbox.add(0, m)
        while (inbox.size > 80) inbox.removeAt(inbox.size - 1)
        return m
    }

    /* --------------------------------------------------------- START */

    fun start(clubId: Int, manager: String, nation: String) {
        world.userClubId = clubId
        world.managerName = manager
        world.managerNation = nation
        val c = world.club(clubId) ?: return
        c.isUser = true
        world.managerRep = (c.reputation * 0.45).roundToInt()
        season.buildCalendar()
        setObjectives()
        news("\u270D", "$manager is appointed manager of ${c.name}.", NewsItem.CLUB)
        inbox(
            "The Board", "Welcome to the club",
            "Congratulations on your appointment. We have set out what we expect this season. " +
                    "Meet it and you will be backed in the market. Fall short and we will have to talk.",
            "\u2691"
        )
    }

    /* ---------------------------------------------------- OBJECTIVES */

    fun setObjectives() {
        val c = world.userClub ?: return
        val div = world.division(c.divisionId) ?: return
        val ranked = div.clubIds.mapNotNull { world.club(it) }.sortedByDescending { it.reputation }
        val rank = ranked.indexOfFirst { it.id == c.id } + 1
        objectives = ArrayList()
        val (label, target) = when {
            rank <= 3 -> Pair("Win the division", 1)
            rank <= 6 -> Pair("Finish in the top four", 4)
            rank <= 12 -> Pair("Finish in the top half", 10)
            else -> Pair("Avoid relegation", 17)
        }
        objectives.add(Objective(label, Objective.POSITION, target))
        objectives.add(
            Objective(
                if (c.tier <= 2) "Reach the cup quarter-final" else "Reach the cup fourth round",
                Objective.CUP_ROUND, if (c.tier <= 2) 5 else 3
            )
        )
        objectives.add(Objective("Keep the club out of debt", Objective.BALANCE, 0))
        c.boardConfidence = 65
    }

    fun refreshObjectives(): List<Objective> {
        val c = world.userClub ?: return emptyList()
        val pos = season.position(c.id)
        for (o in objectives) {
            when (o.kind) {
                Objective.POSITION -> { o.met = pos in 1..o.target; o.detail = "Currently ${Fmt.ord(pos)}" }
                Objective.CUP_ROUND -> {
                    val r = cupRoundReached(c.id)
                    o.met = r >= o.target; o.detail = "Reached round $r"
                }
                else -> { o.met = c.balance >= 0; o.detail = Fmt.money(c.balance) }
            }
        }
        return objectives
    }

    fun cupRoundReached(clubId: Int): Int {
        var r = 0
        for (i in season.cup.rounds.indices) {
            for (t in season.cup.rounds[i].ties) {
                if (t.homeId == clubId || t.awayId == clubId) r = max(r, i + 1)
            }
        }
        return r
    }

    /* ------------------------------------------------------ WEEKLY */

    /** The training ground: recovery first, then development. */
    fun applyTraining() {
        val c = world.userClub ?: return
        val focus = Training.ALL[trainingFocus]
        val rng = Rng(world.seed + world.week * 991L + world.season * 17L)
        val iMul = when (intensity) { 0 -> 0.55; 2 -> 1.5; else -> 1.0 }

        for (id in c.squad) {
            val p = world.player(id) ?: continue

            val rec = (if (focus.id == 5) 30.0 else 18.0) / iMul * (0.85 + p.att[Att.STA] / 400.0)
            p.fitness = min(100.0, p.fitness + rec)
            p.sharpness = min(100.0, p.sharpness + (if (p.minutes > 0) 2.0 else 5.0) * iMul)

            if (intensity == 2 && rng.chance(0.012 * (if (p.hasTrait(Traits.GLASS)) 2.0 else 1.0))) {
                p.injuryWeeks = rng.i(1, 3)
                p.injuryType = "Training injury"
                news("\u2695", "${p.full} picks up a knock in training.", NewsItem.INJURY)
            }

            if (focus.id != 5) {
                val before = p.overall()
                val gap = p.potential - p.overall()
                var rate = when {
                    p.age <= 20 -> 0.11; p.age <= 24 -> 0.07; p.age <= 28 -> 0.03
                    p.age <= 31 -> 0.005; else -> -0.02
                }
                rate *= (0.5 + gap * 0.03) * iMul * (if (p.hasTrait(Traits.WONDERKID)) 1.5 else 1.0)
                rate *= p.morale / 70.0
                // the man himself: a professional gets more out of the same week
                // on the training ground than someone who treats it as a chore
                rate *= Personalities.of(p.personality).growth
                // Game time still counts for something, but the big lever was
                // the rounding fix below; stacking a youth bonus on top of it
                // sent teenagers to their ceiling in a season and a half.
                if (p.age <= 21 && p.minutes > 400) rate *= 1.10
                val list = if (focus.attrs.isEmpty()) IntArray(Att.COUNT) { it } else focus.attrs
                for (a in list) {
                    if (a < 0) continue
                    if ((a == Att.GKR || a == Att.GKH || a == Att.GKD) && p.pos != Pos.GK) continue
                    // Attributes are whole numbers and a week's work is worth
                    // about a fifth of a point, so adding and rounding threw
                    // nearly all of it away: training was doing almost nothing
                    // and the annual step was quietly doing all the developing.
                    // Advancing by chance instead keeps the same expected rate
                    // without losing the fraction.
                    val step = rate * (0.6 + rng.f() * 0.8)
                    val whole = kotlin.math.floor(step).toInt()
                    val part = step - whole
                    var inc = whole
                    if (part > 0 && rng.f() < part) inc += 1
                    if (part < 0 && rng.f() < -part) inc -= 1
                    if (inc != 0) p.att[a] = (p.att[a] + inc).coerceIn(4, 99)
                }
                p.capToPotential()

                // Development you can watch. A young player crossing a round
                // number gets written up, so the academy is something that
                // visibly pays off week to week rather than a number you only
                // notice at the end of a season.
                val after = p.overall()
                if (after > before && p.age <= 21 && after / 3 > before / 3) {
                    val verdict = when {
                        p.potential - after <= 4 -> "close to the finished article."
                        p.potential - after <= 14 -> "still has plenty to come."
                        else -> "could go a very long way."
                    }
                    news(
                        "\u2B06", "${p.full} (${p.age}) is up to $after overall \u2014 $verdict",
                        NewsItem.YOUTH
                    )
                }
            }

            val wantMins = when (p.squadStatus) { 0 -> 80; 1 -> 60; 2 -> 35; 3 -> 15; else -> 10 }
            val gotMins = p.minutes / max(1, world.week)
            // an ambitious man who is not playing takes it much worse than a
            // casual one, and is quicker to want away
            p.shiftMorale(if (gotMins >= wantMins) 0.8 else -1.1)
            if (p.injured) p.morale -= 0.6
            p.morale = p.morale.coerceIn(8.0, 99.0)
        }

        healSquad(c)

        // the rest of the world recovers too
        for (other in world.clubs) {
            if (other.isUser) continue
            for (id in other.squad) {
                val p = world.player(id) ?: continue
                p.fitness = min(100.0, p.fitness + 20.0)
            }
            healSquad(other)
            world.autoPickSquad(other)
        }
    }

    private fun healSquad(c: Club) {
        for (id in c.squad) {
            val p = world.player(id) ?: continue
            if (p.injuryWeeks > 0) {
                p.injuryWeeks--
                if (p.injuryWeeks <= 0) {
                    p.injuryType = null
                    p.sharpness = max(30.0, p.sharpness - 25)
                    if (c.isUser) news("\u2714", "${p.full} is back in training.", NewsItem.INJURY)
                }
            }
            if (p.suspended > 0) p.suspended--
        }
    }

    /** Wages, running costs and sponsorship, every week. */
    fun weeklyFinance() {
        val c = world.userClub ?: return
        val wages = world.wageBill(c).toLong()
        val ops = (wages * 0.55).toLong() + c.capacity * 1L
        val sponsor = c.sponsor / 38

        c.balance -= wages
        c.balance -= ops
        c.balance += sponsor

        for (other in world.clubs) {
            if (other.isUser) continue
            val b = world.wageBill(other).toLong()
            other.balance += other.sponsor / 38 - (b * 1.35).toLong() - other.capacity
            if (other.balance < 0) other.balance = other.sponsor / 8
        }

        if (c.balance < -5_000_000L && !sackWarned) {
            inbox(
                "Finance Director", "The club is in the red",
                "We are ${Fmt.money(-c.balance)} in debt. Sell players or cut the wage bill.",
                "\u25BC"
            )
        }
        if (c.balance < -20_000_000L) forceSale(c)
    }

    /** The board cashes in the smallest asset that clears the debt. */
    fun forceSale(c: Club): Player? {
        if (c.squad.size <= 18) return null
        val need = max(0L, -c.balance)
        val squad = world.squadOf(c).sortedBy { it.value() }
        val asset = squad.firstOrNull { it.value() >= need } ?: squad.lastOrNull() ?: return null
        val fee = asset.value()
        val buyer = world.clubs
            .filter { it.id != c.id && it.balance > fee * 1.2 }
            .maxByOrNull { it.reputation }
        c.squad.remove(asset.id)
        c.balance += fee
        if (buyer != null) { buyer.squad.add(asset.id); buyer.balance -= fee; asset.clubId = buyer.id; world.autoPickSquad(buyer) }
        else asset.clubId = -1
        world.autoPickSquad(c)
        c.morale = max(15.0, c.morale - 8)
        if (c.isUser) {
            inbox(
                "The Board", "We have accepted an offer",
                "${asset.full} has been sold${if (buyer != null) " to ${buyer.name}" else ""} for ${Fmt.money(fee)}. " +
                        "Get the wage bill under control.", "\u2696"
            )
            c.boardConfidence = max(3, c.boardConfidence - 12)
        }
        return asset
    }

    fun updateBoard(): Boolean {
        val c = world.userClub ?: return false
        val st = refreshObjectives()
        val met = st.count { it.met }
        val form = c.form.take(5)
        var pts = 0
        for (ch in form) pts += if (ch == 'W') 3 else if (ch == 'D') 1 else 0
        val target = max(1, form.size * 3)
        var conf = 42.0 + (met.toDouble() / max(1, st.size)) * 34.0 + (pts.toDouble() / target) * 26.0
        conf += (world.managerRep - 40) * 0.12
        c.boardConfidence = (c.boardConfidence * 0.55 + conf * 0.45).roundToInt().coerceIn(2, 99)

        if (c.boardConfidence < 14 && world.week > 8 && !sackWarned) {
            sackWarned = true
            inbox(
                "The Board", "A difficult conversation",
                "Results have not been acceptable. You have a short window to turn this around.",
                "\u26A0"
            )
        }
        return c.boardConfidence < 6 && world.week > 12
    }

    val transferWindowOpen: Boolean
        get() = world.week <= 5 || (world.week in 19..22)

    /** Rival clubs come knocking during the window. */
    fun generateOffers() {
        if (!transferWindowOpen) return
        val c = world.userClub ?: return
        val rng = Rng(world.seed + world.week * 5573L + world.season * 17L)
        val squadRating = world.squadRating(c)
        for (id in c.squad.toList()) {
            val p = world.player(id) ?: continue
            if (p.injured) continue
            val pool = world.clubs.filter {
                !it.isUser && it.reputation > c.reputation - 5 && it.balance > p.value() * 1.3
            }
            if (pool.isEmpty()) continue
            var chance = 0.014 + max(0, p.overall() - squadRating) * 0.008
            if (p.listed) chance += 0.22
            if (p.contractYears <= 1) chance += 0.06
            if (!rng.chance(chance)) continue
            val buyer = rng.pick(pool)
            val fee = ((p.value() * (if (p.listed) 0.95 else 1.15 + rng.f() * 0.5)) / 50_000.0).roundToInt() * 50_000L
            val offer = TransferOffer(nextOfferId++, p.id, buyer.id, fee, world.week)
            offers.add(offer)
            val m = inbox(
                buyer.name, "Offer for ${p.full}",
                "${buyer.name} have bid ${Fmt.money(fee)} for ${p.full}. " +
                        (if (p.morale < 45) "The player is keen on the move." else "He is happy to listen."),
                "\u25C6"
            )
            m.offerId = offer.id
        }
    }

    fun logDeal(p: Player, from: String, to: String, fee: Long) {
        transferLog.add(0, Deal(p.full, p.pos, p.age, p.overall(), from, to, fee, world.season, world.week))
        while (transferLog.size > 140) transferLog.removeAt(transferLog.size - 1)
    }

    fun worldEvent(icon: String, headline: String, detail: String) {
        worldNews.add(0, WorldEvent(icon, headline, detail, world.season, world.week))
        while (worldNews.size > 90) worldNews.removeAt(worldNews.size - 1)
    }

    /**
     * The rest of the football world gets on with its business: clubs buy and
     * sell, runs of form get noticed, and managers lose their jobs.
     */
    fun aiTransfers() {
        val rng = Rng(world.seed + world.week * 8123L + world.season * 53L)
        repeat(18) {
            val buyer = rng.pick(world.clubs.filter { !it.isUser })
            if (buyer.squad.size >= 28) return@repeat
            val buyerRating = world.squadRating(buyer)
            val targets = world.players.values.filter { p ->
                p.clubId >= 0 && p.clubId != buyer.id &&
                        world.club(p.clubId)?.isUser == false &&
                        p.overall() > buyerRating && p.value() < buyer.balance * 0.35
            }
            if (targets.isEmpty()) return@repeat
            val p = rng.pick(targets)
            val seller = world.club(p.clubId) ?: return@repeat
            if (seller.squad.size <= 18) return@repeat
            val fee = (p.value() * (1.1 + rng.f() * 0.3)).toLong()
            seller.squad.remove(p.id); seller.balance += fee
            buyer.squad.add(p.id); buyer.balance -= fee; p.clubId = buyer.id
            world.autoPickSquad(seller); world.autoPickSquad(buyer)
            logDeal(p, seller.name, buyer.name, fee)
            // a headline deal gets talked about
            if (fee > 25_000_000L) {
                worldEvent("\u25C6", "${buyer.name} break the bank for ${p.full}",
                    "${Fmt.money(fee)} from ${seller.name} for the ${p.age}-year-old ${Pos.name(p.pos)}.")
            }
        }
    }

    /** Form, milestones and sackings elsewhere in the game. */
    fun worldPulse() {
        val rng = Rng(world.seed + world.week * 4409L + world.season * 71L)

        // a club on a run
        val hot = world.clubs.filter { !it.isUser && it.form.size >= 5 && it.form.take(5).all { f -> f == 'W' } }
        if (hot.isNotEmpty() && rng.chance(0.6)) {
            val c = rng.pick(hot)
            worldEvent("\u25B2", "${c.name} make it five straight wins",
                "${world.division(c.divisionId)?.name ?: "Their division"} \u00B7 ${c.won}W ${c.drawn}D ${c.lost}L")
        }
        // a club in freefall loses its manager
        val cold = world.clubs.filter { !it.isUser && it.form.size >= 5 && it.form.take(5).count { f -> f == 'L' } >= 5 }
        if (cold.isNotEmpty() && rng.chance(0.35)) {
            val c = rng.pick(cold)
            worldEvent("\u25BC", "${c.name} part company with their manager",
                "Five defeats in a row has cost him his job.")
        }
        // a squad player who is not playing enough lets it be known
        val c = world.userClub
        if (c != null && rng.chance(0.16)) {
            val unhappy = c.squad.mapNotNull { world.player(it) }
                .filter { it.morale < 42 && it.squadStatus <= 1 && it.minutes < world.week * 25 }
                .minByOrNull { it.morale }
            if (unhappy != null) {
                inbox(
                    unhappy.full, "I want to be playing",
                    "I did not come here to watch. If it carries on I will look at what else is out there.",
                    "\u26A0"
                )
            }
        }
        // a rival takes a look at one of yours, but only once per player per
        // season: the same story every fortnight stops being news
        if (c != null && rng.chance(0.13)) {
            val star = c.squad.mapNotNull { world.player(it) }
                .filter { it.id !in watched }
                .maxByOrNull { it.overall() }
            // somebody from his own country first, so it reads like a real link
            val here = world.division(c.divisionId)?.country ?: "ENG"
            val suitor = world.clubs.filter {
                !it.isUser && it.reputation > c.reputation + 6 &&
                    (world.division(it.divisionId)?.country ?: "ENG") == here
            }.ifEmpty {
                world.clubs.filter { !it.isUser && it.reputation > c.reputation + 10 }
            }
            if (star != null && suitor.isNotEmpty()) {
                val s2 = rng.pick(suitor)
                watched.add(star.id)
                worldEvent("\u25C6", "${s2.name} watching ${star.full}",
                    "Scouts were at your last match. No approach has been made yet.")
            }
        }
        // someone is banging them in
        val scorer = world.players.values
            .filter { it.clubId >= 0 && world.club(it.clubId)?.isUser == false && it.goals >= 12 }
            .maxByOrNull { it.goals }
        if (scorer != null && rng.chance(0.25)) {
            worldEvent("\u2605", "${scorer.full} reaches ${scorer.goals} goals",
                "${world.club(scorer.clubId)?.name} \u00B7 ${scorer.apps} appearances this season.")
        }
        // a wonderkid emerges
        val kid = world.players.values
            .filter { it.age <= 19 && it.potential - it.overall() > 18 && it.apps >= 5 && world.club(it.clubId)?.isUser == false }
            .maxByOrNull { it.potential }
        if (kid != null && rng.chance(0.18)) {
            worldEvent("\u2726", "Europe takes note of ${kid.full}",
                "${kid.age}-year-old ${Pos.name(kid.pos)} at ${world.club(kid.clubId)?.name}, already ${kid.overall()} rated.")
        }
    }

    /** One full week between matches. Returns true if the manager was sacked. */
    fun advanceWeek(): Boolean {
        // a week's work on the training ground in the same shape
        for (c in world.clubs) {
            val t = c.tactics
            if (t.familiarWith != t.formation) t.familiarWith = t.formation
            val gain = if (c.isUser && trainingFocus == 6) 5.6 else 2.6
            t.familiarity = min(100.0, t.familiarity + gain)
        }
        applyTraining()
        weeklyFinance()
        generateOffers()
        val sacked = updateBoard()
        world.week++
        if (transferWindowOpen) aiTransfers()
        worldPulse()
        return sacked
    }

    /* ------------------------------------------------------------ DAYS */

    /**
     * A week is not one button press. The days between matches are walked
     * through one at a time, each with its own business, so a season has a
     * rhythm instead of jumping from kick-off to kick-off.
     */
    var dayIndex = 0

    val dayNames = arrayOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday")

    /** How many days are walked through before the next match. */
    val daysBetweenMatches = 3

    /** True when the next press of continue takes you to the team sheet. */
    val onMatchDay: Boolean get() = dayIndex >= daysBetweenMatches

    fun dayLabel(): String =
        if (onMatchDay) "Match day" else dayNames.getOrElse(dayIndex) { "Midweek" }

    /**
     * Moves the career on one day. The real weekly work — training, wages,
     * transfers, the board — still happens once, on the last day before the
     * match, so nothing is done three times over.
     */
    fun advanceDay(): Boolean {
        var sacked = false
        dailyEvents(dayIndex)
        dayIndex++
        if (dayIndex >= daysBetweenMatches) {
            sacked = advanceWeek()
        }
        return sacked
    }

    /** Called when a match finishes: the following week starts on Monday. */
    fun resetWeekDays() { dayIndex = 0 }

    /**
     * The small business of a day. Kept deliberately light: a session report,
     * a fitness note, a scouting line. The heavier things — bids, board mail,
     * the press — arrive through their own systems and show up in the briefing.
     */
    private fun dailyEvents(day: Int) {
        val c = world.userClub ?: return
        val rng = Rng(world.seed + world.week * 977L + world.season * 31L + day * 7717L)
        val squad = c.squad.mapNotNull { world.player(it) }
        if (squad.isEmpty()) return

        when (day) {
            0 -> {
                // Monday: how the legs are after the weekend
                val sore = squad.filter { it.fitness < 72 }
                if (sore.isNotEmpty()) {
                    news("\u2699", "${sore.size} came through the weekend short of fitness. " +
                            "${sore.maxByOrNull { 100 - it.fitness }?.full} is the worst of them.",
                        NewsItem.CLUB)
                }
                val back = squad.filter { it.injuryWeeks == 1 }
                for (p in back.take(2)) {
                    news("\u271A", "${p.full} is back in full training.", NewsItem.INJURY)
                }
            }
            1 -> {
                // Tuesday: the training ground
                val sharp = squad.filter { it.age <= 23 }.maxByOrNull { it.morale }
                if (sharp != null && rng.chance(0.55)) {
                    news("\u25B2", "${sharp.full} has been the standout in training this week.",
                        NewsItem.CLUB)
                }
                if (rng.chance(0.30)) {
                    val f = Training.ALL[trainingFocus]
                    news("\u2699", "Session focus: ${f.label.lowercase()}. ${f.desc}.", NewsItem.CLUB)
                }
            }
            else -> {
                // Thursday or Friday: shape and the opposition
                val fx = season.nextUserFixture()
                if (fx != null) {
                    val oppId = if (fx.homeId == c.id) fx.awayId else fx.homeId
                    world.club(oppId)?.let { opp ->
                        val form = opp.form.take(5).joinToString("")
                        val tail = if (form.isBlank()) "Nothing to go on yet this season."
                        else "Their recent form reads $form."
                        news("\u25C6", "Work on the shape for ${opp.name}. $tail", NewsItem.CLUB)
                    }
                }
                val t = c.tactics
                if (t.familiarity < 60) {
                    news("\u26A0", "The players are still finding their way in ${t.formation}.",
                        NewsItem.CLUB)
                }
            }
        }
    }

    /* -------------------------------------------------------- BRIEFING */

    /**
     * What the manager should be made to look at before he gets to the next
     * match. Events used to land silently in the inbox and the news feed, which
     * meant a week passed and nothing appeared to have happened; this is the
     * short list that earns an interruption.
     */
    class Briefing(val icon: String, val title: String, val body: String, val urgent: Boolean)

    fun briefing(): List<Briefing> {
        val out = ArrayList<Briefing>(6)
        val c = world.userClub ?: return out

        for (q in press.filter { !it.answered }) {
            out.add(Briefing("\u2709", "The press are waiting", q.text, true))
        }
        // bids get their own line below, so the mail about them is skipped
        // rather than saying the same thing twice
        for (m in inbox.filter { !it.read && !it.subject.startsWith("Offer for") }.take(3)) {
            out.add(Briefing(m.icon, "${m.from}: ${m.subject}", m.body, m.from == "The Board"))
        }
        for (o in offers.take(2)) {
            world.player(o.playerId)?.let { p ->
                out.add(Briefing(
                    "\u21C4", "Bid received for ${p.full}",
                    "${world.club(o.buyerId)?.name ?: "A club"} have offered ${Fmt.money(o.fee)}.",
                    true
                ))
            }
        }
        // anyone who will not be available
        val out2 = c.squad.mapNotNull { world.player(it) }.filter { it.injuryWeeks > 0 }
        if (out2.isNotEmpty()) {
            out.add(Briefing(
                "\u2695", "${out2.size} out injured",
                out2.take(3).joinToString(", ") { "${it.full} (${it.injuryWeeks}w)" },
                false
            ))
        }
        // and the two most interesting things that happened elsewhere
        for (e in worldNews.take(2)) {
            out.add(Briefing(e.icon, e.headline, e.detail, false))
        }
        return out
    }

    /* ---------------------------------------------------------- PRESS */

    /**
     * Called when a signing goes through. The manager is asked about the fee,
     * and what he says follows him: hype settles the dressing room and the new
     * man, but the board then expects to see it on the pitch.
     */
    fun pressOnSigning(p: Player, fee: Long) {
        val c = world.userClub ?: return
        val dear = fee > c.balance / 4 && fee > 0
        val q = PressQuestion(
            from = "Match Day Press",
            text = if (dear)
                "${Fmt.money(fee)} is a club record sort of fee. Is ${p.full} worth it?"
            else
                "You have brought in ${p.full}. What does he give you?",
            subjectId = p.id,
            options = listOf(
                PressOption(
                    "He will be the difference this season",
                    "\u201CHe is the best in this league at what he does. You will see that quickly.\u201D",
                    squadMorale = 0.6, subjectMorale = 5.0, repDelta = 2
                ),
                PressOption(
                    "One of eleven, nothing more",
                    "\u201CHe joins a group that was already working. No one man wins you anything.\u201D",
                    squadMorale = 1.4, subjectMorale = -1.5, repDelta = 0
                ),
                PressOption(
                    "He has everything to prove",
                    "\u201CHe knows what the fee is. Now he has to earn it on a Saturday.\u201D",
                    squadMorale = -0.4, subjectMorale = -4.0, repDelta = 1
                )
            )
        )
        press.add(q)
        inbox(
            "Press Officer", "Media are asking about ${p.full}",
            "The room wants a line on the signing before the weekend.", "\u2709"
        )
    }

    /** After a hiding, the questions get harder. */
    fun pressOnDefeat(margin: Int, opponent: String) {
        press.add(
            PressQuestion(
                from = "Match Day Press",
                text = "Beaten by $margin at $opponent. What went wrong?",
                options = listOf(
                    PressOption(
                        "That is on me",
                        "\u201CI picked the side and I set it up. The players are not to blame for that.\u201D",
                        squadMorale = 1.8, repDelta = -1
                    ),
                    PressOption(
                        "Not good enough from the players",
                        "\u201CI saw people who did not want it. They know that.\u201D",
                        squadMorale = -2.4, repDelta = 1
                    ),
                    PressOption(
                        "One result, nothing more",
                        "\u201CWe move on to Tuesday. I am not making it more than it is.\u201D",
                        squadMorale = 0.4, repDelta = 0
                    )
                )
            )
        )
    }

    /** Applies whatever he said. */
    fun answerPress(q: PressQuestion, opt: PressOption) {
        if (q.answered) return
        q.answered = true
        q.chosen = opt
        val c = world.userClub
        if (c != null) {
            for (id in c.squad) {
                val pl = world.player(id) ?: continue
                pl.shiftMorale(opt.squadMorale)
            }
        }
        if (q.subjectId >= 0) {
            world.player(q.subjectId)?.shiftMorale(opt.subjectMorale)
        }
        world.managerRep = (world.managerRep + opt.repDelta).coerceIn(1, 99)
        news("\u2709", "Press: ${opt.reply}", NewsItem.CLUB)
    }

    /* --------------------------------------------------------- YOUTH */

    fun youthIntake(): List<Player> {
        val c = world.userClub ?: return emptyList()
        val rng = Rng(world.seed + world.season * 7331L)
        val room = max(0, 28 - c.squad.size)
        val n = min(rng.i(3, 5), room)
        val kids = ArrayList<Player>(n)
        if (n <= 0) {
            inbox(
                "Head of Youth Development", "Youth intake day",
                "Promising youngsters came through, but there is no room to register them.", "\u2740"
            )
            return kids
        }
        val quality = 30.0 + c.reputation * 0.35
        val homeNation = Names.byCode("ENG")
        repeat(n) {
            val p = world.makePlayer(
                rng, rng.i(0, Pos.COUNT - 1), rng.i(16, 17),
                rng.norm(quality * 0.62, 6.0, 18, 60),
                if (rng.chance(0.8)) homeNation else rng.pick(Names.NATIONS)
            )
            p.potential = rng.norm(quality * 0.95, 12.0, 45, 95).coerceAtLeast(p.overall())
            p.clubId = c.id
            p.squadStatus = 4
            p.wage = 500
            p.contractYears = 3
            world.players[p.id] = p
            c.squad.add(p.id)
            kids.add(p)
        }
        val best = kids.maxByOrNull { it.potential }
        inbox(
            "Head of Youth Development", "Youth intake day",
            "$n young players have joined the academy." + (best?.let {
                " ${it.full} (${Pos.name(it.pos)}) looks the pick of the group — the staff think he could become " +
                        when {
                            it.potential >= 80 -> "a first-team player at the highest level."
                            it.potential >= 68 -> "a useful squad player."
                            else -> "a decent lower-league professional."
                        }
            } ?: ""), "\u2740"
        )
        return kids
    }

    /* ----------------------------------------------------- TRANSFERS */

    fun askingPrice(p: Player): Long {
        val owner = world.club(p.clubId) ?: return 0
        var mult = 1.25
        if (p.listed) mult = 0.90
        if (owner.squad.indexOf(p.id) < 11) mult += 0.35
        if (p.age <= 21 && p.potential - p.overall() > 12) mult += 0.40
        if (owner.balance < 2_000_000L) mult -= 0.25
        return ((p.value() * max(0.6, mult)) / 50_000.0).roundToInt() * 50_000L
    }

    class BidResult(val ok: Boolean, val message: String) {
        var counterFee: Long = -1
        var wantWage: Int = -1
    }

    fun makeBid(playerId: Int, fee: Long, wage: Int, years: Int): BidResult {
        val c = world.userClub ?: return BidResult(false, "No club.")
        val p = world.player(playerId) ?: return BidResult(false, "Player not found.")
        if (!transferWindowOpen) return BidResult(false, "The transfer window is closed.")
        if (c.squad.size >= 30) return BidResult(false, "Your squad is full.")
        if (fee > c.transferBudget) return BidResult(false, "That fee is beyond your transfer budget.")

        val ask = askingPrice(p)
        val owner = world.club(p.clubId)
        val rng = Rng(world.seed + playerId * 131L + world.week)

        if (owner != null) {
            if (fee < ask * 0.78) {
                val r = BidResult(false, "${owner.name} reject the bid.")
                r.counterFee = ((ask * (0.95 + rng.f() * 0.2)) / 50_000.0).roundToInt() * 50_000L
                return r
            }
            if (fee < ask * 0.97 && rng.chance(0.45)) {
                val r = BidResult(false, "${owner.name} want more.")
                r.counterFee = ((ask * 1.05) / 50_000.0).roundToInt() * 50_000L
                return r
            }
        }

        val want = (p.expectedWage() * (1.05 + if (p.hasTrait(Traits.GREEDY)) 0.35 else 0.0) *
                (if (c.reputation > (owner?.reputation ?: 30)) 0.95 else 1.20)).roundToInt()
        if (wage < want) {
            val r = BidResult(false, "${p.last} wants ${Fmt.wage(want)} to sign.")
            r.wantWage = want
            return r
        }
        val room = c.wageBudget - world.wageBill(c)
        if (wage > room) return BidResult(false, "That wage breaks your budget. You have ${Fmt.wage(max(0, room))} of room.")

        if (owner != null) {
            owner.squad.remove(p.id)
            owner.balance += fee
            world.autoPickSquad(owner)
        }
        c.transferBudget -= fee
        c.balance -= fee
        p.clubId = c.id
        p.wage = wage
        p.contractYears = years
        p.listed = false
        p.shiftMorale(12.0)
        c.squad.add(p.id)
        world.autoPickSquad(c)
        logDeal(p, owner?.name ?: "Free agent", c.name, fee)
        news("\u270D", "${c.name} sign ${p.full} for ${Fmt.money(fee)}.", NewsItem.TRANSFER)
        pressOnSigning(p, fee)
        return BidResult(true, "${p.full} has signed for ${c.name}!")
    }

    fun sellPlayer(playerId: Int, fee: Long, buyerId: Int): BidResult {
        val c = world.userClub ?: return BidResult(false, "No club.")
        val p = world.player(playerId) ?: return BidResult(false, "Player not found.")
        if (p.clubId != c.id) return BidResult(false, "Not your player.")
        if (c.squad.size <= 16) return BidResult(false, "You cannot go below 16 players.")
        val buyer = world.club(buyerId)
        c.squad.remove(p.id)
        c.balance += fee
        c.transferBudget += (fee * 0.7).toLong()
        if (buyer != null) { buyer.squad.add(p.id); p.clubId = buyer.id; world.autoPickSquad(buyer) }
        else p.clubId = -1
        if (p.overall() > world.squadRating(c)) c.morale = max(20.0, c.morale - 6)
        world.autoPickSquad(c)
        logDeal(p, c.name, buyer?.name ?: "Free agent", fee)
        news("\u25B6", "${p.full} leaves ${c.name} for ${Fmt.money(fee)}.", NewsItem.TRANSFER)
        return BidResult(true, "${p.full} sold for ${Fmt.money(fee)}.")
    }

    fun acceptOffer(offerId: Int): BidResult {
        val o = offers.firstOrNull { it.id == offerId } ?: return BidResult(false, "That offer has expired.")
        val r = sellPlayer(o.playerId, o.fee, o.buyerId)
        offers.remove(o)
        inbox.removeAll { it.offerId == offerId }
        return r
    }

    fun rejectOffer(offerId: Int) {
        offers.removeAll { it.id == offerId }
        inbox.removeAll { it.offerId == offerId }
    }

    /* ------------------------------------------------------- CONTRACTS */

    /** What he will sign a new deal for, given how well things are going. */
    fun renewalDemand(p: Player): Int {
        val c = world.userClub ?: return p.expectedWage()
        var want = p.expectedWage() * 1.12
        if (p.hasTrait(Traits.GREEDY)) want *= 1.30
        if (p.hasTrait(Traits.LOYAL)) want *= 0.88
        if (p.morale < 40) want *= 1.20
        if (p.form > 7.2) want *= 1.15
        // a player at a club punching above its level asks for less
        if (c.reputation > 70) want *= 0.94
        return (want / 100.0).roundToInt() * 100
    }

    fun renewContract(playerId: Int, wage: Int, years: Int): BidResult {
        val c = world.userClub ?: return BidResult(false, "No club.")
        val p = world.player(playerId) ?: return BidResult(false, "Player not found.")
        if (p.clubId != c.id) return BidResult(false, "Not your player.")
        val want = renewalDemand(p)
        if (wage < want) {
            val r = BidResult(false, "${p.last} is holding out for ${Fmt.wage(want)}.")
            r.wantWage = want
            return r
        }
        val room = c.wageBudget - wageBillExcluding(p)
        if (wage > room) return BidResult(false, "That breaks the wage budget. Room: ${Fmt.wage(max(0, room))}.")
        p.wage = wage
        p.contractYears = years
        p.shiftMorale(10.0)
        news("\u270D", "${p.full} signs a new $years-year deal.", NewsItem.CLUB)
        return BidResult(true, "${p.full} has signed until season ${world.season + years}.")
    }

    private fun wageBillExcluding(p: Player): Int {
        val c = world.userClub ?: return 0
        return c.squad.sumOf { if (it == p.id) 0 else (world.player(it)?.wage ?: 0) }
    }

    /** Players whose deals run out this season — chase them or lose them free. */
    fun expiringContracts(): List<Player> {
        val c = world.userClub ?: return emptyList()
        return world.squadOf(c).filter { it.contractYears <= 1 }.sortedByDescending { it.overall() }
    }

    /* --------------------------------------------------------- SCOUTING */

    class ScoutReport(val message: String, val found: List<Player>)

    /** Sends the scouts out for unattached players matching a brief. */
    fun scoutMission(pos: Int, young: Boolean): ScoutReport {
        val c = world.userClub ?: return ScoutReport("No club.", emptyList())
        val cost = 120_000L
        if (c.balance < cost) return ScoutReport("Not enough in the bank for a scouting trip.", emptyList())
        c.balance -= cost
        val rng = Rng(world.seed + world.week * 991L + scoutFinds.size * 37L + world.season)
        val found = ArrayList<Player>(5)
        val target = world.squadRating(c)
        repeat(5) {
            val p = world.makePlayer(
                rng,
                if (pos >= 0) pos else rng.i(0, Pos.COUNT - 1),
                if (young) rng.i(16, 20) else rng.i(19, 28),
                rng.norm((target + rng.i(-8, 8)).toDouble(), 4.0, 24, 90),
                rng.pick(Names.NATIONS),
                if (young) 92 else 88
            )
            p.clubId = -1
            p.scouted = rng.i(55, 100)
            world.players[p.id] = p
            scoutFinds.add(0, p.id)
            found.add(p)
        }
        while (scoutFinds.size > 30) scoutFinds.removeAt(scoutFinds.size - 1)
        return ScoutReport("Your scouts return with ${found.size} names.", found)
    }

    fun freeAgents(): List<Player> =
        world.players.values.filter { it.clubId < 0 }.sortedByDescending { it.overall() }.take(40)

    /** Everything the market has to show, filtered. */
    fun market(pos: Int, maxAge: Int, minRating: Int, maxFee: Long = Long.MAX_VALUE): List<Player> {
        val c = world.userClub ?: return emptyList()
        val squadRating = world.squadRating(c)
        val out = ArrayList<Player>(80)
        for (p in world.players.values) {
            if (p.clubId == c.id) continue
            val owner = world.club(p.clubId)
            if (owner != null && kotlin.math.abs(owner.tier - c.tier) > 1 && owner.divisionId >= 0) continue
            val listed = p.listed || (owner != null && owner.squad.indexOf(p.id) > 15)
            val attainable = owner == null || p.overall() <= squadRating + 9
            if (!listed && !attainable) continue
            if (pos >= 0 && p.pos != pos) continue
            if (p.age > maxAge) continue
            if (p.overall() < minRating) continue
            if (owner != null && askingPrice(p) > maxFee) continue
            out.add(p)
        }
        return out.sortedByDescending { it.overall() }.take(80)
    }
}
