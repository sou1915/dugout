package com.dugout.career.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Every sound in the match, made from noise and sine waves at run time.
 *
 * Nothing here is a recording: shipping a crowd loop long enough not to
 * audibly repeat would cost several megabytes, and a short one gives itself
 * away within a minute. A generated bed never repeats and costs a few hundred
 * kilobytes of RAM.
 *
 * This file is deliberately free of Android imports so the whole thing can be
 * rendered to a WAV on a desktop and measured.
 */
object Synth {

    const val RATE = 22050

    /** Which one-shot to fire. */
    object Sfx {
        const val WHISTLE_SHORT = 0
        const val WHISTLE_LONG = 1
        const val KICK = 2
        const val KICK_HARD = 3
        const val NET = 4
        const val POST = 5
        const val ROAR = 6
        const val GROAN = 7
        const val APPLAUSE = 8
        const val OOH = 9
        const val TACKLE = 10
        const val COUNT = 11
    }

    /* ------------------------------------------------------------ HELPERS */

    /** Small fast noise source; a full Rng per sample would dominate the cost. */
    class Noise(seed: Long) {
        private var s = if (seed == 0L) 0x9E3779B97F4A7C15uL.toLong() else seed
        fun next(): Float {
            s = s xor (s shl 13); s = s xor (s ushr 7); s = s xor (s shl 17)
            return ((s ushr 40).toInt() - 8388608) / 8388608f
        }
    }

    /** One-pole low pass. `a` near 0 is dark, near 1 is open. */
    class LP(var a: Float) {
        private var y = 0f
        fun run(x: Float): Float { y += a * (x - y); return y }
    }

    /** One-pole high pass, built from the low pass. */
    class HP(var a: Float) {
        private val lp = LP(a)
        fun run(x: Float): Float = x - lp.run(x)
    }

    /** Two-pole band pass, for the vowel-like colour in crowd noise. */
    class BP(freq: Float, private val q: Float) {
        private var low = 0f
        private var band = 0f
        var f = 2f * sin(PI.toFloat() * freq / RATE)
        fun run(x: Float): Float {
            low += f * band
            val high = x - low - q * band
            band += f * high
            return band
        }
        fun tune(freq: Float) { f = 2f * sin(PI.toFloat() * min(freq, RATE / 2.2f) / RATE) }
    }

    private fun env(i: Int, n: Int, attack: Float, decay: Float): Float {
        val t = i.toFloat() / RATE
        val total = n.toFloat() / RATE
        val a = if (attack <= 0f) 1f else min(1f, t / attack)
        val r = exp(-(t / decay))
        val tail = min(1f, (total - t) * 40f).coerceAtLeast(0f)   // never click at the end
        return a * r * tail
    }

    private fun toPcm(f: FloatArray): ShortArray {
        val out = ShortArray(f.size)
        for (i in f.indices) {
            val v = f[i].coerceIn(-1f, 1f)
            out[i] = (v * 32000f).toInt().toShort()
        }
        return out
    }

    /* ------------------------------------------------------- THE ONE-SHOTS */

    /**
     * A pea whistle: two close tones so they beat against each other, a fast
     * warble, and the breath noise that makes it sound blown rather than played.
     */
    private fun whistle(seconds: Float, seed: Long): ShortArray {
        val n = (RATE * seconds).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val hp = HP(0.75f)
        var p1 = 0f; var p2 = 0f
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val warble = sin(2f * PI.toFloat() * 17f * t) * 34f
            val f1 = 3180f + warble
            val f2 = 3255f + warble * 0.8f
            p1 += 2f * PI.toFloat() * f1 / RATE
            p2 += 2f * PI.toFloat() * f2 / RATE
            val tone = sin(p1) * 0.5f + sin(p2) * 0.34f + sin(p1 * 2f) * 0.06f
            val breath = hp.run(nz.next()) * 0.16f
            val e = min(1f, t / 0.012f) *
                min(1f, ((seconds - t) / 0.05f).coerceAtLeast(0f))
            out[i] = (tone + breath) * e * 0.42f
        }
        return toPcm(out)
    }

    /** Boot on ball: a sharp click over a short low thump. */
    private fun kick(power: Float, seed: Long): ShortArray {
        val n = (RATE * 0.28f).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val lp = LP(0.42f)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val click = lp.run(nz.next()) * exp(-t / 0.012f)
            val body = sin(2f * PI.toFloat() * 132f * t) * exp(-t / 0.055f)
            val thock = sin(2f * PI.toFloat() * 410f * t) * exp(-t / 0.022f) * 0.5f
            out[i] = (click * 0.85f + body * 0.7f + thock) * power * 0.55f
        }
        return toPcm(out)
    }

    /** The ball hitting the netting: bright, dry, and gone quickly. */
    private fun net(seed: Long): ShortArray {
        val n = (RATE * 0.45f).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val bp = BP(2400f, 0.9f)
        val hp = HP(0.5f)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val flutter = 1f + sin(2f * PI.toFloat() * 38f * t) * 0.35f
            val s = hp.run(bp.run(nz.next())) * flutter
            out[i] = s * exp(-t / 0.085f) * 0.5f
        }
        return toPcm(out)
    }

    /** Woodwork. Inharmonic partials so it rings rather than pitches. */
    private fun post(seed: Long): ShortArray {
        val n = (RATE * 1.1f).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val a = sin(2f * PI.toFloat() * 396f * t) * exp(-t / 0.34f)
            val b = sin(2f * PI.toFloat() * 1157f * t) * exp(-t / 0.16f) * 0.5f
            val c = sin(2f * PI.toFloat() * 2310f * t) * exp(-t / 0.07f) * 0.25f
            val knock = nz.next() * exp(-t / 0.006f) * 0.6f
            out[i] = (a + b + c + knock) * 0.34f
        }
        return toPcm(out)
    }

    /**
     * The crowd going up. Broadband noise pushed through a moving band pass so
     * it opens out as it swells, which is what a stand actually does.
     */
    private fun roar(seconds: Float, seed: Long, joyful: Boolean): ShortArray {
        val n = (RATE * seconds).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val bp1 = BP(520f, 1.1f)
        val bp2 = BP(1150f, 1.3f)
        val lp = LP(0.30f)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val x = t / seconds
            // fast up, slow down for a goal; a shallower shape for a groan
            val e = if (joyful) min(1f, x / 0.10f) * exp(-max(0f, x - 0.10f) * 3.1f)
            else min(1f, x / 0.22f) * exp(-max(0f, x - 0.22f) * 2.4f)
            val open = if (joyful) 380f + 900f * e else 300f + 240f * e
            bp1.tune(open)
            bp2.tune(open * 2.3f)
            val src = nz.next()
            val body = lp.run(src) * 0.5f + bp1.run(src) * 0.8f + bp2.run(src) * 0.45f
            out[i] = body * e * 0.62f
        }
        return toPcm(out)
    }

    /** Applause: a shower of little claps, dense at first then thinning out. */
    private fun applause(seconds: Float, seed: Long): ShortArray {
        val n = (RATE * seconds).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val r = Rng(seed xor 0x5DEECE66DL)
        val hp = HP(0.62f)
        // each clap is a very short filtered burst dropped at a random moment
        val claps = (seconds * 260).toInt()
        for (k in 0 until claps) {
            val at = (r.f() * n).toInt()
            val x = at.toFloat() / n
            val gain = (1f - x * 0.75f).coerceAtLeast(0.1f) * (0.35f + r.f().toFloat() * 0.65f)
            val len = (RATE * (0.008f + r.f().toFloat() * 0.012f)).toInt()
            for (j in 0 until len) {
                val i = at + j
                if (i >= n) break
                out[i] += hp.run(nz.next()) * exp(-j.toFloat() / (len * 0.35f)) * gain * 0.30f
            }
        }
        return toPcm(out)
    }

    /** The intake of breath at a near miss: a short vowel that falls away. */
    private fun ooh(seconds: Float, seed: Long): ShortArray {
        val n = (RATE * seconds).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val bp1 = BP(430f, 0.8f)
        val bp2 = BP(860f, 1.0f)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val x = t / seconds
            val e = min(1f, x / 0.09f) * exp(-max(0f, x - 0.09f) * 2.8f)
            val slide = 470f - 210f * x
            bp1.tune(slide); bp2.tune(slide * 2.1f)
            val src = nz.next()
            out[i] = (bp1.run(src) * 0.9f + bp2.run(src) * 0.4f) * e * 0.5f
        }
        return toPcm(out)
    }

    /** Studs and body: a dull scuff, no ring to it. */
    private fun tackle(seed: Long): ShortArray {
        val n = (RATE * 0.3f).toInt()
        val out = FloatArray(n)
        val nz = Noise(seed)
        val lp = LP(0.20f)
        val bp = BP(700f, 1.6f)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val src = nz.next()
            val scuff = bp.run(src) * exp(-t / 0.09f)
            val thud = lp.run(src) * exp(-t / 0.035f)
            out[i] = (scuff * 0.5f + thud * 0.9f) * 0.5f
        }
        return toPcm(out)
    }

    /* ---------------------------------------------------------- THE BANK */

    /**
     * Renders one of everything up front. A phone should never be doing this
     * work while the ball is moving, so it happens once when the match loads.
     */
    fun bank(seed: Long): Array<ShortArray> = arrayOf(
        whistle(0.42f, seed + 1),
        whistle(1.55f, seed + 2),
        kick(0.7f, seed + 3),
        kick(1.0f, seed + 4),
        net(seed + 5),
        post(seed + 6),
        roar(3.4f, seed + 7, joyful = true),
        roar(2.2f, seed + 8, joyful = false),
        applause(2.6f, seed + 9),
        ooh(1.3f, seed + 10),
        tackle(seed + 11)
    )

    /* ------------------------------------------------------- THE CROWD BED */

    /**
     * A continuous stand. Noise through two band passes for the vowel colour,
     * with several slow, unrelated swells laid over it so it breathes and never
     * settles into a loop. `intensity` is driven by the match: it rises with a
     * chance, falls back at a goal kick.
     */
    class CrowdBed(seed: Long) {
        private val nz = Noise(seed)
        private val bp1 = BP(330f, 1.35f)
        private val bp2 = BP(720f, 1.6f)
        private val lp = LP(0.16f)
        private val hp = HP(0.02f)
        private var t = 0.0

        /** 0 quiet, 1 boiling. Moves toward [target] rather than jumping. */
        var level = 0.25f
        var target = 0.25f

        fun mixInto(out: FloatArray, n: Int, gain: Float) {
            val dt = 1.0 / RATE
            for (i in 0 until n) {
                t += dt
                level += (target - level) * 0.00004f
                val tt = t.toFloat()
                // three unrelated periods: the sum never repeats audibly
                val swell = 1f +
                    sin(2f * PI.toFloat() * 0.073f * tt) * 0.20f +
                    sin(2f * PI.toFloat() * 0.117f * tt) * 0.13f +
                    sin(2f * PI.toFloat() * 0.191f * tt) * 0.09f
                val src = nz.next()
                val body = lp.run(src) * 0.55f + bp1.run(src) * 0.75f + bp2.run(src) * 0.35f
                val amp = (0.10f + level * 0.42f) * swell
                out[i] += hp.run(body) * amp * gain
            }
        }
    }

    /* ---------------------------------------------------------- THE MIXER */

    private class Shot(val buf: ShortArray, var pos: Int, val gain: Float, val pan: Float)

    /**
     * Holds the bed and whatever one-shots are sounding, and fills a buffer of
     * interleaved stereo. Kept allocation-free once running.
     */
    class Mixer(seed: Long) {
        private val bank = bank(seed)
        val crowd = CrowdBed(seed xor 0x1234)
        private val shots = ArrayList<Shot>(12)
        private var scratch = FloatArray(0)
        var masterGain = 0.9f
        var crowdGain = 0.75f
        var sfxGain = 1.0f

        /** [pan] runs -1 left to +1 right, taken from where on the pitch it happened. */
        @Synchronized
        fun play(kind: Int, gain: Float = 1f, pan: Float = 0f) {
            if (kind < 0 || kind >= bank.size) return
            if (shots.size >= 10) shots.removeAt(0)
            shots.add(Shot(bank[kind], 0, gain, pan.coerceIn(-1f, 1f)))
        }

        @Synchronized
        fun clear() = shots.clear()

        /** Fills [out] with `frames` stereo frames (so 2 * frames shorts). */
        @Synchronized
        fun render(out: ShortArray, frames: Int) {
            if (scratch.size < frames) scratch = FloatArray(frames)
            java.util.Arrays.fill(scratch, 0, frames, 0f)
            crowd.mixInto(scratch, frames, crowdGain)

            var i = 0
            while (i < shots.size) {
                val s = shots[i]
                val remain = s.buf.size - s.pos
                if (remain <= 0) { shots.removeAt(i); continue }
                i++
            }

            for (f in 0 until frames) {
                var l = scratch[f]
                var r = scratch[f]
                for (k in shots.indices) {
                    val s = shots[k]
                    val p = s.pos + f
                    if (p >= s.buf.size) continue
                    val v = s.buf[p] / 32768f * s.gain * sfxGain
                    l += v * (1f - max(0f, s.pan)) 
                    r += v * (1f + min(0f, s.pan))
                }
                out[f * 2] = soft(l * masterGain)
                out[f * 2 + 1] = soft(r * masterGain)
            }
            for (k in shots.indices) shots[k].pos += frames
        }

        /** A gentle knee instead of hard clipping, so peaks do not crackle. */
        private fun soft(x: Float): Short {
            val a = abs(x)
            val y = if (a <= 0.7f) x else {
                val over = a - 0.7f
                val comp = 0.7f + over / (1f + over * 2.2f)
                if (x < 0) -comp else comp
            }
            return (y.coerceIn(-1f, 1f) * 32000f).toInt().toShort()
        }
    }
}
