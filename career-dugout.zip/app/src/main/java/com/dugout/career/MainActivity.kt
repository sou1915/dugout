package com.dugout.career

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.dugout.career.core.*
import com.dugout.career.sim.*
import com.dugout.career.ui.*

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var rail: LinearLayout

    private var world: World? = null
    private var season: Season? = null
    private var career: Career? = null

    private var screen = SCR_HUB
    private var tableDivision = 0
    private var squadFilter = -1
    private var selectedPlayer = -1

    private var managerName = "Yassine"
    private var managerNation = "MAR"
    private var seedValue = System.currentTimeMillis() % 999_999L

    /** Held here until the career starts, then copied onto the world. */
    private val pendingProfile = ManagerProfile()

    companion object {
        const val SCR_HUB = 0
        const val SCR_SQUAD = 1
        const val SCR_TACTICS = 2
        const val SCR_TABLE = 3
        const val SCR_CLUB = 4
        const val SCR_INBOX = 5
        const val SCR_PLAYER = 6
        const val SCR_MATCH = 7
        const val SCR_TRAINING = 8
        const val SCR_WORLD = 9
        const val SCR_MARKET = 10
        const val SCR_SCOUT = 11
        const val SCR_STAFF = 12
    }

    private var engine: MatchEngine? = null
    private var matchView: MatchView? = null
    private var matchAudio: MatchAudio? = null
    private var soundOn = true
    private var feedHost: LinearLayout? = null
    private var scoreHost: LinearLayout? = null
    private var controlHost: LinearLayout? = null
    private val loopHandler = Handler(Looper.getMainLooper())
    private var lastFrame = 0L
    private var lastFeedSize = -1

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        root = FrameLayout(this)
        root.setBackgroundColor(Theme.GROUND)
        setContentView(root)
        showSplash()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (world == null) { super.onBackPressed(); return }
        if (screen == SCR_MATCH) return
        if (screen == SCR_PLAYER) { screen = SCR_SQUAD; renderShell(); return }
        if (screen != SCR_HUB) { screen = SCR_HUB; renderShell(); return }
        super.onBackPressed()
    }

    private var noticeHost: LinearLayout? = null

    /**
     * A message from inside the game rather than from Android: it sits on the
     * screen in the game's own type and colours, and fades on its own.
     */
    private fun toast(s: String) {
        val host = noticeHost ?: run {
            val h = column()
            h.gravity = Gravity.CENTER_HORIZONTAL
            val lpx = FrameLayout.LayoutParams(MATCH, WRAP)
            lpx.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lpx.bottomMargin = dp(18)
            root.addView(h, lpx)
            noticeHost = h
            h
        }
        host.bringToFront()

        val card = row()
        card.background = boxBg(0xF0181B2E.toInt(), Theme.ACCENT_DARK, dp(6))
        card.setPadding(dp(16), dp(10), dp(16), dp(10))
        val dot = View(this)
        dot.background = boxBg(Theme.ACCENT, 0, dp(99))
        card.addView(dot, lp(dp(7), dp(7)).also { it.rightMargin = dp(10) })
        card.addView(text(s, 13f, Theme.TEXT, Theme.BODY_MED))
        val p2 = lp(WRAP, WRAP)
        p2.topMargin = dp(5)
        host.addView(card, p2)

        card.alpha = 0f
        card.animate().alpha(1f).setDuration(140).start()
        card.postDelayed({
            card.animate().alpha(0f).setDuration(260).withEndAction {
                host.removeView(card)
            }.start()
        }, 2200)
    }

    /* ------------------------------------------------------------ SPLASH */

    private fun showSplash() {
        root.removeAllViews()
        val outer = column()
        outer.gravity = Gravity.CENTER
        outer.setPadding(dp(40), dp(20), dp(40), dp(20))

        outer.addView(text("FOOTBALL MANAGEMENT", 11f, Theme.ACCENT, Theme.DISPLAY, 0.34f, Gravity.CENTER), lp(MATCH, WRAP))
        outer.addView(text("CAREER DUGOUT", 44f, Theme.TEXT, Theme.DISPLAY, 0f, Gravity.CENTER), lp(MATCH, WRAP))
        outer.addView(spacer(8))
        outer.addView(
            text(
                "Four divisions \u00B7 140 clubs \u00B7 3,600 footballers who never repeat",
                13f, Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER
            ), lp(MATCH, WRAP)
        )
        outer.addView(spacer(26))

        val holder = row(); holder.gravity = Gravity.CENTER
        if (Save.exists(this)) {
            val cont = actionButton("Continue career", true)
            cont.setOnClickListener { loadSaved() }
            holder.addView(cont, lp(WRAP, WRAP).also { it.rightMargin = dp(10) })
        }
        val btn = actionButton(if (Save.exists(this)) "Start again" else "New career", true)
        btn.setOnClickListener {
            if (Save.exists(this)) {
                Save.delete(this)
                toast("Previous career deleted.")
            }
            showManagerSetup()
        }
        holder.addView(btn)
        outer.addView(holder, lp(MATCH, WRAP))

        root.addView(outer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun loadSaved() {
        root.removeAllViews()
        val t = text("Loading your career\u2026", 16f, Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER)
        root.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        t.post {
            val snap = Save.read(this)
            if (snap == null) {
                Save.delete(this)
                showSplash()
                toast("That save could not be read. Starting fresh.")
                return@post
            }
            world = snap.world
            // the same assignment on load, so faces survive a save
            Face.assignAll(snap.world.players.values)
            season = snap.season
            career = snap.career
            screen = SCR_HUB
            tableDivision = snap.world.userClub?.divisionId ?: 0
            renderShell()
        }
    }

    /** Called whenever the career moves on, so nothing is ever lost. */
    private fun autosave() {
        val w = world ?: return
        val s = season ?: return
        val c = career ?: return
        Save.write(this, w, s, c)
    }

    override fun onPause() {
        super.onPause()
        // a match left playing to itself in the background is both a battery
        // drain and, with sound, extremely rude
        matchAudio?.stop()
        if (world != null) autosave()
    }

    override fun onResume() {
        super.onResume()
        if (engine != null && screen == SCR_MATCH) {
            matchAudio = MatchAudio((world?.seed ?: 1L) + (engine?.fixture?.id ?: 0)).also {
                it.enabled = soundOn
                it.start()
            }
        }
    }

    private fun showManagerSetup() {
        root.removeAllViews()
        val scroll = ScrollView(this)
        val outer = column(20)

        outer.addView(text("STEP 1 OF 2", 11f, Theme.ACCENT, Theme.DISPLAY, 0.30f))
        outer.addView(text("Who are you?", 28f, Theme.TEXT, Theme.DISPLAY))
        outer.addView(spacer(14))

        val cols = row()
        cols.gravity = Gravity.TOP

        val left = column()
        left.addView(text("MANAGER NAME", 11f, Theme.MUTED, Theme.DISPLAY, 0.10f))
        val nameField = EditText(this)
        nameField.setText(managerName)
        nameField.setTextColor(Theme.TEXT)
        nameField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        nameField.background = boxBg(Theme.PANEL, Theme.BORDER, dp(4))
        nameField.setPadding(dp(12), dp(11), dp(12), dp(11))
        left.addView(nameField, lp(MATCH, WRAP))
        left.addView(spacer(12))

        // The seed box has gone. It told you nothing about the man in the
        // dugout, and every one of these does: what the board thinks of you on
        // day one, how quickly a squad takes to your ideas, whether the
        // teenagers come through, and how the dressing room is spoken to.
        val prof = pendingProfile

        fun choice(title: String, options: List<String>, blurbs: List<String>,
                   current: () -> Int, onPick: (Int) -> Unit) {
            left.addView(text(title, 11f, Theme.MUTED, Theme.DISPLAY, 0.10f))
            left.addView(spacer(5))
            val rowV = LinearLayout(this)
            rowV.orientation = LinearLayout.HORIZONTAL
            for (i in options.indices) {
                val ch = chip(options[i], i == current())
                ch.setOnClickListener { onPick(i); showManagerSetup() }
                val cp = lp(WRAP, WRAP); cp.rightMargin = dp(5)
                rowV.addView(ch, cp)
            }
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(rowV, lp(WRAP, WRAP))
            left.addView(hs, lp(MATCH, WRAP))
            left.addView(text(blurbs[current()], 10.5f, Theme.FAINT))
            left.addView(spacer(11))
        }

        choice("AGE", ManagerAges.ALL.map { "${it.label} (${it.years.first}-${it.years.last})" },
            ManagerAges.ALL.map { it.blurb }, { prof.ageBand }) {
            prof.ageBand = it
            prof.age = ManagerAges.of(it).years.let { r -> (r.first + r.last) / 2 }
        }
        choice("HOW YOUR SIDES PLAY", ManagerSchools.ALL.map { it.label },
            ManagerSchools.ALL.map { it.blurb }, { prof.school }) { prof.school = it }
        choice("SQUAD BUILDING", ManagerPhilosophies.ALL.map { it.label },
            ManagerPhilosophies.ALL.map { it.blurb }, { prof.philosophy }) { prof.philosophy = it }
        choice("WITH THE PLAYERS", ManagerManners.ALL.map { it.label },
            ManagerManners.ALL.map { it.blurb }, { prof.manner }) { prof.manner = it }
        cols.addView(left, lp(0, WRAP, 1f))

        val gap = View(this); gap.layoutParams = lp(dp(16), 1)
        cols.addView(gap)

        val right = column()
        right.addView(text("NATIONALITY", 11f, Theme.MUTED, Theme.DISPLAY, 0.10f))
        right.addView(spacer(6))
        val natWrap = LinearLayout(this)
        natWrap.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        for (n in Names.NATIONS) {
            val c = chip("${n.flag} ${n.code}", n.code == managerNation)
            c.setOnClickListener {
                managerNation = n.code
                for (i in chips.indices) {
                    val on = Names.NATIONS[i].code == managerNation
                    chips[i].background = boxBg(
                        if (on) Theme.ACCENT else Theme.PANEL_HEAD,
                        if (on) Theme.ACCENT_DARK else Theme.BORDER, dp(3)
                    )
                    chips[i].setTextColor(if (on) 0xFFFFFFFF.toInt() else Theme.MUTED)
                }
            }
            chips.add(c)
            val p = lp(WRAP, WRAP); p.rightMargin = dp(6)
            natWrap.addView(c, p)
        }
        val hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false
        hs.addView(natWrap)
        right.addView(hs, lp(MATCH, WRAP))
        cols.addView(right, lp(0, WRAP, 1.4f))

        outer.addView(cols, lp(MATCH, WRAP))
        outer.addView(spacer(20))

        val next = actionButton("Choose a club", true)
        next.setOnClickListener {
            managerName = nameField.text.toString().trim().ifEmpty { "The Gaffer" }
            // the world is still seeded, just not by hand any more
            seedValue = System.nanoTime() and 0xFFFFFFL
            buildWorld()
        }
        val holder = row(); holder.addView(next)
        outer.addView(holder, lp(MATCH, WRAP))

        scroll.addView(outer, lp(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildWorld() {
        root.removeAllViews()
        val t = text("Building the world\u2026", 16f, Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER)
        root.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        t.post {
            val w = World.build(seedValue)
            // Faces are handed out once, in id order, so the assignment cannot
            // depend on which cards happen to get opened first. Doing it lazily
            // would give a different face to the same man in two playthroughs of
            // the same save.
            Face.assignAll(w.players.values)
            // carry the manager across before anything reads it
            w.profile.ageBand = pendingProfile.ageBand
            w.profile.age = pendingProfile.age
            w.profile.school = pendingProfile.school
            w.profile.philosophy = pendingProfile.philosophy
            w.profile.manner = pendingProfile.manner
            world = w
            season = Season(w)
            showClubSelect(2)
        }
    }

    /** Which nation the job list is currently showing. */
    private var pickCountry = "ENG"

    private fun countryLabel(code: String): String =
        if (code == "ENG") "England" else Names.byCode(code).label

    private fun showClubSelect(tier: Int) {
        val w = world ?: return
        root.removeAllViews()
        val outer = column(14)

        outer.addView(text("STEP 2 OF 2 \u00B7 TAKE A JOB", 11f, Theme.ACCENT, Theme.DISPLAY, 0.24f))
        outer.addView(spacer(8))

        // Country first, then the league inside it. Only the nation picked here
        // gets a full fixture list, so this choice is what makes a league
        // playable rather than just something to read the champion of.
        val nations = row()
        for (code in w.playableCountries()) {
            val ch = chip(countryLabel(code), code == pickCountry)
            ch.setOnClickListener {
                pickCountry = code
                showClubSelect(w.pyramidOf(code).firstOrNull()?.id ?: 0)
            }
            val np = lp(WRAP, WRAP); np.rightMargin = dp(6)
            nations.addView(ch, np)
        }
        val ns = HorizontalScrollView(this)
        ns.isHorizontalScrollBarEnabled = false
        ns.addView(nations, lp(WRAP, WRAP))
        outer.addView(ns, lp(MATCH, WRAP))
        outer.addView(spacer(8))

        val pyramid = w.pyramidOf(pickCountry)
        val shown = if (pyramid.any { it.id == tier }) tier else (pyramid.firstOrNull()?.id ?: 0)

        val tabs = row()
        for (d in pyramid) {
            val c = chip(d.name, d.id == shown)
            c.setOnClickListener { showClubSelect(d.id) }
            val p = lp(WRAP, WRAP); p.rightMargin = dp(6)
            tabs.addView(c, p)
        }
        val ts = HorizontalScrollView(this)
        ts.isHorizontalScrollBarEnabled = false
        ts.addView(tabs, lp(WRAP, WRAP))
        outer.addView(ts, lp(MATCH, WRAP))
        outer.addView(spacer(10))

        val list = column()
        val clubs = (w.division(shown)?.clubIds ?: emptyList()).mapNotNull { w.club(it) }
            .sortedByDescending { it.reputation }
        for (c in clubs) {
            val r = row()
            r.setPadding(dp(10), dp(9), dp(10), dp(9))
            r.background = boxBg(Theme.PANEL, Theme.BORDER_SOFT, dp(4))
            r.addView(crest(c, 32))
            val mid = column()
            mid.setPadding(dp(10), 0, dp(10), 0)
            mid.addView(text(c.name, 14.5f, Theme.TEXT, Theme.BODY_MED))
            mid.addView(text("${c.stadiumName} \u00B7 ${c.capacity} seats", 11f, Theme.MUTED))
            r.addView(mid, lp(0, WRAP, 1f))
            r.addView(stars(ratingToHalves(w.squadRating(c)), 13))
            val money = text(Fmt.money(c.balance), 12.5f, Theme.GOLD, Theme.DATA)
            money.setPadding(dp(12), 0, 0, 0)
            r.addView(money)
            r.isClickable = true
            r.setOnClickListener { takeJob(c) }
            val p = lp(MATCH, WRAP); p.bottomMargin = dp(6)
            list.addView(r, p)
        }

        val scroll = ScrollView(this)
        scroll.addView(list, lp(MATCH, WRAP))
        outer.addView(scroll, lp(MATCH, 0, 1f))
        root.addView(outer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun takeJob(c: Club) {
        val w = world ?: return
        val s = season ?: return
        // set before the career starts: start() builds the calendar, and the
        // calendar only covers the home pyramid plus this nation
        w.playerCountry = w.division(c.divisionId)?.country ?: "ENG"
        career = Career(w, s).also { it.start(c.id, managerName, managerNation) }
        screen = SCR_HUB
        tableDivision = c.divisionId
        autosave()
        renderShell()
    }

    /* ------------------------------------------------------------- SHELL */

    private fun renderShell() {
        world ?: return
        root.removeAllViews()

        val outer = row()
        outer.gravity = Gravity.TOP

        if (screen != SCR_MATCH) {
            rail = buildRail()
            outer.addView(rail, lp(dp(52), MATCH))
        }

        val right = column()
        // During a match the pitch owns the screen: no top bar, so the
        // Continue button cannot restart the game that is already running.
        if (screen != SCR_MATCH) {
            topBar = buildTopBar()
            right.addView(topBar, lp(MATCH, WRAP))
        }

        stage = FrameLayout(this)
        right.addView(stage, lp(MATCH, 0, 1f))
        outer.addView(right, lp(0, MATCH, 1f))

        root.addView(outer, FrameLayout.LayoutParams(MATCH, MATCH))
        renderScreen()
    }

    private fun buildRail(): LinearLayout {
        val nav = column()
        nav.setBackgroundColor(0xFF171932.toInt())
        nav.gravity = Gravity.CENTER_HORIZONTAL
        nav.setPadding(0, dp(6), 0, dp(6))

        val items = arrayOf(
            Triple(SCR_INBOX, Icon.INBOX, "Inbox"),
            Triple(SCR_HUB, Icon.HUB, "Hub"),
            Triple(SCR_SQUAD, Icon.SQUAD, "Squad"),
            Triple(SCR_TACTICS, Icon.TACTICS, "Tactics"),
            Triple(SCR_TRAINING, Icon.TRAINING, "Train"),
            Triple(SCR_MARKET, Icon.TRANSFERS, "Market"),
            Triple(SCR_TABLE, Icon.TABLE, "Table"),
            Triple(SCR_WORLD, Icon.WORLD, "World"),
            Triple(SCR_CLUB, Icon.CLUB, "Club")
        )
        for ((id, glyph, name) in items) {
            val on = screen == id || (screen == SCR_PLAYER && id == SCR_SQUAD)
            val cell = column()
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(3), dp(7), dp(3), dp(7))
            if (on) cell.background = boxBg(Theme.HILITE, 0, dp(5))
            val tint = if (on) 0xFFFFFFFF.toInt() else Theme.FAINT
            val ic = icon(glyph, 21, tint)
            val holder = row(); holder.gravity = Gravity.CENTER
            holder.addView(ic)
            cell.addView(holder, lp(MATCH, WRAP))
            cell.addView(
                text(name, 7.5f, tint, Theme.DISPLAY, 0.04f, Gravity.CENTER),
                lp(MATCH, WRAP).also { it.topMargin = dp(2) }
            )
            cell.isClickable = true
            cell.setOnClickListener { screen = id; renderShell() }
            val p = lp(dp(48), WRAP); p.bottomMargin = dp(3)
            nav.addView(cell, p)
        }
        return nav
    }

    private fun buildTopBar(): LinearLayout {
        val w = world!!
        val car = career!!
        val c = w.userClub!!
        val bar = row()
        bar.setBackgroundColor(0xFF191B33.toInt())
        bar.setPadding(dp(10), dp(7), dp(10), dp(7))

        bar.addView(crest(c, 30))
        val title = column()
        title.setPadding(dp(9), 0, dp(9), 0)
        title.addView(text(c.name, 15f, Theme.TEXT, Theme.DISPLAY, 0.02f))
        title.addView(text(screenTitle(), 10.5f, Theme.MUTED, Theme.BODY, 0.04f))
        bar.addView(title, lp(0, WRAP, 1f))

        val unread = car.unread
        if (unread > 0) {
            val badge = tag("$unread NEW", Theme.HILITE, 0xFFFFFFFF.toInt())
            val p = lp(WRAP, WRAP); p.rightMargin = dp(10)
            bar.addView(badge, p)
        }

        val date = column()
        date.gravity = Gravity.END
        date.addView(text("SEASON ${w.season}", 10f, Theme.MUTED, Theme.DISPLAY, 0.10f, Gravity.END), lp(WRAP, WRAP))
        date.addView(text("WEEK ${minOf(w.week, 38)}", 13f, Theme.TEXT, Theme.DISPLAY, 0.06f, Gravity.END), lp(WRAP, WRAP))
        bar.addView(date)

        val money = text(Fmt.money(c.balance), 12.5f, Theme.GOLD, Theme.DATA)
        money.setPadding(dp(14), 0, dp(14), 0)
        bar.addView(money)

        val cont = actionButton(
            if (career!!.onMatchDay) "Play match" else "Continue \u00B7 ${career!!.dayLabel()}"
        )
        cont.setOnClickListener { onContinue() }
        bar.addView(cont)
        return bar
    }

    private fun screenTitle(): String = when (screen) {
        SCR_SQUAD -> "Squad"
        SCR_TACTICS -> "Tactics"
        SCR_TABLE -> "League Table"
        SCR_CLUB -> "Club Overview"
        SCR_TRAINING -> "Training and Academy"
        SCR_WORLD -> "Around the World"
        SCR_MARKET -> "Transfer Market"
        SCR_SCOUT -> "Scouting"
        SCR_STAFF -> "Backroom Staff"
        SCR_INBOX -> "Inbox"
        SCR_PLAYER -> "Player Profile"
        else -> "Pre-Match Hub"
    }

    private fun renderScreen() {
        stage.removeAllViews()
        if (screen == SCR_MATCH) { stage.addView(buildMatchScreen(), FrameLayout.LayoutParams(MATCH, MATCH)); return }
        // a completed signing takes precedence: it is shown once, then cleared
        career?.lastSigning?.let { showSigningVerdict(it); return }

        val body = when (screen) {
            SCR_SQUAD -> screenSquad()
            SCR_TACTICS -> screenTactics()
            SCR_TABLE -> screenTable()
            SCR_CLUB -> screenClub()
            SCR_TRAINING -> screenTraining()
            SCR_WORLD -> screenWorld()
            SCR_MARKET -> screenMarket()
            SCR_SCOUT -> screenScout()
            SCR_STAFF -> screenStaff()
            SCR_INBOX -> screenInbox()
            SCR_PLAYER -> screenPlayer()
            else -> screenHub()
        }
        stage.addView(body, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Two panels side by side, the standard layout of every screen here. */
    private fun twoColumn(left: View, right: View, leftWeight: Float = 1f, rightWeight: Float = 1f): View {
        val r = row()
        r.gravity = Gravity.TOP
        r.setPadding(dp(10), dp(10), dp(10), dp(10))
        r.addView(left, lp(0, WRAP, leftWeight))
        val gap = View(this); gap.layoutParams = lp(dp(10), 1)
        r.addView(gap)
        r.addView(right, lp(0, WRAP, rightWeight))
        val s = ScrollView(this)
        s.addView(r, lp(MATCH, WRAP))
        return s
    }

    /* --------------------------------------------------------- PRE-MATCH */

    private fun screenHub(): View {
        val w = world!!
        val s = season!!
        val car = career!!
        val c = w.userClub!!
        val fx = s.nextUserFixture()

        if (fx == null) {
            val p = panel("Season complete")
            p.add(text("The season is over. Continue to begin the next one.", 13f, Theme.MUTED).also {
                it.setPadding(dp(12), dp(14), dp(12), dp(14))
            })
            val holder = column(12); holder.addView(p, lp(MATCH, WRAP))
            val sc = ScrollView(this); sc.addView(holder, lp(MATCH, WRAP))
            return sc
        }

        val home = fx.homeId == c.id
        val opp = w.club(if (home) fx.awayId else fx.homeId)!!
        val compName = when (fx.comp) {
            Comp.CUP -> s.cup.name
            Comp.CONTI -> s.conti.name
            else -> w.division(c.divisionId)?.name ?: "League"
        }

        /* ---- left column ---- */
        val leftCol = column()

        // The press room sits above the fixture, because it is something the
        // manager has to deal with before he gets to Saturday.
        car.press.firstOrNull { !it.answered }?.let { q ->
            val pp = panel("Press conference")
            pp.add(text(q.from.uppercase(), 10f, Theme.ACCENT, Theme.DISPLAY, 0.18f).also {
                it.setPadding(dp(12), dp(11), dp(12), dp(2))
            })
            pp.add(text(q.text, 13.5f, Theme.TEXT, Theme.BODY_MED).also {
                it.setPadding(dp(12), dp(2), dp(12), dp(10))
            })
            for (opt in q.options) {
                val b = row()
                b.setPadding(dp(12), dp(10), dp(12), dp(10))
                b.background = boxBg(Theme.PANEL, Theme.BORDER_SOFT, dp(4))
                b.addView(text(opt.text, 12.5f, Theme.TEXT), lp(0, WRAP, 1f))
                b.isClickable = true
                b.setOnClickListener {
                    car.answerPress(q, opt)
                    autosave()
                    renderShell()
                }
                pp.add(b)
            }
            leftCol.addView(pp, lp(MATCH, WRAP))
            leftCol.addView(spacer(10))
        }

        val fixturePanel = panel(compName)
        val vs = row()
        vs.setPadding(dp(8), dp(12), dp(8), dp(10))

        fun sideBlock(club: Club): LinearLayout {
            val col = column()
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.addView(crest(club, 44))
            col.addView(spacer(4))
            col.addView(text(club.name, 13.5f, Theme.TEXT, Theme.BODY_MED, 0f, Gravity.CENTER), lp(MATCH, WRAP))
            val st = stars(ratingToHalves(w.squadRating(club)), 13)
            val holder = row(); holder.gravity = Gravity.CENTER
            holder.addView(st)
            col.addView(holder, lp(MATCH, WRAP))
            col.addView(spacer(4))
            val fh = row(); fh.gravity = Gravity.CENTER
            fh.addView(formRow(club.form, 17))
            col.addView(fh, lp(MATCH, WRAP))
            return col
        }

        vs.addView(sideBlock(if (home) c else opp), lp(0, WRAP, 1f))
        vs.addView(text("VS", 13f, Theme.MUTED, Theme.DISPLAY, 0.10f, Gravity.CENTER), lp(dp(44), WRAP))
        vs.addView(sideBlock(if (home) opp else c), lp(0, WRAP, 1f))
        fixturePanel.add(vs)
        fixturePanel.add(hairline())

        val venue = row()
        venue.setPadding(dp(10), dp(8), dp(10), dp(8))
        venue.addView(text((if (home) c else opp).stadiumName, 12.5f, Theme.TEXT), lp(0, WRAP, 1f))
        venue.addView(text(if (home) "HOME" else "AWAY", 11f, Theme.GOLD, Theme.DISPLAY, 0.10f))
        fixturePanel.add(venue)
        leftCol.addView(fixturePanel, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val tacticsPanel = panel("Match tactics")
        val t = c.tactics
        val tr = row()
        tr.setPadding(dp(10), dp(10), dp(10), dp(10))
        val styleCol = column()
        styleCol.addView(text("STYLE", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
        styleCol.addView(text(Instr.MENTALITY[t.mentality], 14f, Theme.TEXT, Theme.BODY_MED))
        tr.addView(styleCol, lp(0, WRAP, 1f))
        val formCol = column()
        formCol.gravity = Gravity.END
        formCol.addView(text("FORMATION", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f, Gravity.END), lp(WRAP, WRAP))
        formCol.addView(text(t.formation, 14f, Theme.TEXT, Theme.BODY_MED, 0f, Gravity.END), lp(WRAP, WRAP))
        tr.addView(formCol)
        tacticsPanel.add(tr)
        tacticsPanel.add(hairline())
        tacticsPanel.add(kv("Tempo", Instr.TEMPO[t.tempo]))
        tacticsPanel.add(kv("Passing", Instr.PASSING[t.passing]))
        tacticsPanel.add(kv("Pressing", Instr.PRESS[t.press]))
        tacticsPanel.add(kv("Defensive line", Instr.LINE[t.line]))

        val editRow = row()
        editRow.setPadding(dp(10), dp(4), dp(10), dp(10))
        val edit = subtleButton("Change tactics")
        edit.setOnClickListener { screen = SCR_TACTICS; renderShell() }
        editRow.addView(edit, lp(0, WRAP, 1f))
        tacticsPanel.add(editRow)
        leftCol.addView(tacticsPanel, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val objPanel = panel("Board confidence \u00B7 ${c.boardConfidence}%")
        for (o in car.refreshObjectives()) {
            objPanel.add(
                kv(
                    (if (o.met) "\u2714  " else "\u25CB  ") + o.label, o.detail,
                    if (o.met) Theme.GREEN else Theme.MUTED
                )
            )
        }
        leftCol.addView(objPanel, lp(MATCH, WRAP))

        /* ---- right column ---- */
        val rightCol = column()

        val oppPanel = panel(opp.name)
        val oppRow = row()
        oppRow.setPadding(dp(10), dp(10), dp(10), dp(6))
        val oppInfo = column()
        oppInfo.addView(text("STYLE", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
        oppInfo.addView(text(Instr.MENTALITY[opp.tactics.mentality], 13.5f, Theme.TEXT, Theme.BODY_MED))
        oppInfo.addView(spacer(8))
        oppInfo.addView(text("FORMATION", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
        oppInfo.addView(text(opp.tactics.formation, 13.5f, Theme.TEXT, Theme.BODY_MED))
        oppInfo.addView(spacer(8))
        oppInfo.addView(text("KEY PLAYER", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
        val key = w.squadOf(opp).maxByOrNull { it.overall() }
        oppInfo.addView(text(key?.full ?: "\u2014", 13.5f, Theme.TEXT, Theme.BODY_MED))
        if (key != null) {
            oppInfo.addView(text("${Pos.name(key.pos)} \u00B7 ${key.overall()} rated", 11f, Theme.MUTED))
        }
        oppRow.addView(oppInfo, lp(0, WRAP, 1f))
        oppRow.addView(pitch(opp.tactics.formation, 128, 168))
        oppPanel.add(oppRow)
        rightCol.addView(oppPanel, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val swPanel = panel("Strengths and weaknesses")
        val sw = row()
        sw.setPadding(dp(10), dp(8), dp(10), dp(10))
        sw.gravity = Gravity.TOP

        val strengths = analyseSquad(opp, true)
        val weaknesses = analyseSquad(opp, false)

        val sCol = column()
        sCol.addView(text("STRENGTHS", 10f, Theme.GREEN, Theme.DISPLAY, 0.10f))
        sCol.addView(spacer(4))
        for (item in strengths) sCol.addView(text("\u25B8  $item", 12.5f, Theme.TEXT).also { it.setPadding(0, dp(3), 0, dp(3)) })
        sw.addView(sCol, lp(0, WRAP, 1f))

        val wCol = column()
        wCol.addView(text("WEAKNESSES", 10f, Theme.RED, Theme.DISPLAY, 0.10f))
        wCol.addView(spacer(4))
        for (item in weaknesses) wCol.addView(text("\u25B8  $item", 12.5f, Theme.TEXT).also { it.setPadding(0, dp(3), 0, dp(3)) })
        sw.addView(wCol, lp(0, WRAP, 1f))
        swPanel.add(sw)
        rightCol.addView(swPanel, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val verdictPanel = panel("The word from the press box")
        val verdict = text(buildVerdict(c, opp, home, w), 12.5f, Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER)
        verdict.setPadding(dp(12), dp(12), dp(12), dp(12))
        verdictPanel.add(verdict)

        val playRow = row()
        playRow.setPadding(dp(10), dp(2), dp(10), dp(10))
        val play = actionButton("Play the match", true)
        play.setOnClickListener { playNextMatch() }
        playRow.addView(play, lp(0, WRAP, 1f))
        verdictPanel.add(playRow)
        rightCol.addView(verdictPanel, lp(MATCH, WRAP))

        return twoColumn(leftCol, rightCol, 1f, 1f)
    }

    /** Reads a squad and names the three things it does best or worst. */
    private fun analyseSquad(c: Club, best: Boolean): List<String> {
        val w = world!!
        val xi = c.tactics.lineup.map { w.player(it) }.filterNotNull()
        if (xi.isEmpty()) return listOf("Unknown")
        val checks = arrayOf(
            Pair("Pace", Att.PAC), Pair("Finishing", Att.FIN), Pair("Creativity", Att.VIS),
            Pair("Passing", Att.PAS), Pair("Tackling", Att.TAC), Pair("Marking", Att.MAR),
            Pair("Strength", Att.STR), Pair("Stamina", Att.STA), Pair("Composure", Att.COM)
        )
        val scored = ArrayList<Pair<String, Int>>(checks.size)
        for (chk in checks) {
            var total = 0
            for (pl in xi) total += pl.att[chk.second]
            scored.add(Pair(chk.first, total / xi.size))
        }
        val sorted = if (best) scored.sortedByDescending { it.second } else scored.sortedBy { it.second }
        val out = sorted.take(2).map { it.first }.toMutableList()
        val injured = w.squadOf(c).count { it.injured }
        if (!best && injured >= 3) out.add("Injuries") else if (!best) out.add("Recent form")
        if (best) out.add(if (c.morale > 70) "Team morale" else "Experience")
        return out
    }

    private fun buildVerdict(me: Club, opp: Club, home: Boolean, w: World): String {
        val mine = w.squadRating(me)
        val theirs = w.squadRating(opp)
        val diff = mine - theirs + (if (home) 3 else 0)
        return when {
            diff >= 8 -> "\u201C${me.name} should have far too much for ${opp.name} here.\u201D"
            diff >= 3 -> "\u201C${if (home) "Home advantage gives" else "Form gives"} ${me.name} a slight edge over ${opp.name}.\u201D"
            diff >= -2 -> "\u201CThere is very little between these two sides.\u201D"
            diff >= -7 -> "\u201C${opp.name} start as the favourites, but it is far from settled.\u201D"
            else -> "\u201C${me.name} will need something special to get anything from this one.\u201D"
        }
    }

    /* ------------------------------------------------------------- SQUAD */

    private fun screenSquad(): View {
        val w = world!!
        val c = w.userClub!!
        val car = career!!
        val outer = column(10)

        // The dressing room, before the list of players. Who carries weight in
        // that group is worth knowing before you sell one of them.
        val squadAll = c.squad.mapNotNull { w.player(it) }
        if (squadAll.isNotEmpty()) {
            val avg = car.squadAverage(c)
            val mood = DressingRoom.roomMood(squadAll, avg, c.tactics.captain)
            val leaders = squadAll
                .sortedByDescending { DressingRoom.influence(it, avg, c.tactics.captain) }
                .take(3)
            val room = panel("The dressing room")
            room.add(kv("Mood", String.format("%.0f", mood),
                if (mood >= 65) Theme.GREEN else if (mood >= 45) Theme.GOLD else Theme.RED))
            for (p in leaders) {
                val inf = DressingRoom.influence(p, avg, c.tactics.captain)
                val st = DressingRoom.standingOf(inf)
                val rowV = row()
                rowV.setPadding(dp(10), dp(6), dp(10), dp(6))
                val col = column()
                col.addView(playerName(p, 12f), lp(MATCH, WRAP))
                col.addView(text(Standing.NOTE[st], 10f, Theme.FAINT), lp(MATCH, WRAP))
                rowV.addView(col, lp(0, WRAP, 1f))
                rowV.addView(text(Standing.LABEL[st], 10.5f,
                    if (st <= 1) Theme.GOLD else Theme.MUTED, Theme.DISPLAY, 0f, Gravity.CENTER),
                    lp(dp(92), WRAP))
                rowV.addView(text(
                    String.format("%.0f", p.morale), 12f,
                    if (p.morale >= 60) Theme.GREEN else if (p.morale >= 40) Theme.GOLD else Theme.RED,
                    Theme.DATA, 0f, Gravity.CENTER), lp(dp(40), WRAP))
                room.add(rowV)
            }
            val suggested = DressingRoom.suggestedCaptain(squadAll, avg)
            if (suggested != null && suggested.id != c.tactics.captain) {
                room.add(text(
                    "${suggested.last} carries more weight in that group than your captain does.",
                    10.5f, Theme.HILITE
                ).also { it.setPadding(dp(10), dp(2), dp(10), dp(10)) })
            }
            outer.addView(room, lp(MATCH, WRAP))
            outer.addView(spacer(10))
        }

        val filters = row()
        val groups = arrayOf("All" to -1, "Goalkeepers" to 0, "Defence" to 1, "Midfield" to 2, "Attack" to 3)
        for ((lbl, g) in groups) {
            val ch = chip(lbl, squadFilter == g)
            ch.setOnClickListener { squadFilter = g; renderScreen() }
            val p = lp(WRAP, WRAP); p.rightMargin = dp(6)
            filters.addView(ch, p)
        }
        val bill = w.wageBill(c)
        filters.addView(View(this), lp(0, 1, 1f))
        filters.addView(text("WAGES ${Fmt.wage(bill)} / ${Fmt.wage(c.wageBudget)}", 11f,
            if (bill > c.wageBudget) Theme.RED else Theme.MUTED, Theme.DISPLAY, 0.06f))
        outer.addView(filters, lp(MATCH, WRAP))
        outer.addView(spacer(8))

        val p = panel("Squad \u00B7 ${c.squad.size} players")

        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(6), dp(8), dp(6))
        fun h(s: String, weight: Float, width: Int = 0, align: Int = Gravity.START) {
            val v = text(s.uppercase(), 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, align)
            head.addView(v, if (weight > 0f) lp(0, WRAP, weight) else lp(dp(width), WRAP))
        }
        h("Pos", 0f, 38); h("Name", 1.6f); h("Age", 0f, 34, Gravity.CENTER)
        h("Nat", 0f, 40, Gravity.CENTER); h("Role", 1f)
        h("Fit", 0f, 42, Gravity.CENTER); h("Mor", 0f, 62, Gravity.CENTER)
        h("Apps", 0f, 42, Gravity.CENTER); h("Gls", 0f, 36, Gravity.CENTER)
        h("Avg", 0f, 44, Gravity.CENTER); h("Value", 0f, 66, Gravity.END)
        h("Ovr", 0f, 40, Gravity.CENTER)
        p.add(head)

        var players = w.squadOf(c)
        if (squadFilter >= 0) players = players.filter { Pos.group(it.pos) == squadFilter }
        players = players.sortedWith(compareBy({ Pos.group(it.pos) }, { -it.overall() }))

        var alt = false
        for (pl in players) {
            p.add(squadRow(pl, alt)); alt = !alt
        }

        val sc = ScrollView(this)
        val holder = column()
        holder.addView(p, lp(MATCH, WRAP))
        sc.addView(holder, lp(MATCH, WRAP))
        outer.addView(sc, lp(MATCH, 0, 1f))
        return outer
    }

    private fun squadRow(pl: Player, alt: Boolean): View {
        val r = row()
        r.setPadding(dp(8), dp(4), dp(8), dp(4))
        // a thumbnail of the same generated portrait as his profile card
        val thumb = FaceView(this, pl)
        val tp = lp(dp(26), dp(26))
        tp.rightMargin = dp(6)
        r.addView(thumb, tp)
        if (alt) r.setBackgroundColor(Theme.PANEL_ALT)

        fun cell(v: View, weight: Float, width: Int = 0) {
            r.addView(v, if (weight > 0f) lp(0, WRAP, weight) else lp(dp(width), WRAP))
        }

        cell(posTag(pl.pos), 0f, 38)

        val nameCol = column()
        val nm = row()
        nm.addView(playerName(pl, 13f, Theme.TEXT, Theme.BODY_MED))
        if (pl.hasTrait(Traits.WONDERKID)) nm.addView(text("  \u2726", 11f, Theme.GOLD))
        if (pl.injured) nm.addView(text("  \u2695", 11f, Theme.RED))
        if (pl.suspended > 0) nm.addView(text("  \u25A0", 11f, Theme.RED))
        nameCol.addView(nm, lp(WRAP, WRAP))
        cell(nameCol, 1.6f)

        cell(text(pl.age.toString(), 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 34)
        cell(text(Names.byCode(pl.nation).flag, 12f, Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER), 0f, 40)
        cell(text(pl.role, 11.5f, Theme.MUTED), 1f)

        val fitColor = when {
            pl.fitness > 85 -> Theme.GREEN; pl.fitness > 65 -> Theme.AMBER; else -> Theme.RED
        }
        cell(text("${pl.fitness.toInt()}%", 12f, fitColor, Theme.DATA, 0f, Gravity.CENTER), 0f, 42)

        val morColor = when {
            pl.morale > 70 -> Theme.GREEN; pl.morale > 45 -> Theme.AMBER; else -> Theme.RED
        }
        cell(text(pl.moraleLabel(), 10.5f, morColor, Theme.BODY, 0f, Gravity.CENTER), 0f, 62)

        cell(text(pl.apps.toString(), 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 42)
        cell(text(pl.goals.toString(), 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 36)
        cell(
            text(if (pl.ratingN > 0) Fmt.rating(pl.avgRating) else "\u2014", 12f,
                if (pl.ratingN > 0 && pl.avgRating >= 7.0) Theme.GREEN else Theme.MUTED,
                Theme.DATA, 0f, Gravity.CENTER), 0f, 44
        )
        cell(text(Fmt.money(pl.value()), 11.5f, Theme.GOLD, Theme.DATA, 0f, Gravity.END), 0f, 66)

        val o = pl.overall()
        cell(tag(o.toString(), Theme.ratingColor(o), 0xFF14162B.toInt()), 0f, 40)

        r.isClickable = true
        r.setOnClickListener { selectedPlayer = pl.id; screen = SCR_PLAYER; renderShell() }
        return r
    }

    /* ------------------------------------------------------------ PLAYER */

    /**
     * A player's name, tappable, opening his card. Everywhere a name is shown —
     * scout reports, the transfer wire, the dressing room, match ratings — it
     * should be a way into his profile rather than just text.
     */
    private fun playerName(
        p: Player, size: Float = 12.5f, colour: Int = Theme.TEXT,
        face: Typeface = Theme.BODY_MED
    ): View {
        val t = text(p.full, size, colour, face)
        t.isClickable = true
        t.setOnClickListener {
            selectedPlayer = p.id
            screen = SCR_PLAYER
            renderShell()
        }
        return t
    }

    private fun screenPlayer(): View {
        val w = world!!
        val pl = w.player(selectedPlayer) ?: return screenSquad()

        val leftCol = column()

        val head = panel(pl.full)
        val hr = row()
        hr.setPadding(dp(10), dp(10), dp(10), dp(10))

        // A generated portrait. Nothing is stored: the face comes from his id,
        // his nation and his age, so it is the same every time you open the card
        // and it changes as he gets older.
        val portrait = FaceView(this, pl)
        portrait.background = boxBg(Theme.PANEL_ALT, Theme.BORDER_SOFT, dp(4))
        val pp = lp(dp(76), dp(76))
        pp.rightMargin = dp(10)
        hr.addView(portrait, pp)

        val info = column()
        val nat = Names.byCode(pl.nation)
        info.addView(text("${nat.flag}  ${nat.label}", 12.5f, Theme.MUTED))
        info.addView(text("${pl.age} years old", 12.5f, Theme.MUTED))
        info.addView(spacer(6))
        val tags = row()
        tags.addView(posTag(pl.pos))
        if (pl.altPos >= 0) {
            val alt = posTag(pl.altPos); alt.alpha = 0.6f
            val p2 = lp(WRAP, WRAP); p2.leftMargin = dp(4)
            tags.addView(alt, p2)
        }
        info.addView(tags, lp(WRAP, WRAP))
        info.addView(spacer(6))
        info.addView(text(pl.role, 13f, Theme.TEXT, Theme.BODY_MED))
        info.addView(text(pl.personality, 11.5f, Theme.MUTED))
        hr.addView(info, lp(0, WRAP, 1f))

        val ovrCol = column()
        ovrCol.gravity = Gravity.CENTER_HORIZONTAL
        val o = pl.overall()
        ovrCol.addView(text(o.toString(), 34f, Theme.ratingColor(o), Theme.DATA, 0f, Gravity.CENTER), lp(WRAP, WRAP))
        ovrCol.addView(text("CURRENT", 9f, Theme.FAINT, Theme.DISPLAY, 0.10f, Gravity.CENTER), lp(WRAP, WRAP))
        ovrCol.addView(spacer(6))
        ovrCol.addView(text(pl.potential.toString(), 20f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), lp(WRAP, WRAP))
        ovrCol.addView(text("POTENTIAL", 9f, Theme.FAINT, Theme.DISPLAY, 0.10f, Gravity.CENTER), lp(WRAP, WRAP))
        hr.addView(ovrCol)
        head.add(hr)

        if (pl.traits.isNotEmpty()) {
            head.add(hairline())
            val tr = column()
            tr.setPadding(dp(10), dp(8), dp(10), dp(8))
            for (t in pl.traits) {
                val trait = Traits.get(t)
                tr.addView(text("${trait.icon}  ${trait.label} \u2014 ${trait.desc}", 12f, Theme.MUTED))
            }
            head.add(tr)
        }
        leftCol.addView(head, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val cond = panel("Condition and contract")
        cond.add(kv("Fitness", "${pl.fitness.toInt()}%",
            if (pl.fitness > 85) Theme.GREEN else if (pl.fitness > 65) Theme.AMBER else Theme.RED))
        cond.add(kv("Match sharpness", "${pl.sharpness.toInt()}%"))
        cond.add(kv("Morale", pl.moraleLabel()))
        cond.add(kv("Form", Fmt.rating(pl.form)))
        if (pl.injured) cond.add(kv("Injury", "${pl.injuryType} \u00B7 ${pl.injuryWeeks}w", Theme.RED))
        cond.add(hairline())
        cond.add(kv("Value", Fmt.money(pl.value()), Theme.GOLD))
        cond.add(kv("Wage", Fmt.wage(pl.wage)))
        cond.add(kv("Contract", "${pl.contractYears} years remaining"))
        cond.add(kv("Squad status", pl.statusLabel()))
        if (pl.clubId == w.userClubId) {
            val act = row()
            act.setPadding(dp(10), dp(8), dp(10), dp(10))
            val renew = actionButton("New contract")
            renew.setOnClickListener { renewDialog(pl) }
            act.addView(renew, lp(0, WRAP, 1f).also { it.rightMargin = dp(6) })
            val sell = subtleButton("Sell")
            sell.setOnClickListener { sellDialog(pl) }
            act.addView(sell)
            cond.add(act)
        } else {
            val act = row()
            act.setPadding(dp(10), dp(8), dp(10), dp(10))
            val bid = actionButton("Make an offer")
            bid.setOnClickListener { bidDialog(pl) }
            act.addView(bid, lp(0, WRAP, 1f))
            cond.add(act)
        }
        leftCol.addView(cond, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val season = panel("This season")
        val statRow = row()
        statRow.setPadding(dp(8), dp(10), dp(8), dp(10))
        statRow.addView(stat("Apps", pl.apps.toString()), lp(0, WRAP, 1f))
        statRow.addView(stat("Goals", pl.goals.toString(), Theme.GOLD), lp(0, WRAP, 1f))
        statRow.addView(stat("Assists", pl.assists.toString()), lp(0, WRAP, 1f))
        statRow.addView(
            stat("Avg", if (pl.ratingN > 0) Fmt.rating(pl.avgRating) else "\u2014",
                if (pl.ratingN > 0 && pl.avgRating >= 7.0) Theme.GREEN else Theme.TEXT), lp(0, WRAP, 1f)
        )
        season.add(statRow)
        leftCol.addView(season, lp(MATCH, WRAP))

        /* attributes on the right */
        val rightCol = column()
        rightCol.addView(attributePanel("Technical", Att.TECHNICAL, pl), lp(MATCH, WRAP))
        rightCol.addView(spacer(10))
        rightCol.addView(attributePanel("Mental", Att.MENTAL, pl), lp(MATCH, WRAP))
        rightCol.addView(spacer(10))
        rightCol.addView(attributePanel("Physical", Att.PHYSICAL, pl), lp(MATCH, WRAP))
        if (pl.pos == Pos.GK) {
            rightCol.addView(spacer(10))
            rightCol.addView(attributePanel("Goalkeeping", Att.KEEPING, pl), lp(MATCH, WRAP))
        }

        if (pl.seasons.isNotEmpty()) {
            rightCol.addView(spacer(10))
            val hist = panel("Career history")
            val hh = row()
            hh.setBackgroundColor(Theme.PANEL_ALT)
            hh.setPadding(dp(8), dp(5), dp(8), dp(5))
            for ((lbl, wgt) in listOf("Season" to 0.7f, "Club" to 1.4f, "Apps" to 0.6f, "Gls" to 0.5f, "Ast" to 0.5f, "Avg" to 0.6f)) {
                hh.addView(text(lbl.uppercase(), 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, wgt))
            }
            hist.add(hh)
            for (sl in pl.seasons.reversed().take(8)) {
                val r = row()
                r.setPadding(dp(8), dp(5), dp(8), dp(5))
                r.addView(text("S${sl.season}", 11.5f, Theme.MUTED, Theme.DATA), lp(0, WRAP, 0.7f))
                r.addView(text(sl.club, 11.5f, Theme.TEXT), lp(0, WRAP, 1.4f))
                r.addView(text(sl.apps.toString(), 11.5f, Theme.MUTED, Theme.DATA), lp(0, WRAP, 0.6f))
                r.addView(text(sl.goals.toString(), 11.5f, Theme.MUTED, Theme.DATA), lp(0, WRAP, 0.5f))
                r.addView(text(sl.assists.toString(), 11.5f, Theme.MUTED, Theme.DATA), lp(0, WRAP, 0.5f))
                r.addView(text(if (sl.avg > 0) Fmt.rating(sl.avg) else "\u2014", 11.5f, Theme.MUTED, Theme.DATA), lp(0, WRAP, 0.6f))
                hist.add(r)
            }
            rightCol.addView(hist, lp(MATCH, WRAP))
        }

        return twoColumn(leftCol, rightCol, 1f, 1.15f)
    }

    private fun attributePanel(title: String, attrs: IntArray, pl: Player): View {
        val p = panel(title)
        for (a in attrs) {
            val r = row()
            r.setPadding(dp(10), dp(5), dp(10), dp(5))
            val key = Weights.isKey(pl.pos, a)
            r.addView(
                text(Att.NAMES[a], 12.5f, if (key) Theme.TEXT else Theme.MUTED,
                    if (key) Theme.BODY_MED else Theme.BODY), lp(0, WRAP, 1f)
            )
            val v = pl.att[a]
            val bar = BarView(this, v)
            bar.layoutParams = lp(dp(90), dp(6))
            r.addView(bar)
            val num = text(v.toString(), 12.5f, Theme.ratingColor(v), Theme.DATA, 0f, Gravity.END)
            num.setPadding(dp(10), 0, 0, 0)
            num.minWidth = dp(30)
            r.addView(num)
            p.add(r)
        }
        return p
    }

    /* ----------------------------------------------------------- TACTICS */

    private fun screenTactics(): View {
        val w = world!!
        val c = w.userClub!!
        val t = c.tactics

        val leftCol = column()
        val shapePanel = panel("Formation \u00B7 ${t.formation}")
        val pv = pitch(t.formation, 240, 320)
        val holder = row(); holder.gravity = Gravity.CENTER
        holder.setPadding(0, dp(10), 0, dp(10))
        holder.addView(pv)
        shapePanel.add(holder)

        val tr = w.teamRating(c, true)
        val ratings = row()
        ratings.setPadding(dp(8), dp(4), dp(8), dp(12))
        ratings.addView(stat("Attack", tr.attack.toInt().toString(), Theme.RED), lp(0, WRAP, 1f))
        ratings.addView(stat("Control", tr.control.toInt().toString(), Theme.GOLD), lp(0, WRAP, 1f))
        ratings.addView(stat("Defence", tr.defence.toInt().toString(), Theme.BLUE), lp(0, WRAP, 1f))
        shapePanel.add(ratings)

        // How well the players know this shape, and how the numbers compare
        // with whoever is next. Without this the fourteen controls above are
        // guesswork: you cannot see what any of them bought you.
        val famPct = t.familiarity.toInt().coerceIn(0, 100)
        val famWord = when {
            famPct >= 90 -> "Fluid"
            famPct >= 72 -> "Settled"
            famPct >= 50 -> "Working on it"
            famPct >= 30 -> "Unfamiliar"
            else -> "Lost with it"
        }
        val famRow = row()
        famRow.setPadding(dp(10), dp(2), dp(10), dp(4))
        famRow.addView(text("SQUAD KNOWS THIS SHAPE", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.16f),
            lp(0, WRAP, 1f))
        famRow.addView(text("$famWord \u00B7 $famPct%", 11f,
            if (famPct >= 72) Theme.GREEN else if (famPct >= 45) Theme.GOLD else Theme.RED,
            Theme.DISPLAY))
        shapePanel.add(famRow)
        val famBar = View(this)
        famBar.background = boxBg(
            if (famPct >= 72) Theme.GREEN else if (famPct >= 45) Theme.GOLD else Theme.RED, 0, dp(2))
        val fbHolder = row()
        fbHolder.setPadding(dp(10), 0, dp(10), dp(10))
        val track = View(this)
        track.background = boxBg(Theme.HILITE, 0, dp(2))
        fbHolder.addView(famBar, lp(0, dp(4), famPct.toFloat().coerceAtLeast(1f)))
        fbHolder.addView(track, lp(0, dp(4), (100 - famPct).toFloat().coerceAtLeast(0.001f)))
        shapePanel.add(fbHolder)

        // next opponent, side by side
        season?.nextUserFixture()?.let { fx ->
            val oppId = if (fx.homeId == c.id) fx.awayId else fx.homeId
            w.club(oppId)?.let { opp ->
                val or = w.teamRating(opp, fx.homeId == opp.id)
                val cmp = row()
                cmp.setPadding(dp(10), dp(2), dp(10), dp(10))
                fun diff(mine: Double, theirs: Double, label: String): LinearLayout {
                    val d = (mine - theirs).toInt()
                    val col = if (d > 1) Theme.GREEN else if (d < -1) Theme.RED else Theme.MUTED
                    val sign = if (d > 0) "+" else ""
                    return stat(label, "$sign$d", col)
                }
                val head = text("AGAINST ${opp.shortName.uppercase()}", 9.5f, Theme.FAINT,
                    Theme.DISPLAY, 0.16f)
                head.setPadding(dp(10), dp(2), dp(10), dp(2))
                shapePanel.add(head)
                cmp.addView(diff(tr.attack, or.defence, "Att v Def"), lp(0, WRAP, 1f))
                cmp.addView(diff(tr.control, or.control, "Control"), lp(0, WRAP, 1f))
                cmp.addView(diff(tr.defence, or.attack, "Def v Att"), lp(0, WRAP, 1f))
                shapePanel.add(cmp)
            }
        }

        leftCol.addView(shapePanel, lp(MATCH, WRAP))

        val rightCol = column()

        val presetPanel = panel("Tactical style")
        val presetRow = LinearLayout(this)
        presetRow.orientation = LinearLayout.HORIZONTAL
        for (preset in Presets.ALL) {
            val ch = chip(preset.name, false)
            ch.setOnClickListener {
                preset.apply(t); w.autoPickSquad(c)
                toast("${preset.name}: ${preset.blurb}")
                renderScreen()
            }
            val lpx = lp(WRAP, WRAP); lpx.rightMargin = dp(6)
            presetRow.addView(ch, lpx)
        }
        val ps = HorizontalScrollView(this); ps.isHorizontalScrollBarEnabled = false
        ps.addView(presetRow)
        ps.setPadding(dp(8), dp(8), dp(8), dp(8))
        presetPanel.add(ps)
        rightCol.addView(presetPanel, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val rolePanel = panel("Roles and individual instructions")
        val shapeSlots = Formations.byName(t.formation).slots
        for (i in shapeSlots.indices) {
            val pl = w.player(t.lineup.getOrElse(i) { -1 })
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (i % 2 == 1) r.setBackgroundColor(Theme.PANEL_ALT)
            r.addView(posTag(shapeSlots[i].pos), lp(dp(36), WRAP))
            val col = column()
            col.addView(text(pl?.full ?: "\u2014", 12.5f, Theme.TEXT))
            val roleName = t.roleName(i)
            col.addView(text(roleName, 11f, Theme.GOLD))
            val piCount = PI.ALL.count { t.hasPI(i, it) }
            col.addView(text(
                if (piCount == 0) RoleFx.of(roleName).note
                else "$piCount individual instruction${if (piCount > 1) "s" else ""}",
                10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            if (t.captain == i) r.addView(tag("C", Theme.GOLD, 0xFF14162B.toInt()), lp(dp(26), WRAP))
            val roleBtn = subtleButton("Role")
            roleBtn.setOnClickListener { pickRole(t, i, shapeSlots[i].pos) }
            r.addView(roleBtn, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
            val piBtn = subtleButton("PI")
            piBtn.setOnClickListener { pickInstructions(t, i, pl?.full ?: "") }
            r.addView(piBtn)
            rolePanel.add(r)
        }
        rightCol.addView(rolePanel, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val setPiece = panel("Set pieces and captaincy")
        fun taker(labelText: String, current: Int, pick: (Int) -> Unit) {
            val r = row()
            r.setPadding(dp(10), dp(6), dp(10), dp(6))
            r.addView(text(labelText, 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
            val who = w.player(t.lineup.getOrElse(current) { -1 })
            val b = subtleButton(who?.last ?: "Automatic")
            b.setOnClickListener { pickTaker(t, labelText, pick) }
            r.addView(b)
            setPiece.add(r)
        }
        taker("Penalties", t.penaltyTaker) { t.penaltyTaker = it }
        taker("Corners", t.cornerTaker) { t.cornerTaker = it }
        taker("Free kicks", t.freeKickTaker) { t.freeKickTaker = it }
        taker("Captain", t.captain) { t.captain = it }

        // What the side actually does with a dead ball. These change who the
        // delivery is aimed at and what sort of chance it becomes, so they are
        // choices rather than decoration.
        fun setPieceChoice(label: String, values: Array<String>, note: String,
                           current: Int, onPick: (Int) -> Unit) {
            val block = column()
            block.setPadding(dp(10), dp(8), dp(10), dp(2))
            block.addView(text(label.uppercase(), 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
            block.addView(spacer(4))
            val rowV = LinearLayout(this)
            rowV.orientation = LinearLayout.HORIZONTAL
            for (i in values.indices) {
                val ch = chip(values[i], i == current)
                ch.setOnClickListener { onPick(i); renderScreen() }
                val pp = lp(WRAP, WRAP); pp.rightMargin = dp(5)
                rowV.addView(ch, pp)
            }
            val hsv = HorizontalScrollView(this); hsv.isHorizontalScrollBarEnabled = false
            hsv.addView(rowV)
            block.addView(hsv, lp(MATCH, WRAP))
            block.addView(text(note, 10.5f, Theme.FAINT), lp(MATCH, WRAP))
            setPiece.add(block)
        }

        setPieceChoice(
            "Corner delivery",
            arrayOf("Near post", "Far post", "Work it short", "Edge of the box"),
            when (t.cornerRoutine) {
                0 -> "Best chance from a corner, and the easiest to clear."
                2 -> "Safe, keeps the ball, rarely a header."
                3 -> "Pulled back for a striker of the ball."
                else -> "The standard ball into the six yard box."
            },
            t.cornerRoutine
        ) { t.cornerRoutine = it }

        setPieceChoice(
            "Men up for corners",
            arrayOf("Keep men back", "Normal", "Everyone up"),
            when (t.cornerMen) {
                0 -> "Fewer bodies in the box, but safe against the break."
                2 -> "More chance of a goal, and they will catch you on the counter."
                else -> "A normal commitment."
            },
            t.cornerMen
        ) { t.cornerMen = it }

        rightCol.addView(setPiece, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val oppPanel = panel("Opposition plan")
        val nextFx = season!!.nextUserFixture()
        val oppClub = nextFx?.let { w.club(if (it.homeId == c.id) it.awayId else it.homeId) }
        if (oppClub == null) {
            oppPanel.add(text("No fixture to plan for.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(12), dp(10), dp(12)) })
        } else {
            val threats = w.squadOf(oppClub).sortedByDescending { it.overall() }.take(5)
            oppPanel.add(text("Their most dangerous men \u2014 pick one to plan against.", 11.5f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(8), dp(10), dp(6)) })
            for (threat in threats) {
                val r = row()
                r.setPadding(dp(10), dp(6), dp(10), dp(6))
                val on = t.oppTargetId == threat.id
                if (on) r.setBackgroundColor(0x30E0447C)
                r.addView(posTag(threat.pos), lp(dp(36), WRAP))
                val col = column()
                col.addView(playerName(threat, 12.5f, if (on) Theme.GOLD else Theme.TEXT))
                col.addView(text("${threat.overall()} rated \u00B7 ${threat.goals}g ${threat.assists}a", 10.5f, Theme.MUTED))
                r.addView(col, lp(0, WRAP, 1f))
                if (on) r.addView(tag(Instr.OPP[t.oppMode].uppercase(), Theme.HILITE, 0xFFFFFFFF.toInt()))
                r.isClickable = true
                r.setOnClickListener { pickOppPlan(t, threat) }
                oppPanel.add(r)
            }
        }
        rightCol.addView(oppPanel, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val shapes = panel("Shape")
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.HORIZONTAL
        for (s in Formations.ALL) {
            val ch = chip(s.name, s.name == t.formation)
            ch.setOnClickListener {
                // through setFormation, so the squad loses some familiarity
                t.changeFormation(s.name); w.autoPickSquad(c); renderScreen()
            }
            val p = lp(WRAP, WRAP); p.rightMargin = dp(6)
            grid.addView(ch, p)
        }
        val gs = HorizontalScrollView(this); gs.isHorizontalScrollBarEnabled = false
        gs.addView(grid)
        gs.setPadding(dp(8), dp(8), dp(8), dp(8))
        shapes.add(gs)
        rightCol.addView(shapes, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val instr = panel("Team instructions")
        fun options(label: String, values: Array<String>, current: Int, onPick: (Int) -> Unit) {
            val block = column()
            block.setPadding(dp(10), dp(8), dp(10), dp(4))
            block.addView(text(label.uppercase(), 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
            block.addView(spacer(4))
            val rowV = LinearLayout(this)
            rowV.orientation = LinearLayout.HORIZONTAL
            for (i in values.indices) {
                val ch = chip(values[i], i == current)
                ch.setOnClickListener { onPick(i); renderScreen() }
                val p = lp(WRAP, WRAP); p.rightMargin = dp(5)
                rowV.addView(ch, p)
            }
            val hsv = HorizontalScrollView(this); hsv.isHorizontalScrollBarEnabled = false
            hsv.addView(rowV)
            block.addView(hsv, lp(MATCH, WRAP))
            instr.add(block)
        }
        options("Mentality", Instr.MENTALITY, t.mentality) { t.mentality = it }
        options("Tempo", Instr.TEMPO, t.tempo) { t.tempo = it }
        options("Passing", Instr.PASSING, t.passing) { t.passing = it }
        options("Width", Instr.WIDTH, t.width) { t.width = it }
        options("Defensive line", Instr.LINE, t.line) { t.line = it }
        options("Pressing", Instr.PRESS, t.press) { t.press = it }
        options("Tackling", Instr.TACKLING, t.tackling) { t.tackling = it }
        options("Focus of play", Instr.FOCUS, t.focus) { t.focus = it }
        options("Marking", Instr.MARKING, t.marking) { t.marking = it }
        options("Time wasting", Instr.TIME, t.timeWasting) { t.timeWasting = it }

        val toggles = row()
        toggles.setPadding(dp(10), dp(6), dp(10), dp(12))
        val counter = chip("Counter-attack", t.counter)
        counter.setOnClickListener { t.counter = !t.counter; renderScreen() }
        val trap = chip("Offside trap", t.offsideTrap)
        trap.setOnClickListener { t.offsideTrap = !t.offsideTrap; renderScreen() }
        val playOut = chip("Play out of defence", t.playOut)
        playOut.setOnClickListener { t.playOut = !t.playOut; renderScreen() }
        toggles.addView(counter, lp(WRAP, WRAP).also { it.rightMargin = dp(6) })
        toggles.addView(trap, lp(WRAP, WRAP).also { it.rightMargin = dp(6) })
        toggles.addView(playOut)
        instr.add(toggles)
        rightCol.addView(instr, lp(MATCH, WRAP))

        return twoColumn(leftCol, rightCol, 1f, 1.3f)
    }

    private fun overlay(p: Panel, widthDp: Int = 420): FrameLayout {
        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())
        val wrap = column(18)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(p, lp(dp(widthDp), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
        return holder
    }

    private fun pickRole(t: Tactics, slot: Int, pos: Int) {
        val p = panel("Role  \u00B7  ${Pos.name(pos)}")
        val list = Roles.forPos(pos)
        lateinit var holder: FrameLayout
        for (i in list.indices) {
            val r = row()
            r.setPadding(dp(10), dp(8), dp(10), dp(8))
            val on = t.slotRoles.getOrElse(slot) { 0 } == i
            if (on) r.setBackgroundColor(0x30E0447C)
            val col = column()
            col.addView(text(list[i], 13f, if (on) Theme.GOLD else Theme.TEXT, Theme.BODY_MED))
            col.addView(text(RoleFx.of(list[i]).note, 11f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            val fx = RoleFx.of(list[i])
            val deltas = StringBuilder()
            if (fx.atk != 0.0) deltas.append(if (fx.atk > 0) "ATK+ " else "ATK- ")
            if (fx.def != 0.0) deltas.append(if (fx.def > 0) "DEF+ " else "DEF- ")
            if (fx.ctl != 0.0) deltas.append(if (fx.ctl > 0) "CTL+" else "CTL-")
            r.addView(text(deltas.toString(), 10f, Theme.BLUE, Theme.DISPLAY, 0.06f))
            r.isClickable = true
            r.setOnClickListener {
                t.slotRoles[slot] = i
                stage.removeView(holder)
                renderScreen()
            }
            p.add(r); p.add(hairline())
        }
        val cancel = subtleButton("Close")
        val cr = row(); cr.setPadding(dp(10), dp(8), dp(10), dp(10))
        cr.addView(cancel, lp(0, WRAP, 1f))
        cancel.setOnClickListener { stage.removeView(holder) }
        p.add(cr)
        holder = overlay(p, 460)
    }

    private fun pickInstructions(t: Tactics, slot: Int, name: String) {
        val p = panel("Instructions  \u00B7  $name")
        lateinit var holder: FrameLayout
        for (flag in PI.ALL) {
            val r = row()
            r.setPadding(dp(10), dp(9), dp(10), dp(9))
            val on = t.hasPI(slot, flag)
            if (on) r.setBackgroundColor(0x30E0447C)
            r.addView(text(PI.label(flag), 12.5f, if (on) Theme.GOLD else Theme.TEXT), lp(0, WRAP, 1f))
            r.addView(tag(if (on) "ON" else "OFF", if (on) Theme.HILITE else Theme.BORDER, 0xFFFFFFFF.toInt()))
            r.isClickable = true
            r.setOnClickListener {
                t.togglePI(slot, flag)
                stage.removeView(holder)
                pickInstructions(t, slot, name)
                renderScreen()
            }
            p.add(r); p.add(hairline())
        }
        val done = actionButton("Done", true)
        val dr = row(); dr.setPadding(dp(10), dp(8), dp(10), dp(10))
        dr.addView(done, lp(0, WRAP, 1f))
        done.setOnClickListener { stage.removeView(holder); renderScreen() }
        p.add(dr)
        holder = overlay(p, 400)
    }

    private fun pickTaker(t: Tactics, role: String, assign: (Int) -> Unit) {
        val w = world!!
        val p = panel("$role \u2014 who takes them?")
        lateinit var holder: FrameLayout
        val autoRow = row()
        autoRow.setPadding(dp(10), dp(8), dp(10), dp(8))
        autoRow.addView(text("Automatic \u2014 best available", 12.5f, Theme.TEXT), lp(0, WRAP, 1f))
        autoRow.isClickable = true
        autoRow.setOnClickListener { assign(-1); stage.removeView(holder); renderScreen() }
        p.add(autoRow); p.add(hairline())

        val shapeSlots = Formations.byName(t.formation).slots
        for (i in shapeSlots.indices) {
            val pl = w.player(t.lineup.getOrElse(i) { -1 }) ?: continue
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            r.addView(posTag(shapeSlots[i].pos), lp(dp(36), WRAP))
            val col = column()
            col.addView(playerName(pl, 12.5f))
            val skill = when (role) {
                "Corners", "Free kicks" -> "PAS ${pl.att[Att.PAS]} \u00B7 TEC ${pl.att[Att.TEC]}"
                "Captain" -> "${pl.personality}${if (pl.hasTrait(Traits.LEADER)) " \u00B7 natural leader" else ""}"
                else -> "FIN ${pl.att[Att.FIN]} \u00B7 COM ${pl.att[Att.COM]}"
            }
            col.addView(text(skill + (if (pl.hasTrait(Traits.SET_PIECE)) " \u00B7 set-piece specialist" else ""),
                10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.isClickable = true
            r.setOnClickListener { assign(i); stage.removeView(holder); renderScreen() }
            p.add(r)
        }
        holder = overlay(p, 440)
    }

    private fun pickOppPlan(t: Tactics, threat: Player) {
        val p = panel("Plan for ${threat.full}")
        lateinit var holder: FrameLayout
        for (i in Instr.OPP.indices) {
            val r = row()
            r.setPadding(dp(10), dp(9), dp(10), dp(9))
            val on = t.oppTargetId == threat.id && t.oppMode == i
            if (on) r.setBackgroundColor(0x30E0447C)
            val col = column()
            col.addView(text(Instr.OPP[i], 12.5f, if (on) Theme.GOLD else Theme.TEXT, Theme.BODY_MED))
            col.addView(text(when (i) {
                1 -> "A defender follows him everywhere. Costs you shape."
                2 -> "Whoever is nearest hounds him on the ball."
                3 -> "Force him onto his weaker side."
                4 -> "Let him know you are there. Risks cards."
                else -> "Leave him to the back four."
            }, 11f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.isClickable = true
            r.setOnClickListener {
                if (i == 0) { t.oppTargetId = -1; t.oppMode = 0 }
                else { t.oppTargetId = threat.id; t.oppMode = i }
                stage.removeView(holder); renderScreen()
            }
            p.add(r); p.add(hairline())
        }
        holder = overlay(p, 440)
    }

    /* ------------------------------------------------------------- TABLE */

    private fun screenTable(): View {
        val w = world!!
        val s = season!!
        val outer = column(10)

        val tabs = row()
        for (d in w.divisions) {
            val ch = chip(d.name, d.id == tableDivision)
            ch.setOnClickListener { tableDivision = d.id; renderScreen() }
            val p = lp(WRAP, WRAP); p.rightMargin = dp(6)
            tabs.addView(ch, p)
        }
        outer.addView(tabs, lp(MATCH, WRAP))
        outer.addView(spacer(8))

        val cols = row()
        cols.gravity = Gravity.TOP

        val p = panel(w.division(tableDivision)?.name ?: "")
        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(6), dp(8), dp(6))
        fun h(s2: String, weight: Float, width: Int = 0, align: Int = Gravity.CENTER) {
            head.addView(
                text(s2.uppercase(), 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, align),
                if (weight > 0f) lp(0, WRAP, weight) else lp(dp(width), WRAP)
            )
        }
        h("#", 0f, 28); h("Club", 1f, 0, Gravity.START); h("P", 0f, 30)
        h("W", 0f, 30); h("D", 0f, 30); h("L", 0f, 30)
        h("GF", 0f, 34); h("GA", 0f, 34); h("GD", 0f, 38); h("Pts", 0f, 38); h("Form", 0f, 96)
        p.add(head)

        val standings = s.table(tableDivision)
        val div = w.division(tableDivision)
        for (i in standings.indices) {
            val c = standings[i]
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (c.isUser) r.setBackgroundColor(0x30E0447C)
            else if (i % 2 == 1) r.setBackgroundColor(Theme.PANEL_ALT)

            val zone = when {
                i < (div?.promoted ?: 0) -> Theme.GREEN
                tableDivision == 0 && i < 4 -> Theme.BLUE
                i >= standings.size - (div?.relegated ?: 0) -> Theme.RED
                else -> Theme.FAINT
            }
            fun cell(v: View, weight: Float, width: Int = 0) {
                r.addView(v, if (weight > 0f) lp(0, WRAP, weight) else lp(dp(width), WRAP))
            }
            cell(text("${i + 1}", 12f, zone, Theme.DATA, 0f, Gravity.CENTER), 0f, 28)
            cell(text(c.name, 12.5f, if (c.isUser) Theme.GOLD else Theme.TEXT,
                if (c.isUser) Theme.BODY_MED else Theme.BODY), 1f)
            cell(text("${c.played}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 30)
            cell(text("${c.won}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 30)
            cell(text("${c.drawn}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 30)
            cell(text("${c.lost}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 30)
            cell(text("${c.goalsFor}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 34)
            cell(text("${c.goalsAgainst}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 34)
            cell(text(if (c.goalDiff > 0) "+${c.goalDiff}" else "${c.goalDiff}", 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), 0f, 38)
            cell(text("${c.points}", 12.5f, Theme.TEXT, Theme.DISPLAY, 0f, Gravity.CENTER), 0f, 38)
            cell(formRow(c.form, 15), 0f, 96)
            p.add(r)
        }
        cols.addView(p, lp(0, WRAP, 2.4f))

        val gap = View(this); gap.layoutParams = lp(dp(10), 1)
        cols.addView(gap)

        val side = column()
        val scorers = panel("Top scorers")
        val top = s.topScorers(tableDivision, 10)
        if (top.isEmpty()) {
            scorers.add(text("No goals scored yet.", 12f, Theme.MUTED).also { it.setPadding(dp(10), dp(10), dp(10), dp(10)) })
        } else {
            for (i in top.indices) {
                val pl = top[i]
                val r = row()
                r.setPadding(dp(8), dp(5), dp(8), dp(5))
                if (i % 2 == 1) r.setBackgroundColor(Theme.PANEL_ALT)
                r.addView(text("${i + 1}", 11f, Theme.FAINT, Theme.DATA), lp(dp(20), WRAP))
                val nm = column()
                nm.addView(playerName(pl, 12f))
                nm.addView(text(w.club(pl.clubId)?.shortName ?: "", 10f, Theme.MUTED))
                r.addView(nm, lp(0, WRAP, 1f))
                r.addView(text(pl.goals.toString(), 13f, Theme.GOLD, Theme.DATA))
                scorers.add(r)
            }
        }
        side.addView(scorers, lp(MATCH, WRAP))
        cols.addView(side, lp(0, WRAP, 1f))

        val sc = ScrollView(this)
        sc.addView(cols, lp(MATCH, WRAP))
        outer.addView(sc, lp(MATCH, 0, 1f))
        return outer
    }

    /* -------------------------------------------------------------- CLUB */

    private fun screenClub(): View {
        val w = world!!
        val s = season!!
        val c = w.userClub!!

        val leftCol = column()
        val info = panel("Club information")
        info.add(kv("Division", w.division(c.divisionId)?.name ?: "\u2014"))
        info.add(kv("League position", Fmt.ord(s.position(c.id))))
        info.add(kv("Reputation", "${c.reputation} / 100"))
        info.add(kv("Stadium", c.stadiumName))
        info.add(kv("Capacity", c.capacity.toString()))
        info.add(kv("Squad rating", w.squadRating(c).toString(), Theme.ratingColor(w.squadRating(c))))
        info.add(kv("Team morale", if (c.morale > 70) "High" else if (c.morale > 45) "Steady" else "Low"))
        leftCol.addView(info, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val fin = panel("Finances")
        fin.add(kv("Bank balance", Fmt.money(c.balance), if (c.balance < 0) Theme.RED else Theme.GREEN))
        fin.add(kv("Transfer budget", Fmt.money(c.transferBudget), Theme.GOLD))
        fin.add(kv("Wage bill", Fmt.wage(w.wageBill(c))))
        fin.add(kv("Wage budget", Fmt.wage(c.wageBudget)))
        fin.add(kv("Season sponsorship", Fmt.money(c.sponsor)))
        leftCol.addView(fin, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val mgr = panel("Manager")
        mgr.add(kv("Name", w.managerName))
        mgr.add(kv("Reputation", "${w.managerRep} / 100"))
        mgr.add(kv("Record", "${w.managerP}P  ${w.managerW}W  ${w.managerD}D  ${w.managerL}L"))
        mgr.add(kv("Win rate", if (w.managerP > 0) "${w.managerW * 100 / w.managerP}%" else "\u2014"))
        leftCol.addView(mgr, lp(MATCH, WRAP))

        val rightCol = column()
        val fixtures = panel("Fixtures and results")
        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(5), dp(8), dp(5))
        head.addView(text("WK", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(dp(32), WRAP))
        head.addView(text("COMPETITION", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1f))
        head.addView(text("OPPONENT", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.6f))
        head.addView(text("RESULT", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(66), WRAP))
        fixtures.add(head)

        var alt = false
        for (fx in s.userFixtures()) {
            val home = fx.homeId == c.id
            val opp = w.club(if (home) fx.awayId else fx.homeId) ?: continue
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(text("${fx.week}", 11.5f, Theme.FAINT, Theme.DATA), lp(dp(32), WRAP))
            r.addView(text(Comp.label(fx.comp), 11.5f, Theme.MUTED), lp(0, WRAP, 1f))
            r.addView(text("${if (home) "" else "@ "}${opp.name}", 12f, Theme.TEXT), lp(0, WRAP, 1.6f))
            if (fx.played) {
                val mine = if (home) fx.homeGoals else fx.awayGoals
                val theirs = if (home) fx.awayGoals else fx.homeGoals
                val col = when { mine > theirs -> Theme.GREEN; mine == theirs -> Theme.AMBER; else -> Theme.RED }
                r.addView(text("$mine \u2013 $theirs", 12.5f, col, Theme.DATA, 0f, Gravity.CENTER), lp(dp(66), WRAP))
            } else {
                r.addView(text("\u2014", 12.5f, Theme.FAINT, Theme.DATA, 0f, Gravity.CENTER), lp(dp(66), WRAP))
            }
            fixtures.add(r)
        }
        rightCol.addView(fixtures, lp(MATCH, WRAP))

        return twoColumn(leftCol, rightCol, 1f, 1.5f)
    }

    /* ------------------------------------------------------------ MARKET */

    private var mkPos = -1
    private var mkMaxAge = 40
    private var mkMinRating = 0
    private var mkTab = 0        // 0 search, 1 shortlist, 2 my club, 3 free agents

    private fun screenMarket(): View {
        val w = world!!
        val car = career!!
        val c = w.userClub!!
        val outer = column(10)

        // budget strip
        val budget = row()
        budget.background = boxBg(Theme.PANEL, Theme.BORDER, dp(4))
        budget.setPadding(dp(12), dp(9), dp(12), dp(9))
        budget.addView(stat("Window", if (car.transferWindowOpen) "OPEN" else "CLOSED",
            if (car.transferWindowOpen) Theme.GREEN else Theme.RED), lp(0, WRAP, 1f))
        budget.addView(stat("Transfer budget", Fmt.money(c.transferBudget), Theme.GOLD), lp(0, WRAP, 1f))
        budget.addView(stat("Wage room", Fmt.wage(maxOf(0, c.wageBudget - w.wageBill(c))), Theme.TEXT), lp(0, WRAP, 1f))
        budget.addView(stat("Squad", "${c.squad.size} / 30"), lp(0, WRAP, 1f))
        budget.addView(stat("Offers in", car.offers.size.toString(),
            if (car.offers.isNotEmpty()) Theme.HILITE else Theme.MUTED), lp(0, WRAP, 1f))
        outer.addView(budget, lp(MATCH, WRAP))
        outer.addView(spacer(8))

        val tabs = row()
        val names = arrayOf("Search", "Shortlist (${car.shortlist.size})", "My club", "Free agents")
        for (i in names.indices) {
            val ch = chip(names[i], mkTab == i)
            ch.setOnClickListener { mkTab = i; renderScreen() }
            val lpx = lp(WRAP, WRAP); lpx.rightMargin = dp(6)
            tabs.addView(ch, lpx)
        }
        tabs.addView(View(this), lp(0, 1, 1f))
        val scoutBtn = subtleButton("Scouting")
        scoutBtn.setOnClickListener { screen = SCR_SCOUT; renderShell() }
        tabs.addView(scoutBtn)
        val staffBtn = subtleButton("Staff")
        staffBtn.setOnClickListener { screen = SCR_STAFF; renderShell() }
        tabs.addView(staffBtn)
        outer.addView(tabs, lp(MATCH, WRAP))
        outer.addView(spacer(8))

        val content = column()
        when (mkTab) {
            1 -> content.addView(marketList(car.shortlist.mapNotNull { w.player(it) }
                .sortedByDescending { it.overall() }, "Shortlist"), lp(MATCH, WRAP))
            2 -> content.addView(myClubMarket(), lp(MATCH, WRAP))
            3 -> content.addView(marketList(car.freeAgents(), "Free agents"), lp(MATCH, WRAP))
            else -> {
                content.addView(filterPanel(), lp(MATCH, WRAP))
                content.addView(spacer(8))
                content.addView(marketList(
                    car.market(mkPos, mkMaxAge, mkMinRating), "Available players"), lp(MATCH, WRAP))
            }
        }
        val sc = ScrollView(this)
        sc.addView(content, lp(MATCH, WRAP))
        outer.addView(sc, lp(MATCH, 0, 1f))
        return outer
    }

    private fun filterPanel(): View {
        val p = panel("Search brief")
        val posRow = row()
        posRow.setPadding(dp(8), dp(8), dp(8), dp(4))
        val any = chip("Any position", mkPos < 0)
        any.setOnClickListener { mkPos = -1; renderScreen() }
        posRow.addView(any, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        for (i in 0 until Pos.COUNT) {
            val ch = chip(Pos.name(i), mkPos == i)
            ch.setOnClickListener { mkPos = i; renderScreen() }
            posRow.addView(ch, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        }
        val hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false
        hs.addView(posRow)
        p.add(hs)

        val ageRow = row()
        ageRow.setPadding(dp(8), dp(2), dp(8), dp(4))
        for (a in intArrayOf(40, 30, 27, 24, 21)) {
            val ch = chip(if (a == 40) "Any age" else "Under ${a + 1}", mkMaxAge == a)
            ch.setOnClickListener { mkMaxAge = a; renderScreen() }
            ageRow.addView(ch, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        }
        p.add(ageRow)

        val ratRow = row()
        ratRow.setPadding(dp(8), dp(2), dp(8), dp(10))
        for (r in intArrayOf(0, 55, 65, 72, 80)) {
            val ch = chip(if (r == 0) "Any rating" else "$r+", mkMinRating == r)
            ch.setOnClickListener { mkMinRating = r; renderScreen() }
            ratRow.addView(ch, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        }
        p.add(ratRow)
        return p
    }

    private fun marketList(players: List<Player>, title: String): View {
        val w = world!!
        val car = career!!
        val p = panel("$title \u00B7 ${players.size}")

        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(5), dp(8), dp(5))
        fun h(s2: String, weight: Float, width: Int = 0, align: Int = Gravity.START) {
            head.addView(text(s2.uppercase(), 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, align),
                if (weight > 0f) lp(0, WRAP, weight) else lp(dp(width), WRAP))
        }
        h("Pos", 0f, 36); h("Name", 1.5f); h("Age", 0f, 34, Gravity.CENTER)
        h("Club", 1.1f); h("Wage", 0f, 66, Gravity.END)
        h("Asking", 0f, 74, Gravity.END); h("Ovr", 0f, 38, Gravity.CENTER); h("", 0f, 74)

        p.add(head)
        if (players.isEmpty()) {
            p.add(text("Nobody matches that brief.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(14), dp(10), dp(14)) })
        }
        var alt = false
        for (pl in players) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(posTag(pl.pos), lp(dp(36), WRAP))
            val col = column()
            val nm = row()
            nm.addView(playerName(pl, 12.5f))
            if (pl.hasTrait(Traits.WONDERKID)) nm.addView(text("  \u2726", 11f, Theme.GOLD))
            if (pl.listed) nm.addView(text("  \u2691", 11f, Theme.HILITE))
            col.addView(nm, lp(WRAP, WRAP))
            col.addView(text("${Names.byCode(pl.nation).flag} ${pl.role}", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1.5f))
            r.addView(text(pl.age.toString(), 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), lp(dp(34), WRAP))
            r.addView(text(w.club(pl.clubId)?.name ?: "Free agent", 11f, Theme.MUTED), lp(0, WRAP, 1.1f))
            r.addView(text(Fmt.wage(pl.wage), 11f, Theme.MUTED, Theme.DATA, 0f, Gravity.END), lp(dp(66), WRAP))
            val ask = if (pl.clubId >= 0) car.askingPrice(pl) else 0L
            r.addView(text(if (ask > 0) Fmt.money(ask) else "FREE", 11.5f, Theme.GOLD, Theme.DATA, 0f, Gravity.END), lp(dp(74), WRAP))
            val o = pl.overall()
            r.addView(tag(o.toString(), Theme.ratingColor(o), 0xFF14162B.toInt()), lp(dp(38), WRAP))

            val actions = row()
            val star = subtleButton(if (car.shortlist.contains(pl.id)) "\u2605" else "\u2606")
            star.setOnClickListener {
                if (!car.shortlist.add(pl.id)) car.shortlist.remove(pl.id)
                renderScreen()
            }
            actions.addView(star, lp(WRAP, WRAP).also { it.rightMargin = dp(4) })
            val bid = subtleButton("Bid")
            bid.setOnClickListener { bidDialog(pl) }
            actions.addView(bid)
            r.addView(actions, lp(dp(74), WRAP))

            r.isClickable = true
            r.setOnClickListener { selectedPlayer = pl.id; screen = SCR_PLAYER; renderShell() }
            p.add(r)
        }
        return p
    }

    private fun myClubMarket(): View {
        val w = world!!
        val car = career!!
        val c = w.userClub!!
        val col = column()

        val offers = panel("Offers received \u00B7 ${car.offers.size}")
        if (car.offers.isEmpty()) {
            offers.add(text("Nobody has bid for your players.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(14), dp(10), dp(14)) })
        }
        for (o in car.offers.toList()) {
            val pl = w.player(o.playerId) ?: continue
            val buyer = w.club(o.buyerId) ?: continue
            val r = row()
            r.setPadding(dp(10), dp(8), dp(10), dp(8))
            r.addView(posTag(pl.pos), lp(dp(36), WRAP))
            val cc = column()
            cc.addView(playerName(pl, 12.5f, Theme.TEXT, Theme.BODY_MED))
            cc.addView(text("${buyer.name} \u00B7 valued at ${Fmt.money(pl.value())}", 11f, Theme.MUTED))
            r.addView(cc, lp(0, WRAP, 1f))
            r.addView(text(Fmt.money(o.fee), 14f, Theme.GOLD, Theme.DATA), lp(WRAP, WRAP).also { it.rightMargin = dp(10) })
            val acc = actionButton("Accept")
            acc.setOnClickListener { toast(car.acceptOffer(o.id).message); renderShell() }
            r.addView(acc, lp(WRAP, WRAP).also { it.rightMargin = dp(6) })
            val rej = subtleButton("Reject")
            rej.setOnClickListener { car.rejectOffer(o.id); renderScreen() }
            r.addView(rej)
            offers.add(r)
        }
        col.addView(offers, lp(MATCH, WRAP))
        col.addView(spacer(10))

        val expiring = car.expiringContracts()
        val contracts = panel("Contracts running down \u00B7 ${expiring.size}")
        if (expiring.isEmpty()) {
            contracts.add(text("Every contract is secure for now.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(14), dp(10), dp(14)) })
        }
        for (pl in expiring) {
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            r.addView(posTag(pl.pos), lp(dp(36), WRAP))
            val cc = column()
            cc.addView(playerName(pl, 12.5f))
            cc.addView(text("${pl.contractYears} year left \u00B7 on ${Fmt.wage(pl.wage)} \u00B7 wants ${Fmt.wage(car.renewalDemand(pl))}",
                10.5f, if (pl.contractYears <= 1) Theme.RED else Theme.MUTED))
            r.addView(cc, lp(0, WRAP, 1f))
            val renew = actionButton("Offer new deal")
            renew.setOnClickListener { renewDialog(pl) }
            r.addView(renew)
            contracts.add(r)
        }
        col.addView(contracts, lp(MATCH, WRAP))
        col.addView(spacer(10))

        val squad = panel("Your squad \u00B7 list a player to invite bids")
        for (pl in w.squadOf(c).sortedByDescending { it.value() }) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            r.addView(posTag(pl.pos), lp(dp(36), WRAP))
            val cc = column()
            cc.addView(playerName(pl, 12.5f))
            cc.addView(text("${pl.age}y \u00B7 ${pl.overall()} rated \u00B7 ${Fmt.wage(pl.wage)}", 10.5f, Theme.MUTED))
            r.addView(cc, lp(0, WRAP, 1f))
            r.addView(text(Fmt.money(pl.value()), 12f, Theme.GOLD, Theme.DATA),
                lp(WRAP, WRAP).also { it.rightMargin = dp(10) })
            val list = subtleButton(if (pl.listed) "Unlist" else "Transfer list")
            list.setOnClickListener {
                pl.listed = !pl.listed
                toast(if (pl.listed) "${pl.last} is available for transfer." else "${pl.last} taken off the list.")
                renderScreen()
            }
            r.addView(list, lp(WRAP, WRAP).also { it.rightMargin = dp(6) })
            val sell = subtleButton("Sell")
            sell.setOnClickListener { sellDialog(pl) }
            r.addView(sell)
            squad.add(r)
        }
        col.addView(squad, lp(MATCH, WRAP))
        return col
    }

    /* --------------------------------------------------------- DIALOGS */

    private fun bidDialog(pl: Player) {
        val w = world!!
        val car = career!!
        val c = w.userClub!!
        val ask = if (pl.clubId >= 0) car.askingPrice(pl) else 0L
        var fee = minOf(ask, c.transferBudget)
        var wage = (pl.expectedWage() * 1.15).toInt()
        var years = 3

        lateinit var holder: FrameLayout
        lateinit var feeLabel: TextView
        lateinit var wageLabel: TextView
        lateinit var msg: TextView

        val p = panel("Offer for ${pl.full}")
        p.add(kv("Asking price", if (ask > 0) Fmt.money(ask) else "Free transfer", Theme.GOLD))
        p.add(kv("Your budget", Fmt.money(c.transferBudget)))
        p.add(kv("Wage room", Fmt.wage(maxOf(0, c.wageBudget - w.wageBill(c)))))
        p.add(kv("He earns now", Fmt.wage(pl.wage)))
        p.add(hairline())

        fun stepper(labelText: String, minus: () -> Unit, plus: () -> Unit, out: (TextView) -> Unit) {
            val r = row()
            r.setPadding(dp(10), dp(8), dp(10), dp(8))
            r.addView(text(labelText, 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
            val dec = subtleButton("\u2212")
            val valueText = text("", 13.5f, Theme.TEXT, Theme.DATA, 0f, Gravity.CENTER)
            valueText.minWidth = dp(96)
            val inc = subtleButton("+")
            dec.setOnClickListener { minus() }
            inc.setOnClickListener { plus() }
            r.addView(dec, lp(dp(46), WRAP))
            r.addView(valueText, lp(dp(104), WRAP))
            r.addView(inc, lp(dp(46), WRAP))
            out(valueText)
            p.add(r)
        }

        stepper("Transfer fee",
            { fee = maxOf(0L, fee - maxOf(50_000L, ask / 20)); feeLabel.text = Fmt.money(fee) },
            { fee = minOf(c.transferBudget, fee + maxOf(50_000L, ask / 20)); feeLabel.text = Fmt.money(fee) }
        ) { feeLabel = it }
        stepper("Weekly wage",
            { wage = maxOf(500, wage - 500); wageLabel.text = Fmt.wage(wage) },
            { wage += 500; wageLabel.text = Fmt.wage(wage) }
        ) { wageLabel = it }
        feeLabel.text = Fmt.money(fee)
        wageLabel.text = Fmt.wage(wage)

        val yearRow = row()
        yearRow.setPadding(dp(10), dp(4), dp(10), dp(8))
        yearRow.addView(text("Contract length", 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
        for (y in 1..5) {
            val ch = chip("${y}y", y == years)
            ch.setOnClickListener {
                years = y
                stage.removeView(holder)
                bidDialog(pl)
            }
            yearRow.addView(ch, lp(WRAP, WRAP).also { it.leftMargin = dp(4) })
        }
        p.add(yearRow)

        msg = text("", 12f, Theme.HILITE)
        msg.setPadding(dp(10), dp(2), dp(10), dp(6))
        p.add(msg)

        val actions = row()
        actions.setPadding(dp(10), dp(4), dp(10), dp(12))
        val submit = actionButton("Submit offer", true)
        submit.setOnClickListener {
            val r = car.makeBid(pl.id, fee, wage, years)
            if (r.ok) {
                stage.removeView(holder)
                toast(r.message)
                renderShell()
            } else {
                msg.text = r.message
                if (r.counterFee > 0) { fee = minOf(r.counterFee, c.transferBudget); feeLabel.text = Fmt.money(fee) }
                if (r.wantWage > 0) { wage = r.wantWage; wageLabel.text = Fmt.wage(wage) }
            }
        }
        actions.addView(submit, lp(0, WRAP, 1f))
        val cancel = subtleButton("Cancel")
        cancel.setOnClickListener { stage.removeView(holder) }
        actions.addView(cancel, lp(WRAP, WRAP).also { it.leftMargin = dp(8) })
        p.add(actions)

        holder = overlay(p, 460)
    }

    private fun renewDialog(pl: Player) {
        val car = career!!
        var wage = car.renewalDemand(pl)
        var years = 3
        lateinit var holder: FrameLayout
        lateinit var wageLabel: TextView
        lateinit var msg: TextView

        val p = panel("New contract \u00B7 ${pl.full}")
        p.add(kv("Currently on", Fmt.wage(pl.wage)))
        p.add(kv("He is asking for", Fmt.wage(car.renewalDemand(pl)), Theme.GOLD))
        p.add(kv("Contract left", "${pl.contractYears} year(s)"))
        p.add(hairline())

        val r = row()
        r.setPadding(dp(10), dp(8), dp(10), dp(8))
        r.addView(text("Weekly wage", 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
        val dec = subtleButton("\u2212")
        wageLabel = text(Fmt.wage(wage), 13.5f, Theme.TEXT, Theme.DATA, 0f, Gravity.CENTER)
        val inc = subtleButton("+")
        dec.setOnClickListener { wage = maxOf(500, wage - 500); wageLabel.text = Fmt.wage(wage) }
        inc.setOnClickListener { wage += 500; wageLabel.text = Fmt.wage(wage) }
        r.addView(dec, lp(dp(46), WRAP))
        r.addView(wageLabel, lp(dp(104), WRAP))
        r.addView(inc, lp(dp(46), WRAP))
        p.add(r)

        val yearRow = row()
        yearRow.setPadding(dp(10), dp(4), dp(10), dp(8))
        yearRow.addView(text("Length", 12.5f, Theme.MUTED), lp(0, WRAP, 1f))
        for (y in 1..5) {
            val ch = chip("${y}y", y == years)
            ch.setOnClickListener { years = y; stage.removeView(holder); renewDialog(pl) }
            yearRow.addView(ch, lp(WRAP, WRAP).also { it.leftMargin = dp(4) })
        }
        p.add(yearRow)

        // Clauses. Loading the deal with bonuses is how a club signs a player
        // it cannot fit under the wage budget: he takes less guaranteed money
        // in return for a bill that only arrives when he plays or scores.
        p.add(hairline())
        p.add(text("BONUSES AND CLAUSES", 10f, Theme.ACCENT, Theme.DISPLAY, 0.16f).also {
            it.setPadding(dp(10), dp(8), dp(10), dp(4))
        })

        fun clauseRow(label: String, step: Int, get: () -> Int, set: (Int) -> Unit) {
            val cr = row()
            cr.setPadding(dp(10), dp(5), dp(10), dp(5))
            cr.addView(text(label, 12f, Theme.MUTED), lp(0, WRAP, 1f))
            val down = subtleButton("\u2212")
            val v = text(if (get() == 0) "none" else Fmt.wage(get()), 12.5f, Theme.TEXT,
                Theme.DATA, 0f, Gravity.CENTER)
            val up = subtleButton("+")
            down.setOnClickListener {
                set(maxOf(0, get() - step))
                v.text = if (get() == 0) "none" else Fmt.wage(get())
                wage = car.renewalDemand(pl); wageLabel.text = Fmt.wage(wage)
            }
            up.setOnClickListener {
                set(get() + step)
                v.text = Fmt.wage(get())
                wage = car.renewalDemand(pl); wageLabel.text = Fmt.wage(wage)
            }
            cr.addView(down, lp(dp(40), WRAP))
            cr.addView(v, lp(dp(92), WRAP))
            cr.addView(up, lp(dp(40), WRAP))
            p.add(cr)
        }

        clauseRow("Per appearance", 250, { pl.appearanceFee }, { pl.appearanceFee = it })
        clauseRow("Per goal", 500, { pl.goalBonus }, { pl.goalBonus = it })
        if (pl.pos == Pos.GK || Pos.group(pl.pos) == 1) {
            clauseRow("Clean sheet", 250, { pl.cleanSheetBonus }, { pl.cleanSheetBonus = it })
        }

        val relRow = row()
        relRow.setPadding(dp(10), dp(5), dp(10), dp(8))
        relRow.addView(text("Release clause", 12f, Theme.MUTED), lp(0, WRAP, 1f))
        val relDown = subtleButton("\u2212")
        val relVal = text(if (pl.releaseClause == 0L) "none" else Fmt.money(pl.releaseClause),
            12.5f, Theme.TEXT, Theme.DATA, 0f, Gravity.CENTER)
        val relUp = subtleButton("+")
        val relStep = 2_500_000L
        relDown.setOnClickListener {
            pl.releaseClause = maxOf(0L, pl.releaseClause - relStep)
            relVal.text = if (pl.releaseClause == 0L) "none" else Fmt.money(pl.releaseClause)
            wage = car.renewalDemand(pl); wageLabel.text = Fmt.wage(wage)
        }
        relUp.setOnClickListener {
            pl.releaseClause += relStep
            relVal.text = Fmt.money(pl.releaseClause)
            wage = car.renewalDemand(pl); wageLabel.text = Fmt.wage(wage)
        }
        relRow.addView(relDown, lp(dp(40), WRAP))
        relRow.addView(relVal, lp(dp(92), WRAP))
        relRow.addView(relUp, lp(dp(40), WRAP))
        p.add(relRow)

        p.add(text(
            if (pl.releaseClause in 1 until pl.value())
                "That clause is below what he is worth. Expect somebody to pay it."
            else "The clauses knock ${Fmt.wage(pl.clauseValue())} a week off what he asks for.",
            10.5f,
            if (pl.releaseClause in 1 until pl.value()) Theme.RED else Theme.FAINT
        ).also { it.setPadding(dp(10), dp(0), dp(10), dp(8)) })

        msg = text("", 12f, Theme.HILITE)
        msg.setPadding(dp(10), dp(2), dp(10), dp(6))
        p.add(msg)

        val actions = row()
        actions.setPadding(dp(10), dp(4), dp(10), dp(12))
        val offer = actionButton("Offer contract", true)
        offer.setOnClickListener {
            val res = car.renewContract(pl.id, wage, years)
            if (res.ok) { stage.removeView(holder); toast(res.message); renderShell() }
            else { msg.text = res.message; if (res.wantWage > 0) { wage = res.wantWage; wageLabel.text = Fmt.wage(wage) } }
        }
        actions.addView(offer, lp(0, WRAP, 1f))
        val cancel = subtleButton("Cancel")
        cancel.setOnClickListener { stage.removeView(holder) }
        actions.addView(cancel, lp(WRAP, WRAP).also { it.leftMargin = dp(8) })
        p.add(actions)

        holder = overlay(p, 430)
    }

    private fun sellDialog(pl: Player) {
        val w = world!!
        val car = career!!
        val value = pl.value()
        lateinit var holder: FrameLayout

        val p = panel("Sell ${pl.full}")
        p.add(kv("Valued at", Fmt.money(value), Theme.GOLD))
        p.add(kv("On", Fmt.wage(pl.wage)))
        p.add(hairline())
        p.add(text("Clubs who could take him now:", 11.5f, Theme.MUTED)
            .also { it.setPadding(dp(10), dp(8), dp(10), dp(4)) })

        val buyers = w.clubs.filter { !it.isUser && it.balance > value * 1.1 && it.squad.size < 30 }
            .sortedByDescending { it.reputation }.take(8)
        if (buyers.isEmpty()) {
            p.add(text("No club can afford him right now.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(10), dp(10), dp(10)) })
        }
        for (b in buyers) {
            val fee = (value * (0.85 + b.reputation / 400.0)).toLong()
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            r.addView(crest(b, 24))
            val col = column()
            col.setPadding(dp(8), 0, dp(8), 0)
            col.addView(text(b.name, 12.5f, Theme.TEXT))
            col.addView(text(w.division(b.divisionId)?.name ?: "Abroad", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            val take = actionButton(Fmt.money(fee))
            take.setOnClickListener {
                val res = car.sellPlayer(pl.id, fee, b.id)
                stage.removeView(holder); toast(res.message); renderShell()
            }
            r.addView(take)
            p.add(r)
        }
        val cancelRow = row()
        cancelRow.setPadding(dp(10), dp(8), dp(10), dp(12))
        val cancel = subtleButton("Cancel")
        cancel.setOnClickListener { stage.removeView(holder) }
        cancelRow.addView(cancel, lp(0, WRAP, 1f))
        p.add(cancelRow)
        holder = overlay(p, 440)
    }

    /* -------------------------------------------------------- SCOUTING */

    private var scoutPos = -1

    /**
     * The morning after a signing: what the board make of it, what the
     * supporters make of it, and what it does to the side. Shown once, then
     * cleared, so it interrupts exactly as a piece of news would.
     */
    private fun showSigningVerdict(v: Career.SigningVerdict) {
        career?.lastSigning = null
        stage.removeAllViews()
        val col = column()

        val head = panel("${v.player.full} signs for ${Fmt.money(v.fee)}")
        val top = row()
        top.setPadding(dp(12), dp(12), dp(12), dp(10))
        val portrait = FaceView(this, v.player)
        portrait.background = boxBg(Theme.PANEL_ALT, Theme.BORDER_SOFT, dp(4))
        val pp = lp(dp(72), dp(72)); pp.rightMargin = dp(12)
        top.addView(portrait, pp)
        val info = column()
        info.addView(text("${Pos.name(v.player.pos)} \u00B7 ${v.player.age} \u00B7 " +
            "${v.player.overall()} rated", 13f, Theme.TEXT, Theme.BODY_MED))
        info.addView(text(v.player.personality, 11.5f, Theme.MUTED))
        info.addView(spacer(4))
        val delta = v.ratingChange
        info.addView(text(
            if (delta > 0) "Squad rating ${v.ratingBefore} \u2192 ${v.ratingAfter}  (+$delta)"
            else if (delta < 0) "Squad rating ${v.ratingBefore} \u2192 ${v.ratingAfter}  ($delta)"
            else "Squad rating unchanged at ${v.ratingAfter}",
            12f, if (delta > 0) Theme.GREEN else if (delta < 0) Theme.RED else Theme.MUTED))
        top.addView(info, lp(0, WRAP, 1f))
        head.add(top)
        col.addView(head, lp(MATCH, WRAP))
        col.addView(spacer(10))

        fun opinion(who: String, mood: Int, line: String) {
            val p = panel(who)
            val moodRow = row()
            moodRow.setPadding(dp(12), dp(8), dp(12), dp(4))
            val col2 = if (mood > 0) Theme.GREEN else if (mood < 0) Theme.RED else Theme.MUTED
            val label = when (mood) {
                2 -> "Delighted"; 1 -> "Pleased"; 0 -> "Reserving judgement"
                -1 -> "Unimpressed"; else -> "Furious"
            }
            moodRow.addView(text(label.uppercase(), 10.5f, col2, Theme.DISPLAY, 0.14f), lp(0, WRAP, 1f))
            p.add(moodRow)
            p.add(text(line, 12.5f, Theme.TEXT).also {
                it.setPadding(dp(12), dp(0), dp(12), dp(12))
            })
            col.addView(p, lp(MATCH, WRAP))
            col.addView(spacer(8))
        }

        opinion("The board", v.boardMood, v.boardLine)
        opinion("The supporters", v.fanMood, v.fanLine)

        val squad = panel("What it means for the side")
        squad.add(text(v.squadLine, 12.5f, Theme.TEXT).also {
            it.setPadding(dp(12), dp(10), dp(12), if (v.riskLine == null) dp(12) else dp(4))
        })
        v.riskLine?.let {
            squad.add(text("\u26A0  $it", 12f, Theme.HILITE).also { t ->
                t.setPadding(dp(12), dp(0), dp(12), dp(12))
            })
        }
        col.addView(squad, lp(MATCH, WRAP))
        col.addView(spacer(10))

        val go = actionButton("Get back to work", true)
        go.setOnClickListener { renderShell() }
        val r = row(); r.addView(go, lp(0, WRAP, 1f))
        col.addView(r, lp(MATCH, WRAP))

        val sc = ScrollView(this)
        sc.addView(col, lp(MATCH, WRAP))
        val pad = row(); pad.setPadding(dp(10), dp(10), dp(10), dp(10))
        pad.addView(sc, lp(MATCH, MATCH))
        stage.addView(pad, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Who works for you, what they are worth, and what it costs. */
    private fun screenStaff(): View {
        val w = world!!
        val c = w.userClub!!

        val leftCol = column()
        val summary = panel("What your staff are worth")
        summary.add(kv("Coaching", String.format("%.2fx development",
            Backroom.coachingFactor(c.staff)), Theme.GOLD))
        summary.add(kv("Treatment room", String.format("%.2fx injury length",
            Backroom.physioFactor(c.staff)),
            if (Backroom.physioFactor(c.staff) < 1.0) Theme.GREEN else Theme.RED))
        summary.add(kv("Academy", String.format("%.2fx intake quality",
            Backroom.youthFactor(c.staff)), Theme.GOLD))
        summary.add(kv("Scout reports", "\u00B1${Backroom.scoutError(c.staff)} rating points",
            Theme.MUTED))
        summary.add(kv("Backroom wages", "${Fmt.wage(Backroom.wageBill(c.staff))} a week", Theme.MUTED))
        leftCol.addView(summary, lp(MATCH, WRAP))

        val rightCol = column()
        val list = panel("The backroom \u00B7 ${c.staff.size}")
        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(10), dp(5), dp(10), dp(5))
        head.addView(text("ROLE", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.1f))
        head.addView(text("NAME", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.3f))
        head.addView(text("RATED", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(84), WRAP))
        head.addView(text("WAGE", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(72), WRAP))
        list.add(head)

        for (st in c.staff.sortedBy { it.role }) {
            val rowV = row()
            rowV.setPadding(dp(10), dp(9), dp(10), dp(9))
            val roleCol = column()
            roleCol.addView(text(st.roleName, 12f, Theme.TEXT, Theme.BODY_MED), lp(MATCH, WRAP))
            roleCol.addView(text(StaffRole.WHAT_THEY_DO[st.role], 10f, Theme.FAINT), lp(MATCH, WRAP))
            rowV.addView(roleCol, lp(0, WRAP, 1.1f))
            rowV.addView(text(st.name, 12f, Theme.MUTED), lp(0, WRAP, 1.3f))
            val q = column()
            q.addView(text("\u2605".repeat(st.stars), 11f,
                if (st.quality >= 70) Theme.GOLD else Theme.MUTED, Theme.BODY, 0f, Gravity.CENTER),
                lp(MATCH, WRAP))
            q.addView(text(st.standing, 9.5f, Theme.FAINT, Theme.BODY, 0f, Gravity.CENTER), lp(MATCH, WRAP))
            rowV.addView(q, lp(dp(84), WRAP))
            rowV.addView(text(Fmt.wage(st.wage), 11.5f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER),
                lp(dp(72), WRAP))
            list.add(rowV)
        }
        rightCol.addView(list, lp(MATCH, WRAP))
        return twoColumn(leftCol, rightCol, 1f, 1.8f)
    }

    private fun screenScout(): View {
        val w = world!!
        val car = career!!
        val c = w.userClub!!
        val leftCol = column()

        val brief = panel("Send the scouts out")
        brief.add(text("A trip costs \u20AC120,000 and returns five unattached players who fit the brief.",
            11.5f, Theme.MUTED).also { it.setPadding(dp(10), dp(10), dp(10), dp(6)) })
        val posRow = row()
        posRow.setPadding(dp(8), dp(2), dp(8), dp(6))
        val any = chip("Any position", scoutPos < 0)
        any.setOnClickListener { scoutPos = -1; renderScreen() }
        posRow.addView(any, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        for (i in 0 until Pos.COUNT) {
            val ch = chip(Pos.name(i), scoutPos == i)
            ch.setOnClickListener { scoutPos = i; renderScreen() }
            posRow.addView(ch, lp(WRAP, WRAP).also { it.rightMargin = dp(5) })
        }
        val hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false
        hs.addView(posRow)
        brief.add(hs)

        val go = row()
        go.setPadding(dp(10), dp(4), dp(10), dp(12))
        val best = actionButton("Best available")
        best.setOnClickListener {
            val r = car.scoutMission(scoutPos, false); toast(r.message); renderShell()
        }
        val young = actionButton("Young prospects")
        young.setOnClickListener {
            val r = car.scoutMission(scoutPos, true); toast(r.message); renderShell()
        }
        go.addView(best, lp(0, WRAP, 1f).also { it.rightMargin = dp(8) })
        go.addView(young, lp(0, WRAP, 1f))
        brief.add(go)
        brief.add(kv("In the bank", Fmt.money(c.balance), if (c.balance > 120_000L) Theme.GREEN else Theme.RED))
        leftCol.addView(brief, lp(MATCH, WRAP))

        // whose judgement you are relying on
        val chief = c.staff.filter { it.role == StaffRole.SCOUT }.maxByOrNull { it.quality }
        if (chief != null) {
            brief.add(kv("Chief scout", "${chief.name} \u00B7 ${chief.standing}",
                if (chief.quality >= 70) Theme.GREEN else if (chief.quality >= 50) Theme.GOLD else Theme.RED))
            brief.add(kv("Reports accurate to", "\u00B1${Backroom.scoutError(c.staff)} rating points",
                Theme.MUTED))
        }

        val rightCol = column()
        val finds = car.scoutFinds.mapNotNull { w.player(it) }.filter { it.clubId < 0 }
        val reports = panel("Scout reports \u00B7 ${finds.size}")
        if (finds.isEmpty()) {
            reports.add(text("Nothing yet. Send them out.", 12f, Theme.FAINT).also {
                it.setPadding(dp(12), dp(14), dp(12), dp(14))
            })
        }
        for (p in finds.take(18)) {
            val rowV = row()
            rowV.setPadding(dp(10), dp(8), dp(10), dp(8))
            rowV.addView(text(Pos.name(p.pos), 10.5f, Theme.FAINT, Theme.DISPLAY), lp(dp(38), WRAP))
            val col = column()
            col.addView(playerName(p), lp(MATCH, WRAP))
            col.addView(text("${p.age} \u00B7 ${p.personality}", 10.5f, Theme.FAINT), lp(MATCH, WRAP))
            rowV.addView(col, lp(0, WRAP, 1f))
            // a band, not a number: how wide it is depends on the chief scout
            rowV.addView(text(car.reportedOverall(p), 13f, Theme.GOLD, Theme.DATA, 0f,
                Gravity.CENTER), lp(dp(64), WRAP))
            rowV.addView(text(car.reportedPotential(p), 12f, Theme.MUTED, Theme.DATA, 0f,
                Gravity.CENTER), lp(dp(64), WRAP))
            rowV.isClickable = true
            rowV.setOnClickListener { selectedPlayer = p.id; screen = SCR_PLAYER; renderShell() }
            reports.add(rowV)
        }
        rightCol.addView(reports, lp(MATCH, WRAP))
        return twoColumn(leftCol, rightCol, 1f, 1.6f)
    }

    /* -------------------------------------------------------------- WORLD */

    private fun screenWorld(): View {
        val w = world!!
        val s2 = season!!
        val car = career!!

        val leftCol = column()
        val wire = panel("Transfer wire")
        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(5), dp(8), dp(5))
        head.addView(text("PLAYER", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.5f))
        head.addView(text("FROM", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.2f))
        head.addView(text("TO", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.2f))
        head.addView(text("FEE", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.END), lp(dp(72), WRAP))
        wire.add(head)

        if (car.transferLog.isEmpty()) {
            wire.add(text("The window has been quiet so far.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(12), dp(10), dp(12)) })
        }
        var alt = false
        for (d in car.transferLog.take(28)) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            val nameCol = column()
            val nm = row()
            nm.addView(posTag(d.pos), lp(dp(34), WRAP))
            nm.addView(text("  ${d.player}", 12f, Theme.TEXT))
            nameCol.addView(nm, lp(WRAP, WRAP))
            nameCol.addView(text("${d.age}y \u00B7 ${d.rating} rated \u00B7 S${d.season} W${d.week}", 10f, Theme.FAINT))
            r.addView(nameCol, lp(0, WRAP, 1.5f))
            r.addView(text(d.from, 11f, Theme.MUTED), lp(0, WRAP, 1.2f))
            r.addView(text(d.to, 11f, Theme.TEXT), lp(0, WRAP, 1.2f))
            r.addView(text(Fmt.money(d.fee), 11.5f,
                if (d.fee > 20_000_000L) Theme.GOLD else Theme.MUTED, Theme.DATA, 0f, Gravity.END), lp(dp(72), WRAP))
            wire.add(r)
        }
        leftCol.addView(wire, lp(MATCH, WRAP))

        val rightCol = column()
        val news = panel("Around the game")
        if (car.worldNews.isEmpty()) {
            news.add(text("Nothing much happening elsewhere yet.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(12), dp(10), dp(12)) })
        }
        for (n in car.worldNews.take(16)) {
            val block = column()
            block.setPadding(dp(10), dp(8), dp(10), dp(8))
            val h2 = row()
            h2.addView(text(n.icon, 13f, Theme.GOLD))
            h2.addView(text("  ${n.headline}", 12.5f, Theme.TEXT, Theme.BODY_MED), lp(0, WRAP, 1f))
            h2.addView(text("S${n.season} W${n.week}", 10f, Theme.FAINT, Theme.DATA))
            block.addView(h2, lp(MATCH, WRAP))
            block.addView(text(n.detail, 11.5f, Theme.MUTED))
            news.add(block)
            news.add(hairline())
        }
        rightCol.addView(news, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val golden = panel("Leading scorers \u00B7 all divisions")
        val top = s2.topScorers(-1, 10)
        for (i in top.indices) {
            val pl = top[i]
            val r = row()
            r.setPadding(dp(8), dp(5), dp(8), dp(5))
            if (i % 2 == 1) r.setBackgroundColor(Theme.PANEL_ALT)
            r.addView(text("${i + 1}", 11f, Theme.FAINT, Theme.DATA), lp(dp(20), WRAP))
            val col = column()
            col.addView(playerName(pl, 12f))
            col.addView(text("${w.club(pl.clubId)?.name ?: ""} \u00B7 ${Names.byCode(pl.nation).flag}", 10f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(text(pl.goals.toString(), 13f, Theme.GOLD, Theme.DATA))
            golden.add(r)
        }
        rightCol.addView(golden, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val euro = panel("European leagues")
        for (fl in w.foreignLeagues) {
            val clubs = w.clubs.filter { it.foreignLeague == fl.id }
            if (clubs.isEmpty()) continue
            val best = clubs.maxByOrNull { it.reputation }
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            r.addView(text(Names.byCode(fl.nationCode).flag, 14f, Theme.TEXT), lp(dp(28), WRAP))
            val col2 = column()
            col2.addView(text(fl.name, 12.5f, Theme.TEXT, Theme.BODY_MED))
            col2.addView(text("${clubs.size} clubs \u00B7 strongest: ${best?.name ?: ""}", 10.5f, Theme.MUTED))
            r.addView(col2, lp(0, WRAP, 1f))
            r.addView(text("${clubs.map { w.squadRating(it) }.average().toInt()}", 13f,
                Theme.ratingColor(clubs.map { w.squadRating(it) }.average().toInt()), Theme.DATA))
            r.isClickable = true
            r.setOnClickListener { showForeignLeague(fl.id) }
            euro.add(r)
        }
        rightCol.addView(euro, lp(MATCH, WRAP))

        return twoColumn(leftCol, rightCol, 1.25f, 1f)
    }

    private fun showForeignLeague(id: Int) {
        val w = world!!
        val fl = w.foreignLeagues.firstOrNull { it.id == id } ?: return
        val clubs = w.clubs.filter { it.foreignLeague == id }.sortedByDescending { it.reputation }
        val p = panel("${Names.byCode(fl.nationCode).flag}  ${fl.name}")
        lateinit var holder: FrameLayout
        for (c in clubs) {
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            r.addView(crest(c, 26))
            val col = column()
            col.setPadding(dp(9), 0, dp(9), 0)
            col.addView(text(c.name, 12.5f, Theme.TEXT))
            col.addView(text("${c.stadiumName} \u00B7 ${c.capacity} \u00B7 rep ${c.reputation}", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(stars(ratingToHalves(w.squadRating(c)), 12), lp(WRAP, WRAP).also { it.rightMargin = dp(8) })
            r.addView(text(Fmt.money(c.balance), 11.5f, Theme.GOLD, Theme.DATA))
            r.isClickable = true
            r.setOnClickListener { stage.removeView(holder); showClubSquad(c) }
            p.add(r)
        }
        val closeRow = row()
        closeRow.setPadding(dp(10), dp(8), dp(10), dp(12))
        val close = actionButton("Back", true)
        close.setOnClickListener { stage.removeView(holder) }
        closeRow.addView(close, lp(0, WRAP, 1f))
        p.add(closeRow)
        holder = overlay(p, 520)
    }

    private fun showClubSquad(c: Club) {
        val w = world!!
        val p = panel("${c.name} \u00B7 squad")
        lateinit var holder: FrameLayout
        var alt = false
        for (pl in w.squadOf(c).sortedByDescending { it.overall() }) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(posTag(pl.pos), lp(dp(36), WRAP))
            val col = column()
            col.addView(playerName(pl, 12.5f))
            col.addView(text("${pl.age}y \u00B7 ${Names.byCode(pl.nation).flag} \u00B7 ${pl.role}", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(text(Fmt.money(pl.value()), 11.5f, Theme.GOLD, Theme.DATA),
                lp(WRAP, WRAP).also { it.rightMargin = dp(10) })
            val o = pl.overall()
            r.addView(tag(o.toString(), Theme.ratingColor(o), 0xFF14162B.toInt()))
            r.isClickable = true
            r.setOnClickListener { stage.removeView(holder); selectedPlayer = pl.id; screen = SCR_PLAYER; renderShell() }
            p.add(r)
        }
        val closeRow = row()
        closeRow.setPadding(dp(10), dp(8), dp(10), dp(12))
        val close = actionButton("Back", true)
        close.setOnClickListener { stage.removeView(holder) }
        closeRow.addView(close, lp(0, WRAP, 1f))
        p.add(closeRow)
        holder = overlay(p, 540)
    }

    /* --------------------------------------------------- TRAINING & YOUTH */

    private fun screenTraining(): View {
        val w = world!!
        val car = career!!
        val c = w.userClub!!

        val leftCol = column()

        val focusPanel = panel("Weekly training focus")
        for (f in Training.ALL) {
            val r = row()
            r.setPadding(dp(10), dp(8), dp(10), dp(8))
            val on = car.trainingFocus == f.id
            if (on) r.setBackgroundColor(0x30E0447C)
            val col = column()
            col.addView(text(f.label, 13.5f, if (on) Theme.GOLD else Theme.TEXT, Theme.BODY_MED))
            col.addView(text(f.desc, 11f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            if (on) r.addView(tag("ACTIVE", Theme.HILITE, 0xFFFFFFFF.toInt()))
            r.isClickable = true
            r.setOnClickListener { car.trainingFocus = f.id; renderScreen() }
            focusPanel.add(r)
            focusPanel.add(hairline())
        }
        leftCol.addView(focusPanel, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val intensityPanel = panel("Intensity")
        val ir = row()
        ir.setPadding(dp(10), dp(10), dp(10), dp(6))
        for (i in Training.INTENSITY.indices) {
            val ch = chip(Training.INTENSITY[i], car.intensity == i)
            ch.setOnClickListener { car.intensity = i; renderScreen() }
            val lpx = lp(WRAP, WRAP); lpx.rightMargin = dp(6)
            ir.addView(ch, lpx)
        }
        intensityPanel.add(ir)
        val note = text(
            when (car.intensity) {
                0 -> "Light work. Fitness recovers fastest, development is slow."
                2 -> "Hard sessions. Players improve quicker but tire and pick up knocks."
                else -> "A balanced week of work."
            }, 11.5f, Theme.MUTED
        )
        note.setPadding(dp(10), 0, dp(10), dp(10))
        intensityPanel.add(note)
        leftCol.addView(intensityPanel, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        val mgr = panel("Manager reputation")
        val repRow = row()
        repRow.setPadding(dp(10), dp(10), dp(10), dp(6))
        repRow.addView(text(w.managerName, 15f, Theme.TEXT, Theme.DISPLAY), lp(0, WRAP, 1f))
        repRow.addView(text("${w.managerRep}", 22f, Theme.GOLD, Theme.DATA))
        mgr.add(repRow)
        val bar = BarView(this, w.managerRep, 100)
        val barHolder = column()
        barHolder.setPadding(dp(10), 0, dp(10), dp(10))
        barHolder.addView(bar, lp(MATCH, dp(7)))
        mgr.add(barHolder)
        mgr.add(kv("Standing", when {
            w.managerRep >= 80 -> "Elite \u2014 the biggest clubs are watching"
            w.managerRep >= 60 -> "Well regarded across the divisions"
            w.managerRep >= 40 -> "Building a name"
            w.managerRep >= 22 -> "Unproven"
            else -> "Unknown"
        }))
        mgr.add(kv("Record", "${w.managerP}P  ${w.managerW}W  ${w.managerD}D  ${w.managerL}L"))
        mgr.add(kv("Win rate", if (w.managerP > 0) "${w.managerW * 100 / w.managerP}%" else "\u2014"))
        mgr.add(kv("Seasons in charge", w.seasonsManaged.toString()))
        leftCol.addView(mgr, lp(MATCH, WRAP))

        /* --- academy --- */
        val rightCol = column()
        val youth = w.squadOf(c).filter { it.age <= 21 }.sortedByDescending { it.potential }
        val academy = panel("Academy \u00B7 ${youth.size} prospects")

        val head = row()
        head.setBackgroundColor(Theme.PANEL_ALT)
        head.setPadding(dp(8), dp(5), dp(8), dp(5))
        head.addView(text("POS", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(dp(38), WRAP))
        head.addView(text("NAME", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f), lp(0, WRAP, 1.4f))
        head.addView(text("AGE", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(34), WRAP))
        head.addView(text("NOW", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(38), WRAP))
        head.addView(text("CEILING", 9.5f, Theme.FAINT, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(dp(90), WRAP))
        academy.add(head)

        if (youth.isEmpty()) {
            academy.add(text("No youngsters in the squad. Intake happens each pre-season.",
                12f, Theme.MUTED).also { it.setPadding(dp(10), dp(12), dp(10), dp(12)) })
        }
        var alt = false
        for (pl in youth) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(posTag(pl.pos), lp(dp(38), WRAP))
            val col = column()
            val nm = row()
            nm.addView(playerName(pl, 12.5f))
            if (pl.hasTrait(Traits.WONDERKID)) nm.addView(text("  \u2726", 11f, Theme.GOLD))
            col.addView(nm, lp(WRAP, WRAP))
            col.addView(text("${pl.role}  \u00B7  ${Names.byCode(pl.nation).flag}", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1.4f))
            r.addView(text(pl.age.toString(), 12f, Theme.MUTED, Theme.DATA, 0f, Gravity.CENTER), lp(dp(34), WRAP))
            val o = pl.overall()
            r.addView(tag(o.toString(), Theme.ratingColor(o), 0xFF14162B.toInt()), lp(dp(38), WRAP))
            // ceiling shown as stars so a raw number never spoils the surprise
            val ceiling = ((pl.potential - 40).coerceIn(0, 57) * 10 / 57)
            r.addView(stars(ceiling, 12), lp(dp(90), WRAP))
            r.isClickable = true
            r.setOnClickListener { selectedPlayer = pl.id; screen = SCR_PLAYER; renderShell() }
            academy.add(r)
        }
        rightCol.addView(academy, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val developing = panel("Best improvers this season")
        val improvers = w.squadOf(c)
            .filter { it.age <= 26 && it.potential > it.overall() }
            .sortedByDescending { it.potential - it.overall() }
            .take(8)
        if (improvers.isEmpty()) {
            developing.add(text("Nobody with room to grow right now.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(10), dp(12), dp(10), dp(12)) })
        }
        for (pl in improvers) {
            val r = row()
            r.setPadding(dp(10), dp(6), dp(10), dp(6))
            val col = column()
            col.addView(playerName(pl, 12.5f))
            col.addView(text("${pl.age}y  \u00B7  ${pl.overall()} now, ${pl.potential} ceiling", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(text("+${pl.potential - pl.overall()}", 14f, Theme.GREEN, Theme.DATA))
            developing.add(r)
        }
        rightCol.addView(developing, lp(MATCH, WRAP))

        return twoColumn(leftCol, rightCol, 1f, 1.3f)
    }

    /* ------------------------------------------------------------- INBOX */

    private fun screenInbox(): View {
        val car = career!!
        val outer = column(10)
        val p = panel("Inbox \u00B7 ${car.inbox.size} messages")
        if (car.inbox.isEmpty()) {
            p.add(text("Nothing here yet.", 12.5f, Theme.MUTED).also { it.setPadding(dp(12), dp(14), dp(12), dp(14)) })
        }
        for (m in car.inbox) {
            m.read = true
            val block = column()
            block.setPadding(dp(10), dp(9), dp(10), dp(9))
            val head = row()
            head.addView(text(m.icon, 14f, Theme.GOLD))
            val t = text("  ${m.subject}", 13f, Theme.TEXT, Theme.BODY_MED)
            head.addView(t, lp(0, WRAP, 1f))
            head.addView(text("S${m.season} W${m.week}", 10.5f, Theme.FAINT, Theme.DATA))
            block.addView(head, lp(MATCH, WRAP))
            block.addView(text(m.from, 11f, Theme.MUTED))
            block.addView(spacer(4))
            block.addView(text(m.body, 12f, Theme.MUTED))

            if (m.offerId >= 0) {
                val actions = row()
                actions.setPadding(0, dp(8), 0, 0)
                val accept = actionButton("Accept")
                accept.setOnClickListener {
                    val r = car.acceptOffer(m.offerId); toast(r.message); renderShell()
                }
                val reject = subtleButton("Reject")
                reject.setOnClickListener { car.rejectOffer(m.offerId); renderShell() }
                actions.addView(accept, lp(WRAP, WRAP).also { it.rightMargin = dp(8) })
                actions.addView(reject)
                block.addView(actions, lp(MATCH, WRAP))
            }
            p.add(block)
            p.add(hairline())
        }
        val sc = ScrollView(this)
        val holder = column(); holder.addView(p, lp(MATCH, WRAP))
        sc.addView(holder, lp(MATCH, WRAP))
        outer.addView(sc, lp(MATCH, 0, 1f))
        return outer
    }

    /* ----------------------------------------------------------- ACTIONS */

    private fun onContinue() {
        val s = season ?: return
        val car = career ?: return
        if (s.nextUserFixture() == null) { rollSeason(); return }
        // Walk through the days first. Only when the week's work is done does
        // the next fixture come round, so there is a build up to a match rather
        // than one button that skips a week.
        if (!car.onMatchDay) {
            val sacked = car.advanceDay()
            autosave()
            if (sacked) {
                screen = SCR_HUB
                renderShell()
                toast("The board have dismissed you.")
            } else {
                showBriefing()
            }
            return
        }
        playNextMatch()
    }

    /* ------------------------------------------------------- LIVE MATCH */

    private fun playNextMatch() {
        val w = world ?: return
        val s = season ?: return
        val fx = s.nextUserFixture() ?: return
        engine = MatchEngine(w, s, fx)
        matchAudio?.stop()
        matchAudio = MatchAudio(w.seed + fx.id).also {
            it.enabled = soundOn
            it.start()
        }
        lastFeedSize = -1
        screen = SCR_MATCH
        renderShell()
        startLoop()
    }

    private fun buildMatchScreen(): View {
        val e = engine ?: return View(this)
        val outer = column()

        scoreHost = row()
        scoreHost!!.setBackgroundColor(0xFF191B33.toInt())
        scoreHost!!.setPadding(dp(10), dp(6), dp(10), dp(6))
        outer.addView(scoreHost, lp(MATCH, WRAP))
        paintScore()

        val middle = row()
        middle.gravity = Gravity.TOP

        val mv = MatchView(this, e)
        matchView = mv
        middle.addView(mv, lp(0, MATCH, 2.05f))

        val side = column()
        side.setBackgroundColor(Theme.PANEL)
        val feedTitle = text("COMMENTARY", 11f, Theme.MUTED, Theme.DISPLAY, 0.10f, Gravity.CENTER)
        feedTitle.setBackgroundColor(Theme.PANEL_HEAD)
        feedTitle.setPadding(dp(6), dp(6), dp(6), dp(6))
        side.addView(feedTitle, lp(MATCH, WRAP))

        feedHost = column()
        lastFeedSize = -1
        val feedScroll = ScrollView(this)
        feedScroll.addView(feedHost, lp(MATCH, WRAP))
        side.addView(feedScroll, lp(MATCH, 0, 1f))
        middle.addView(side, lp(0, MATCH, 1f))

        outer.addView(middle, lp(MATCH, 0, 1f))

        controlHost = row()
        controlHost!!.setBackgroundColor(0xFF191B33.toInt())
        controlHost!!.setPadding(dp(8), dp(6), dp(8), dp(6))
        outer.addView(controlHost, lp(MATCH, WRAP))
        paintControls()
        paintFeed()
        return outer
    }

    private fun paintScore() {
        val e = engine ?: return
        val host = scoreHost ?: return
        host.removeAllViews()

        host.addView(crest(e.home, 26))
        host.addView(text("  ${e.home.name}", 14f, Theme.TEXT, Theme.DISPLAY, 0.02f), lp(0, WRAP, 1f))

        val mid = column()
        mid.gravity = Gravity.CENTER_HORIZONTAL
        mid.addView(text("${e.score[0]}  \u2013  ${e.score[1]}", 22f, Theme.TEXT, Theme.DATA, 0f, Gravity.CENTER), lp(WRAP, WRAP))
        val clockText = when {
            e.finished -> "FULL TIME"
            !e.running && e.half == 2 && e.clock >= 45.0 -> "HALF TIME"
            else -> "${minOf(e.clock.toInt(), 90)}'"
        }
        mid.addView(text(clockText, 11f, Theme.GOLD, Theme.DISPLAY, 0.08f, Gravity.CENTER), lp(WRAP, WRAP))
        host.addView(mid)

        val away = text("${e.away.name}  ", 14f, Theme.TEXT, Theme.DISPLAY, 0.02f, Gravity.END)
        host.addView(away, lp(0, WRAP, 1f))
        host.addView(crest(e.away, 26))
    }

    private fun paintFeed() {
        val e = engine ?: return
        val host = feedHost ?: return
        if (lastFeedSize == e.feed.size) return
        lastFeedSize = e.feed.size
        host.removeAllViews()
        for (line in e.feed.take(30)) {
            val r = row()
            r.setPadding(dp(7), dp(4), dp(7), dp(4))
            r.addView(text("${line.minute}'", 10.5f, Theme.FAINT, Theme.DATA), lp(dp(26), WRAP))
            val colour = when (line.kind) {
                FeedLine.GOAL -> Theme.GOLD
                FeedLine.CARD -> Theme.RED
                FeedLine.CHANCE -> Theme.TEXT
                FeedLine.SUB -> Theme.BLUE
                FeedLine.WHISTLE -> Theme.GREEN
                else -> Theme.MUTED
            }
            val face = if (line.kind == FeedLine.GOAL) Theme.BODY_MED else Theme.BODY
            r.addView(text(line.text, 11.5f, colour, face), lp(0, WRAP, 1f))
            host.addView(r, lp(MATCH, WRAP))
        }
    }

    private fun paintControls() {
        val e = engine ?: return
        val host = controlHost ?: return
        host.removeAllViews()

        fun btn(labelText: String, action: () -> Unit) {
            val b = subtleButton(labelText)
            b.setOnClickListener { action() }
            val p = lp(0, WRAP, 1f); p.rightMargin = dp(6)
            host.addView(b, p)
        }

        if (e.finished) {
            val done = actionButton("Full time report", true)
            done.setOnClickListener { finishMatch() }
            host.addView(done, lp(0, WRAP, 1f))
            return
        }

        btn(if (e.running) "\u2016  Pause" else "\u25B6  Play") {
            if (e.running) { e.pause(); stopLoop() } else { e.start(); startLoop() }
            paintControls()
        }
        btn("${e.speed.toInt()}\u00D7") {
            e.speed = when (e.speed) { 1f -> 2f; 2f -> 4f; else -> 1f }
            paintControls()
        }
        btn("Zoom ${if ((matchView?.zoom ?: 2.7f) > 3.1f) "Tight" else if ((matchView?.zoom ?: 2.7f) > 2.2f) "Close" else "Wide"}") {
            val mv = matchView ?: return@btn
            mv.zoom = when { mv.zoom < 2.2f -> 2.7f; mv.zoom < 3.1f -> 3.6f; else -> 1.9f }
            paintControls()
        }
        btn("Pixels ${matchView?.pixelWidth ?: 384}") {
            val mv = matchView ?: return@btn
            mv.pixelWidth = when (mv.pixelWidth) {
                256 -> 320; 320 -> 384; 384 -> 512; else -> 256
            }
            paintControls()
        }
        btn(if (soundOn) "\uD83D\uDD0A Sound" else "\uD83D\uDD07 Muted") {
            soundOn = !soundOn
            matchAudio?.enabled = soundOn
            paintControls()
        }
        btn("Shout") { showShouts() }
        btn("Stats") { showMatchStats(false) }
        btn("Dugout") { showDugout() }
        btn("Skip to end") {
            stopLoop()
            e.skipToEnd()
            paintScore(); paintFeed(); paintControls()
            matchView?.invalidate()
        }
    }

    private fun startLoop() {
        val e = engine ?: return
        e.start()
        lastFrame = System.nanoTime()
        loopHandler.removeCallbacksAndMessages(null)
        loopHandler.post(object : Runnable {
            override fun run() {
                val cur = engine ?: return
                val now = System.nanoTime()
                val dt = ((now - lastFrame) / 1_000_000_000.0f).coerceAtMost(0.05f)
                lastFrame = now
                if (cur.running) cur.update(dt)

                // hand whatever the engine reported to the mixer
                matchAudio?.let { audio ->
                    if (cur.sound.isNotEmpty()) {
                        for (c in cur.sound) audio.play(c.kind, c.gain, c.pan)
                    }
                    audio.crowd(cur.crowdTarget)
                }
                cur.sound.clear()

                // the replay advances inside update(); nothing to drive here
                matchView?.invalidate()
                paintScore()
                paintFeed()
                if (!cur.running && !cur.finished) { paintControls(); halfTime(); return }
                if (cur.finished) { paintControls(); return }
                loopHandler.postDelayed(this, 28L)
            }
        })
    }

    private fun stopLoop() = loopHandler.removeCallbacksAndMessages(null)

    private fun halfTime() {
        val e = engine ?: return
        if (e.half != 2 || e.clock > 46.0) return
        val w = world ?: return
        val c = w.userClub ?: return
        val side = if (e.home.isUser) 0 else 1
        val mine = e.score[side]
        val theirs = e.score[1 - side]

        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())

        val panel = panel("Half time  \u00B7  ${e.home.shortName} ${e.score[0]} \u2013 ${e.score[1]} ${e.away.shortName}")
        panel.add(kv("Possession", "${e.possessionHome}%  \u2013  ${100 - e.possessionHome}%"))
        panel.add(kv("Shots (on target)", "${e.shots[0]} (${e.onTarget[0]})  \u2013  ${e.shots[1]} (${e.onTarget[1]})"))
        panel.add(kv("Expected goals", "${Fmt.rating(e.xg[0])}  \u2013  ${Fmt.rating(e.xg[1])}"))
        panel.add(hairline())

        val head = text("TEAM TALK", 11f, Theme.MUTED, Theme.DISPLAY, 0.10f, Gravity.CENTER)
        head.setPadding(dp(8), dp(9), dp(8), dp(5))
        panel.add(head)

        var chosenTalk = -1
        val talkRow = row()
        talkRow.setPadding(dp(8), 0, dp(8), dp(8))
        val talks = arrayOf("Encourage", "Assertive", "Demand more", "Fury")
        val chips = ArrayList<TextView>()
        for (i in talks.indices) {
            val ch = chip(talks[i], false)
            ch.setOnClickListener {
                chosenTalk = i
                for (j in chips.indices) {
                    val on = j == i
                    chips[j].background = boxBg(
                        if (on) Theme.ACCENT else Theme.PANEL_HEAD,
                        if (on) Theme.ACCENT_DARK else Theme.BORDER, dp(4)
                    )
                    chips[j].setTextColor(if (on) 0xFFFFFFFF.toInt() else Theme.MUTED)
                }
                applyTeamTalk(c, i, mine, theirs)
                e.refreshRatings()
            }
            chips.add(ch)
            val lpx = lp(0, WRAP, 1f); lpx.rightMargin = dp(5)
            talkRow.addView(ch, lpx)
        }
        panel.add(talkRow)
        panel.add(hairline())

        // three clear ways out of this screen
        val actions = column()
        actions.setPadding(dp(10), dp(10), dp(10), dp(12))

        val tacticsBtn = subtleButton("Change tactics and substitutions")
        tacticsBtn.setOnClickListener {
            stage.removeView(holder)
            showDugout()
        }
        actions.addView(tacticsBtn, lp(MATCH, WRAP))
        actions.addView(spacer(8))

        val statsBtn = subtleButton("Full match statistics")
        statsBtn.setOnClickListener { showMatchStats(false) }
        actions.addView(statsBtn, lp(MATCH, WRAP))
        actions.addView(spacer(8))

        val resume = actionButton("Kick off the second half", true)
        resume.setOnClickListener {
            stage.removeView(holder)
            startLoop()
            paintControls()
        }
        actions.addView(resume, lp(MATCH, WRAP))
        panel.add(actions)

        val wrap = column(16)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(panel, lp(dp(440), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /**
     * Touchline shouts: one tap, immediate effect, no menus. What you can say
     * depends on how the game is going, the way it would from a real dugout.
     */
    private fun showShouts() {
        val e = engine ?: return
        val w = world ?: return
        val c = w.userClub ?: return
        val side = if (e.home.isUser) 0 else 1
        val mine = e.score[side]
        val theirs = e.score[1 - side]
        val t = c.tactics
        val wasRunning = e.running
        e.pause(); stopLoop()

        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())
        val p = panel("From the touchline")

        class Shout(val name: String, val note: String, val act: () -> String)
        val shouts = ArrayList<Shout>()

        shouts.add(Shout("Push them forward", "Take the game to them") {
            if (t.mentality < 4) t.mentality++
            if (t.line < 2) t.line++
            "The line pushes up."
        })
        shouts.add(Shout("Tighten up", "Protect what you have") {
            if (t.mentality > 0) t.mentality--
            if (t.line > 0) t.line--
            t.tackling = 0
            "They drop off and get compact."
        })
        shouts.add(Shout("Get it wide", "Stretch their back line") {
            t.width = 2; t.focus = 3
            "The wingers hold the touchline."
        })
        shouts.add(Shout("Through the middle", "Play between the lines") {
            t.width = 0; t.focus = 1
            "They narrow the play."
        })
        shouts.add(Shout("Press them", "Win it back high") {
            t.press = 2
            "The front line starts hunting."
        })
        shouts.add(Shout("Slow it down", "Take the sting out") {
            t.tempo = 0; t.timeWasting = 2
            "They take their time on everything."
        })
        if (mine < theirs) shouts.add(Shout("Throw everyone up", "Nothing to lose") {
            t.mentality = 4; t.line = 2; t.press = 2; t.counter = false
            "Everybody forward."
        })
        if (mine > theirs) shouts.add(Shout("See it out", "Kill the game") {
            t.mentality = 0; t.line = 0; t.timeWasting = 2; t.tackling = 0
            "Eleven behind the ball."
        })

        for (sh in shouts) {
            val r = row()
            r.setPadding(dp(12), dp(10), dp(12), dp(10))
            val col = column()
            col.addView(text(sh.name, 13.5f, Theme.TEXT, Theme.BODY_MED))
            col.addView(text(sh.note, 11f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.isClickable = true
            r.setOnClickListener {
                val said = sh.act()
                e.refreshRatings()
                for (id in c.squad) w.player(id)?.let { it.morale = (it.morale + 1.5).coerceAtMost(99.0) }
                toast(said)
                stage.removeView(holder)
                if (wasRunning) startLoop()
                paintControls()
            }
            p.add(r)
            p.add(hairline())
        }

        val cancelRow = row()
        cancelRow.setPadding(dp(12), dp(10), dp(12), dp(14))
        val cancel = subtleButton("Say nothing")
        cancel.setOnClickListener {
            stage.removeView(holder)
            if (wasRunning) startLoop()
            paintControls()
        }
        cancelRow.addView(cancel, lp(0, WRAP, 1f))
        p.add(cancelRow)

        val wrap = column(16)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(p, lp(dp(430), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Live statistics, reachable at any point in the match. */
    private fun showMatchStats(atFullTime: Boolean) {
        val e = engine ?: return
        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())

        val col = column()
        val p = panel("${e.home.name}  ${e.score[0]} \u2013 ${e.score[1]}  ${e.away.name}")

        fun bar(labelText: String, hv: Float, av: Float, fmt: (Float) -> String) {
            val block = column()
            block.setPadding(dp(12), dp(7), dp(12), dp(7))
            val top = row()
            top.addView(text(fmt(hv), 12.5f, Theme.TEXT, Theme.DATA), lp(dp(64), WRAP))
            top.addView(text(labelText.uppercase(), 10.5f, Theme.MUTED, Theme.DISPLAY, 0.08f, Gravity.CENTER),
                lp(0, WRAP, 1f))
            top.addView(text(fmt(av), 12.5f, Theme.TEXT, Theme.DATA, 0f, Gravity.END), lp(dp(64), WRAP))
            block.addView(top, lp(MATCH, WRAP))
            val total = kotlin.math.max(0.001f, hv + av)
            val split = row()
            split.setPadding(0, dp(4), 0, 0)
            val left = View(this); left.setBackgroundColor(e.home.primary)
            val right = View(this); right.setBackgroundColor(e.away.primary)
            split.addView(left, lp(0, dp(7), hv / total))
            val gap = View(this); gap.layoutParams = lp(dp(3), dp(7))
            split.addView(gap)
            split.addView(right, lp(0, dp(7), av / total))
            block.addView(split, lp(MATCH, WRAP))
            p.add(block)
        }

        bar("Possession", e.possessionHome.toFloat(), (100 - e.possessionHome).toFloat()) { "${it.toInt()}%" }
        bar("Shots", e.shots[0].toFloat(), e.shots[1].toFloat()) { it.toInt().toString() }
        bar("On target", e.onTarget[0].toFloat(), e.onTarget[1].toFloat()) { it.toInt().toString() }
        bar("Expected goals", e.xg[0].toFloat(), e.xg[1].toFloat()) { Fmt.rating(it.toDouble()) }
        bar("Passes", e.passesTotal[0].toFloat(), e.passesTotal[1].toFloat()) { it.toInt().toString() }
        bar("Take-ons", e.takeOns(0).toFloat(), e.takeOns(1).toFloat()) { it.toInt().toString() }
        bar("Corners", e.corners[0].toFloat(), e.corners[1].toFloat()) { it.toInt().toString() }
        bar("Fouls", e.fouls[0].toFloat(), e.fouls[1].toFloat()) { it.toInt().toString() }
        bar("Yellow cards", e.yellows[0].toFloat(), e.yellows[1].toFloat()) { it.toInt().toString() }
        bar("Red cards", e.reds[0].toFloat(), e.reds[1].toFloat()) { it.toInt().toString() }
        col.addView(p, lp(MATCH, WRAP))
        col.addView(spacer(10))

        // every goal, card and change, in order
        val timeline = panel("Match events")
        if (e.events.isEmpty()) {
            timeline.add(text("Nothing of note yet.", 12f, Theme.MUTED)
                .also { it.setPadding(dp(12), dp(12), dp(12), dp(12)) })
        }
        for (ev in e.events) {
            val r = row()
            r.setPadding(dp(12), dp(6), dp(12), dp(6))
            r.addView(text("${ev.minute}'", 11.5f, Theme.FAINT, Theme.DATA), lp(dp(34), WRAP))
            val icon = when (ev.type) {
                Ev.GOAL -> "\u26BD"; Ev.YELLOW -> "\u25A0"; Ev.RED -> "\u25A0"
                Ev.SUB -> "\u21C4"; else -> "\u2695"
            }
            val colour = when (ev.type) {
                Ev.GOAL -> Theme.GOLD; Ev.YELLOW -> 0xFFD9C26A.toInt()
                Ev.RED -> Theme.RED; Ev.SUB -> Theme.BLUE; else -> Theme.MUTED
            }
            r.addView(text(icon, 12f, colour), lp(dp(22), WRAP))
            val txt = if (ev.type == Ev.SUB) "${ev.player} on for ${ev.extra}"
            else if (ev.type == Ev.GOAL && ev.extra.isNotEmpty()) "${ev.player}  (${ev.extra})"
            else ev.player
            r.addView(text(txt, 12.5f, Theme.TEXT), lp(0, WRAP, 1f))
            r.addView(text(if (ev.side == 0) e.home.shortName else e.away.shortName,
                11f, Theme.MUTED, Theme.DISPLAY), lp(WRAP, WRAP))
            timeline.add(r)
        }
        col.addView(timeline, lp(MATCH, WRAP))
        col.addView(spacer(10))

        val closeRow = row()
        closeRow.setPadding(dp(10), 0, dp(10), dp(14))
        val close = actionButton("Back", true)
        close.setOnClickListener { stage.removeView(holder) }
        closeRow.addView(close, lp(0, WRAP, 1f))
        col.addView(closeRow, lp(MATCH, WRAP))

        val wrap = column(14)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(col, lp(dp(520), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun applyTeamTalk(c: Club, talk: Int, mine: Int, theirs: Int) {
        val w = world ?: return
        val winning = mine > theirs
        val losing = mine < theirs
        val delta = when (talk) {
            0 -> if (losing) 3.0 else 1.0
            1 -> 2.0
            2 -> if (mine == theirs) 4.0 else if (winning) -1.0 else 2.0
            else -> if (losing) (if (Math.random() < 0.55) 8.0 else -8.0) else -5.0
        }
        for (id in c.squad) {
            val p = w.player(id) ?: continue
            p.morale = (p.morale + delta * 0.6).coerceIn(8.0, 99.0)
        }
        c.morale = (c.morale + delta * 0.5).coerceIn(10.0, 99.0)
        toast(if (delta > 3) "They responded to that." else if (delta < -3) "That did not land well." else "Message delivered.")
    }

    /**
     * The dugout: one scrolling column so nothing is ever cut off on a phone.
     * Substitutions at the top, instructions below, one way back out.
     */
    private fun showDugout() {
        val e = engine ?: return
        val w = world ?: return
        val c = w.userClub ?: return
        val side = if (e.home.isUser) 0 else 1
        val wasRunning = e.running
        e.pause(); stopLoop()

        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())
        val col = column()

        // --- who is on --------------------------------------------------
        val onPitch = panel("Substitutions  \u00B7  ${e.subsLeft[side]} left")
        val hint = text("Tap a player to take him off.", 11.5f, Theme.MUTED)
        hint.setPadding(dp(12), dp(8), dp(12), dp(4))
        onPitch.add(hint)
        var alt = false
        for (p2 in e.onPitch(side).sortedBy { Pos.group(it.pos) }) {
            val r = row()
            r.setPadding(dp(10), dp(7), dp(10), dp(7))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(posTag(p2.pos), lp(dp(38), WRAP))
            val info = column()
            info.addView(playerName(p2.ref, 13f))
            val bits = StringBuilder()
            bits.append("${p2.minutes.toInt()} mins")
            if (p2.goals > 0) bits.append("  \u00B7  ${p2.goals} goal${if (p2.goals > 1) "s" else ""}")
            if (p2.yellow > 0) bits.append("  \u00B7  booked")
            if (p2.injured) bits.append("  \u00B7  injured")
            info.addView(text(bits.toString(), 10.5f, if (p2.injured) Theme.RED else Theme.MUTED))
            r.addView(info, lp(0, WRAP, 1f))
            val fitCol = if (p2.fitness < 55) Theme.RED else if (p2.fitness < 75) Theme.AMBER else Theme.GREEN
            r.addView(text("${p2.fitness.toInt()}%", 13f, fitCol, Theme.DATA),
                lp(WRAP, WRAP).also { it.rightMargin = dp(10) })
            val off = subtleButton("Off")
            off.setOnClickListener { pickReplacement(e, side, p2.key, holder, wasRunning) }
            r.addView(off)
            onPitch.add(r)
        }
        col.addView(onPitch, lp(MATCH, WRAP))
        col.addView(spacer(10))

        // --- what they are doing ----------------------------------------
        val t = c.tactics
        val instr = panel("Instructions")
        fun opts(labelText: String, values: Array<String>, cur: Int, pick: (Int) -> Unit) {
            val block = column()
            block.setPadding(dp(10), dp(8), dp(10), dp(2))
            block.addView(text(labelText.uppercase(), 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
            block.addView(spacer(4))
            val rowV = LinearLayout(this)
            rowV.orientation = LinearLayout.HORIZONTAL
            for (i in values.indices) {
                val ch = chip(values[i], i == cur)
                ch.setOnClickListener {
                    pick(i)
                    e.refreshRatings()
                    stage.removeView(holder)
                    showDugout()
                }
                val p3 = lp(WRAP, WRAP); p3.rightMargin = dp(5)
                rowV.addView(ch, p3)
            }
            val hsv = HorizontalScrollView(this)
            hsv.isHorizontalScrollBarEnabled = false
            hsv.addView(rowV)
            block.addView(hsv, lp(MATCH, WRAP))
            instr.add(block)
        }
        // shape can be changed without leaving the dugout
        val shapeBlock = column()
        shapeBlock.setPadding(dp(10), dp(8), dp(10), dp(2))
        shapeBlock.addView(text("FORMATION", 10f, Theme.FAINT, Theme.DISPLAY, 0.10f))
        shapeBlock.addView(spacer(4))
        val shapeRow = LinearLayout(this)
        shapeRow.orientation = LinearLayout.HORIZONTAL
        for (shape in Formations.ALL) {
            val ch = chip(shape.name, shape.name == t.formation)
            ch.setOnClickListener {
                t.changeFormation(shape.name)
                w.autoPickSquad(c)
                e.reshape(side)
                e.refreshRatings()
                toast("Switched to ${shape.name}.")
                stage.removeView(holder)
                showDugout()
            }
            val lpx = lp(WRAP, WRAP); lpx.rightMargin = dp(5)
            shapeRow.addView(ch, lpx)
        }
        val shapeScroll = HorizontalScrollView(this)
        shapeScroll.isHorizontalScrollBarEnabled = false
        shapeScroll.addView(shapeRow)
        shapeBlock.addView(shapeScroll, lp(MATCH, WRAP))
        instr.add(shapeBlock)

        opts("Mentality", Instr.MENTALITY, t.mentality) { t.mentality = it }
        opts("Tempo", Instr.TEMPO, t.tempo) { t.tempo = it }
        opts("Passing", Instr.PASSING, t.passing) { t.passing = it }
        opts("Width", Instr.WIDTH, t.width) { t.width = it }
        opts("Defensive line", Instr.LINE, t.line) { t.line = it }
        opts("Pressing", Instr.PRESS, t.press) { t.press = it }
        opts("Tackling", Instr.TACKLING, t.tackling) { t.tackling = it }
        opts("Focus of play", Instr.FOCUS, t.focus) { t.focus = it }
        opts("Time wasting", Instr.TIME, t.timeWasting) { t.timeWasting = it }

        val toggles = row()
        toggles.setPadding(dp(10), dp(8), dp(10), dp(10))
        val counter = chip("Counter-attack", t.counter)
        counter.setOnClickListener {
            t.counter = !t.counter; e.refreshRatings(); stage.removeView(holder); showDugout()
        }
        val trap = chip("Offside trap", t.offsideTrap)
        trap.setOnClickListener {
            t.offsideTrap = !t.offsideTrap; e.refreshRatings(); stage.removeView(holder); showDugout()
        }
        toggles.addView(counter, lp(WRAP, WRAP).also { it.rightMargin = dp(6) })
        toggles.addView(trap)
        instr.add(toggles)
        col.addView(instr, lp(MATCH, WRAP))
        col.addView(spacer(10))

        // --- how it is going ---------------------------------------------
        val quick = panel("How it is going")
        quick.add(kv("Possession", "${e.possessionHome}%  \u2013  ${100 - e.possessionHome}%"))
        quick.add(kv("Shots", "${e.shots[0]}  \u2013  ${e.shots[1]}"))
        quick.add(kv("Expected goals", "${Fmt.rating(e.xg[0])}  \u2013  ${Fmt.rating(e.xg[1])}"))
        val statRow = row()
        statRow.setPadding(dp(10), dp(6), dp(10), dp(10))
        val full = subtleButton("Full statistics")
        full.setOnClickListener { showMatchStats(false) }
        statRow.addView(full, lp(0, WRAP, 1f))
        quick.add(statRow)
        col.addView(quick, lp(MATCH, WRAP))
        col.addView(spacer(12))

        val backRow = row()
        backRow.setPadding(dp(10), 0, dp(10), dp(16))
        val back = actionButton("Back to the match", true)
        back.setOnClickListener {
            stage.removeView(holder)
            if (wasRunning) startLoop()
            paintControls()
        }
        backRow.addView(back, lp(0, WRAP, 1f))
        col.addView(backRow, lp(MATCH, WRAP))

        val wrap = column(14)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(col, lp(dp(520), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun pickReplacement(e: MatchEngine, side: Int, outKey: String, parent: View, wasRunning: Boolean) {
        val bench = if (side == 0) e.benchHome else e.benchAway
        if (e.subsLeft[side] <= 0) { toast("No substitutions left."); return }

        val holder = FrameLayout(this)
        holder.setBackgroundColor(0xE60B0D1C.toInt())
        val p = panel("Bring on")
        for (b in bench) {
            val r = row()
            r.setPadding(dp(10), dp(8), dp(10), dp(8))
            r.addView(posTag(b.pos), lp(dp(36), WRAP))
            val col = column()
            col.addView(playerName(b, 12.5f))
            col.addView(text("${b.role}  \u00B7  ${b.fitness.toInt()}% fit", 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(tag(b.overall().toString(), Theme.ratingColor(b.overall()), 0xFF14162B.toInt()))
            r.isClickable = true
            r.setOnClickListener {
                val ok = e.substitute(side, outKey, b.id)
                toast(if (ok) "Substitution made." else "That change is not possible.")
                stage.removeView(holder)
                stage.removeView(parent)
                paintFeed()
                if (wasRunning) startLoop()
                paintControls()
            }
            p.add(r)
            p.add(hairline())
        }
        val cancelRow = row()
        cancelRow.setPadding(dp(10), dp(8), dp(10), dp(10))
        val cancel = subtleButton("Cancel")
        cancel.setOnClickListener { stage.removeView(holder) }
        cancelRow.addView(cancel, lp(0, WRAP, 1f))
        p.add(cancelRow)

        val wrap = column(20)
        wrap.gravity = Gravity.CENTER_HORIZONTAL
        wrap.addView(p, lp(dp(400), WRAP))
        val sc = ScrollView(this)
        sc.addView(wrap, lp(MATCH, WRAP))
        holder.addView(sc, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun finishMatch() {
        val e = engine ?: return
        val w = world ?: return
        val s = season ?: return
        val car = career ?: return
        val c = w.userClub ?: return
        stopLoop()

        val fx = e.fixture
        e.commit()
        s.simWeek(fx.week, fx.id)

        val home = fx.homeId == c.id
        val mine = if (home) fx.homeGoals else fx.awayGoals
        val theirs = if (home) fx.awayGoals else fx.homeGoals
        w.managerP++
        when {
            mine > theirs -> { w.managerW++; w.managerRep = minOf(100, w.managerRep + 1) }
            mine == theirs -> w.managerD++
            else -> { w.managerL++; w.managerRep = maxOf(1, w.managerRep - 1) }
        }
        // settle whatever the contracts say is owed for this one
        val side = if (home) 0 else 1
        val played = e.players.filter { it.side == side && it.minutes > 0 }.map { it.ref.id }
        val scorers = ArrayList<Int>()
        for (pl in e.players) if (pl.side == side) repeat(pl.goals) { scorers.add(pl.ref.id) }
        car.payMatchBonuses(played, scorers, theirs == 0)

        // the week's work is now spread across the days that follow
        car.resetWeekDays()
        autosave()
        showFullTime(e, false)
    }


    private fun showBriefing() {
        val car = career ?: run { screen = SCR_HUB; renderShell(); return }
        val items = car.briefing()
        if (items.isEmpty()) { screen = SCR_HUB; renderShell(); return }

        stage.removeAllViews()
        val col = column()
        val head = panel(car.dayLabel())
        for (b in items) {
            val rowV = row()
            rowV.setPadding(dp(10), dp(9), dp(10), dp(9))
            if (b.urgent) rowV.background = boxBg(Theme.PANEL_ALT, 0, dp(4))
            rowV.addView(
                text(b.icon, 15f, if (b.urgent) Theme.GOLD else Theme.MUTED, Theme.BODY),
                lp(dp(26), WRAP)
            )
            val txt = column()
            txt.addView(
                text(b.title, 12.5f, if (b.urgent) Theme.TEXT else Theme.MUTED, Theme.BODY_MED),
                lp(MATCH, WRAP)
            )
            txt.addView(text(b.body, 11f, Theme.FAINT), lp(MATCH, WRAP))
            rowV.addView(txt, lp(0, WRAP, 1f))
            head.add(rowV)
        }
        col.addView(head, lp(MATCH, WRAP))
        col.addView(spacer(10))

        val car2 = career!!
        val go = actionButton(
            if (car2.onMatchDay) "To the match" else "On to ${car2.dayLabel()}", true
        )
        go.setOnClickListener { screen = SCR_HUB; renderShell() }
        val r = row(); r.addView(go, lp(0, WRAP, 1f))
        col.addView(r, lp(MATCH, WRAP))

        val sc = ScrollView(this)
        sc.addView(col, lp(MATCH, WRAP))
        val pad = row(); pad.setPadding(dp(10), dp(10), dp(10), dp(10))
        pad.addView(sc, lp(MATCH, MATCH))
        stage.addView(pad, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun showFullTime(e: MatchEngine, sacked: Boolean) {
        val side = if (e.home.isUser) 0 else 1
        stage.removeAllViews()

        val leftCol = column()
        val result = panel("Full time")
        val vs = row()
        vs.setPadding(dp(10), dp(14), dp(10), dp(14))
        vs.gravity = Gravity.CENTER
        vs.addView(crest(e.home, 40))
        vs.addView(text("  ${e.score[0]}  \u2013  ${e.score[1]}  ", 30f, Theme.GOLD, Theme.DATA, 0f, Gravity.CENTER))
        vs.addView(crest(e.away, 40))
        result.add(vs)
        result.add(hairline())
        result.add(kv("Possession", "${e.possessionHome}%  \u2013  ${100 - e.possessionHome}%"))
        result.add(kv("Shots (on target)", "${e.shots[0]} (${e.onTarget[0]})  \u2013  ${e.shots[1]} (${e.onTarget[1]})"))
        result.add(kv("Expected goals", "${Fmt.rating(e.xg[0])}  \u2013  ${Fmt.rating(e.xg[1])}"))
        result.add(kv("Corners", "${e.corners[0]}  \u2013  ${e.corners[1]}"))
        result.add(kv("Fouls", "${e.fouls[0]}  \u2013  ${e.fouls[1]}"))
        result.add(kv("Cards", "${e.yellows[0]}Y ${e.reds[0]}R  \u2013  ${e.yellows[1]}Y ${e.reds[1]}R"))
        result.add(kv("Attendance", e.attendance.toString()))
        leftCol.addView(result, lp(MATCH, WRAP))
        leftCol.addView(spacer(10))

        e.manOfTheMatch?.let {
            val motm = panel("Man of the match")
            val r = row()
            r.setPadding(dp(10), dp(10), dp(10), dp(10))
            val col = column()
            col.addView(playerName(it.ref, 16f, Theme.TEXT, Theme.DISPLAY))
            col.addView(text(if (it.side == 0) e.home.name else e.away.name, 11.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(text(Fmt.one(it.rating), 22f, Theme.GREEN, Theme.DATA))
            motm.add(r)
            leftCol.addView(motm, lp(MATCH, WRAP))
        }

        val rightCol = column()
        val ratings = panel("Your player ratings")
        val ranked = e.players.filter { it.side == side && it.minutes > 1 }.sortedByDescending { it.rating }
        var alt = false
        for (p in ranked) {
            val r = row()
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            if (alt) r.setBackgroundColor(Theme.PANEL_ALT)
            alt = !alt
            r.addView(posTag(p.pos), lp(dp(36), WRAP))
            val col = column()
            col.addView(playerName(p.ref, 12.5f))
            val bits = StringBuilder()
            bits.append("${p.minutes.toInt()} mins")
            if (p.goals > 0) bits.append("  \u00B7  ${p.goals} goal${if (p.goals > 1) "s" else ""}")
            if (p.assists > 0) bits.append("  \u00B7  ${p.assists} assist${if (p.assists > 1) "s" else ""}")
            if (p.yellow > 0) bits.append("  \u00B7  booked")
            if (p.sentOff) bits.append("  \u00B7  sent off")
            col.addView(text(bits.toString(), 10.5f, Theme.MUTED))
            r.addView(col, lp(0, WRAP, 1f))
            val col2 = if (p.rating >= 7.5) Theme.GREEN else if (p.rating >= 6.4) Theme.AMBER else Theme.RED
            r.addView(text(Fmt.one(p.rating), 14f, col2, Theme.DATA))
            ratings.add(r)
        }
        rightCol.addView(ratings, lp(MATCH, WRAP))
        rightCol.addView(spacer(10))

        val contRow = row()
        val cont = actionButton("Continue", true)
        cont.setOnClickListener {
            engine = null; matchView = null
            matchAudio?.stop(); matchAudio = null
            if (sacked) {
                screen = SCR_HUB
                renderShell()
                toast("The board have dismissed you.")
            } else {
                screen = SCR_HUB
                renderShell()
            }
        }
        contRow.addView(cont, lp(0, WRAP, 1f))
        rightCol.addView(contRow, lp(MATCH, WRAP))

        stage.addView(twoColumn(leftCol, rightCol, 1f, 1.2f), FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun rollSeason() {
        val s = season ?: return
        val car = career ?: return
        s.endSeason()
        s.rolloverPlayers()
        s.newSeason()
        car.setObjectives()
        car.youthIntake()
        autosave()
        screen = SCR_HUB
        renderShell()
        toast("Season ${world?.season} begins.")
    }
}
