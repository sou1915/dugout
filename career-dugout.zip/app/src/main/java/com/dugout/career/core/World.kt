package com.dugout.career.core

import kotlin.math.max
import kotlin.math.roundToInt

/* ------------------------------------------------------------- PLACE NAMES */

/**
 * Town names are built from parts rather than listed, so the pool is large
 * and every world draws a different set.
 */
object Places {
    private val HEAD = arrayOf(
        "Red", "North", "Ash", "Vel", "Port", "Hal", "Stone", "Mer", "Wex", "Cald",
        "Bright", "Fen", "Iron", "Lark", "Dun", "East", "Raven", "Thorn", "Whit", "Sel",
        "Alder", "Grant", "March", "Oak", "Pine", "Queens", "Rock", "Stan", "Tarn", "Ulls",
        "Vere", "West", "Yar", "Barrow", "Crest", "Elms", "Farn", "Glen", "Harts", "Ingle",
        "Kel", "Lynd", "Moss", "New", "Oster", "Pen", "Quarry", "Roth", "Salt", "Temple",
        "Under", "Vella", "Winder", "Xanthe", "Yew", "Zen", "Black", "Green", "Grey", "Silver",
        "Kings", "Bishops", "Abbots", "Castle", "Chapel", "Mill", "Bridge", "Kirk", "Wold", "Combe"
    )
    private val TAIL = arrayOf(
        "bridge", "gate", "ford", "moor", "castle", "brook", "bury", "ridge", "holm", "eron",
        "sea", "wick", "vale", "field", "more", "cliff", "dale", "bourne", "mere", "hurst",
        "wood", "hampton", "mouth", "worth", "haven", "port", "stead", "thorpe", "combe", "shaw"
    )
    private val SUFFIX = arrayOf(
        "United", "City", "Athletic", "FC", "Rovers", "Wanderers", "Town", "Albion",
        "County", "Rangers", "Sporting", "Dynamo", "Wednesday", "Argyle", "Orient", "Alexandra"
    )
    private val GROUND = arrayOf(
        "Park", "Arena", "Stadium", "Ground", "Field", "Bowl", "Terrace", "Lane", "Road", "Meadow"
    )

    fun cityPool(rng: Rng, n: Int): List<String> {
        val out = ArrayList<String>(n)
        val seen = HashSet<String>(n * 2)
        var guard = 0
        while (out.size < n && guard++ < n * 60) {
            val c = rng.pick(HEAD) + rng.pick(TAIL)
            if (seen.add(c)) out.add(c)
        }
        return out
    }

    fun suffix(rng: Rng) = rng.pick(SUFFIX)
    fun ground(rng: Rng) = rng.pick(GROUND)
}

/* ------------------------------------------------------------------- KITS */

object Kits {
    const val PLAIN = 0; const val STRIPES = 1; const val HOOPS = 2
    const val SASH = 3; const val HALVES = 4; const val BAND = 5
    const val COUNT = 6

    /** primary, secondary */
    val PALETTE = arrayOf(
        intArrayOf(0xFFE63946.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF1D4ED8.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF0F766E.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF7C3AED.toInt(), 0xFFFFE7A3.toInt()),
        intArrayOf(0xFFF59E0B.toInt(), 0xFF111827.toInt()),
        intArrayOf(0xFF111827.toInt(), 0xFFF2B544.toInt()),
        intArrayOf(0xFF16A34A.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF0EA5E9.toInt(), 0xFF0B2545.toInt()),
        intArrayOf(0xFFBE123C.toInt(), 0xFFFDE68A.toInt()),
        intArrayOf(0xFF4338CA.toInt(), 0xFFE0E7FF.toInt()),
        intArrayOf(0xFFB45309.toInt(), 0xFFFFF7ED.toInt()),
        intArrayOf(0xFF065F46.toInt(), 0xFFD1FAE5.toInt()),
        intArrayOf(0xFF9D174D.toInt(), 0xFFFBCFE8.toInt()),
        intArrayOf(0xFF1E3A8A.toInt(), 0xFFFCA5A5.toInt()),
        intArrayOf(0xFF374151.toInt(), 0xFF93C5FD.toInt()),
        intArrayOf(0xFF7F1D1D.toInt(), 0xFFFEF3C7.toInt()),
        intArrayOf(0xFFFFFFFF.toInt(), 0xFF1D4ED8.toInt()),
        intArrayOf(0xFFEAB308.toInt(), 0xFF1E293B.toInt()),
        intArrayOf(0xFF155E75.toInt(), 0xFFFDE047.toInt()),
        intArrayOf(0xFF831843.toInt(), 0xFFF1F5F9.toInt())
    )
}

/* ------------------------------------------------------------- DIVISIONS */

class Division(
    val id: Int,
    val name: String,
    val shortName: String,
    val tier: Int,
    val baseRating: Int,
    val prize: Long,
    val tv: Long,
    val promoted: Int,
    val relegated: Int
) {
    val clubIds = ArrayList<Int>(20)
}

/* ------------------------------------------------------------------ WORLD */

class World(val seed: Long) {

    val clubs = ArrayList<Club>(160)
    val players = HashMap<Int, Player>(4096)
    val divisions = ArrayList<Division>(4)
    val foreignClubIds = ArrayList<Int>(64)

    var season = 1
    var week = 1
    var userClubId = -1

    var managerName = "The Gaffer"
    var managerNation = "ENG"
    var managerRep = 22
    var managerP = 0; var managerW = 0; var managerD = 0; var managerL = 0
    var seasonsManaged = 0

    private var nextPlayerId = 1
    private var nextClubId = 1

    val userClub: Club? get() = clubs.firstOrNull { it.id == userClubId }

    fun club(id: Int): Club? = clubs.firstOrNull { it.id == id }
    fun player(id: Int): Player? = players[id]

    fun division(id: Int): Division? = divisions.firstOrNull { it.id == id }

    fun squadOf(c: Club): List<Player> = c.squad.mapNotNull { players[it] }

    fun wageBill(c: Club): Int = c.squad.sumOf { players[it]?.wage ?: 0 }

    fun squadRating(c: Club): Int {
        val xi = c.tactics.lineup.map { players[it] }.filterNotNull()
        if (xi.isEmpty()) {
            val top = squadOf(c).sortedByDescending { it.overall() }.take(11)
            return if (top.isEmpty()) 50 else top.sumOf { it.overall() } / top.size
        }
        return xi.sumOf { it.overall() } / xi.size
    }

    /* ------------------------------------------------------------ BUILD */

    companion object {
        const val CLUBS_PER_DIV = 20
        const val FOREIGN_LEAGUES = 8
        const val FOREIGN_PER_LEAGUE = 18
        const val SQUAD_SIZE = 26

        fun build(seed: Long): World {
            val w = World(seed)
            w.generate()
            return w
        }
    }

    private fun generate() {
        val rng = Rng(seed)
        Names.reset()

        divisions.add(Division(0, "Premier Division", "PRM", 1, 76, 55_000_000L, 75_000_000L, 0, 3))
        divisions.add(Division(1, "Championship", "CHP", 2, 66, 10_000_000L, 12_000_000L, 3, 3))
        divisions.add(Division(2, "League One", "LG1", 3, 58, 2_500_000L, 3_000_000L, 3, 3))
        divisions.add(Division(3, "League Two", "LG2", 4, 50, 900_000L, 1_100_000L, 3, 3))
        divisions.add(Division(4, "National League", "NAT", 5, 42, 350_000L, 400_000L, 3, 0))

        val need = divisions.size * CLUBS_PER_DIV + FOREIGN_LEAGUES * FOREIGN_PER_LEAGUE
        val cities = Places.cityPool(rng, need + 20)
        var cityAt = 0
        val palette = rng.shuffle(Kits.PALETTE.toList())
        var kitAt = 0

        // domestic pyramid
        for (div in divisions) {
            for (k in 0 until CLUBS_PER_DIV) {
                val city = cities[cityAt++]
                val kit = palette[kitAt++ % palette.size]
                val rep = rng.norm(baseRepFor(div.tier).toDouble(), 8.0, 6, 97)
                val c = makeClub(rng, city, "HOM", kit, rep)
                c.divisionId = div.id
                c.tier = div.tier
                c.capacity = when (div.tier) {
                    1 -> rng.i(26_000, 78_000); 2 -> rng.i(13_000, 36_000)
                    3 -> rng.i(6_000, 18_000); 4 -> rng.i(2_500, 9_000); else -> rng.i(1_200, 5_000)
                } / 500 * 500
                c.balance = (when (div.tier) {
                    1 -> rng.i(20, 160); 2 -> rng.i(4, 32); 3 -> rng.i(1, 9)
                    4 -> rng.i(1, 4); else -> rng.i(1, 2)
                }).toLong() * 1_000_000L
                c.sponsor = (when (div.tier) {
                    1 -> rng.i(15, 55); 2 -> rng.i(3, 11); 3 -> rng.i(1, 3)
                    4 -> rng.i(1, 2); else -> rng.i(1, 1)
                }).toLong() * 1_000_000L
                buildSquad(rng, c, div.baseRating + ((rep - baseRepFor(div.tier)) * 0.42).roundToInt())
                divisions[div.id].clubIds.add(c.id)
                clubs.add(c)
            }
        }

        // foreign clubs — they do not play a league here, but they buy, sell
        // and enter the continental competition
        val foreignNations = Names.NATIONS.filter { it.code != "ENG" }.take(FOREIGN_LEAGUES + 4)
        for (li in 0 until FOREIGN_LEAGUES) {
            val nat = foreignNations[li % foreignNations.size]
            for (k in 0 until FOREIGN_PER_LEAGUE) {
                val city = cities[cityAt++]
                val kit = palette[kitAt++ % palette.size]
                val rep = rng.norm(60.0 + nat.strength * 0.22, 11.0, 20, 98)
                val c = makeClub(rng, city, nat.code, kit, rep)
                c.divisionId = -1
                c.tier = 1
                c.capacity = rng.i(15_000, 68_000) / 500 * 500
                c.balance = rng.i(8, 120).toLong() * 1_000_000L
                c.sponsor = rng.i(6, 40).toLong() * 1_000_000L
                buildSquad(rng, c, 60 + ((rep - 60) * 0.45).roundToInt())
                foreignClubIds.add(c.id)
                clubs.add(c)
            }
        }

        for (c in clubs) {
            autoPickSquad(c)
            recalcBudgets(c)
        }
    }

    private fun baseRepFor(tier: Int) = when (tier) { 1 -> 78; 2 -> 60; 3 -> 44; 4 -> 30; else -> 18 }

    /**
     * A player found in the fourth tier rarely turns into a superstar. Capping
     * potential by level is what stops lower-league squads inflating past what
     * their club could ever pay for.
     */
    fun potentialCapFor(tier: Int, divisionId: Int): Int =
        if (divisionId < 0) 97 else when (tier) { 1 -> 97; 2 -> 89; 3 -> 81; 4 -> 73; else -> 66 }

    private fun makeClub(rng: Rng, city: String, nation: String, kit: IntArray, rep: Int): Club {
        val suffix = Places.suffix(rng)
        val name = "$city $suffix"
        val short = (city.take(3) + suffix.take(1)).uppercase()
        val c = Club(
            nextClubId++, name, short, city, nation,
            rng.i(1, 1_000_000), kit[0], kit[1], rng.i(0, Kits.COUNT - 1)
        )
        c.reputation = rep
        c.stadiumName = "$city ${Places.ground(rng)}"
        return c
    }

    /** Positional plan for a 26-man squad: three keepers and cover everywhere. */
    private val SQUAD_PLAN = intArrayOf(
        Pos.GK, Pos.GK, Pos.GK,
        Pos.DC, Pos.DC, Pos.DC, Pos.DC, Pos.DL, Pos.DL, Pos.DR, Pos.DR,
        Pos.DM, Pos.DM, Pos.MC, Pos.MC, Pos.MC, Pos.ML, Pos.ML, Pos.MR, Pos.MR,
        Pos.AM, Pos.AM, Pos.ST, Pos.ST, Pos.ST, Pos.ST
    )

    private fun buildSquad(rng: Rng, c: Club, base: Int) {
        val homeNation = Names.byCode(if (c.nation == "HOM") "ENG" else c.nation)
        for (idx in SQUAD_PLAN.indices) {
            val pos = SQUAD_PLAN[idx]
            val starter = idx < 14
            val target = rng.norm((base + if (starter) 3 else -6).toDouble(), 5.0, 18, 95)
            val age = when {
                rng.chance(0.17) -> rng.i(16, 20)
                rng.chance(0.26) -> rng.i(30, 36)
                else -> rng.i(21, 29)
            }
            // 70% home-grown, the rest imported from anywhere in the world
            val nat = if (rng.chance(0.70)) homeNation else rng.pick(Names.NATIONS)
            val p = makePlayer(rng, pos, age, target, nat, potentialCapFor(c.tier, c.divisionId))
            p.clubId = c.id
            p.shirt = idx + 1
            players[p.id] = p
            c.squad.add(p.id)
        }
    }

    fun makePlayer(
        rng: Rng, pos: Int, age: Int, targetOverall: Int, nation: Nation,
        potentialCap: Int = 97
    ): Player {
        val nm = Names.make(rng, nation)
        val att = IntArray(Att.COUNT)
        val w = Weights.of(pos)
        for (a in 0 until Att.COUNT) {
            val importance = w[a]
            val bias = if (importance > 0.0) 4.0 + importance * 30.0 else -14.0
            att[a] = rng.norm(targetOverall + bias, 7.0, 8, 97)
        }
        if (pos != Pos.GK) {
            att[Att.GKR] = rng.i(6, 20); att[Att.GKH] = rng.i(6, 20); att[Att.GKD] = rng.i(6, 24)
        }

        val gap = max(0, targetOverall - 40)
        var pot = targetOverall + when {
            age <= 18 -> rng.i(10, 30)
            age <= 21 -> rng.i(6, 24)
            age <= 24 -> rng.i(3, 15)
            age <= 27 -> rng.i(0, 7)
            else -> rng.i(0, 3)
        }
        pot = pot.coerceAtMost(potentialCap)

        val altPos = if (rng.chance(0.42)) {
            var a = rng.i(0, Pos.COUNT - 1)
            var tries = 0
            while ((a == pos || Pos.group(a) != Pos.group(pos)) && tries++ < 8) a = rng.i(0, Pos.COUNT - 1)
            if (a == pos) -1 else a
        } else -1

        val p = Player(
            nextPlayerId++, nm.first, nm.last, nm.full, nation.code,
            age, pos, altPos, Roles.random(rng, pos), att, pot
        )

        // calibrate: the weighted bias above inflates the rating, so pull it back
        p.shiftTo(targetOverall.toDouble())
        p.potential = max(p.potential, p.overall())

        val traits = ArrayList<Int>(3)
        if (rng.chance(0.40)) traits.add(rng.i(0, Traits.ALL.size - 1))
        if (rng.chance(0.12)) traits.add(rng.i(0, Traits.ALL.size - 1))
        if (age <= 20 && p.potential - p.overall() >= 18 && rng.chance(0.55)) traits.add(Traits.WONDERKID)
        p.traits = traits.distinct().toIntArray()
        p.personality = rng.pick(PERSONALITIES)
        p.morale = rng.i(56, 84).toDouble()
        p.sharpness = rng.i(65, 95).toDouble()
        p.contractYears = rng.i(1, 5)
        p.wage = p.expectedWage()
        p.squadStatus = when {
            p.overall() >= 78 -> 0
            p.overall() >= 68 -> 1
            age <= 20 -> 4
            p.overall() >= 58 -> 2
            else -> 3
        }
        p.gap()
        return p
    }

    /* ----------------------------------------------------- SELECTION */

    /** Picks the strongest legal XI and bench for the club's formation. */
    fun autoPickSquad(c: Club) {
        val shape = Formations.byName(c.tactics.formation)
        val avail = squadOf(c).filter { it.available }
        val taken = HashSet<Int>()
        for (i in shape.slots.indices) {
            val pos = shape.slots[i].pos
            var best: Player? = null
            var bestScore = -1.0
            for (p in avail) {
                if (taken.contains(p.id)) continue
                val sc = p.ratingAt(pos) + p.form * 0.8 + (p.fitness - 80.0) * 0.15
                if (sc > bestScore) { bestScore = sc; best = p }
            }
            if (best != null) { taken.add(best.id); c.tactics.lineup[i] = best.id }
            else c.tactics.lineup[i] = -1
        }
        val rest = avail.filter { !taken.contains(it.id) }.sortedByDescending { it.overall() }
        val bench = ArrayList<Int>(7)
        rest.firstOrNull { it.pos == Pos.GK }?.let { bench.add(it.id) }
        for (p in rest) {
            if (bench.size >= 7) break
            if (!bench.contains(p.id)) bench.add(p.id)
        }
        for (i in 0 until 7) c.tactics.bench[i] = if (i < bench.size) bench[i] else -1
    }

    /** Estimated income for a full season: prize money, TV, sponsor and the gate. */
    fun seasonRevenue(c: Club): Long {
        val div = division(c.divisionId)
        val prize = div?.prize ?: 30_000_000L
        val tv = div?.tv ?: 40_000_000L
        val ticket = when (c.tier) { 1 -> 38; 2 -> 22; 3 -> 13; 4 -> 8; else -> 5 }
        val attend = (c.capacity * (0.50 + c.reputation / 200.0)).toLong()
        val gate = attend * ticket * 19L
        return (prize * 0.6).toLong() + tv + c.sponsor + gate
    }

    fun recalcBudgets(c: Club) {
        c.transferBudget = max(0L, (c.balance * 0.55).toLong())
        // 55% of income on wages is what a well-run club can carry
        c.wageBudget = ((seasonRevenue(c) * 0.64) / 38.0).roundToInt()
    }

    /* ------------------------------------------------------- RATINGS */

    class TeamRating(var attack: Double, var defence: Double, var control: Double)

    /** Turns a squad plus its instructions into three numbers the match engine uses. */
    fun teamRating(c: Club, home: Boolean): TeamRating {
        val shape = Formations.byName(c.tactics.formation)
        val t = c.tactics
        var atk = 0.0; var def = 0.0; var ctl = 0.0
        var wa = 0.0; var wd = 0.0; var wc = 0.0

        for (i in shape.slots.indices) {
            val p = players[t.lineup.getOrElse(i) { -1 }] ?: continue
            val pos = shape.slots[i].pos
            var e = p.effective(pos)

            // the role he has been given
            val fx = RoleFx.of(t.roleName(i))
            atk += fx.atk; def += fx.def; ctl += fx.ctl
            // a player asked to do something unnatural loses a little sharpness
            if (t.hasPI(i, PI.TAKE_RISKS)) { atk += 0.8; ctl -= 0.9 }
            if (t.hasPI(i, PI.SHOOT_ON_SIGHT)) { atk += 0.5; ctl -= 0.4 }
            if (t.hasPI(i, PI.CLOSE_DOWN)) { ctl += 0.5; def -= 0.3 }
            if (t.hasPI(i, PI.STAY_BACK)) { def += 0.9; atk -= 0.7 }
            if (t.hasPI(i, PI.GET_FORWARD)) { atk += 0.9; def -= 0.7 }
            if (t.hasPI(i, PI.HOLD_POSITION)) { def += 0.5; ctl += 0.3 }
            // a captain steadies everyone around him
            if (t.captain == i && p.hasTrait(Traits.LEADER)) e += 2.0

            val g = Pos.group(pos)
            val sa: Double; val sd: Double; val sc: Double
            when (g) {
                0 -> { sa = 0.0; sd = 1.00; sc = 0.05 }
                1 -> { sa = 0.18; sd = 0.72; sc = 0.25 }
                2 -> { sa = 0.38; sd = 0.32; sc = 0.85 }
                else -> { sa = 0.85; sd = 0.08; sc = 0.32 }
            }
            atk += e * sa; wa += sa
            def += e * sd; wd += sd
            ctl += e * sc; wc += sc
        }
        atk /= max(wa, 0.01); def /= max(wd, 0.01); ctl /= max(wc, 0.01)

        val m = t.mentality - 2                       // -2 .. +2
        atk += m * 3.6; def -= m * 2.8; ctl += m * 0.6

        val press = t.press - 1                       // -1 .. +1
        ctl += press * 2.6; def -= press * 1.4

        val tempo = t.tempo - 1
        atk += tempo * 1.6; ctl -= tempo * 1.0

        when (t.passing) {
            0 -> { ctl += 1.8; atk -= 0.6 }
            2 -> { atk += 1.4; ctl -= 1.6 }
        }
        when (t.width) {
            0 -> { ctl += 1.0; def += 0.5 }
            2 -> atk += 1.1
        }
        when (t.line) {
            0 -> { def += 2.0; atk -= 0.7 }
            2 -> { def -= 1.6; ctl += 1.2 }
        }
        if (t.offsideTrap) def += 1.0
        when (t.marking) { 0 -> ctl += 0.8; 2 -> { def += 1.2; ctl -= 0.6 } }
        when (t.timeWasting) { 0 -> atk += 0.6; 2 -> { def += 1.0; atk -= 1.2; ctl -= 0.8 } }
        if (t.playOut) { ctl += 1.4; def -= 0.9 }
        if (t.focus == 3) atk += 0.8            // both flanks stretches a back four
        if (t.focus == 1) ctl += 0.6            // through the middle keeps it tight
        if (t.counter && m < 0) atk += 2.4
        when (t.tackling) { 0 -> def -= 0.8; 2 -> def += 1.0 }

        val bump = (c.morale - 70.0) * 0.05
        atk += bump; def += bump; ctl += bump

        if (home) { atk += 1.9; ctl += 1.2; def += 1.0 }
        return TeamRating(atk, def, ctl)
    }
}

/** Small helper so squad status and potential stay consistent after creation. */
private fun Player.gap() {
    if (potential < overall()) potential = overall()
}
