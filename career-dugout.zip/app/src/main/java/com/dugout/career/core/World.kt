package com.dugout.career.core

import kotlin.math.max
import kotlin.math.roundToInt

/* ------------------------------------------------------------- PLACE NAMES */

/**
 * Town names are built from parts rather than listed, so the pool is large
 * and every world draws a different set.
 */
object Places {
    private val HEAD = arrayOf(
        "Red", "North", "Ash", "Vel", "Port", "Hal", "Stone", "Mer", "Wex", "Cald",
        "Bright", "Fen", "Iron", "Lark", "Dun", "East", "Raven", "Thorn", "Whit", "Sel",
        "Alder", "Grant", "March", "Oak", "Pine", "Queens", "Rock", "Stan", "Tarn", "Ulls",
        "Vere", "West", "Yar", "Barrow", "Crest", "Elms", "Farn", "Glen", "Harts", "Ingle",
        "Kel", "Lynd", "Moss", "New", "Oster", "Pen", "Quarry", "Roth", "Salt", "Temple",
        "Under", "Vella", "Winder", "Xanthe", "Yew", "Zen", "Black", "Green", "Grey", "Silver",
        "Kings", "Bishops", "Abbots", "Castle", "Chapel", "Mill", "Bridge", "Kirk", "Wold", "Combe"
    )
    private val TAIL = arrayOf(
        "bridge", "gate", "ford", "moor", "castle", "brook", "bury", "ridge", "holm", "eron",
        "sea", "wick", "vale", "field", "more", "cliff", "dale", "bourne", "mere", "hurst",
        "wood", "hampton", "mouth", "worth", "haven", "port", "stead", "thorpe", "combe", "shaw"
    )
    private val SUFFIX = arrayOf(
        "United", "City", "Athletic", "FC", "Rovers", "Wanderers", "Town", "Albion",
        "County", "Rangers", "Sporting", "Dynamo", "Wednesday", "Argyle", "Orient", "Alexandra"
    )
    private val GROUND = arrayOf(
        "Park", "Arena", "Stadium", "Ground", "Field", "Bowl", "Terrace", "Lane", "Road", "Meadow"
    )

    /** Invented towns that sound like they belong to their country. */
    private val BY_NATION = mapOf(
        "ESP" to arrayOf("Valdoro", "San Ferrol", "Almeranza", "Castellera", "Ribadeña", "Montenar",
            "Puerto Sella", "Alcarraz", "Vegalonso", "Torrebella", "Sanlúcar del Rey", "Nuevaljar",
            "Peñascal", "Cabodoro"),
        "ITA" to arrayOf("Montalcino", "Vallenza", "Castelrosa", "Porto Ligure", "San Vittore",
            "Ferrantina", "Borgomare", "Aquileta", "Cormonte", "Sereghetto", "Villanova", "Pietralba",
            "Marentino", "Costalago"),
        "GER" to arrayOf("Rheinbach", "Nordstadt", "Eisenberg", "Blauwald", "Hohenfeld", "Steinbrück",
            "Grünthal", "Weissenau", "Adlerhorst", "Kalkstadt", "Oberlingen", "Freihafen",
            "Bergwitz", "Lindenau"),
        "FRA" to arrayOf("Val-d'Or", "Saint-Rémy", "Beauclair", "Montrichard", "Port-Aurel",
            "Villeneuve", "Charmontier", "Roquefort", "La Rochelle-sur-Mer", "Aubertin",
            "Grandvaux", "Clairmont", "Bellecourt", "Sancerre"),
        "NED" to arrayOf("Nieuwhaven", "Zandvoort", "Oosterdijk", "Rijnvelde", "Groenmeer",
            "Bergendam", "Wijkstede", "Havenzicht", "Maasbrug", "Vlaardam", "Kloosterveen",
            "Duinhorst", "Steenwijk", "Aalsmeer"),
        "POR" to arrayOf("Vila Nova", "Serramar", "Porto Belo", "Alcobaça", "Ribamonte",
            "Castelinho", "Praia Verde", "Montalegre", "Vale do Sol", "Estoril Novo",
            "Sanfins", "Aveirinho", "Barroca", "Fonteclara"),
        "BEL" to arrayOf("Sint-Anders", "Waterloo-Noord", "Vlaanderveld", "Hasselbeek",
            "Meerhout", "Doornik", "Blankenzee", "Grimbergen", "Kortenberg", "Lierdal",
            "Zoutbrugge", "Aalstveld", "Ronsevaal", "Diestbeek"),
        "CRO" to arrayOf("Zlatograd", "Primorje", "Vukovina", "Dubravnik", "Slavonski Brod",
            "Kamenica", "Modrolje", "Sveti Juraj", "Rijekagrad", "Bjelovica",
            "Zadarin", "Trogirje", "Sinjska", "Poreča"),
        "BRA" to arrayOf("Vila Aurora", "Rio Claro", "Santa Cruz", "Palmeirinha", "Boa Vista",
            "Ipanema Novo", "Serra Verde", "Porto Sul", "Campo Belo", "Nova Esperança",
            "Cachoeira", "Morro Alto", "Juazeirinho", "Itaquara"),
        "ARG" to arrayOf("Villa Real", "Rosarito", "San Telmo", "La Plata Norte", "Bahía Nueva",
            "Córdoba Chica", "Tigre Viejo", "Mar Azul", "Quilmes Sur", "Avellanito",
            "Santa Fe Nueva", "Lomas Altas", "Berazá", "Chacarita"),
        "SWE" to arrayOf("Norrvik", "Sjöberga", "Lindhamn", "Vasterlund", "Gränsby",
            "Kalmarö", "Fjällstad", "Björnhult", "Skogsvik", "Malmberga",
            "Uppland", "Öresund", "Halmby", "Torshamn"),
        "MAR" to arrayOf("Bab Chamal", "Ain Zohra", "Sidi Marouane", "Oued Salam", "Jbel Tarik",
            "Dar Bouazza", "Kasbat Nour", "Riad Anfa", "Tafraout Jdid", "Souk Lakbir",
            "Mers El Bahr", "Ait Melloul", "Bir Rami", "Zaouiat Chems")
    )

    /** Regional qualifiers, so a country's town list never runs dry. */
    private val QUALIFIER = mapOf(
        "ESP" to arrayOf("del Norte", "de Abajo", "Nuevo", "Viejo"),
        "ITA" to arrayOf("Alta", "Bassa", "Nuova", "Vecchia"),
        "GER" to arrayOf("Nord", "Süd", "Neu", "Alt"),
        "FRA" to arrayOf("Nord", "Sud", "Neuf", "Vieux"),
        "NED" to arrayOf("Noord", "Zuid", "Nieuw", "Oud"),
        "POR" to arrayOf("do Norte", "do Sul", "Novo", "Velho"),
        "BEL" to arrayOf("Noord", "Zuid", "Nieuw", "Oost"),
        "CRO" to arrayOf("Gornji", "Donji", "Novi", "Stari"),
        "BRA" to arrayOf("do Norte", "do Sul", "Novo", "Velho"),
        "ARG" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "SWE" to arrayOf("Norra", "Södra", "Nya", "Gamla"),
        "MAR" to arrayOf("Jdid", "Kdim", "Fou9ani", "Ta7tani")
    )

    /*
     * Town pools for the countries added since. Without an entry here a
     * country falls back to the invented English pool, so its clubs come out
     * named after places like Yarcastle. These used to be three standalone
     * arrays reached through a `when` inside forNation; at sixty countries
     * that would have been sixty branches, so they live in the map instead.
     */
    private val MORE_TOWNS = mapOf(
        "NOR" to arrayOf("Bergvik", "Trondsund", "Haugestad", "Nordfjell", "Osland", "Stavik",
            "Fredrikstrand", "Molvik", "Sandehavn", "Lilledal", "Kristiansund",
            "Tromsvik", "Bodofjord", "Alesand", "Drammenfjell", "Vestbyen"),
        "SEN" to arrayOf("Ndakaru", "Thiaroye", "Mbourane", "Kaolane", "Ziguindor", "Saint-Loubis",
            "Rufisq", "Tambacounde", "Diourbelle", "Fatikane", "Louganne", "Matamane",
            "Kolbadou", "Sedhioune", "Bignonaye", "Podorane"),
        "JPN" to arrayOf("Ashikawa", "Nagamori", "Tsurugaya", "Kitahama", "Shirakawa", "Minatoshi",
            "Yamagase", "Fukuhara", "Sakaebashi", "Higashino", "Toyokawa", "Aoyagi",
            "Kurihama", "Nishinada", "Hoshizaki", "Machidate"),
        "TUR" to arrayOf(
            "Karabuk", "Yesilkent", "Denizova",
            "Akcasehir", "Bursakale", "Trabzonkent",
            "Golbasi", "Adakoy", "Marmaris Yeni",
            "Elmadag", "Sarikaya", "Konyaova",
            "Izmirdere", "Antalyakent", "Kayseriova",
            "Samsunkale"),
        "SCO" to arrayOf(
            "Glenmorrow", "Kirkbraes", "Auchterloch",
            "Dunvarrick", "Inverclyde", "Strathdon",
            "Balgownie", "Craigmuir", "Lochranza",
            "Tarbetshaw", "Fettermuir", "Ardrossanby",
            "Kilmarnie", "Bannockhaugh", "Carsebridge",
            "Drumlanrig"),
        "SUI" to arrayOf(
            "Baselheim", "Grindelau", "Thunersee",
            "Luzernthal", "Aarwangen", "Sittendorf",
            "Vevey-Rive", "Bellinzano", "Chur-Alt",
            "Neuchamps", "Fribourgeau", "Wintertal",
            "Zugersee", "Sionval", "Lausannois",
            "Bernegg"),
        "AUT" to arrayOf(
            "Grazwald", "Linzberg", "Salzenau",
            "Innsbruck-Neu", "Klagenthal", "Wiener Feld",
            "Steyrbach", "Villachhof", "Wolfsgrub",
            "Amstetten Nord", "Kufstadt", "Bregenzau",
            "Hallstein", "Leobenau", "Ebreichsau",
            "Ternitzgrund"),
        "DEN" to arrayOf(
            "Nordhavn", "Aarhusby", "Odensedal",
            "Vejlestrand", "Randersborg", "Silkevang",
            "Esbjergsund", "Holstenbro", "Koldingholm",
            "Naestvedby", "Roskildeholm", "Viborghede",
            "Hvidmose", "Frederiksvig", "Sonderholt",
            "Ringstedlund"),
        "MEX" to arrayOf(
            "Santa Marta", "Puebla Nueva", "Toluca Alta",
            "Guadalquivir", "Monteverde", "Leon Viejo",
            "Queretaro Sur", "Pachuquilla", "Necaxtla",
            "Tijuanilla", "Mazatlanejo", "Veracruzano",
            "Morelinda", "Zacateca Nueva", "Culiacanito",
            "Oaxaqueño"),
        "GRE" to arrayOf(
            "Kalamaria", "Nea Thermi", "Peloponnisos",
            "Larisaki", "Volos Nea", "Ioanninos",
            "Chaniades", "Serresia", "Patrina",
            "Xanthiko", "Trikalina", "Kavalos"),
        "UKR" to arrayOf(
            "Zoryagrad", "Karpatsk", "Dniprovka",
            "Lvivske", "Poltavets", "Chernihivka",
            "Vinnytsya Nova", "Odesamore", "Kryvyi Log",
            "Zhytomyrsk", "Sumyriv", "Rivnepil"),
        "POL" to arrayOf(
            "Bialystok Nowy", "Gdanskie", "Krakowice",
            "Lublinek", "Poznanka", "Szczecinek",
            "Wroclawek", "Katowicza", "Radomsko Nowe",
            "Torunia", "Kielczyn", "Opolna"),
        "SRB" to arrayOf(
            "Novisad Gornji", "Nisava", "Kragujevo",
            "Subotica Nova", "Zrenjanske", "Panceva",
            "Cacanski", "Uzicko", "Leskovica",
            "Smederevka", "Valjevo Novo", "Somborje"),
        "RUS" to arrayOf(
            "Volgorod", "Uralsk Novy", "Sibirskoye",
            "Kazanka", "Rostovets", "Samargrad",
            "Permskoye", "Voronezhki", "Tverskoy",
            "Krasnodolsk", "Yaroslavka", "Omskaya"),
        "CZE" to arrayOf(
            "Brnoles", "Ostravka", "Plzenec",
            "Liberecke", "Olomoucky", "Budejovka",
            "Hradecko", "Zlinsky", "Pardubka",
            "Jihlavske", "Teplicka", "Mladavod"),
        "ROU" to arrayOf(
            "Clujana", "Timisoara Noua", "Iasilor",
            "Constantina", "Craiovita", "Brasovel",
            "Galatiu", "Ploiestin", "Aradean",
            "Oradina", "Pitestiu", "Bacauel"),
        "HUN" to arrayOf(
            "Debrecenyi", "Gyorvar", "Pecsalja",
            "Szegedhaza", "Miskolcvar", "Kecskehely",
            "Szekesvar", "Sopronfalu", "Egerhegy",
            "Zalavar", "Nyiregyfalu", "Bekesvar"),
        "BUL" to arrayOf(
            "Plovdivgrad", "Varnenska", "Burgaska",
            "Ruseto", "Starazagora", "Plevenska",
            "Slivenko", "Dobrichka", "Shumenska",
            "Haskovets", "Pazardzhik Nov", "Vidinets"),
        "SVK" to arrayOf(
            "Bratislavka", "Kosicka", "Zilinske",
            "Trnavsky", "Nitrianske", "Presovka",
            "Banskadol", "Trencinsky", "Michalovka",
            "Ruzomberok Novy", "Dunajska Nova", "Poprad Nizny"),
        "SVN" to arrayOf(
            "Mariborje", "Celjska", "Koperska",
            "Kranjdol", "Novogorica", "Ptujska",
            "Velenjske", "Domzalce", "Murska Nova",
            "Trbovlje Novo", "Jesenice Gorenje", "Postojnka"),
        "FIN" to arrayOf(
            "Tampereski", "Turunlahti", "Ouluvesi",
            "Lahtiniemi", "Kuopionkyla", "Vaasanranta",
            "Jyvasjarvi", "Porinsalo", "Kotkaharju",
            "Espoonranta", "Rovaniema", "Seinajoki Uusi"),
        "ISL" to arrayOf(
            "Reykjanes", "Akureyrarhof", "Hafnarvik",
            "Selfossnes", "Keflavold", "Gardabaer Nyi",
            "Kopavik", "Isafjardur", "Vestmannahof",
            "Egilsstadir Nyr", "Borgarnes Efri", "Husavikur"),
        "IRL" to arrayOf(
            "Ballyroan", "Drumcashel", "Kilbarrick",
            "Ennisglen", "Rathmoyne", "Carrigduff",
            "Tullyshane", "Moyvane", "Clonbeg",
            "Lisnagarve", "Donaghbeg", "Ardclough"),
        "WAL" to arrayOf(
            "Llanberis Fawr", "Aberdyfi", "Pontglyn",
            "Caerfelin", "Rhoswen", "Tregaron Newydd",
            "Cwmbrannog", "Nantyffin", "Penarthen",
            "Machynlleth Isaf", "Bryncoed", "Dolgellau Uchaf"),
        "CYP" to arrayOf(
            "Lemesos Nea", "Larnakos", "Pafiotiko",
            "Ammochostos", "Kyreneia", "Morfouli",
            "Athienou Nea", "Aradippa", "Paralimni Kato",
            "Polemidia", "Geroskipa", "Lakatamos"),
        "COL" to arrayOf(
            "Villa Nueva", "Cali Norte", "Medellinda",
            "Barranca Alta", "Cartagenilla", "Bucaramanga Sur",
            "Pereirita", "Manizal Nuevo", "Cucutano",
            "Ibaguera", "Neivan", "Pastoral"),
        "CHI" to arrayOf(
            "Valparaisito", "Concepcion Alta", "Antofagasto",
            "Temucano", "Rancagua Nueva", "Iquiqueno",
            "Talcahuanito", "Chillanejo", "Osorno Nuevo",
            "La Serenilla", "Curicano", "Puerto Montt Alto"),
        "URU" to arrayOf(
            "Montevideo Sur", "Punta Nueva", "Salto Grande",
            "Paysandino", "Rivera Alta", "Maldonado Viejo",
            "Tacuarembo Nuevo", "Melo Chico", "Durazno Norte",
            "Florida Nueva", "Minas Altas", "Colonia Vieja"),
        "PER" to arrayOf(
            "Limatambo", "Arequipeno", "Trujillano",
            "Chiclayano", "Cuscano", "Piurano",
            "Huancayino", "Iquiteno", "Tacneno",
            "Callaito", "Juliaquita", "Ayacuchano"),
        "ECU" to arrayOf(
            "Quitumbe", "Guayaquileno", "Cuencano",
            "Ambateno", "Machalita", "Manta Nueva",
            "Portovejo", "Loja Alta", "Esmeraldino",
            "Ibarreno", "Riobambeno", "Quevedito"),
        "PAR" to arrayOf(
            "Asuncion Norte", "Encarnacion Nueva", "Ciudad Este",
            "Luqueno", "Capiata Alta", "Itaugua Nuevo",
            "Concepcion Sur", "Pilarito", "Villarrica Nueva",
            "Coronel Oviedo Alto", "Caaguazu Norte", "San Lorenzo Viejo"),
        "USA" to arrayOf(
            "Fairhaven", "Northgate", "Rivertown",
            "Lakeshore", "Baypoint", "Summit Falls",
            "Cedar Rapids West", "Granite City", "Harbor Springs",
            "Silverlake", "Kingsport", "Eastvale"),
        "CRC" to arrayOf(
            "San Jose Norte", "Alajuelita Nueva", "Herediano Alto",
            "Cartago Viejo", "Puntarenas Sur", "Limonense",
            "Liberia Nueva", "Perez Alto", "Guanacaste Norte",
            "Turrialba Nuevo", "Grecia Alta", "Santa Ana Sur"),
        "CAN" to arrayOf(
            "Maple Ridge", "Fort Warden", "Lakehead",
            "Sainte-Claire", "Cypress Bay", "Red Deer North",
            "Kingsbury", "Trois-Rivets", "Halifax East",
            "Winnipegosis", "Thunder Cove", "Okanagan Falls"),
        "JAM" to arrayOf(
            "Kingston East", "Montego Nueva", "Spanish Point",
            "Portmore Heights", "Ocho Vale", "Mandeville Hill",
            "Negril Bay", "Falmouth Cove", "Savanna Cross",
            "Linstead Ridge", "May Pen North", "Morant Bay South"),
        "EGY" to arrayOf(
            "Bur Nasr", "Madinat Shams", "Al Gadida",
            "Sidi Rashad", "Kafr Zayan", "Tanta Gedida",
            "Mansoura Bahri", "Assiut Qibli", "Suez Sharq",
            "Ismailia Gharb", "Minya Nasr", "Sohag Gedid"),
        "ALG" to arrayOf(
            "Bab Zouar", "Sidi Belkacem", "Oued Mimoun",
            "Ain Temzert", "Kouba Nouvelle", "Setif Gharb",
            "Tizi Ouzil", "Constantine Nord", "Blidatt",
            "Annaba Sud", "Bejaia Haut", "Tlemcen Neuf"),
        "TUN" to arrayOf(
            "Bab Bhar", "Sidi Bouzid Jdid", "La Marsa Nord",
            "Sousse Jdida", "Sfax Gharb", "Bizerte Nord",
            "Kairouan Jdid", "Gabes Bahri", "Monastir Sud",
            "Nabeul Jdid", "Beja Alia", "Medenine Nouvelle"),
        "NGA" to arrayOf(
            "Ikeja Nova", "Enuguland", "Kanoville",
            "Ibadanshi", "Portville", "Abujaland",
            "Jos Heights", "Warribank", "Owerrito",
            "Kadunaland", "Calabar New", "Benin Ridge"),
        "GHA" to arrayOf(
            "Accra Newtown", "Kumasi Ridge", "Takoradi Bay",
            "Tamale North", "Cape Point", "Sunyani Hills",
            "Koforidua New", "Ho Central", "Techiman East",
            "Obuasi Gold", "Bolgatanga North", "Wa South"),
        "CIV" to arrayOf(
            "Abidjan Nord", "Yamoussou Neuf", "Bouake Sud",
            "San Pedro Bay", "Korhogo Haut", "Daloa Neuf",
            "Man Central", "Gagnoa Est", "Divo Nouveau",
            "Anyama Nord", "Grand Bassam Sud", "Abengourou Neuf"),
        "RSA" to arrayOf(
            "Ekurhuleni North", "Tshwane East", "Umlazi Heights",
            "Soweto Central", "Mbombela New", "Polokwane North",
            "Bloemhof South", "Nelspoort", "Kimberley Ridge",
            "Rustenvale", "Vanderbijl North", "Port Alfred East"),
        "KOR" to arrayOf(
            "Seongnamgu", "Ulsandong", "Jeonjuseo",
            "Pohangnam", "Suwonbuk", "Daejeonsan",
            "Gwangjuhae", "Incheonpo", "Busanjin",
            "Chuncheonri", "Gimcheonwon", "Jejudo Nam"),
        "CHN" to arrayOf(
            "Beihai New", "Nanshan", "Dongcheng",
            "Xiling", "Jiangbei", "Hepingqu",
            "Yuzhou New", "Fenghua", "Qingshan",
            "Wuxing", "Haidian South", "Liangjiang"),
        "KSA" to arrayOf(
            "Al Madinah Jadidah", "Ar Riyad Shamal", "Jeddah Gharb",
            "Ad Dammam Sharq", "Al Khobar Jadid", "Buraydah Shamal",
            "At Taif Alia", "Tabuk Jadid", "Abha Alia",
            "Hail Gharb", "Najran Janub", "Yanbu Bahri"),
        "QAT" to arrayOf(
            "Al Wakrah Jadid", "Ar Rayyan Shamal", "Umm Salal Gharb",
            "Al Khor Bahri", "Madinat Khalifa", "Al Daayen Jadid",
            "Mesaieed Janub", "Dukhan Gharb", "Al Shamal Bahri",
            "Lusail Jadid", "Al Bidda Sharq", "Al Waab Shamal"),
        "AUS" to arrayOf(
            "Southbank", "Newhaven Park", "Kingsvale",
            "Bellarine", "Warringah", "Coolangara",
            "Redcliff Bay", "Marrickvale", "Fremantle North",
            "Torrens East", "Ipswich Hills", "Toowoon Bay"),
    )

    /** Regional qualifiers for the countries above, so a town list never runs dry. */
    private val MORE_QUALIFIERS = mapOf(
        "NOR" to arrayOf("Nord", "Sor", "Ost", "Vest"),
        "SEN" to arrayOf("Nord", "Sud", "Est", "Ouest"),
        "JPN" to arrayOf("Kita", "Minami", "Higashi", "Nishi"),
        "TUR" to arrayOf("Kuzey", "Guney", "Yeni", "Eski"),
        "SCO" to arrayOf("North", "South", "East", "West"),
        "SUI" to arrayOf("Nord", "Sud", "Neu", "Alt"),
        "AUT" to arrayOf("Nord", "Sud", "Neu", "Alt"),
        "DEN" to arrayOf("Nord", "Syd", "Ny", "Gammel"),
        "MEX" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "GRE" to arrayOf("Voreia", "Notia", "Nea", "Palia"),
        "UKR" to arrayOf("Pivnich", "Pivden", "Nove", "Stare"),
        "POL" to arrayOf("Polnoc", "Poludnie", "Nowy", "Stary"),
        "SRB" to arrayOf("Severni", "Juzni", "Novi", "Stari"),
        "RUS" to arrayOf("Severny", "Yuzhny", "Novy", "Stary"),
        "CZE" to arrayOf("Severni", "Jizni", "Novy", "Stary"),
        "ROU" to arrayOf("Nord", "Sud", "Nou", "Vechi"),
        "HUN" to arrayOf("Eszaki", "Deli", "Uj", "Regi"),
        "BUL" to arrayOf("Severen", "Yuzhen", "Nov", "Star"),
        "SVK" to arrayOf("Severny", "Juzny", "Novy", "Stary"),
        "SVN" to arrayOf("Severni", "Juzni", "Novi", "Stari"),
        "FIN" to arrayOf("Pohjoinen", "Etela", "Uusi", "Vanha"),
        "ISL" to arrayOf("Nordur", "Sudur", "Nyja", "Gamla"),
        "IRL" to arrayOf("North", "South", "New", "Old"),
        "WAL" to arrayOf("Gogledd", "De", "Newydd", "Hen"),
        "CYP" to arrayOf("Voreia", "Notia", "Nea", "Palia"),
        "COL" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "CHI" to arrayOf("Norte", "Sur", "Nuevo", "Viejo"),
        "URU" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "PER" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "ECU" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "PAR" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "USA" to arrayOf("North", "South", "New", "East"),
        "CRC" to arrayOf("del Norte", "del Sur", "Nuevo", "Viejo"),
        "CAN" to arrayOf("North", "South", "New", "East"),
        "JAM" to arrayOf("North", "South", "New", "East"),
        "EGY" to arrayOf("Shamal", "Janoub", "Gedid", "Qadim"),
        "ALG" to arrayOf("Nord", "Sud", "Neuf", "Ancien"),
        "TUN" to arrayOf("Nord", "Sud", "Jdid", "Kdim"),
        "NGA" to arrayOf("North", "South", "New", "Old"),
        "GHA" to arrayOf("North", "South", "New", "Old"),
        "CIV" to arrayOf("Nord", "Sud", "Neuf", "Ancien"),
        "RSA" to arrayOf("North", "South", "New", "Old"),
        "KOR" to arrayOf("Buk", "Nam", "Sin", "Gu"),
        "CHN" to arrayOf("Bei", "Nan", "Xin", "Jiu"),
        "KSA" to arrayOf("Shamal", "Janoub", "Jadid", "Qadim"),
        "QAT" to arrayOf("Shamal", "Janoub", "Jadid", "Qadim"),
        "AUS" to arrayOf("North", "South", "New", "East"),
    )

    fun forNation(rng: Rng, code: String, n: Int): List<String> {
        val pool = BY_NATION[code] ?: MORE_TOWNS[code] ?: return cityPool(rng, n)
        val quals = QUALIFIER[code] ?: MORE_QUALIFIERS[code]
            ?: arrayOf("North", "South", "New", "Old")
        val out = ArrayList<String>(n)
        val base = rng.shuffle(pool.toList())
        out.addAll(base.take(n))
        // still short? pair the same towns with a regional qualifier
        var q = 0
        while (out.size < n) {
            val town = base[(out.size - base.size) % base.size]
            out.add("$town ${quals[q % quals.size]}")
            q++
        }
        return out.take(n)
    }

    fun cityPool(rng: Rng, n: Int): List<String> {
        val out = ArrayList<String>(n)
        val seen = HashSet<String>(n * 2)
        var guard = 0
        while (out.size < n && guard++ < n * 60) {
            val c = rng.pick(HEAD) + rng.pick(TAIL)
            if (seen.add(c)) out.add(c)
        }
        return out
    }

    fun suffix(rng: Rng) = rng.pick(SUFFIX)
    fun ground(rng: Rng) = rng.pick(GROUND)
}

/* ------------------------------------------------------------------- KITS */

object Kits {
    const val PLAIN = 0; const val STRIPES = 1; const val HOOPS = 2
    const val SASH = 3; const val HALVES = 4; const val BAND = 5
    const val COUNT = 6

    /** primary, secondary */
    val PALETTE = arrayOf(
        intArrayOf(0xFFE63946.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF1D4ED8.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF0F766E.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF7C3AED.toInt(), 0xFFFFE7A3.toInt()),
        intArrayOf(0xFFF59E0B.toInt(), 0xFF111827.toInt()),
        intArrayOf(0xFF111827.toInt(), 0xFFF2B544.toInt()),
        intArrayOf(0xFF16A34A.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF0EA5E9.toInt(), 0xFF0B2545.toInt()),
        intArrayOf(0xFFBE123C.toInt(), 0xFFFDE68A.toInt()),
        intArrayOf(0xFF4338CA.toInt(), 0xFFE0E7FF.toInt()),
        intArrayOf(0xFFB45309.toInt(), 0xFFFFF7ED.toInt()),
        intArrayOf(0xFF065F46.toInt(), 0xFFD1FAE5.toInt()),
        intArrayOf(0xFF9D174D.toInt(), 0xFFFBCFE8.toInt()),
        intArrayOf(0xFF1E3A8A.toInt(), 0xFFFCA5A5.toInt()),
        intArrayOf(0xFF374151.toInt(), 0xFF93C5FD.toInt()),
        intArrayOf(0xFF7F1D1D.toInt(), 0xFFFEF3C7.toInt()),
        intArrayOf(0xFFFFFFFF.toInt(), 0xFF1D4ED8.toInt()),
        intArrayOf(0xFFEAB308.toInt(), 0xFF1E293B.toInt()),
        intArrayOf(0xFF155E75.toInt(), 0xFFFDE047.toInt()),
        intArrayOf(0xFF831843.toInt(), 0xFFF1F5F9.toInt())
    )
}

/** A league somewhere else in Europe. Its clubs trade and enter the continental cup. */
class ForeignLeague(
    val id: Int, val country: String, val name: String,
    val nationCode: String, val tier: Int
)

/** First, second and third tier names for each country. */
/**
 * Which part of the world a nation sits in.
 *
 * The country list had grown long enough to be a wall of names. Grouping it
 * gives the picker some shape, and lets a search be narrowed to a continent.
 */
val CONTINENTS = listOf("Europe", "South America", "North America",
    "Africa", "Asia", "Oceania")

val CONTINENT_OF = mapOf(
    "ENG" to "Europe", "ESP" to "Europe", "ITA" to "Europe", "GER" to "Europe",
    "FRA" to "Europe", "NED" to "Europe", "POR" to "Europe", "BEL" to "Europe",
    "CRO" to "Europe", "SWE" to "Europe", "NOR" to "Europe", "BRA" to "South America",
    "ARG" to "South America", "MAR" to "Africa", "SEN" to "Africa", "JPN" to "Asia",
    "TUR" to "Europe", "SCO" to "Europe", "SUI" to "Europe", "AUT" to "Europe",
    "DEN" to "Europe", "MEX" to "North America", "GRE" to "Europe", "UKR" to "Europe",
    "POL" to "Europe", "SRB" to "Europe", "RUS" to "Europe", "CZE" to "Europe",
    "ROU" to "Europe", "HUN" to "Europe", "BUL" to "Europe", "SVK" to "Europe",
    "SVN" to "Europe", "FIN" to "Europe", "ISL" to "Europe", "IRL" to "Europe",
    "WAL" to "Europe", "CYP" to "Europe", "COL" to "South America", "CHI" to "South America",
    "URU" to "South America", "PER" to "South America", "ECU" to "South America", "PAR" to "South America",
    "USA" to "North America", "CRC" to "North America", "CAN" to "North America", "JAM" to "North America",
    "EGY" to "Africa", "ALG" to "Africa", "TUN" to "Africa", "NGA" to "Africa",
    "GHA" to "Africa", "CIV" to "Africa", "RSA" to "Africa", "KOR" to "Asia",
    "CHN" to "Asia", "KSA" to "Asia", "QAT" to "Asia", "AUS" to "Oceania",
)

fun continentOf(code: String): String = CONTINENT_OF[code] ?: "Europe"

/**
 * The nations outside the home pyramid, in one place.
 *
 * This list used to be written out twice, once where the divisions are built
 * and once where the clubs are generated. Adding three countries to one copy
 * and not the other overran a fixed size array on the next world build.
 */
val FOREIGN_CODES = arrayOf(
    // The sixteen the world started with keep their positions. FOREIGN_CODES
    // is walked in order to lay out the foreign divisions, and a division id
    // is what a save stores against every club, so anything appended is safe
    // and anything inserted silently moves every club after it.
    "ESP", "ITA", "GER", "FRA", "NED", "POR",
    "BEL", "CRO", "SWE", "NOR", "BRA", "ARG",
    "MAR", "SEN", "JPN",
    // added as full three tier countries
    "TUR", "SCO", "SUI", "AUT", "DEN", "MEX",
    // added with a single division each
    "GRE", "UKR", "POL", "SRB", "RUS", "CZE",
    "ROU", "HUN", "BUL", "SVK", "SVN", "FIN",
    "ISL", "IRL", "WAL", "CYP", "COL", "CHI",
    "URU", "PER", "ECU", "PAR", "USA", "CRC",
    "CAN", "JAM", "EGY", "ALG", "TUN", "NGA",
    "GHA", "CIV", "RSA", "KOR", "CHN", "KSA",
    "QAT", "AUS"
)

/**
 * How big each country's league is: number of divisions, and clubs in each.
 *
 * Three tiers of twelve everywhere would have been two thousand two hundred
 * clubs and a fourteen megabyte save for sixty countries. A country with a
 * real pyramid gets one; the rest get a single division, which is both cheaper
 * and closer to how much of world football actually looks. Anything not listed
 * falls back to one division of ten, so a country added to FOREIGN_CODES and
 * forgotten here still builds rather than crashing.
 */
val FOREIGN_SHAPE: Map<String, Pair<Int, Int>> = HashMap<String, Pair<Int, Int>>().apply {
    put("ESP", Pair(3, 12))
    put("ITA", Pair(3, 12))
    put("GER", Pair(3, 12))
    put("FRA", Pair(3, 12))
    put("NED", Pair(3, 12))
    put("POR", Pair(3, 12))
    put("BEL", Pair(3, 12))
    put("CRO", Pair(3, 12))
    put("SWE", Pair(3, 12))
    put("NOR", Pair(3, 12))
    put("BRA", Pair(3, 12))
    put("ARG", Pair(3, 12))
    put("MAR", Pair(3, 12))
    put("SEN", Pair(3, 12))
    put("JPN", Pair(3, 12))
    put("TUR", Pair(3, 12))
    put("SCO", Pair(3, 12))
    put("SUI", Pair(3, 12))
    put("AUT", Pair(3, 12))
    put("DEN", Pair(3, 12))
    put("MEX", Pair(3, 12))
    put("GRE", Pair(1, 10))
    put("UKR", Pair(1, 10))
    put("POL", Pair(1, 10))
    put("SRB", Pair(1, 10))
    put("RUS", Pair(1, 10))
    put("CZE", Pair(1, 10))
    put("ROU", Pair(1, 10))
    put("HUN", Pair(1, 10))
    put("BUL", Pair(1, 10))
    put("SVK", Pair(1, 10))
    put("SVN", Pair(1, 10))
    put("FIN", Pair(1, 10))
    put("ISL", Pair(1, 10))
    put("IRL", Pair(1, 10))
    put("WAL", Pair(1, 10))
    put("CYP", Pair(1, 10))
    put("COL", Pair(1, 10))
    put("CHI", Pair(1, 10))
    put("URU", Pair(1, 10))
    put("PER", Pair(1, 10))
    put("ECU", Pair(1, 10))
    put("PAR", Pair(1, 10))
    put("USA", Pair(1, 10))
    put("CRC", Pair(1, 10))
    put("CAN", Pair(1, 10))
    put("JAM", Pair(1, 10))
    put("EGY", Pair(1, 10))
    put("ALG", Pair(1, 10))
    put("TUN", Pair(1, 10))
    put("NGA", Pair(1, 10))
    put("GHA", Pair(1, 10))
    put("CIV", Pair(1, 10))
    put("RSA", Pair(1, 10))
    put("KOR", Pair(1, 10))
    put("CHN", Pair(1, 10))
    put("KSA", Pair(1, 10))
    put("QAT", Pair(1, 10))
    put("AUS", Pair(1, 10))
}

/** Divisions this country has. */
fun tiersOf(code: String): Int = FOREIGN_SHAPE[code]?.first ?: 1

/** Clubs in each of this country's divisions. */
fun clubsPerLeagueOf(code: String): Int = FOREIGN_SHAPE[code]?.second ?: 10

val LEAGUE_NAMES = mapOf(
    "NOR" to arrayOf("Eliteserien", "OBOS-ligaen", "PostNord-ligaen"),
    "SEN" to arrayOf("Ligue 1", "Ligue 2", "National 1"),
    "JPN" to arrayOf("J1 League", "J2 League", "J3 League"),
    "ESP" to arrayOf("Primera", "Segunda", "Primera Federación"),
    "ITA" to arrayOf("Serie A", "Serie B", "Serie C"),
    "GER" to arrayOf("Bundesliga", "2. Bundesliga", "3. Liga"),
    "FRA" to arrayOf("Ligue 1", "Ligue 2", "National"),
    "NED" to arrayOf("Eredivisie", "Eerste Divisie", "Tweede Divisie"),
    "POR" to arrayOf("Primeira", "Liga 2", "Liga 3"),
    "BEL" to arrayOf("Pro League", "Challenger League", "First Division"),
    "CRO" to arrayOf("Prva Liga", "Druga Liga", "Treća Liga"),
    "BRA" to arrayOf("Série A", "Série B", "Série C"),
    "ARG" to arrayOf("Primera División", "Primera Nacional", "Primera B"),
    "SWE" to arrayOf("Allsvenskan", "Superettan", "Division 1"),
    "MAR" to arrayOf("Botola Pro", "Botola 2", "Amateurs"),
    "TUR" to arrayOf("Super Lig", "1. Lig", "2. Lig"),
    "SCO" to arrayOf("Premiership", "Championship", "League One"),
    "SUI" to arrayOf("Super League", "Challenge League", "Promotion League"),
    "AUT" to arrayOf("Bundesliga", "2. Liga", "Regionalliga"),
    "DEN" to arrayOf("Superliga", "1. Division", "2. Division"),
    "MEX" to arrayOf("Liga MX", "Liga de Expansion", "Liga Premier"),
    "GRE" to arrayOf("Super League", "Super League 2", "Gamma Ethniki"),
    "UKR" to arrayOf("Premier League", "Persha Liha", "Druha Liha"),
    "POL" to arrayOf("Ekstraklasa", "I Liga", "II Liga"),
    "SRB" to arrayOf("Superliga", "Prva Liga", "Srpska Liga"),
    "RUS" to arrayOf("Premier Liga", "FNL", "Vtoroy Divizion"),
    "CZE" to arrayOf("Fortuna Liga", "FNL", "CFL"),
    "ROU" to arrayOf("Liga I", "Liga II", "Liga III"),
    "HUN" to arrayOf("NB I", "NB II", "NB III"),
    "BUL" to arrayOf("Parva Liga", "Vtora Liga", "Treta Liga"),
    "SVK" to arrayOf("Fortuna Liga", "2. Liga", "3. Liga"),
    "SVN" to arrayOf("Prva Liga", "2. SNL", "3. SNL"),
    "FIN" to arrayOf("Veikkausliiga", "Ykkonen", "Kakkonen"),
    "ISL" to arrayOf("Besta deild", "Lengjudeild", "2. deild"),
    "IRL" to arrayOf("Premier Division", "First Division", "Leinster Senior"),
    "WAL" to arrayOf("Cymru Premier", "Cymru North", "Cymru South"),
    "CYP" to arrayOf("First Division", "Second Division", "Third Division"),
    "COL" to arrayOf("Categoria Primera A", "Primera B", "Primera C"),
    "CHI" to arrayOf("Primera Division", "Primera B", "Segunda Division"),
    "URU" to arrayOf("Primera Division", "Segunda Division", "Primera Amateur"),
    "PER" to arrayOf("Liga 1", "Liga 2", "Copa Peru"),
    "ECU" to arrayOf("Serie A", "Serie B", "Segunda Categoria"),
    "PAR" to arrayOf("Primera Division", "Intermedia", "Primera B"),
    "USA" to arrayOf("Premier League", "Championship", "League One"),
    "CRC" to arrayOf("Primera Division", "Segunda Division", "Liga de Ascenso"),
    "CAN" to arrayOf("Premier League", "Championship", "League One"),
    "JAM" to arrayOf("Premier League", "Super League", "Parish League"),
    "EGY" to arrayOf("Premier League", "Second Division", "Third Division"),
    "ALG" to arrayOf("Ligue 1", "Ligue 2", "Division Nationale"),
    "TUN" to arrayOf("Ligue 1", "Ligue 2", "Ligue 3"),
    "NGA" to arrayOf("Premier League", "National League", "Nationwide"),
    "GHA" to arrayOf("Premier League", "Division One", "Division Two"),
    "CIV" to arrayOf("Ligue 1", "Ligue 2", "Division 3"),
    "RSA" to arrayOf("Premiership", "First Division", "Motsepe League"),
    "KOR" to arrayOf("K League 1", "K League 2", "K3 League"),
    "CHN" to arrayOf("Super League", "League One", "League Two"),
    "KSA" to arrayOf("Pro League", "First Division", "Second Division"),
    "QAT" to arrayOf("Stars League", "Second Division", "Qatari League"),
    "AUS" to arrayOf("A-League", "National League", "State League"),
)

/* ------------------------------------------------------------- DIVISIONS */

class Division(
    val id: Int,
    val name: String,
    val shortName: String,
    val tier: Int,
    val baseRating: Int,
    val prize: Long,
    val tv: Long,
    val promoted: Int,
    val relegated: Int,
    /** Three letter nation code. The home pyramid keeps the default. */
    val country: String = "ENG",
    /** True for the five divisions of the home pyramid. */
    val isHome: Boolean = true
) {
    val clubIds = ArrayList<Int>(20)
}

/* ------------------------------------------------------------------ WORLD */

class World(val seed: Long) {

    val clubs = ArrayList<Club>(160)
    val players = HashMap<Int, Player>(4096)
    val divisions = ArrayList<Division>(4)
    val foreignClubIds = ArrayList<Int>(200)
    val foreignLeagues = ArrayList<ForeignLeague>(8)

    /**
     * Every foreign league also exists as a Division, which is what lets the
     * season build fixtures and tables for it with no special cases. They are
     * kept out of [divisions] so the home pyramid stays a contiguous ladder for
     * promotion and relegation, and so screens that walk the home leagues do
     * not suddenly list forty of them.
     */
    val foreignDivisions = ArrayList<Division>(40)

    /** Ids for foreign divisions start well clear of the home pyramid. */
    val FOREIGN_DIV_BASE = 100

    /**
     * Which nation the manager is working in. Only the home pyramid and this
     * country get a full fixture list; the rest of the world stays abstract,
     * because building all thirty-six foreign leagues would roughly quadruple
     * both the save file and the time it takes to load one.
     */
    var playerCountry: String = "ENG"

    /** Who the manager is: age, school, philosophy, manner. */
    val profile = ManagerProfile()

    /** Every club he has managed, and what happened at each. */
    val record = ManagerRecord()

    /** True before he has taken his first job, and again after being sacked. */
    val unemployed: Boolean get() = userClubId < 0

    /** Home pyramid plus every foreign league, for lookups by id. */
    fun allDivisions(): List<Division> = divisions + foreignDivisions

    /** The three tiers of one country, top first. */
    fun pyramidOf(code: String): List<Division> =
        if (code == "ENG") divisions
        else foreignDivisions.filter { it.country == code }.sortedBy { it.tier }

    /** Countries the manager can take a job in. */
    fun playableCountries(): List<String> =
        listOf("ENG") + foreignDivisions.map { it.country }.distinct()

    var season = 1
    var week = 1
    var userClubId = -1

    var managerName = "The Gaffer"
    var managerNation = "ENG"
    var managerRep = 22
    var managerP = 0; var managerW = 0; var managerD = 0; var managerL = 0
    var seasonsManaged = 0

    private var nextPlayerId = 1
    private var nextClubId = 1

    val userClub: Club? get() = clubs.firstOrNull { it.id == userClubId }

    fun club(id: Int): Club? = clubs.firstOrNull { it.id == id }
    fun player(id: Int): Player? = players[id]

    fun division(id: Int): Division? =
        divisions.firstOrNull { it.id == id } ?: foreignDivisions.firstOrNull { it.id == id }

    fun squadOf(c: Club): List<Player> = c.squad.mapNotNull { players[it] }

    /**
     * The weekly wage bill.
     *
     * A borrowed player is in this club's squad but only part of his wage is
     * this club's to pay, and a player sent out is not in the squad at all
     * while part of his wage still is. Both halves are here so the two clubs
     * between them always pay exactly one wage.
     */
    fun wageBill(c: Club): Int = c.squad.sumOf { id ->
        val p = players[id] ?: return@sumOf 0
        if (p.onLoan) p.wage * p.loanWageShare / 100 else p.wage
    } + c.loanWageOut

    fun squadRating(c: Club): Int {
        val xi = c.tactics.lineup.map { players[it] }.filterNotNull()
        if (xi.isEmpty()) {
            val top = squadOf(c).sortedByDescending { it.overall() }.take(11)
            return if (top.isEmpty()) 50 else top.sumOf { it.overall() } / top.size
        }
        return xi.sumOf { it.overall() } / xi.size
    }

    /* ------------------------------------------------------------ BUILD */

    companion object {
        const val CLUBS_PER_DIV = 20
        val FOREIGN_NATIONS get() = FOREIGN_CODES.size

        /**
         * How many foreign divisions exist in total.
         *
         * Every country used to get three, so this was a multiplication. It is
         * a sum now because a country's shape is looked up per nation: see
         * FOREIGN_SHAPE. Anything that still assumes three tiers everywhere
         * will silently point at the wrong league.
         */
        val FOREIGN_DIV_COUNT: Int get() = FOREIGN_CODES.sumOf { tiersOf(it) }

        /** Total foreign clubs, for sizing the town and city pools up front. */
        val FOREIGN_CLUB_COUNT: Int
            get() = FOREIGN_CODES.sumOf { tiersOf(it) * clubsPerLeagueOf(it) }
        const val SQUAD_SIZE = 26

        fun build(seed: Long): World {
            val w = World(seed)
            w.generate()
            return w
        }
    }

    /** Lays out the competition structure only, for restoring a saved career. */
    fun buildStructureOnly() {
        divisions.clear(); foreignLeagues.clear()
        addDivisions()
        addForeignDivisions()
        val codes = FOREIGN_CODES
        var id = 0
        for (code in codes) {
            val nat = Names.byCode(code)
            val names = LEAGUE_NAMES[code] ?: arrayOf("First", "Second", "Third")
            for (tier in 1..tiersOf(code)) {
                foreignLeagues.add(ForeignLeague(id++, nat.label, "${nat.label} ${names[tier - 1]}", code, tier))
            }
        }
    }

    /**
     * Builds the Division for every foreign league. Called both when generating
     * a world and when restoring one, because a save only stores which division
     * each club belongs to: if these are missing on load, every foreign club
     * points at a division that does not exist.
     */
    private fun addForeignDivisions() {
        foreignDivisions.clear()
        val codes = FOREIGN_CODES
        var id = 0
        for (code in codes) {
            val nat = Names.byCode(code)
            val names = LEAGUE_NAMES[code] ?: arrayOf("First", "Second", "Third")
            val tiers = tiersOf(code)
            /*
             * Prize money and television scale with how strong the country is.
             * Every first division used to be worth the same eight million, so
             * a single division nation was as rich as Spain, and a job there
             * paid the same. Strength runs from the high nineties down to the
             * high twenties, so this spans roughly a factor of four.
             */
            val pull = (nat.strength / 90.0).coerceIn(0.28, 1.10)
            for (tier in 1..tiers) {
                foreignDivisions.add(
                    Division(
                        id = FOREIGN_DIV_BASE + id,
                        name = "${nat.label} ${names[tier - 1]}",
                        shortName = names[tier - 1],
                        tier = tier,
                        baseRating = when (tier) { 1 -> 74; 2 -> 58; else -> 42 },
                        prize = ((when (tier) { 1 -> 8_000_000L; 2 -> 2_200_000L; else -> 700_000L })
                                * pull).toLong(),
                        tv = ((when (tier) { 1 -> 24_000_000L; 2 -> 6_000_000L; else -> 1_400_000L })
                                * pull).toLong(),
                        // A country with one division promotes and relegates
                        // nobody; the ladder loop pairs adjacent tiers, so the
                        // top of any pyramid has nowhere up and the bottom has
                        // nowhere down. Stated honestly here so a screen that
                        // prints "2 relegated" is not lying about it.
                        promoted = if (tier == 1) 0 else 2,
                        relegated = if (tier == tiers) 0 else 2,
                        country = code,
                        isHome = false
                    )
                )
                id++
            }
        }
    }

    private fun addDivisions() {
        divisions.add(Division(0, "Premier Division", "PRM", 1, 76, 55_000_000L, 75_000_000L, 0, 3))
        divisions.add(Division(1, "Championship", "CHP", 2, 66, 10_000_000L, 12_000_000L, 3, 3))
        divisions.add(Division(2, "League One", "LG1", 3, 58, 2_500_000L, 3_000_000L, 3, 3))
        divisions.add(Division(3, "League Two", "LG2", 4, 50, 900_000L, 1_100_000L, 3, 3))
        divisions.add(Division(4, "National League", "NAT", 5, 42, 350_000L, 400_000L, 3, 0))
    }

    private fun generate() {
        val rng = Rng(seed)
        Names.reset()
        usedClubNames.clear()
        addDivisions()
        addForeignDivisions()

        val need = divisions.size * CLUBS_PER_DIV + FOREIGN_CLUB_COUNT
        val cities = Places.cityPool(rng, need + 20)
        var cityAt = 0
        val palette = rng.shuffle(Kits.PALETTE.toList())
        var kitAt = 0

        // domestic pyramid
        for (div in divisions) {
            for (k in 0 until CLUBS_PER_DIV) {
                val city = cities[cityAt++]
                val kit = palette[kitAt++ % palette.size]
                val rep = rng.norm(baseRepFor(div.tier).toDouble(), 8.0, 6, 97)
                val c = makeClub(rng, city, "HOM", kit, rep)
                c.divisionId = div.id
                c.tier = div.tier
                c.capacity = when (div.tier) {
                    1 -> rng.i(26_000, 78_000); 2 -> rng.i(13_000, 36_000)
                    3 -> rng.i(6_000, 18_000); 4 -> rng.i(2_500, 9_000); else -> rng.i(1_200, 5_000)
                } / 500 * 500
                c.balance = (when (div.tier) {
                    1 -> rng.i(20, 160); 2 -> rng.i(4, 32); 3 -> rng.i(1, 9)
                    4 -> rng.i(1, 4); else -> rng.i(1, 2)
                }).toLong() * 1_000_000L
                c.sponsor = (when (div.tier) {
                    1 -> rng.i(15, 55); 2 -> rng.i(3, 11); 3 -> rng.i(1, 3)
                    4 -> rng.i(1, 2); else -> rng.i(1, 1)
                }).toLong() * 1_000_000L
                buildSquad(rng, c, div.baseRating + ((rep - baseRepFor(div.tier)) * 0.42).roundToInt())
                divisions[div.id].clubIds.add(c.id)
                clubs.add(c)
            }
        }

        // The rest of the world: each league belongs to a country, and its
        // clubs are named after towns from that country. How many divisions a
        // country gets, and how big they are, comes from FOREIGN_SHAPE.
        val foreignCodes = FOREIGN_CODES
        var leagueId = 0
        for (ni in 0 until FOREIGN_NATIONS) {
            val code = foreignCodes[ni]
            val nat = Names.byCode(code)
            val names = LEAGUE_NAMES[code] ?: arrayOf("First", "Second", "Third")
            val tiers = tiersOf(code)
            val perLeague = clubsPerLeagueOf(code)
            // enough towns for every tier of this country
            val towns = Places.forNation(rng, code, tiers * perLeague)
            var townAt = 0
            for (tier in 1..tiers) {
                foreignLeagues.add(
                    ForeignLeague(leagueId, nat.label, "${nat.label} ${names[tier - 1]}", code, tier)
                )
                val fdiv = foreignDivisions[leagueId]
                for (k in 0 until perLeague) {
                    val city = towns.getOrElse(townAt++) { cities[cityAt++] }
                    val kit = palette[kitAt++ % palette.size]
                    val baseRep = when (tier) { 1 -> 62.0 + nat.strength * 0.22; 2 -> 44.0; else -> 30.0 }
                    val rep = rng.norm(baseRep, 9.0, 12, 98)
                    val c = makeClub(rng, city, nat.code, kit, rep)
                    c.divisionId = fdiv.id
                    c.tier = tier
                    c.foreignLeague = leagueId
                    fdiv.clubIds.add(c.id)
                    c.capacity = when (tier) {
                        1 -> rng.i(18_000, 70_000); 2 -> rng.i(8_000, 26_000); else -> rng.i(3_000, 11_000)
                    } / 500 * 500
                    c.balance = when (tier) {
                        1 -> rng.i(10, 130); 2 -> rng.i(3, 22); else -> rng.i(1, 7)
                    }.toLong() * 1_000_000L
                    c.sponsor = when (tier) {
                        1 -> rng.i(8, 42); 2 -> rng.i(2, 9); else -> rng.i(1, 3)
                    }.toLong() * 1_000_000L
                    /*
                     * Every first division in the world used to be pitched at
                     * 62, so a single division nation produced players as good
                     * as Spain's. Club reputation already scaled with nation
                     * strength but the squad target did not, so the scaling
                     * cancelled out. Anchored so that a strength of 82 — the
                     * average of the countries that were here before — still
                     * lands on 62 and those leagues are left where they were.
                     */
                    val target = when (tier) {
                        1 -> (62.0 + (nat.strength - 82) * 0.30).roundToInt().coerceIn(44, 70)
                        2 -> 52
                        else -> 44
                    }
                    buildSquad(rng, c, target + ((rep - baseRep) * 0.42).roundToInt())
                    foreignClubIds.add(c.id)
                    clubs.add(c)
                }
                leagueId++
            }
        }

        for (c in clubs) {
            autoPickSquad(c)
            recalcBudgets(c)
        }
    }

    private fun baseRepFor(tier: Int) = when (tier) { 1 -> 78; 2 -> 60; 3 -> 44; 4 -> 30; else -> 18 }

    /**
     * A player found in the fourth tier rarely turns into a superstar. Capping
     * potential by level is what stops lower-league squads inflating past what
     * their club could ever pay for.
     */
    fun potentialCapFor(tier: Int, divisionId: Int): Int =
        if (divisionId < 0) 97 else when (tier) { 1 -> 97; 2 -> 89; 3 -> 81; 4 -> 73; else -> 66 }

    /**
     * Club name furniture by country. A Spanish side called "Wednesday" gave
     * the foreign leagues away instantly; these are the shapes each country
     * actually uses, with a few that sit in front of the town rather than after.
     */
    private val CLUB_WORDS = mapOf(
        "ESP" to arrayOf("CF", "FC", "Real", "Deportivo", "Atletico", "Union", "Racing", "Sporting"),
        "ITA" to arrayOf("Calcio", "FC", "AC", "US", "Virtus", "Pro", "Internazionale", "Unione"),
        "GER" to arrayOf("FC", "SV", "VfB", "Borussia", "Eintracht", "SC", "TSV", "FSV"),
        "FRA" to arrayOf("FC", "AS", "Olympique", "Racing", "Stade", "US", "SC", "Sporting"),
        "NED" to arrayOf("FC", "SC", "VV", "Sparta", "Willem", "Go Ahead", "Excelsior", "Ajax"),
        "POR" to arrayOf("FC", "SC", "Sporting", "Academica", "Uniao", "Belenenses", "Nacional", "Maritimo"),
        "BEL" to arrayOf("KV", "KRC", "RSC", "Cercle", "Union", "Standard", "Beerschot", "Eendracht"),
        "CRO" to arrayOf("NK", "HNK", "Dinamo", "Hajduk", "Slaven", "Istra", "Rijeka", "Osijek"),
        "BRA" to arrayOf("FC", "EC", "SC", "Atletico", "Gremio", "Cruzeiro", "Internacional", "Nautico"),
        "ARG" to arrayOf("CA", "Club Atletico", "Racing", "Estudiantes", "Independiente", "Union", "Newell", "Talleres"),
        "SWE" to arrayOf("IF", "IFK", "BK", "AIK", "GIF", "Djurgarden", "Hammarby", "Malmo"),
        "MAR" to arrayOf("Raja", "Wydad", "MAS", "KAC", "OCS", "DHJ", "IRT", "CAY"),
        "NOR" to arrayOf("IL", "FK", "IF", "SK", "BK", "Rosenborg", "Valerenga", "Lillestrom"),
        "SEN" to arrayOf("ASC", "US", "AS", "Casa", "Jaraaf", "Teungueth", "Diambars", "Genereation"),
        "JPN" to arrayOf("FC", "Reysol", "Antlers", "Frontale", "Sanfrecce", "Grampus", "Marinos", "Vissel"),
        "TUR" to arrayOf("FK", "SK", "Spor", "Genclik", "Buyuksehir", "Idman", "Kulubu", "Belediye"),
        "SCO" to arrayOf("FC", "Athletic", "Thistle", "Rangers", "Academical", "Caledonian", "United", "Rovers"),
        "SUI" to arrayOf("FC", "SC", "BSC", "Grasshopper", "Servette", "Young Boys", "Lugano", "Sport"),
        "AUT" to arrayOf("SK", "FC", "SV", "Austria", "Rapid", "Sturm", "LASK", "Wacker"),
        "DEN" to arrayOf("BK", "IF", "FC", "Boldklub", "AGF", "Brondby", "Vejle", "Naestved"),
        "MEX" to arrayOf("CF", "Club", "Deportivo", "Atletico", "Real", "Union", "Toros", "Aguilas"),
        "GRE" to arrayOf("FC", "AO", "PAE", "Aris", "Panathinaikos", "Olympiakos", "Asteras", "Atromitos"),
        "UKR" to arrayOf("FC", "SC", "Dynamo", "Shakhtar", "Zorya", "Karpaty", "Metalist", "Kolos"),
        "POL" to arrayOf("KS", "MKS", "Legia", "Wisla", "Lech", "Gornik", "Zaglebie", "Pogon"),
        "SRB" to arrayOf("FK", "OFK", "Crvena", "Partizan", "Vojvodina", "Radnicki", "Cukaricki", "Spartak"),
        "RUS" to arrayOf("FK", "FC", "Dinamo", "Lokomotiv", "Torpedo", "Spartak", "Krylya", "Rubin"),
        "CZE" to arrayOf("FC", "SK", "AC", "Slavia", "Sparta", "Viktoria", "Banik", "Sigma"),
        "ROU" to arrayOf("FC", "CS", "CSM", "Steaua", "Dinamo", "Rapid", "Universitatea", "Petrolul"),
        "HUN" to arrayOf("FC", "SE", "VSC", "Ferencvaros", "Ujpest", "Honved", "Vasas", "Puskas"),
        "BUL" to arrayOf("FC", "PFC", "Levski", "CSKA", "Ludogorets", "Botev", "Lokomotiv", "Beroe"),
        "SVK" to arrayOf("FC", "MSK", "AS", "Slovan", "Spartak", "Zemplin", "Podbrezova", "Tatran"),
        "SVN" to arrayOf("NK", "FC", "Olimpija", "Maribor", "Domzale", "Celje", "Bravo", "Mura"),
        "FIN" to arrayOf("FC", "HJK", "IFK", "KuPS", "Ilves", "Inter", "VPS", "SJK"),
        "ISL" to arrayOf("IF", "KR", "FH", "Valur", "Breidablik", "Vikingur", "Stjarnan", "Fylkir"),
        "IRL" to arrayOf("FC", "AFC", "Shamrock", "Bohemian", "Athletic", "Wanderers", "Harps", "Town"),
        "WAL" to arrayOf("FC", "AFC", "Town", "United", "Cefn", "Connahs", "Airbus", "Caernarfon"),
        "CYP" to arrayOf("FC", "AC", "APOEL", "Anorthosis", "Omonia", "Apollon", "Aris", "Ethnikos"),
        "COL" to arrayOf("CD", "Atletico", "Deportivo", "Independiente", "Junior", "Millonarios", "Once", "America"),
        "CHI" to arrayOf("CD", "Union", "Colo", "Universidad", "Everton", "Cobreloa", "Palestino", "Audax"),
        "URU" to arrayOf("CA", "Club Atletico", "Danubio", "Penarol", "Nacional", "Defensor", "Wanderers", "Progreso"),
        "PER" to arrayOf("CD", "Club", "Alianza", "Universitario", "Sporting", "Cienciano", "Melgar", "Cristal"),
        "ECU" to arrayOf("CD", "CS", "Barcelona", "Emelec", "Independiente", "Aucas", "Delfin", "Macara"),
        "PAR" to arrayOf("CA", "Club", "Olimpia", "Cerro", "Libertad", "Guarani", "Sol", "Nacional"),
        "USA" to arrayOf("FC", "SC", "United", "City", "Rapids", "Sounders", "Union", "Dynamo"),
        "CRC" to arrayOf("CS", "CD", "Deportivo", "Municipal", "Herediano", "Saprissa", "Alajuelense", "Puntarenas"),
        "CAN" to arrayOf("FC", "SC", "Whitecaps", "Cavalry", "Forge", "Pacific", "Valour", "York"),
        "JAM" to arrayOf("FC", "SC", "United", "Harbour", "Portmore", "Waterhouse", "Arnett", "Humble"),
        "EGY" to arrayOf("SC", "FC", "Al Ahli", "Zamalek", "Ittihad", "Masry", "Ismaily", "Pyramids"),
        "ALG" to arrayOf("CR", "JS", "MC", "USM", "ES", "NA", "ASO", "CS"),
        "TUN" to arrayOf("CA", "ES", "CS", "US", "AS", "OB", "JS", "SR"),
        "NGA" to arrayOf("FC", "United", "Rangers", "Enyimba", "Rovers", "Pillars", "Insurance", "Sunshine"),
        "GHA" to arrayOf("FC", "SC", "Hearts", "Kotoko", "Chelsea", "Aduana", "Medeama", "Dwarfs"),
        "CIV" to arrayOf("ASEC", "AS", "FC", "Africa", "Sporting", "Stella", "Racing", "Sewe"),
        "RSA" to arrayOf("FC", "AmaZulu", "Sundowns", "Chiefs", "Pirates", "United", "Stars", "Arrows"),
        "KOR" to arrayOf("FC", "Ilhwa", "Hyundai", "Motors", "Steelers", "Bluewings", "Citizen", "United"),
        "CHN" to arrayOf("FC", "Zhongyuan", "Guoan", "Shenhua", "Hailifeng", "Sanzhen", "Taishan", "Rongcheng"),
        "KSA" to arrayOf("Al Nasr", "Al Ittihad", "Al Shabab", "Al Fateh", "Al Taawoun", "Al Raed", "Al Fayha", "Al Wehda"),
        "QAT" to arrayOf("Al Sadd", "Al Duhail", "Al Rayyan", "Al Gharafa", "Umm Salal", "Al Arabi", "Qatar SC", "Al Ahli"),
        "AUS" to arrayOf("FC", "City", "United", "Wanderers", "Victory", "Glory", "Roar", "Jets"),
    )

    /** Words that read naturally in front of the town name rather than behind it. */
    private val PREFIX_WORDS = setOf(
        "CF", "FC", "AC", "US", "SV", "VfB", "SC", "TSV", "FSV", "AS", "KV", "KRC",
        "IL", "FK", "IF", "SK", "ASC", "AS", "Casa",
        "RSC", "NK", "HNK", "EC", "CA", "IF", "IFK", "BK", "GIF", "VV", "Real",
        "Deportivo", "Atletico", "Racing", "Sporting", "Olympique", "Stade", "Calcio",
        "Virtus", "Pro", "Unione", "Union", "Borussia", "Eintracht", "Club Atletico",
        "Dinamo", "Hajduk", "Raja", "Wydad", "Cercle", "Standard", "Uniao",
        // the countries added with the sixty league world
        // Club names that read in front of the town: the Arabic "Al" sides, and
        // the many European club words that are a name in their own right.
        // Without this Qatar produced "Al Bidda Sharq Al Sadd".
        "Al Sadd", "Al Duhail", "Al Rayyan", "Al Gharafa", "Umm Salal", "Al Arabi",
        "Qatar SC", "Al Ahli", "Al Nasr", "Al Ittihad", "Al Shabab", "Al Fateh",
        "Al Taawoun", "Al Raed", "Al Fayha", "Al Wehda", "AmaZulu", "Sundowns",
        "Hearts", "Kotoko", "Aduana", "Medeama", "ASEC", "Africa", "Stella", "Sewe",
        "Shamrock", "Bohemian", "Cefn", "Connahs", "Airbus", "Caernarfon",
        "APOEL", "Anorthosis", "Omonia", "Apollon", "Ethnikos", "Slavia", "Sparta",
        "Viktoria", "Banik", "Sigma", "Steaua", "Rapid", "Universitatea", "Petrolul",
        "Ferencvaros", "Ujpest", "Honved", "Vasas", "Puskas", "Levski", "CSKA",
        "Ludogorets", "Botev", "Lokomotiv", "Beroe", "Slovan", "Zemplin", "Podbrezova",
        "Tatran", "Olimpija", "Maribor", "Domzale", "Celje", "Bravo", "Mura",
        "Crvena", "Partizan", "Vojvodina", "Radnicki", "Cukaricki", "Spartak",
        "Legia", "Wisla", "Lech", "Gornik", "Zaglebie", "Pogon", "Torpedo", "Rubin",
        "Shakhtar", "Zorya", "Karpaty", "Metalist", "Kolos", "Panathinaikos",
        "Olympiakos", "Asteras", "Atromitos", "Aris", "Krylya", "Boldklub",
        "Austria", "Sturm", "Wacker", "Young Boys", "Servette", "Grasshopper",
        "Alianza", "Universitario", "Cristal", "Cienciano", "Melgar", "Barcelona",
        "Emelec", "Independiente", "Aucas", "Delfin", "Macara", "Olimpia", "Cerro",
        "Libertad", "Guarani", "Nacional", "Colo", "Universidad", "Everton",
        "Cobreloa", "Palestino", "Audax", "Junior", "Millonarios", "Once", "America",
        "Danubio", "Penarol", "Defensor", "Wanderers", "Progreso", "Herediano",
        "Saprissa", "Alajuelense", "Puntarenas", "Municipal", "Whitecaps",
        "Cavalry", "Forge", "Pacific", "Valour", "York", "Portmore", "Waterhouse",
        "Arnett", "Humble", "Enyimba", "Pillars", "Insurance", "Sunshine",
        "Rangers", "Thistle", "Academical", "Caledonian", "Ilhwa", "Hyundai",
        "Guoan", "Shenhua", "Taishan", "Rongcheng", "Zhongyuan", "Victory",
        "Glory", "Roar", "Jets", "Valur", "Breidablik", "Vikingur", "Stjarnan",
        "Fylkir", "KuPS", "Ilves", "Inter", "Toros", "Aguilas",
        "AC", "AFC", "AGF", "AO", "AS", "ASEC", "ASO",
        "Academical", "Atletico", "BK", "BSC", "Belediye", "Boldklub", "Buyuksehir",
        "CA", "CD", "CF", "CR", "CS", "CSKA", "CSM",
        "Caledonian", "Club", "Club Atletico", "Deportivo", "ES", "FC", "FH",
        "FK", "Genclik", "HJK", "IF", "IFK", "Idman", "Ilhwa",
        "JS", "KR", "KS", "Kulubu", "LASK", "MC", "MKS",
        "MSK", "NA", "NK", "OB", "OFK", "Olimpia", "PAE",
        "PFC", "Racing", "Real", "SC", "SE", "SJK", "SK",
        "SR", "SV", "Spor", "Sport", "Sporting", "Thistle", "US",
        "USM", "Union", "VPS", "VSC", "Zhongyuan"
    )

    private var nextStaffId = 1

    /**
     * Club names already handed out. Sixteen towns spread across thirty six
     * clubs will eventually pair the same town with the same club word twice;
     * this catches it and reaches for another word rather than shipping two
     * clubs with one name.
     */
    private val usedClubNames = HashSet<String>(700)

    private fun makeClub(rng: Rng, city: String, nation: String, kit: IntArray, rep: Int): Club {
        val words = CLUB_WORDS[nation]
        var suffix = if (words != null) words[rng.i(0, words.size - 1)] else Places.suffix(rng)
        var name = if (words != null && suffix in PREFIX_WORDS) "$suffix $city" else "$city $suffix"
        // try the other club words for this country before giving up
        if (name in usedClubNames && words != null) {
            for (w in words) {
                val alt = if (w in PREFIX_WORDS) "$w $city" else "$city $w"
                if (alt !in usedClubNames) { suffix = w; name = alt; break }
            }
        }
        var guard = 1
        while (name in usedClubNames && guard < 40) {
            suffix = Places.suffix(rng)
            name = "$city $suffix"
            guard++
        }
        usedClubNames.add(name)
        val short = (city.take(3) + suffix.take(1)).uppercase()
        val c = Club(
            nextClubId++, name, short, city, nation,
            rng.i(1, 1_000_000), kit[0], kit[1], rng.i(0, Kits.COUNT - 1)
        )
        c.reputation = rep
        c.stadiumName = "$city ${Places.ground(rng)}"
        // A backroom team, pitched at what a club of this standing could
        // attract. Drawn from its own stream: sharing the world generator would
        // shift every squad in the game and quietly move the match balance,
        // which is exactly what happened the first time this was added.
        val staffRng = Rng(seed + c.id * 7919L + 104729L)
        c.staff.addAll(
            Backroom.buildFor(staffRng, rep, Names.byCode(if (nation == "HOM") "ENG" else nation)) {
                nextStaffId++
            }
        )
        return c
    }

    /** Positional plan for a 26-man squad: three keepers and cover everywhere. */
    private val SQUAD_PLAN = intArrayOf(
        Pos.GK, Pos.GK, Pos.GK,
        Pos.DC, Pos.DC, Pos.DC, Pos.DC, Pos.DL, Pos.DL, Pos.DR, Pos.DR,
        Pos.DM, Pos.DM, Pos.MC, Pos.MC, Pos.MC, Pos.ML, Pos.ML, Pos.MR, Pos.MR,
        Pos.AM, Pos.AM, Pos.ST, Pos.ST, Pos.ST, Pos.ST
    )

    private fun buildSquad(rng: Rng, c: Club, base: Int) {
        val homeNation = Names.byCode(if (c.nation == "HOM") "ENG" else c.nation)

        /*
         * Squads are mixed. Every player at an English club being English was
         * the thing that actually looked wrong, not the number of leagues: a
         * top flight side is half foreign and a lower league one is nearly all
         * local. Most of these nations have no league of their own, which costs
         * a list of names rather than a thousand players.
         */
        val foreignShare = ((c.reputation - 24) / 110.0).coerceIn(0.04, 0.55)
        fun pickNation(): Nation {
            if (!rng.chance(foreignShare)) return homeNation
            val pool = Names.ALL_NATIONS
            // better clubs reach further and sign better nations
            /*
             * The best of k uniform draws, with k rising with reputation.
             *
             * This was a flat threshold — take the first nation whose strength
             * cleared the club's reputation minus 26, else one more uniform
             * draw. That worked at forty nations, where nearly the whole pool
             * cleared the bar for a big club. At a hundred and eighty five it
             * does not: most of world football is mid-strength, so "anything
             * above 49" still meant a Premier Division side fielding a back
             * four from Oman, Thailand and Ethiopia, and the fallback draw
             * behind it could produce the Cook Islands.
             *
             * Taking the strongest of several draws biases toward the good
             * footballing nations without ever ruling anywhere out, so a small
             * country still appears — just at the clubs that would realistically
             * be looking there.
             */
            val reach = when {
                c.reputation >= 70 -> 7
                c.reputation >= 55 -> 5
                c.reputation >= 40 -> 3
                // A single uniform draw at the bottom. With any widening at
                // all the weakest thirty nations stopped appearing anywhere in
                // the world at all — 163 of 185 represented — and the brief
                // wants every footballing nation on the map. A National League
                // club taking a punt on a Nepalese trialist is also the right
                // place for it to happen.
                else -> 1
            }
            var best: Nation? = null
            for (attempt in 0 until reach) {
                val n = pool[rng.i(0, pool.size - 1)]
                if (n.code == homeNation.code) continue
                if (best == null || n.strength > best.strength) best = n
            }
            return best ?: homeNation
        }
        for (idx in SQUAD_PLAN.indices) {
            val pos = SQUAD_PLAN[idx]
            val starter = idx < 14
            val target = rng.norm((base + if (starter) 3 else -6).toDouble(), 5.0, 18, 95)
            val age = when {
                rng.chance(0.17) -> rng.i(16, 20)
                rng.chance(0.26) -> rng.i(30, 36)
                else -> rng.i(21, 29)
            }
            val p = makePlayer(rng, pos, age, target, pickNation(), potentialCapFor(c.tier, c.divisionId))
            p.clubId = c.id
            p.shirt = idx + 1
            players[p.id] = p
            c.squad.add(p.id)
        }
    }

    fun makePlayer(
        rng: Rng, pos: Int, age: Int, targetOverall: Int, nation: Nation,
        potentialCap: Int = 97
    ): Player {
        val nm = Names.make(rng, nation)
        val att = IntArray(Att.COUNT)
        val w = Weights.of(pos)
        for (a in 0 until Att.COUNT) {
            val importance = w[a]
            val bias = if (importance > 0.0) 4.0 + importance * 30.0 else -14.0
            att[a] = rng.norm(targetOverall + bias, 7.0, 8, 97)
        }
        if (pos != Pos.GK) {
            att[Att.GKR] = rng.i(6, 20); att[Att.GKH] = rng.i(6, 20); att[Att.GKD] = rng.i(6, 24)
        }

        val gap = max(0, targetOverall - 40)
        var pot = targetOverall + when {
            age <= 18 -> rng.i(10, 30)
            age <= 21 -> rng.i(6, 24)
            age <= 24 -> rng.i(3, 15)
            age <= 27 -> rng.i(0, 7)
            else -> rng.i(0, 3)
        }
        pot = pot.coerceAtMost(potentialCap)

        val altPos = if (rng.chance(0.42)) {
            var a = rng.i(0, Pos.COUNT - 1)
            var tries = 0
            while ((a == pos || Pos.group(a) != Pos.group(pos)) && tries++ < 8) a = rng.i(0, Pos.COUNT - 1)
            if (a == pos) -1 else a
        } else -1

        val p = Player(
            nextPlayerId++, nm.first, nm.last, nm.full, nation.code,
            age, pos, altPos, Roles.random(rng, pos), att, pot
        )

        // calibrate: the weighted bias above inflates the rating, so pull it back
        p.shiftTo(targetOverall.toDouble())
        p.potential = max(p.potential, p.overall())

        val traits = ArrayList<Int>(3)
        if (rng.chance(0.40)) traits.add(rng.i(0, Traits.ALL.size - 1))
        if (rng.chance(0.12)) traits.add(rng.i(0, Traits.ALL.size - 1))
        if (age <= 20 && p.potential - p.overall() >= 18 && rng.chance(0.55)) traits.add(Traits.WONDERKID)
        p.traits = traits.distinct().toIntArray()
        p.personality = rng.pick(PERSONALITIES)
        p.morale = rng.i(56, 84).toDouble()
        p.sharpness = rng.i(65, 95).toDouble()
        p.contractYears = rng.i(1, 5)
        p.wage = p.expectedWage()
        p.squadStatus = when {
            p.overall() >= 78 -> 0
            p.overall() >= 68 -> 1
            age <= 20 -> 4
            p.overall() >= 58 -> 2
            else -> 3
        }
        p.gap()
        return p
    }

    /* ----------------------------------------------------- SELECTION */

    /** Picks the strongest legal XI and bench for the club's formation. */
    fun autoPickSquad(c: Club) {
        val shape = Formations.byName(c.tactics.formation)
        val avail = squadOf(c).filter { it.available }
        val taken = HashSet<Int>()
        for (i in shape.slots.indices) {
            val pos = shape.slots[i].pos
            var best: Player? = null
            var bestScore = -1.0
            for (p in avail) {
                if (taken.contains(p.id)) continue
                val sc = p.ratingAt(pos) + p.form * 0.8 + (p.fitness - 80.0) * 0.15
                if (sc > bestScore) { bestScore = sc; best = p }
            }
            if (best != null) { taken.add(best.id); c.tactics.lineup[i] = best.id }
            else c.tactics.lineup[i] = -1
        }
        val rest = avail.filter { !taken.contains(it.id) }.sortedByDescending { it.overall() }
        val bench = ArrayList<Int>(7)
        rest.firstOrNull { it.pos == Pos.GK }?.let { bench.add(it.id) }
        for (p in rest) {
            if (bench.size >= 7) break
            if (!bench.contains(p.id)) bench.add(p.id)
        }
        for (i in 0 until 7) c.tactics.bench[i] = if (i < bench.size) bench[i] else -1
    }

    /** Estimated income for a full season: prize money, TV, sponsor and the gate. */
    fun seasonRevenue(c: Club): Long {
        val div = division(c.divisionId)
        val prize = div?.prize ?: 30_000_000L
        val tv = div?.tv ?: 40_000_000L
        val ticket = when (c.tier) { 1 -> 38; 2 -> 22; 3 -> 13; 4 -> 8; else -> 5 }
        val attend = (c.capacity * (0.50 + c.reputation / 200.0)).toLong()
        val gate = attend * ticket * 19L
        return (prize * 0.6).toLong() + tv + c.sponsor + gate
    }

    fun recalcBudgets(c: Club) {
        c.transferBudget = max(0L, (c.balance * 0.55).toLong())
        // 55% of income on wages is what a well-run club can carry
        c.wageBudget = ((seasonRevenue(c) * 0.64) / 38.0).roundToInt()
    }

    /* ------------------------------------------------------- RATINGS */

    class TeamRating(var attack: Double, var defence: Double, var control: Double)

    /** Turns a squad plus its instructions into three numbers the match engine uses. */
    fun teamRating(c: Club, home: Boolean): TeamRating {
        val shape = Formations.byName(c.tactics.formation)
        val t = c.tactics
        var atk = 0.0; var def = 0.0; var ctl = 0.0
        var wa = 0.0; var wd = 0.0; var wc = 0.0

        for (i in shape.slots.indices) {
            val p = players[t.lineup.getOrElse(i) { -1 }] ?: continue
            val pos = shape.slots[i].pos
            var e = p.effective(pos)

            // the role he has been given
            val fx = RoleFx.of(t.roleName(i))
            atk += fx.atk; def += fx.def; ctl += fx.ctl
            // a player asked to do something unnatural loses a little sharpness
            if (t.hasPI(i, PI.TAKE_RISKS)) { atk += 0.8; ctl -= 0.9 }
            if (t.hasPI(i, PI.SHOOT_ON_SIGHT)) { atk += 0.5; ctl -= 0.4 }
            if (t.hasPI(i, PI.CLOSE_DOWN)) { ctl += 0.5; def -= 0.3 }
            if (t.hasPI(i, PI.STAY_BACK)) { def += 0.9; atk -= 0.7 }
            if (t.hasPI(i, PI.GET_FORWARD)) { atk += 0.9; def -= 0.7 }
            if (t.hasPI(i, PI.HOLD_POSITION)) { def += 0.5; ctl += 0.3 }
            // a captain steadies everyone around him
            if (t.captain == i && p.hasTrait(Traits.LEADER)) e += 2.0

            val g = Pos.group(pos)
            val sa: Double; val sd: Double; val sc: Double
            when (g) {
                0 -> { sa = 0.0; sd = 1.00; sc = 0.05 }
                1 -> { sa = 0.18; sd = 0.72; sc = 0.25 }
                2 -> { sa = 0.38; sd = 0.32; sc = 0.85 }
                else -> { sa = 0.85; sd = 0.08; sc = 0.32 }
            }
            atk += e * sa; wa += sa
            def += e * sd; wd += sd
            ctl += e * sc; wc += sc
        }
        atk /= max(wa, 0.01); def /= max(wd, 0.01); ctl /= max(wc, 0.01)

        val m = t.mentality - 2                       // -2 .. +2
        atk += m * 3.6; def -= m * 2.8; ctl += m * 0.6

        val press = t.press - 1                       // -1 .. +1
        ctl += press * 2.6; def -= press * 1.4

        val tempo = t.tempo - 1
        atk += tempo * 1.6; ctl -= tempo * 1.0

        when (t.passing) {
            0 -> { ctl += 1.8; atk -= 0.6 }
            2 -> { atk += 1.4; ctl -= 1.6 }
        }
        when (t.width) {
            0 -> { ctl += 1.0; def += 0.5 }
            2 -> atk += 1.1
        }
        when (t.line) {
            0 -> { def += 2.0; atk -= 0.7 }
            2 -> { def -= 1.6; ctl += 1.2 }
        }
        if (t.offsideTrap) def += 1.0
        when (t.marking) { 0 -> ctl += 0.8; 2 -> { def += 1.2; ctl -= 0.6 } }
        when (t.timeWasting) { 0 -> atk += 0.6; 2 -> { def += 1.0; atk -= 1.2; ctl -= 0.8 } }
        if (t.playOut) { ctl += 1.4; def -= 0.9 }
        if (t.focus == 3) atk += 0.8            // both flanks stretches a back four
        if (t.focus == 1) ctl += 0.6            // through the middle keeps it tight
        if (t.counter && m < 0) atk += 2.4
        when (t.tackling) { 0 -> def -= 0.8; 2 -> def += 1.0 }

        // A side that knows its shape keeps the ball and holds its lines; one
        // still learning gives the ball away. This is what makes chopping and
        // changing formation cost something.
        val fam = (t.familiarity - 65.0) * 0.05
        ctl += fam * 1.4; def += fam * 0.9; atk += fam * 0.6

        val bump = (c.morale - 70.0) * 0.05
        atk += bump; def += bump; ctl += bump

        if (home) { atk += 1.9; ctl += 1.2; def += 1.0 }
        return TeamRating(atk, def, ctl)
    }
}

/** Small helper so squad status and potential stay consistent after creation. */
private fun Player.gap() {
    if (potential < overall()) potential = overall()
}
