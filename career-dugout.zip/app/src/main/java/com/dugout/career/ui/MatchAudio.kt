package com.dugout.career.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.dugout.career.core.Synth

/**
 * Streams the generated match audio to the device.
 *
 * The synthesis itself lives in core/Synth.kt and knows nothing about Android;
 * this is only the pipe. One background thread keeps a small AudioTrack buffer
 * topped up, which is cheap: rendering runs at well over a hundred times
 * realtime, so the thread spends nearly all its life blocked inside write().
 */
class MatchAudio(seed: Long) {

    val mixer = Synth.Mixer(seed)

    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    /** Turned off from the match screen; silence must cost nothing. */
    @Volatile var enabled = true
        set(v) {
            field = v
            if (!v) mixer.clear()
        }

    private val minBuf = AudioTrack.getMinBufferSize(
        Synth.RATE,
        AudioFormat.CHANNEL_OUT_STEREO,
        AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(2048)

    fun start() {
        if (running) return
        running = true
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(Synth.RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Throwable) {
            // a device that will not give us a track is not a reason to lose the match
            running = false
            return
        }
        track = t
        t.play()

        val frames = 1024
        val buf = ShortArray(frames * 2)
        val silence = ShortArray(frames * 2)
        thread = Thread({
            while (running) {
                if (enabled) {
                    mixer.render(buf, frames)
                    t.write(buf, 0, frames * 2)
                } else {
                    t.write(silence, 0, frames * 2)
                }
            }
        }, "match-audio").apply {
            priority = Thread.NORM_PRIORITY + 1
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        thread?.join(250)
        thread = null
        try { track?.pause(); track?.flush(); track?.release() } catch (_: Throwable) {}
        track = null
    }

    fun play(kind: Int, gain: Float = 1f, pan: Float = 0f) {
        if (enabled) mixer.play(kind, gain, pan)
    }

    /** 0 quiet, 1 boiling. The bed slides toward this rather than jumping. */
    fun crowd(level: Float) {
        mixer.crowd.target = level.coerceIn(0f, 1f)
    }
}
