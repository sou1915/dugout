package com.dugout.career.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/* ---------------------------------------------------------------- POSITIONS */

object Pos {
    const val GK = 0; const val DC = 1; const val DL = 2; const val DR = 3
    const val DM = 4; const val MC = 5; const val ML = 6; const val MR = 7
    const val AM = 8; const val ST = 9
    const val COUNT = 10

    val NAMES = arrayOf("GK", "DC", "DL", "DR", "DM", "MC", "ML", "MR", "AM", "ST")

    /** 0 keeper, 1 defence, 2 midfield, 3 attack — used for shirt colours and sorting. */
    val GROUP = intArrayOf(0, 1, 1, 1, 2, 2, 2, 2, 3, 3)

    fun name(p: Int) = NAMES[p]
    fun group(p: Int) = GROUP[p]
}

/* --------------------------------------------------------------- ATTRIBUTES */

/**
 * Fourteen outfield attributes plus three keeping ones. Deeper than a single
 * "overall" so the squad screen has something worth reading.
 */
object Att {
    const val PAC = 0   // pace
    const val ACC = 1   // acceleration
    const val FIN = 2   // finishing
    const val LON = 3   // long shots
    const val PAS = 4   // passing
    const val VIS = 5   // vision
    const val DRI = 6   // dribbling
    const val TEC = 7   // technique
    const val TAC = 8   // tackling
    const val MAR = 9   // marking
    const val POS = 10  // positioning
    const val STR = 11  // strength
    const val STA = 12  // stamina
    const val COM = 13  // composure
    const val GKR = 14  // reflexes
    const val GKH = 15  // handling
    const val GKD = 16  // distribution
    const val COUNT = 17

    val NAMES = arrayOf(
        "Pace", "Acceleration", "Finishing", "Long Shots", "Passing", "Vision",
        "Dribbling", "Technique", "Tackling", "Marking", "Positioning", "Strength",
        "Stamina", "Composure", "Reflexes", "Handling", "Distribution"
    )
    val SHORT = arrayOf(
        "PAC", "ACC", "FIN", "LON", "PAS", "VIS", "DRI", "TEC",
        "TAC", "MAR", "POS", "STR", "STA", "COM", "REF", "HAN", "DIS"
    )

    /** Attributes grouped for the player screen. */
    val TECHNICAL = intArrayOf(FIN, LON, PAS, DRI, TEC, TAC, MAR)
    val MENTAL = intArrayOf(VIS, POS, COM)
    val PHYSICAL = intArrayOf(PAC, ACC, STR, STA)
    val KEEPING = intArrayOf(GKR, GKH, GKD)
}

/** How much each attribute counts toward the rating for a given position. */
object Weights {
    private val W = Array(Pos.COUNT) { DoubleArray(Att.COUNT) }

    private fun set(pos: Int, vararg pairs: Pair<Int, Double>) {
        for (p in pairs) W[pos][p.first] = p.second
    }

    init {
        set(Pos.GK, Att.GKR to .30, Att.GKH to .24, Att.GKD to .12, Att.POS to .16, Att.COM to .10, Att.STR to .08)
        set(Pos.DC, Att.MAR to .22, Att.TAC to .20, Att.POS to .18, Att.STR to .16, Att.COM to .08, Att.PAC to .08, Att.PAS to .08)
        set(Pos.DL, Att.PAC to .16, Att.ACC to .12, Att.TAC to .16, Att.MAR to .12, Att.STA to .14, Att.PAS to .12, Att.DRI to .10, Att.POS to .08)
        set(Pos.DR, Att.PAC to .16, Att.ACC to .12, Att.TAC to .16, Att.MAR to .12, Att.STA to .14, Att.PAS to .12, Att.DRI to .10, Att.POS to .08)
        set(Pos.DM, Att.TAC to .20, Att.POS to .18, Att.PAS to .16, Att.MAR to .12, Att.STR to .12, Att.STA to .12, Att.COM to .10)
        set(Pos.MC, Att.PAS to .22, Att.VIS to .16, Att.TEC to .14, Att.STA to .14, Att.COM to .10, Att.DRI to .10, Att.TAC to .08, Att.LON to .06)
        set(Pos.ML, Att.PAC to .16, Att.ACC to .14, Att.DRI to .18, Att.TEC to .14, Att.PAS to .14, Att.STA to .12, Att.FIN to .12)
        set(Pos.MR, Att.PAC to .16, Att.ACC to .14, Att.DRI to .18, Att.TEC to .14, Att.PAS to .14, Att.STA to .12, Att.FIN to .12)
        set(Pos.AM, Att.PAS to .18, Att.VIS to .18, Att.TEC to .16, Att.DRI to .16, Att.FIN to .12, Att.LON to .10, Att.COM to .10)
        set(Pos.ST, Att.FIN to .30, Att.PAC to .14, Att.ACC to .12, Att.COM to .12, Att.TEC to .10, Att.DRI to .08, Att.STR to .08, Att.POS to .06)
    }

    fun of(pos: Int): DoubleArray = W[pos]
    fun isKey(pos: Int, att: Int): Boolean = W[pos][att] >= 0.14
}

/* ------------------------------------------------------------------- ROLES */

/**
 * What a role actually does. Two of these numbers move the player on the
 * pitch, three change what he contributes, so picking a role is a decision
 * you can both see and feel.
 */
class RoleEffect(
    val xShift: Float,      // up (+) or down (-) the pitch
    val ySpread: Float,     // >1 hugs the touchline, <1 tucks inside
    val atk: Double,
    val def: Double,
    val ctl: Double,
    val note: String
)

object RoleFx {
    private val MAP = HashMap<String, RoleEffect>(48)
    private fun put(name: String, x: Float, y: Float, a: Double, d: Double, c: Double, note: String) {
        MAP[name] = RoleEffect(x, y, a, d, c, note)
    }

    val DEFAULT = RoleEffect(0f, 1f, 0.0, 0.0, 0.0, "Plays the position as written.")

    init {
        put("Shot Stopper", 0f, 1f, 0.0, 1.6, -0.4, "Stays on his line and saves shots.")
        put("Sweeper Keeper", 4f, 1f, 0.0, -0.6, 1.8, "Starts moves and covers behind the line.")

        put("Stopper", 3f, 1f, 0.0, 1.2, -0.4, "Steps out to meet the striker.")
        put("Ball-Playing Defender", 1f, 1f, 0.4, 0.2, 2.0, "Brings the ball out and passes through lines.")
        put("Cover Defender", -3f, 1f, 0.0, 1.8, 0.0, "Drops off to sweep up in behind.")
        put("No-Nonsense Centre-Back", -1f, 0.94f, -0.6, 2.2, -1.2, "Heads it and hoofs it.")

        put("Full-Back", 0f, 1f, 0.2, 0.8, 0.2, "Balanced up and down the flank.")
        put("Wing-Back", 11f, 1.12f, 2.2, -1.4, 0.6, "Lives in the opposition half.")
        put("Inverted Full-Back", 2f, 0.68f, 0.0, 0.6, 2.0, "Tucks into midfield in possession.")

        put("Anchor Man", -5f, 0.9f, -0.8, 2.4, 0.4, "Sits in front of the back four.")
        put("Deep-Lying Playmaker", -2f, 0.95f, 0.4, 0.4, 2.6, "Dictates from deep.")
        put("Ball-Winning Midfielder", 2f, 1f, -0.4, 2.2, -0.6, "Hunts the ball and breaks play up.")
        put("Regista", -1f, 1f, 1.4, -0.6, 2.8, "Roams and takes risks with the pass.")

        put("Box-to-Box", 5f, 1f, 1.6, 0.6, 0.4, "Covers every blade of grass.")
        put("Central Playmaker", 2f, 0.95f, 0.8, -0.2, 2.4, "The side plays through him.")
        put("Carrilero", 0f, 1.10f, 0.2, 1.0, 0.8, "Shuttles into the half-space.")
        put("Mezzala", 7f, 1.16f, 1.8, -0.8, 0.8, "Breaks forward off the flank.")

        put("Winger", 3f, 1.22f, 1.8, -0.6, 0.0, "Holds the width and crosses.")
        put("Wide Playmaker", 1f, 1.08f, 0.6, -0.2, 2.2, "Comes inside to link play.")
        put("Inside Forward", 8f, 0.66f, 2.6, -1.4, 0.2, "Cuts in to shoot.")
        put("Wide Target Man", 4f, 1.18f, 1.2, 0.0, 0.4, "An out ball on the flank.")

        put("Attacking Playmaker", 4f, 0.92f, 1.6, -0.8, 2.2, "Finds the pass between the lines.")
        put("Shadow Striker", 10f, 0.85f, 2.8, -1.6, -0.2, "Runs beyond the striker.")
        put("Trequartista", 5f, 1f, 2.2, -2.0, 1.8, "Free role, no defensive duty.")
        put("Enganche", 1f, 0.9f, 0.8, -1.0, 2.8, "Stands still and creates.")

        put("Poacher", 6f, 0.82f, 2.8, -1.8, -1.0, "Lives on the shoulder for tap-ins.")
        put("Target Man", 0f, 0.9f, 1.4, 0.4, 0.6, "Holds it up and wins headers.")
        put("False Nine", -8f, 0.95f, 0.6, -0.4, 2.6, "Drops in and drags defenders out.")
        put("Complete Forward", 2f, 1f, 2.2, 0.0, 1.4, "Does everything up front.")
        put("Pressing Forward", 4f, 1.05f, 1.0, 1.6, 0.0, "First line of the press.")
        put("Deep-Lying Forward", -5f, 0.95f, 1.0, 0.2, 2.0, "Links midfield and attack.")
    }

    fun of(role: String): RoleEffect = MAP[role] ?: DEFAULT
}

object Roles {
    private val BY_POS = arrayOf(
        arrayOf("Shot Stopper", "Sweeper Keeper"),
        arrayOf("Stopper", "Ball-Playing Defender", "Cover Defender", "No-Nonsense Centre-Back"),
        arrayOf("Full-Back", "Wing-Back", "Inverted Full-Back"),
        arrayOf("Full-Back", "Wing-Back", "Inverted Full-Back"),
        arrayOf("Anchor Man", "Deep-Lying Playmaker", "Ball-Winning Midfielder", "Regista"),
        arrayOf("Box-to-Box", "Central Playmaker", "Carrilero", "Mezzala"),
        arrayOf("Winger", "Wide Playmaker", "Inside Forward", "Wide Target Man"),
        arrayOf("Winger", "Wide Playmaker", "Inside Forward", "Wide Target Man"),
        arrayOf("Attacking Playmaker", "Shadow Striker", "Trequartista", "Enganche"),
        arrayOf("Poacher", "Target Man", "False Nine", "Complete Forward", "Pressing Forward", "Deep-Lying Forward")
    )
    fun forPos(pos: Int): Array<String> = BY_POS[pos]
    fun random(rng: Rng, pos: Int): String = rng.pick(BY_POS[pos])
}

/* ------------------------------------------------------------------ TRAITS */

class Trait(val id: Int, val icon: String, val label: String, val desc: String)

object Traits {
    const val LEADER = 0; const val BIG_GAME = 1; const val GLASS = 2; const val LOYAL = 3
    const val GREEDY = 4; const val SET_PIECE = 5; const val ENGINE = 6; const val HOTHEAD = 7
    const val WONDERKID = 8; const val CONSISTENT = 9; const val FLAIR = 10; const val LATE_BLOOM = 11

    val ALL = listOf(
        Trait(LEADER, "\u2605", "Natural Leader", "Lifts the dressing room"),
        Trait(BIG_GAME, "\u26A1", "Big Game Player", "Rises for the occasion"),
        Trait(GLASS, "\u2695", "Injury Prone", "Picks up knocks easily"),
        Trait(LOYAL, "\u2691", "One-Club Man", "Rarely asks to leave"),
        Trait(GREEDY, "\u25C6", "Money Motivated", "Demands the top wage"),
        Trait(SET_PIECE, "\u25CE", "Set-Piece Specialist", "Dangerous from dead balls"),
        Trait(ENGINE, "\u221E", "Tireless", "Barely tires"),
        Trait(HOTHEAD, "\u25A0", "Hot-Headed", "Collects cards"),
        Trait(WONDERKID, "\u2726", "Wonderkid", "Develops far faster than normal"),
        Trait(CONSISTENT, "\u2261", "Consistent", "Rarely has an off day"),
        Trait(FLAIR, "\u2727", "Flair", "Tries the unexpected"),
        Trait(LATE_BLOOM, "\u21D7", "Late Developer", "Keeps improving past 25")
    )
    fun get(id: Int) = ALL[id]
}

val PERSONALITIES = arrayOf(
    "Professional", "Ambitious", "Determined", "Loyal", "Temperamental",
    "Casual", "Model Citizen", "Fickle", "Resolute", "Spirited"
)

/* ------------------------------------------------------------------ PLAYER */

class Player(
    val id: Int,
    val first: String,
    val last: String,
    val full: String,
    val nation: String,
    var age: Int,
    var pos: Int,
    var altPos: Int,          // -1 when there is none
    var role: String,
    val att: IntArray,        // Att.COUNT entries, 1..99
    var potential: Int
) {
    var clubId: Int = -1
    var shirt: Int = 0

    var fitness: Double = 100.0
    var sharpness: Double = 70.0
    var morale: Double = 70.0
    var form: Double = 6.60

    var injuryType: String? = null
    var injuryWeeks: Int = 0
    var suspended: Int = 0
    var yellowSeason: Int = 0
    var redSeason: Int = 0

    var wage: Int = 0
    var contractYears: Int = 3
    var squadStatus: Int = 2      // 0 star, 1 first team, 2 rotation, 3 backup, 4 youngster
    var listed: Boolean = false
    var scouted: Int = 100        // 0..100 — how much of the report is known

    var traits: IntArray = IntArray(0)
    var personality: String = "Professional"

    // this season
    var apps = 0; var goals = 0; var assists = 0; var cleanSheets = 0
    var motm = 0; var minutes = 0; var ratingSum = 0.0; var ratingN = 0

    // career
    var cApps = 0; var cGoals = 0; var cAssists = 0; var cTrophies = 0

    val seasons = ArrayList<SeasonLine>(8)

    val injured: Boolean get() = injuryWeeks > 0
    val available: Boolean get() = injuryWeeks <= 0 && suspended <= 0
    val avgRating: Double get() = if (ratingN == 0) 0.0 else ratingSum / ratingN

    fun hasTrait(t: Int): Boolean {
        for (x in traits) if (x == t) return true
        return false
    }

    /** Weighted rating in the player's natural position. */
    fun overall(): Int = ratingAt(pos)

    /** Weighted rating if asked to play somewhere else. */
    fun ratingAt(p: Int): Int {
        val w = Weights.of(p)
        var sum = 0.0; var tot = 0.0
        for (a in 0 until Att.COUNT) {
            val ww = w[a]
            if (ww > 0.0) { sum += att[a] * ww; tot += ww }
        }
        var o = sum / tot
        if (p != pos) {
            o -= when {
                p == altPos -> 2.0
                Pos.group(p) == Pos.group(pos) -> 6.0
                else -> 14.0
            }
        }
        return o.roundToInt().coerceIn(1, 99)
    }

    /** What the player is actually worth today, on and off the pitch. */
    fun effective(p: Int = pos): Double {
        var base = ratingAt(p).toDouble()
        base *= 0.72 + 0.28 * (fitness / 100.0)
        base *= 0.90 + 0.10 * (sharpness / 100.0)
        base *= 0.93 + 0.07 * (morale / 100.0)
        base *= 0.94 + (form - 6.5) * 0.02
        return base
    }

    fun value(): Long {
        val o = overall()
        var v = 2.0.pow((o - 40) / 5.5) * 300_000.0
        val gap = max(0, potential - o)
        v *= when {
            age <= 19 -> 1.9 + gap * 0.05
            age <= 22 -> 1.5 + gap * 0.04
            age <= 25 -> 1.25 + gap * 0.02
            age <= 28 -> 1.0
            else -> max(0.12, 1.0 - 0.16 * (age - 28))
        }
        if (contractYears <= 1) v *= 0.55
        v *= 0.9 + form / 40.0
        val r = (v / 50_000.0).roundToLong() * 50_000L
        return max(50_000L, r)
    }

    fun expectedWage(): Int {
        val o = overall()
        var w = 2.0.pow((o - 40) / 6.0) * 900.0
        if (age < 21) w *= 0.55
        if (age > 31) w *= 0.80
        if (hasTrait(Traits.GREEDY)) w *= 1.35
        return max(400, (w / 100.0).roundToInt() * 100)
    }

    /** Shift every attribute so the overall lands on a target. */
    fun shiftTo(targetOverall: Double) {
        val diff = targetOverall - overall()
        if (kotlin.math.abs(diff) < 0.01) return
        val d = diff.roundToInt()
        if (d == 0) return
        for (a in 0 until Att.COUNT) att[a] = (att[a] + d).coerceIn(2, 99)
    }

    fun capToPotential() {
        if (overall() > potential) shiftTo(potential.toDouble())
    }

    fun moraleLabel(): String = when {
        morale > 82 -> "Delighted"; morale > 66 -> "Happy"; morale > 48 -> "Content"
        morale > 32 -> "Unsettled"; else -> "Furious"
    }

    fun statusLabel(): String = STATUS[squadStatus]

    companion object {
        val STATUS = arrayOf("Star Player", "First Team", "Rotation", "Backup", "Youngster")
    }
}

class SeasonLine(
    val season: Int, val club: String, val division: String,
    val apps: Int, val goals: Int, val assists: Int, val avg: Double
)

/* ------------------------------------------------------------------ TACTICS */

object Formations {
    /** x runs 0 (own goal) to 100 (their goal); y runs 0 to 100 across the pitch. */
    class Slot(val pos: Int, val x: Int, val y: Int)
    class Shape(val name: String, val slots: Array<Slot>)

    private fun s(p: Int, x: Int, y: Int) = Slot(p, x, y)

    val ALL: Array<Shape> = arrayOf(
        Shape("4-4-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MR, 52, 86), s(Pos.MC, 46, 60), s(Pos.MC, 46, 40), s(Pos.ML, 52, 14),
            s(Pos.ST, 76, 58), s(Pos.ST, 76, 42))),
        Shape("4-3-3", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MC, 44, 50), s(Pos.MC, 50, 70), s(Pos.MC, 50, 30),
            s(Pos.MR, 72, 86), s(Pos.ST, 80, 50), s(Pos.ML, 72, 14))),
        Shape("4-2-3-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.DM, 40, 60), s(Pos.DM, 40, 40),
            s(Pos.MR, 62, 84), s(Pos.AM, 62, 50), s(Pos.ML, 62, 16), s(Pos.ST, 80, 50))),
        Shape("4-1-4-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.DM, 38, 50), s(Pos.MR, 58, 86), s(Pos.MC, 54, 62), s(Pos.MC, 54, 38), s(Pos.ML, 58, 14),
            s(Pos.ST, 78, 50))),
        Shape("3-5-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DC, 20, 72), s(Pos.DC, 18, 50), s(Pos.DC, 20, 28),
            s(Pos.MR, 54, 90), s(Pos.MC, 46, 64), s(Pos.DM, 40, 50), s(Pos.MC, 46, 36), s(Pos.ML, 54, 10),
            s(Pos.ST, 76, 58), s(Pos.ST, 76, 42))),
        Shape("5-3-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 26, 88), s(Pos.DC, 18, 70), s(Pos.DC, 16, 50), s(Pos.DC, 18, 30), s(Pos.DL, 26, 12),
            s(Pos.MC, 48, 66), s(Pos.DM, 42, 50), s(Pos.MC, 48, 34),
            s(Pos.ST, 74, 58), s(Pos.ST, 74, 42))),
        Shape("3-4-3", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DC, 20, 72), s(Pos.DC, 18, 50), s(Pos.DC, 20, 28),
            s(Pos.MR, 52, 88), s(Pos.MC, 46, 60), s(Pos.MC, 46, 40), s(Pos.ML, 52, 12),
            s(Pos.MR, 74, 82), s(Pos.ST, 80, 50), s(Pos.ML, 74, 18))),
        Shape("4-4-1-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MR, 52, 86), s(Pos.MC, 46, 60), s(Pos.MC, 46, 40), s(Pos.ML, 52, 14),
            s(Pos.AM, 64, 50), s(Pos.ST, 80, 50))),
        Shape("4-3-1-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MC, 46, 72), s(Pos.DM, 40, 50), s(Pos.MC, 46, 28),
            s(Pos.AM, 62, 50), s(Pos.ST, 78, 58), s(Pos.ST, 78, 42))),
        Shape("4-2-4", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MC, 46, 62), s(Pos.MC, 46, 38),
            s(Pos.MR, 74, 86), s(Pos.ST, 80, 58), s(Pos.ST, 80, 42), s(Pos.ML, 74, 14))),
        Shape("4-5-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MR, 54, 88), s(Pos.MC, 48, 66), s(Pos.DM, 42, 50), s(Pos.MC, 48, 34), s(Pos.ML, 54, 12),
            s(Pos.ST, 76, 50))),
        Shape("3-4-1-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DC, 20, 72), s(Pos.DC, 18, 50), s(Pos.DC, 20, 28),
            s(Pos.MR, 52, 88), s(Pos.MC, 46, 60), s(Pos.MC, 46, 40), s(Pos.ML, 52, 12),
            s(Pos.AM, 64, 50), s(Pos.ST, 80, 58), s(Pos.ST, 80, 42))),
        Shape("4-1-2-1-2", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.DM, 38, 50), s(Pos.MC, 50, 68), s(Pos.MC, 50, 32),
            s(Pos.AM, 64, 50), s(Pos.ST, 80, 58), s(Pos.ST, 80, 42))),
        Shape("5-2-3", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 26, 88), s(Pos.DC, 18, 70), s(Pos.DC, 16, 50), s(Pos.DC, 18, 30), s(Pos.DL, 26, 12),
            s(Pos.MC, 46, 60), s(Pos.MC, 46, 40),
            s(Pos.MR, 74, 82), s(Pos.ST, 80, 50), s(Pos.ML, 74, 18))),
        Shape("3-4-2-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DC, 20, 72), s(Pos.DC, 18, 50), s(Pos.DC, 20, 28),
            s(Pos.MR, 52, 88), s(Pos.MC, 46, 60), s(Pos.MC, 46, 40), s(Pos.ML, 52, 12),
            s(Pos.AM, 66, 64), s(Pos.AM, 66, 36), s(Pos.ST, 82, 50))),
        Shape("4-3-2-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 24, 84), s(Pos.DC, 20, 62), s(Pos.DC, 20, 38), s(Pos.DL, 24, 16),
            s(Pos.MC, 46, 68), s(Pos.DM, 40, 50), s(Pos.MC, 46, 32),
            s(Pos.AM, 66, 62), s(Pos.AM, 66, 38), s(Pos.ST, 82, 50))),
        Shape("5-4-1", arrayOf(
            s(Pos.GK, 6, 50), s(Pos.DR, 26, 88), s(Pos.DC, 18, 70), s(Pos.DC, 16, 50), s(Pos.DC, 18, 30), s(Pos.DL, 26, 12),
            s(Pos.MR, 52, 84), s(Pos.MC, 44, 60), s(Pos.MC, 44, 40), s(Pos.ML, 52, 16),
            s(Pos.ST, 74, 50)))
    )

    fun byName(n: String): Shape = ALL.firstOrNull { it.name == n } ?: ALL[0]
    fun indexOf(n: String): Int = ALL.indexOfFirst { it.name == n }.coerceAtLeast(0)
}

object Instr {
    val MENTALITY = arrayOf("Very Defensive", "Defensive", "Balanced", "Attacking", "Very Attacking")
    val TEMPO = arrayOf("Slow", "Normal", "Fast")
    val PASSING = arrayOf("Short", "Mixed", "Direct")
    val WIDTH = arrayOf("Narrow", "Normal", "Wide")
    val LINE = arrayOf("Deep", "Normal", "High")
    val PRESS = arrayOf("Low", "Medium", "High")
    val TACKLING = arrayOf("Cautious", "Normal", "Aggressive")
    val FOCUS = arrayOf("Left Flank", "Down the Middle", "Right Flank", "Both Flanks")
    val MARKING = arrayOf("Zonal", "Mixed", "Man to Man")
    val TIME = arrayOf("Never", "Normal", "Waste Time")
    val OPP = arrayOf("No special plan", "Man-mark him", "Close him down", "Show onto weaker foot", "Rough him up")
}

/** Individual instructions. Each one moves the player or changes what he does. */
object PI {
    const val GET_FORWARD = 1
    const val HOLD_POSITION = 2
    const val STAY_WIDER = 4
    const val CUT_INSIDE = 8
    const val CLOSE_DOWN = 16
    const val SHOOT_ON_SIGHT = 32
    const val TAKE_RISKS = 64
    const val STAY_BACK = 128

    val ALL = intArrayOf(
        GET_FORWARD, HOLD_POSITION, STAY_WIDER, CUT_INSIDE,
        CLOSE_DOWN, SHOOT_ON_SIGHT, TAKE_RISKS, STAY_BACK
    )
    val LABELS = arrayOf(
        "Get forward", "Hold position", "Stay wider", "Cut inside",
        "Close down more", "Shoot on sight", "Take more risks", "Stay back at all times"
    )
    fun label(flag: Int): String = LABELS[ALL.indexOf(flag).coerceAtLeast(0)]
}

/** A whole philosophy in one tap. */
class Preset(val name: String, val blurb: String, val apply: (Tactics) -> Unit)

object Presets {
    val ALL = listOf(
        Preset("Tiki-Taka", "Short passing, high line, patient possession") { t ->
            t.mentality = 3; t.tempo = 0; t.passing = 0; t.width = 2; t.line = 2
            t.press = 2; t.tackling = 1; t.counter = false; t.offsideTrap = true
            t.playOut = true; t.focus = 1; t.marking = 0
        },
        Preset("Gegenpress", "Win it back within seconds, high and hard") { t ->
            t.mentality = 4; t.tempo = 2; t.passing = 1; t.width = 1; t.line = 2
            t.press = 2; t.tackling = 2; t.counter = false; t.offsideTrap = true
            t.playOut = false; t.focus = 1; t.marking = 2
        },
        Preset("Catenaccio", "Deep, narrow, and nearly impossible to break") { t ->
            t.mentality = 0; t.tempo = 0; t.passing = 1; t.width = 0; t.line = 0
            t.press = 0; t.tackling = 0; t.counter = true; t.offsideTrap = false
            t.playOut = false; t.focus = 1; t.marking = 2; t.timeWasting = 2
        },
        Preset("Route One", "Straight to the big man, second balls everywhere") { t ->
            t.mentality = 2; t.tempo = 2; t.passing = 2; t.width = 0; t.line = 1
            t.press = 1; t.tackling = 2; t.counter = false; t.playOut = false
            t.focus = 1; t.marking = 1
        },
        Preset("Wing Play", "Stretch them and put it in the box") { t ->
            t.mentality = 3; t.tempo = 1; t.passing = 1; t.width = 2; t.line = 1
            t.press = 1; t.tackling = 1; t.counter = false; t.playOut = false
            t.focus = 3; t.marking = 1
        },
        Preset("Counter-Attack", "Sit in, then go through them at speed") { t ->
            t.mentality = 1; t.tempo = 2; t.passing = 2; t.width = 1; t.line = 0
            t.press = 0; t.tackling = 1; t.counter = true; t.offsideTrap = false
            t.playOut = false; t.focus = 1; t.marking = 1
        },
        Preset("Control", "Balanced, patient, in charge of the game") { t ->
            t.mentality = 2; t.tempo = 1; t.passing = 0; t.width = 1; t.line = 1
            t.press = 1; t.tackling = 1; t.counter = false; t.playOut = true
            t.focus = 1; t.marking = 1
        },
        Preset("Park the Bus", "Everyone behind the ball, hold what you have") { t ->
            t.mentality = 0; t.tempo = 0; t.passing = 2; t.width = 0; t.line = 0
            t.press = 0; t.tackling = 0; t.counter = false; t.playOut = false
            t.focus = 1; t.marking = 2; t.timeWasting = 2
        }
    )
}

class Tactics {
    var formation: String = "4-4-2"
    var mentality = 2     // index into Instr.MENTALITY
    var tempo = 1
    var passing = 1
    var width = 1
    var line = 1
    var press = 1
    var tackling = 1
    var counter = false
    var offsideTrap = false
    var focus = 1          // index into Instr.FOCUS
    var marking = 1        // index into Instr.MARKING
    var timeWasting = 1    // index into Instr.TIME
    var playOut = false    // work it out from the back

    var lineup = IntArray(11) { -1 }     // player ids by formation slot
    var bench = IntArray(7) { -1 }

    /** Role index into the slot position's role list, one per slot. */
    var slotRoles = IntArray(11) { 0 }
    /** Bitmask of PI.* flags, one per slot. */
    var slotInstructions = IntArray(11) { 0 }

    var cornerTaker = -1
    var freeKickTaker = -1
    var penaltyTaker = -1
    var captain = -1

    /** Player id of the opponent to target, and how. */
    var oppTargetId = -1
    var oppMode = 0                      // index into Instr.OPP

    fun copyFrom(o: Tactics) {
        formation = o.formation; mentality = o.mentality; tempo = o.tempo; passing = o.passing
        width = o.width; line = o.line; press = o.press; tackling = o.tackling
        counter = o.counter; offsideTrap = o.offsideTrap
        focus = o.focus; marking = o.marking; timeWasting = o.timeWasting; playOut = o.playOut
        slotRoles = o.slotRoles.copyOf(); slotInstructions = o.slotInstructions.copyOf()
        cornerTaker = o.cornerTaker; freeKickTaker = o.freeKickTaker
        penaltyTaker = o.penaltyTaker; captain = o.captain
        oppTargetId = o.oppTargetId; oppMode = o.oppMode
    }

    fun roleName(slot: Int): String {
        val shape = Formations.byName(formation)
        val pos = shape.slots.getOrNull(slot)?.pos ?: return ""
        val list = Roles.forPos(pos)
        return list[slotRoles.getOrElse(slot) { 0 }.coerceIn(0, list.size - 1)]
    }

    fun hasPI(slot: Int, flag: Int): Boolean = (slotInstructions.getOrElse(slot) { 0 } and flag) != 0
    fun togglePI(slot: Int, flag: Int) {
        if (slot !in 0..10) return
        slotInstructions[slot] = slotInstructions[slot] xor flag
    }
}

/* -------------------------------------------------------------------- CLUB */

class Club(
    val id: Int,
    val name: String,
    val shortName: String,
    val city: String,
    val nation: String,
    val crestSeed: Int,
    val primary: Int,
    val secondary: Int,
    val kitPattern: Int
) {
    var divisionId: Int = -1        // -1 for foreign clubs outside the pyramid
    var tier: Int = 1
    var reputation: Int = 50
    var isUser: Boolean = false

    var stadiumName: String = ""
    var capacity: Int = 10_000

    var balance: Long = 0
    var transferBudget: Long = 0
    var wageBudget: Int = 0
    var sponsor: Long = 0

    val squad = ArrayList<Int>(30)
    val tactics = Tactics()

    var played = 0; var won = 0; var drawn = 0; var lost = 0
    var goalsFor = 0; var goalsAgainst = 0; var points = 0
    val form = ArrayList<Char>(8)

    var morale: Double = 70.0
    var boardConfidence: Int = 65
    val honours = ArrayList<String>(8)

    val goalDiff: Int get() = goalsFor - goalsAgainst

    fun resetSeason() {
        played = 0; won = 0; drawn = 0; lost = 0
        goalsFor = 0; goalsAgainst = 0; points = 0
        form.clear()
    }

    fun record(gf: Int, ga: Int) {
        played++; goalsFor += gf; goalsAgainst += ga
        when {
            gf > ga -> { won++; points += 3; form.add(0, 'W') }
            gf == ga -> { drawn++; points += 1; form.add(0, 'D') }
            else -> { lost++; form.add(0, 'L') }
        }
        while (form.size > 6) form.removeAt(form.size - 1)
    }
}

/* ------------------------------------------------------------------ FORMAT */

object Fmt {
    fun money(n: Long): String {
        val neg = n < 0
        val a = kotlin.math.abs(n)
        val body = when {
            a >= 1_000_000_000L -> String.format("%.2fB", a / 1_000_000_000.0)
            a >= 10_000_000L -> String.format("%.1fM", a / 1_000_000.0)
            a >= 1_000_000L -> String.format("%.2fM", a / 1_000_000.0)
            a >= 1_000L -> "${(a / 1000.0).roundToInt()}K"
            else -> a.toString()
        }
        return (if (neg) "-\u20AC" else "\u20AC") + body
    }

    fun wage(n: Int): String = money(n.toLong()) + "/wk"

    fun ord(n: Int): String {
        val v = n % 100
        val suf = when {
            v in 11..13 -> "th"
            n % 10 == 1 -> "st"
            n % 10 == 2 -> "nd"
            n % 10 == 3 -> "rd"
            else -> "th"
        }
        return "$n$suf"
    }

    fun rating(r: Double): String = String.format("%.2f", r)
    fun one(r: Double): String = String.format("%.1f", r)
}
