package com.dugout.career.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import com.dugout.career.core.Club
import com.dugout.career.core.Kits
import com.dugout.career.core.Pos
import com.dugout.career.core.Rng
import com.dugout.career.sim.Act
import com.dugout.career.sim.LivePlayer
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import kotlin.math.cos
import kotlin.math.sin

/**
 * The match, seen from a high camera tilted just enough to show the players
 * as figures rather than discs. The pitch is drawn close to flat — mown bands
 * run straight up the screen and the lines stay parallel — with the far
 * touchline, its hoardings and the dugouts sitting along the top.
 */
class MatchView(ctx: Context, private val m: MatchEngine) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val path = Path()

    /** 1 = the whole length fits, higher = closer in. */
    var zoom = 1.9f
    var followBall = true

    private var camX = 50f
    private var camY = 50f
    private var unit = 1f          // screen pixels per pitch unit along the length
    private val SQUASH = 0.62f     // how much the width is foreshortened

    private var crowd: FloatArray? = null
    private var crowdColor: IntArray? = null
    private var ads: Array<String>? = null
    private var adColors: IntArray? = null

    private val GRASS_LIGHT = 0xFF8FBF4E.toInt()
    private val GRASS_DARK = 0xFF83B446.toInt()
    private val LINE_WHITE = 0xFFF4F7F0.toInt()

    private val SPONSORS = arrayOf(
        "KOVAX", "AURA BANK", "NORTEL AIR", "VOLTIQ", "MERIDIAN", "FYRE",
        "TESSERA", "HALCYON", "ORBIS", "SANDROC", "VELMONT", "IRONHART",
        "QUANTA", "NIMBUS", "CALDERA", "ZEPHYR", "LUMEN"
    )
    private val AD_COLORS = intArrayOf(
        0xFF1F4FA8.toInt(), 0xFF9A1B2E.toInt(), 0xFF15703F.toInt(), 0xFF5B2D91.toInt(),
        0xFFB4560F.toInt(), 0xFF106A66.toInt(), 0xFF23262F.toInt()
    )
    private val HAIR = intArrayOf(
        0xFF120E0B.toInt(), 0xFF2B1C10.toInt(), 0xFF4A3120.toInt(),
        0xFF6E4826.toInt(), 0xFFB9903F.toInt(), 0xFF1C1C1C.toInt()
    )
    private val SKIN = intArrayOf(
        0xFFF0C39C.toInt(), 0xFFD9A377.toInt(), 0xFFB9793F.toInt(),
        0xFF8A5426.toInt(), 0xFF5E3617.toInt()
    )

    /* ------------------------------------------------------- PROJECTION */

    private fun sx(x: Float): Float = width / 2f + (x - camX) * unit
    private fun sy(y: Float): Float = height * 0.46f + (y - camY) * unit * SQUASH

    /* ------------------------------------------------------------ DRAW */

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        unit = (w / 100f) * zoom

        if (followBall) {
            camX += (m.ball.x - camX) * 0.09f
            // hold the view a touch nearer than the ball, so the far
            // touchline, its hoardings and the stand stay on screen
            camY += ((m.ball.y - 7f) - camY) * 0.09f
        }
        // never show more than a sliver of grass beyond the touchlines
        val halfX = (w / 2f) / unit
        val halfY = (h * 0.46f) / (unit * SQUASH)
        camX = camX.coerceIn(halfX - 8f, 100f - halfX + 8f)
        camY = camY.coerceIn(halfY - 24f, 100f - halfY + 20f)

        c.save()
        if (m.shake > 0f) {
            c.translate((Math.random().toFloat() - 0.5f) * 6f * m.shake,
                (Math.random().toFloat() - 0.5f) * 4f * m.shake)
        }

        drawGrass(c, w, h)
        drawSurrounds(c, w)
        drawMarkings(c)
        drawGoals(c)
        if (m.scene == Scene.FREEKICK) drawSpray(c)

        // everything on the grass, sorted so the nearer figures overlap
        val figures = ArrayList<LivePlayer>(m.players.size)
        for (p in m.players) if (p.onPitch) figures.add(p)
        figures.sortBy { it.y }
        for (p in figures) drawFigure(c, p, if (p.side == 0) m.home else m.away)

        if (m.refCard > 0) drawReferee(c)
        drawBall(c)
        drawSelector(c)

        m.celebrateKey?.let { k ->
            m.players.firstOrNull { it.key == k }?.let { drawSparkle(c, it) }
        }

        drawHud(c, w, h)

        if (m.flash > 0f) {
            paint.shader = null
            paint.color = ((m.flash * 0.30f * 255).toInt() shl 24) or 0xFFFFFF
            c.drawRect(0f, 0f, w, h, paint)
        }
        m.banner?.let { drawBanner(c, w, h, it) }
        c.restore()
    }

    /* ----------------------------------------------------------- GRASS */

    private fun drawGrass(c: Canvas, w: Float, h: Float) {
        paint.shader = null
        paint.color = GRASS_DARK
        c.drawRect(0f, 0f, w, h, paint)

        // mown bands run up the screen, so they are bands of pitch length
        val bands = 16
        for (i in 0 until bands) {
            if (i % 2 != 0) continue
            paint.color = GRASS_LIGHT
            val x0 = sx(i * 100f / bands - 10f)
            val x1 = sx((i + 1) * 100f / bands - 10f)
            c.drawRect(x0, sy(-30f), x1, sy(130f), paint)
        }
    }

    /* --------------------------------------------------- FAR TOUCHLINE */

    /** Verge, hoardings, dugouts and the stand, all beyond the far line. */
    private fun drawSurrounds(c: Canvas, w: Float) {
        val lineY = sy(0f)
        if (lineY < -40f) return

        val vergeH = unit * SQUASH * 2.6f
        val boardH = unit * SQUASH * 3.6f
        val standTop = lineY - vergeH - boardH - unit * SQUASH * 24f

        paint.shader = null
        // stand
        paint.color = 0xFF6E6A66.toInt()
        c.drawRect(0f, standTop, w, lineY - vergeH - boardH, paint)
        if (crowd == null) buildCrowd(w, standTop, lineY - vergeH - boardH)
        drawCrowd(c)

        // hoardings
        if (ads == null) {
            val r = Rng(m.fixture.id * 8887L + 13)
            ads = Array(7) { SPONSORS[r.i(0, SPONSORS.size - 1)] }
            adColors = IntArray(7) { AD_COLORS[r.i(0, AD_COLORS.size - 1)] }
        }
        val boards = ads!!
        val cols = adColors!!
        val bw = w / boards.size
        for (i in boards.indices) {
            val x0 = i * bw
            paint.color = cols[i]
            c.drawRect(x0 + 1.5f, lineY - vergeH - boardH, x0 + bw - 1.5f, lineY - vergeH, paint)
            label.color = 0xFFFFFFFF.toInt()
            label.textSize = boardH * 0.56f
            c.drawText(boards[i], x0 + bw / 2f, lineY - vergeH - boardH * 0.30f, label)
        }

        // sand-coloured verge between the boards and the line
        paint.color = 0xFFC9BE93.toInt()
        c.drawRect(0f, lineY - vergeH, w, lineY, paint)

        drawDugout(c, sx(34f), lineY - vergeH * 0.15f, m.home)
        drawDugout(c, sx(66f), lineY - vergeH * 0.15f, m.away)
        drawSteward(c, sx(15f), lineY - vergeH * 0.15f)
        drawSteward(c, sx(85f), lineY - vergeH * 0.15f)
    }

    private fun drawDugout(c: Canvas, cx: Float, baseY: Float, club: Club) {
        val dw = unit * 13f
        val dh = unit * SQUASH * 4.4f
        paint.shader = null
        paint.color = 0xFF2B3550.toInt()
        rect.set(cx - dw / 2, baseY - dh, cx + dw / 2, baseY)
        c.drawRoundRect(rect, dh * 0.16f, dh * 0.16f, paint)
        paint.color = 0xFF1A2136.toInt()
        c.drawRect(cx - dw / 2, baseY - dh, cx + dw / 2, baseY - dh * 0.78f, paint)
        // substitutes on the bench
        val n = 5
        for (i in 0 until n) {
            val px = cx - dw / 2 + dw * (i + 0.5f) / n
            paint.color = club.primary
            rect.set(px - dw * 0.055f, baseY - dh * 0.66f, px + dw * 0.055f, baseY - dh * 0.20f)
            c.drawRoundRect(rect, dw * 0.03f, dw * 0.03f, paint)
            paint.color = SKIN[(club.id + i) % SKIN.size]
            c.drawCircle(px, baseY - dh * 0.70f, dw * 0.045f, paint)
        }
    }

    private fun drawSteward(c: Canvas, cx: Float, baseY: Float) {
        val hgt = unit * SQUASH * 3.4f
        paint.shader = null
        paint.color = 0xFFD9E24A.toInt()
        rect.set(cx - hgt * 0.22f, baseY - hgt * 0.72f, cx + hgt * 0.22f, baseY - hgt * 0.22f)
        c.drawRoundRect(rect, hgt * 0.08f, hgt * 0.08f, paint)
        paint.color = 0xFF20242E.toInt()
        c.drawRect(cx - hgt * 0.18f, baseY - hgt * 0.24f, cx + hgt * 0.18f, baseY, paint)
        paint.color = SKIN[1]
        c.drawCircle(cx, baseY - hgt * 0.82f, hgt * 0.16f, paint)
    }

    private fun buildCrowd(w: Float, top: Float, bottom: Float) {
        val n = 1400
        val xs = FloatArray(n * 2)
        val cs = IntArray(n)
        val r = Rng(m.fixture.id * 31L + 7)
        for (i in 0 until n) {
            xs[i * 2] = r.f().toFloat() * w
            xs[i * 2 + 1] = top + r.f().toFloat() * (bottom - top)
            cs[i] = when {
                r.chance(0.40) -> m.home.primary
                r.chance(0.50) -> m.away.primary
                r.chance(0.5) -> 0xFF8C8781.toInt()
                else -> 0xFF544F4B.toInt()
            }
        }
        crowd = xs; crowdColor = cs
    }

    private fun drawCrowd(c: Canvas) {
        val xs = crowd ?: return
        val cs = crowdColor ?: return
        paint.shader = null
        val s = kotlin.math.max(2.4f, unit * 0.28f)
        for (i in cs.indices) {
            paint.color = cs[i]
            c.drawRect(xs[i * 2], xs[i * 2 + 1], xs[i * 2] + s, xs[i * 2 + 1] + s, paint)
        }
    }

    /* -------------------------------------------------------- MARKINGS */

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        c.drawLine(sx(x1), sy(y1), sx(x2), sy(y2), stroke)
    }

    private fun drawMarkings(c: Canvas) {
        stroke.color = LINE_WHITE
        stroke.strokeWidth = kotlin.math.max(1.6f, unit * 0.30f)

        line(c, 0f, 0f, 100f, 0f)
        line(c, 0f, 100f, 100f, 100f)
        line(c, 0f, 0f, 0f, 100f)
        line(c, 100f, 0f, 100f, 100f)
        line(c, 50f, 0f, 50f, 100f)

        // centre circle, an ellipse once the width is squashed
        rect.set(sx(50f - 9.2f), sy(50f - 15f), sx(50f + 9.2f), sy(50f + 15f))
        c.drawOval(rect, stroke)
        paint.shader = null
        paint.color = LINE_WHITE
        c.drawCircle(sx(50f), sy(50f), kotlin.math.max(1.8f, unit * 0.35f), paint)

        for (left in booleanArrayOf(true, false)) {
            val gx = if (left) 0f else 100f
            val bx = if (left) 16.5f else 83.5f
            val s6 = if (left) 5.5f else 94.5f
            line(c, gx, 21f, bx, 21f); line(c, gx, 79f, bx, 79f); line(c, bx, 21f, bx, 79f)
            line(c, gx, 37f, s6, 37f); line(c, gx, 63f, s6, 63f); line(c, s6, 37f, s6, 63f)
            val spot = if (left) 11f else 89f
            c.drawCircle(sx(spot), sy(50f), kotlin.math.max(1.6f, unit * 0.30f), paint)
            // the D on the edge of the box
            rect.set(sx(spot - 9.2f), sy(50f - 15f), sx(spot + 9.2f), sy(50f + 15f))
            c.drawArc(rect, if (left) -58f else 122f, 116f, false, stroke)
        }
    }

    private fun drawGoals(c: Canvas) {
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = kotlin.math.max(2f, unit * 0.42f)
        for (left in booleanArrayOf(true, false)) {
            val gx = if (left) 0f else 100f
            val back = if (left) -4.6f else 104.6f
            paint.shader = null
            paint.color = 0x40FFFFFF
            rect.set(kotlin.math.min(sx(gx), sx(back)), sy(42f),
                kotlin.math.max(sx(gx), sx(back)), sy(58f))
            c.drawRect(rect, paint)
            c.drawRect(rect, stroke)
        }
    }

    /** The referee's vanishing spray: the spot and the line for the wall. */
    private fun drawSpray(c: Canvas) {
        paint.shader = null
        paint.color = 0xE6FFFFFF.toInt()
        val r = Rng(1234)
        for (i in 0 until 60) {
            val a = r.f() * Math.PI * 2
            val rad = r.f().toFloat() * 1.5f
            c.drawCircle(sx(m.freeKickX + (cos(a) * rad).toFloat()),
                sy(m.freeKickY + (sin(a) * rad).toFloat()),
                kotlin.math.max(0.8f, unit * 0.06f), paint)
        }
        stroke.color = 0xE6FFFFFF.toInt()
        stroke.strokeWidth = kotlin.math.max(1.4f, unit * 0.16f)
        val half = m.wallCount * 1.2f
        c.drawLine(sx(m.wallX - half), sy(m.wallY - half * 1.6f),
            sx(m.wallX + half), sy(m.wallY + half * 1.6f), stroke)
    }

    /* --------------------------------------------------------- FIGURES */

    /**
     * A footballer as the old handheld games drew him: a big head so he reads
     * at a glance, a clear block of shirt, separate shorts, bare legs into
     * coloured socks, and small dark boots. Everything is sized off one unit
     * so the whole figure scales together.
     */
    private fun drawFigure(c: Canvas, p: LivePlayer, club: Club) {
        val cx = sx(p.x)
        val cy = sy(p.y)
        val u = unit * 1.02f
        val skin = SKIN[p.ref.id % SKIN.size]
        val hair = HAIR[p.ref.id % HAIR.size]
        val shorts = shortsFor(club)
        val socks = club.secondary

        shadow(c, cx, cy, u)

        when (p.action) {
            Act.DOWN -> { prone(c, cx, cy, u, club, skin, hair); return }
            Act.TACKLE -> { sliding(c, cx, cy, u, p, club, skin, hair, socks); return }
            Act.DIVE -> { diving(c, cx, cy, u, p, club, skin, hair, socks); return }
        }

        val running = p.speedNow > 1.2f
        val stride = if (running) sin(p.runPhase.toDouble() * 0.52).toFloat() else 0.16f
        val kicking = p.action == Act.SHOOT || p.action == Act.HEADER
        val kick = if (kicking) (1f - p.actionTime / 0.75f).coerceIn(0f, 1f) else 0f
        val celebrating = p.action == Act.CELEBRATE

        // ---- the ground up: boots, socks, legs -------------------------
        val hipY = cy - u * 0.78f
        val swingA = if (kicking) -0.42f else -stride
        val swingB = if (kicking) 0.34f + kick * 1.25f else stride
        for (sw in floatArrayOf(swingA, swingB)) {
            val footX = cx + sw * u * 0.62f
            val footY = cy - kotlin.math.abs(sw) * u * 0.13f
            val kneeX = cx + sw * u * 0.34f
            // thigh, bare
            stroke.color = skin
            stroke.strokeWidth = u * 0.24f
            c.drawLine(cx + sw * u * 0.11f, hipY + u * 0.04f, kneeX, hipY + u * 0.42f, stroke)
            // sock, club colour
            stroke.color = socks
            stroke.strokeWidth = u * 0.23f
            c.drawLine(kneeX, hipY + u * 0.42f, footX, footY - u * 0.11f, stroke)
            // boot
            paint.shader = null
            paint.color = 0xFF17181F.toInt()
            rect.set(footX - u * 0.20f, footY - u * 0.16f, footX + u * 0.24f, footY + u * 0.01f)
            c.drawRoundRect(rect, u * 0.06f, u * 0.06f, paint)
        }

        // ---- shorts, a block of their own ------------------------------
        paint.shader = null
        paint.color = shorts
        rect.set(cx - u * 0.42f, hipY - u * 0.16f, cx + u * 0.42f, hipY + u * 0.24f)
        c.drawRoundRect(rect, u * 0.09f, u * 0.09f, paint)

        // ---- shirt -----------------------------------------------------
        val topY = hipY - u * 0.96f
        shirt(c, cx, topY, hipY - u * 0.10f, u, club)

        // ---- arms, tucked close so they never read as wings ------------
        stroke.strokeWidth = u * 0.17f
        stroke.color = club.primary
        if (celebrating) {
            c.drawLine(cx - u * 0.38f, topY + u * 0.20f, cx - u * 0.66f, topY - u * 0.52f, stroke)
            c.drawLine(cx + u * 0.38f, topY + u * 0.20f, cx + u * 0.66f, topY - u * 0.52f, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.66f, topY - u * 0.52f, u * 0.12f, paint)
            c.drawCircle(cx + u * 0.66f, topY - u * 0.52f, u * 0.12f, paint)
        } else {
            val sw = -stride * 0.5f
            val ly = topY + u * 0.72f
            c.drawLine(cx - u * 0.36f, topY + u * 0.18f, cx - u * 0.46f - sw * u * 0.10f, ly, stroke)
            c.drawLine(cx + u * 0.36f, topY + u * 0.18f, cx + u * 0.46f + sw * u * 0.10f, ly, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.46f - sw * u * 0.10f, ly, u * 0.11f, paint)
            c.drawCircle(cx + u * 0.46f + sw * u * 0.10f, ly, u * 0.11f, paint)
        }

        // ---- head, deliberately large so he reads from a distance ------
        head(c, cx, topY - u * 0.40f, u * 0.42f, skin, hair, p.facing)

        if (p.injured) {
            paint.shader = null
            paint.color = Theme.RED
            c.drawCircle(cx + u * 0.52f, topY - u * 0.60f, u * 0.17f, paint)
        }
    }

    /** Shorts read best as a clearly different tone from the shirt. */
    private fun shortsFor(club: Club): Int {
        val p = club.primary
        val lum = (((p shr 16) and 0xFF) * 0.30f + ((p shr 8) and 0xFF) * 0.59f + (p and 0xFF) * 0.11f)
        // a dark shirt gets pale shorts and the other way round, so they separate
        return if (lum < 110f) tint(club.secondary, 0.92f) else tint(p, 0.42f)
    }

    private fun shadow(c: Canvas, cx: Float, cy: Float, u: Float) {
        paint.shader = null
        paint.color = 0x2E000000
        rect.set(cx - u * 0.62f, cy - u * 0.16f, cx + u * 0.94f, cy + u * 0.18f)
        c.drawOval(rect, paint)
        paint.color = 0x33000000
        rect.set(cx - u * 0.40f, cy - u * 0.10f, cx + u * 0.52f, cy + u * 0.12f)
        c.drawOval(rect, paint)
    }

    private fun legs(c: Canvas, cx: Float, hipY: Float, footY: Float, u: Float,
                     skin: Int, socks: Int, swingA: Float, swingB: Float) {
        for (sw in floatArrayOf(swingA, swingB)) {
            val kneeX = cx + sw * u * 0.30f
            val footX = cx + sw * u * 0.56f
            val fy = footY - kotlin.math.abs(sw) * u * 0.14f
            stroke.color = skin
            stroke.strokeWidth = u * 0.26f
            c.drawLine(cx + sw * u * 0.10f, hipY + u * 0.16f, kneeX, hipY + u * 0.58f, stroke)
            stroke.color = socks
            c.drawLine(kneeX, hipY + u * 0.58f, footX, fy - u * 0.10f, stroke)
            paint.shader = null
            paint.color = 0xFF15171E.toInt()
            rect.set(footX - u * 0.22f, fy - u * 0.16f, footX + u * 0.26f, fy + u * 0.02f)
            c.drawRoundRect(rect, u * 0.07f, u * 0.07f, paint)
        }
    }

    private fun shirt(c: Canvas, cx: Float, top: Float, bottom: Float, u: Float, club: Club) {
        rect.set(cx - u * 0.47f, top, cx + u * 0.47f, bottom)
        val saved = c.save()
        path.reset()
        path.addRoundRect(rect, u * 0.14f, u * 0.14f, Path.Direction.CW)
        c.clipPath(path)
        paint.shader = null
        paint.color = club.primary
        c.drawRect(rect, paint)
        paint.color = club.secondary
        when (club.kitPattern) {
            Kits.STRIPES -> {
                var x = rect.left; var i = 0
                while (x < rect.right) {
                    if (i % 2 == 0) c.drawRect(x, rect.top, x + u * 0.15f, rect.bottom, paint)
                    x += u * 0.15f; i++
                }
            }
            Kits.HOOPS -> {
                var y = rect.top; var i = 0
                while (y < rect.bottom) {
                    if (i % 2 == 0) c.drawRect(rect.left, y, rect.right, y + u * 0.17f, paint)
                    y += u * 0.17f; i++
                }
            }
            Kits.SASH -> {
                stroke.color = club.secondary
                stroke.strokeWidth = u * 0.26f
                c.drawLine(rect.left, rect.bottom, rect.right, rect.top, stroke)
            }
            Kits.HALVES -> c.drawRect(cx, rect.top, rect.right, rect.bottom, paint)
            Kits.BAND -> c.drawRect(rect.left, top + u * 0.34f, rect.right, top + u * 0.52f, paint)
        }
        c.restoreToCount(saved)
    }

    private fun arms(c: Canvas, cx: Float, shoulderY: Float, u: Float,
                     sleeve: Int, skin: Int, up: Boolean, swing: Float) {
        stroke.strokeWidth = u * 0.20f
        stroke.color = sleeve
        paint.shader = null
        if (up) {
            c.drawLine(cx - u * 0.42f, shoulderY, cx - u * 0.76f, shoulderY - u * 0.70f, stroke)
            c.drawLine(cx + u * 0.42f, shoulderY, cx + u * 0.76f, shoulderY - u * 0.70f, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.76f, shoulderY - u * 0.70f, u * 0.14f, paint)
            c.drawCircle(cx + u * 0.76f, shoulderY - u * 0.70f, u * 0.14f, paint)
        } else {
            val ly = shoulderY + u * 0.58f
            c.drawLine(cx - u * 0.40f, shoulderY, cx - u * 0.56f - swing * u * 0.14f, ly, stroke)
            c.drawLine(cx + u * 0.40f, shoulderY, cx + u * 0.56f + swing * u * 0.14f, ly, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.56f - swing * u * 0.14f, ly, u * 0.13f, paint)
            c.drawCircle(cx + u * 0.56f + swing * u * 0.14f, ly, u * 0.13f, paint)
        }
    }

    private fun head(c: Canvas, cx: Float, cy: Float, r: Float, skin: Int, hair: Int, facing: Float) {
        paint.shader = null
        // neck
        paint.color = tint(skin, 0.86f)
        rect.set(cx - r * 0.30f, cy + r * 0.52f, cx + r * 0.30f, cy + r * 0.98f)
        c.drawRect(rect, paint)

        paint.color = skin
        c.drawCircle(cx, cy, r, paint)

        val deg = ((Math.toDegrees(facing.toDouble()) + 450) % 360).toFloat()
        val backToUs = deg < 60f || deg >= 300f
        val facingUs = deg in 120f..240f

        paint.color = hair
        val saved = c.save()
        path.reset()
        path.addCircle(cx, cy, r, Path.Direction.CW)
        c.clipPath(path)
        when {
            backToUs -> c.drawCircle(cx, cy, r, paint)                       // all we see is hair
            facingUs -> c.drawRect(cx - r, cy - r, cx + r, cy - r * 0.18f, paint)
            else -> {                                                         // profile: hair over the back
                val d = if (deg < 180f) -1f else 1f
                c.drawRect(cx + d * r * 0.05f, cy - r, cx + d * r, cy + r * 0.30f, paint)
                c.drawRect(cx - r, cy - r, cx + r, cy - r * 0.30f, paint)
            }
        }
        c.restoreToCount(saved)

        if (facingUs && r > 6f) {
            paint.color = 0xFF1A1D26.toInt()
            c.drawCircle(cx - r * 0.32f, cy + r * 0.16f, r * 0.11f, paint)
            c.drawCircle(cx + r * 0.32f, cy + r * 0.16f, r * 0.11f, paint)
        }
    }

    private fun sliding(c: Canvas, cx: Float, cy: Float, u: Float, p: LivePlayer,
                        club: Club, skin: Int, hair: Int, socks: Int) {
        val d = if (cos(p.actionDir.toDouble()) >= 0) 1f else -1f
        val by = cy - u * 0.34f
        stroke.strokeWidth = u * 0.24f
        stroke.color = socks
        c.drawLine(cx, by, cx + d * u * 1.15f, by + u * 0.18f, stroke)
        stroke.color = skin
        c.drawLine(cx - d * u * 0.18f, by + u * 0.10f, cx + d * u * 0.48f, by + u * 0.38f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx - d * u * 0.50f - u * 0.20f, by - u * 0.26f, cx - d * u * 0.08f + u * 0.20f, by + u * 0.26f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx - d * u * 1.10f, by - u * 0.36f, cx - d * u * 0.40f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        paint.color = skin
        c.drawCircle(cx - d * u * 1.38f, by - u * 0.22f, u * 0.32f, paint)
        paint.color = hair
        c.drawCircle(cx - d * u * 1.44f, by - u * 0.32f, u * 0.24f, paint)
    }

    private fun diving(c: Canvas, cx: Float, cy: Float, u: Float, p: LivePlayer,
                       club: Club, skin: Int, hair: Int, socks: Int) {
        val d = if (p.actionDir < 0) -1f else 1f
        val by = cy - u * 0.55f
        stroke.strokeWidth = u * 0.26f
        stroke.color = socks
        c.drawLine(cx - d * u * 0.25f, by + u * 0.18f, cx - d * u * 1.20f, by + u * 0.42f, stroke)
        c.drawLine(cx - d * u * 0.25f, by - u * 0.08f, cx - d * u * 1.10f, by - u * 0.04f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx - d * u * 0.56f - u * 0.18f, by - u * 0.28f, cx - d * u * 0.14f + u * 0.18f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx + d * u * 0.08f, by - u * 0.40f, cx + d * u * 0.86f, by + u * 0.32f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        stroke.color = club.primary
        stroke.strokeWidth = u * 0.20f
        c.drawLine(cx + d * u * 0.78f, by - u * 0.16f, cx + d * u * 1.65f, by - u * 0.48f, stroke)
        c.drawLine(cx + d * u * 0.78f, by + u * 0.14f, cx + d * u * 1.60f, by - u * 0.16f, stroke)
        paint.color = club.secondary
        c.drawCircle(cx + d * u * 1.72f, by - u * 0.50f, u * 0.18f, paint)
        c.drawCircle(cx + d * u * 1.68f, by - u * 0.18f, u * 0.18f, paint)
        paint.color = skin
        c.drawCircle(cx + d * u * 1.02f, by - u * 0.52f, u * 0.30f, paint)
        paint.color = hair
        c.drawCircle(cx + d * u * 0.96f, by - u * 0.60f, u * 0.23f, paint)
    }

    private fun prone(c: Canvas, cx: Float, cy: Float, u: Float, club: Club, skin: Int, hair: Int) {
        val by = cy - u * 0.22f
        stroke.strokeWidth = u * 0.22f
        stroke.color = skin
        c.drawLine(cx + u * 0.25f, by + u * 0.10f, cx + u * 1.05f, by + u * 0.26f, stroke)
        c.drawLine(cx + u * 0.25f, by - u * 0.12f, cx + u * 1.00f, by - u * 0.24f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx, by - u * 0.26f, cx + u * 0.40f, by + u * 0.26f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx - u * 0.75f, by - u * 0.32f, cx + u * 0.04f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        paint.color = skin
        c.drawCircle(cx - u * 1.05f, by - u * 0.08f, u * 0.30f, paint)
        paint.color = hair
        c.drawCircle(cx - u * 1.12f, by - u * 0.16f, u * 0.23f, paint)
    }

    /** The official, in yellow, with the card held up. */
    private fun drawReferee(c: Canvas) {
        val cx = sx(m.refX)
        val cy = sy(m.refY)
        val u = unit * 0.92f
        shadow(c, cx, cy, u)
        val hipY = cy - u * 0.92f
        legs(c, cx, hipY, cy, u, SKIN[2], 0xFF15171E.toInt(), -0.2f, 0.2f)
        paint.shader = null
        paint.color = 0xFF23262F.toInt()
        rect.set(cx - u * 0.44f, hipY - u * 0.14f, cx + u * 0.44f, hipY + u * 0.30f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        val topY = hipY - u * 1.10f
        paint.color = 0xFFE8D44A.toInt()
        rect.set(cx - u * 0.47f, topY, cx + u * 0.47f, hipY - u * 0.08f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        // one arm raised, holding the card
        stroke.color = 0xFFE8D44A.toInt()
        stroke.strokeWidth = u * 0.20f
        c.drawLine(cx + u * 0.40f, topY + u * 0.18f, cx + u * 0.78f, topY - u * 0.72f, stroke)
        stroke.color = 0xFFE8D44A.toInt()
        c.drawLine(cx - u * 0.40f, topY + u * 0.18f, cx - u * 0.56f, topY + u * 0.76f, stroke)
        paint.color = if (m.refCard == 2) 0xFFE03434.toInt() else 0xFFF2C94C.toInt()
        rect.set(cx + u * 0.60f, topY - u * 1.16f, cx + u * 0.98f, topY - u * 0.62f)
        c.drawRoundRect(rect, u * 0.05f, u * 0.05f, paint)
        head(c, cx, topY - u * 0.38f, u * 0.36f, SKIN[2], HAIR[0], 0f)
    }

    private fun drawBall(c: Canvas) {
        val bx = sx(m.ball.x)
        val by = sy(m.ball.y)
        val u = unit * 0.92f
        val lift = m.ball.height * u * 0.5f
        paint.shader = null
        paint.color = 0x40000000
        rect.set(bx - u * 0.24f, by - u * 0.09f, bx + u * 0.24f, by + u * 0.09f)
        c.drawOval(rect, paint)
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(bx, by - lift - u * 0.12f, u * 0.22f, paint)
        paint.color = 0xFF23262F.toInt()
        c.drawCircle(bx, by - lift - u * 0.12f, u * 0.08f, paint)
    }

    /** The green wedge over whoever has the ball. */
    private fun drawSelector(c: Canvas) {
        val h = m.ball.holder ?: return
        val p = m.players.firstOrNull { it.key == h } ?: return
        val cx = sx(p.x)
        val topY = sy(p.y) - unit * 0.92f * 2.6f
        val s = unit * 0.62f
        paint.shader = null
        paint.color = if (p.side == 0) 0xFF3FCF4A.toInt() else 0xFFF2B544.toInt()
        path.reset()
        path.moveTo(cx - s, topY - s * 0.9f)
        path.lineTo(cx + s, topY - s * 0.9f)
        path.lineTo(cx, topY)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawSparkle(c: Canvas, p: LivePlayer) {
        val cx = sx(p.x); val cy = sy(p.y) - unit
        val t = m.celebrateTime
        stroke.color = ((((1f - t / 2.4f).coerceIn(0f, 1f) * 255).toInt()) shl 24) or 0xFBBF24
        stroke.strokeWidth = 2.4f
        for (i in 0 until 10) {
            val a = (i / 10f) * Math.PI * 2 + t
            val rr = unit * 1.2f + t * unit * 2.4f
            c.drawLine(cx + (cos(a) * rr * 0.5).toFloat(), cy + (sin(a) * rr * 0.5).toFloat(),
                cx + (cos(a) * rr).toFloat(), cy + (sin(a) * rr).toFloat(), stroke)
        }
    }

    /* -------------------------------------------------------------- HUD */

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val pad = h * 0.022f
        val boxH = h * 0.082f
        paint.shader = null

        // clock, top left
        val clockW = w * 0.20f
        hudBox(c, pad, pad, pad + clockW, pad + boxH)
        label.color = 0xFFFFFFFF.toInt()
        label.textSize = boxH * 0.50f
        val half = if (m.half == 1) "1st" else "2nd"
        c.drawText(half, pad + clockW * 0.22f, pad + boxH * 0.66f, label)
        val mins = kotlin.math.min(m.clock.toInt(), 90)
        c.drawText(String.format("%02d:%02d", mins, ((m.clock - mins) * 60).toInt()),
            pad + clockW * 0.66f, pad + boxH * 0.66f, label)

        // score, top right
        val scoreW = w * 0.26f
        hudBox(c, w - pad - scoreW, pad, w - pad, pad + boxH)
        miniCrest(c, w - pad - scoreW + boxH * 0.55f, pad + boxH / 2f, boxH * 0.36f, m.home)
        miniCrest(c, w - pad - boxH * 0.55f, pad + boxH / 2f, boxH * 0.36f, m.away)
        label.textSize = boxH * 0.56f
        label.color = 0xFFFFFFFF.toInt()
        c.drawText("${m.score[0]} - ${m.score[1]}", w - pad - scoreW / 2f, pad + boxH * 0.68f, label)

        // ball carrier's name, bottom left
        val holder = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
        if (holder != null) {
            val nameW = w * 0.30f
            hudBox(c, pad, h - pad - boxH, pad + nameW, h - pad)
            label.textSize = boxH * 0.50f
            label.color = 0xFFFFFFFF.toInt()
            c.drawText(holder.fullName.uppercase(), pad + nameW / 2f, h - pad - boxH * 0.32f, label)
        }

        drawRadar(c, w, h, pad)
    }

    private fun hudBox(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        paint.color = 0xE014171F.toInt()
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.6f
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, stroke)
    }

    private fun miniCrest(c: Canvas, cx: Float, cy: Float, r: Float, club: Club) {
        paint.shader = null
        paint.color = club.primary
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawRoundRect(rect, r * 0.28f, r * 0.28f, paint)
        paint.color = club.secondary
        c.drawRect(cx - r * 0.22f, cy - r, cx + r * 0.22f, cy + r, paint)
    }

    private fun drawRadar(c: Canvas, w: Float, h: Float, pad: Float) {
        val rw = w * 0.24f
        val rh = rw * 0.62f
        val x0 = w - pad - rw
        val y0 = h - pad - rh
        paint.shader = null
        paint.color = 0xCC1D5B33.toInt()
        rect.set(x0, y0, x0 + rw, y0 + rh)
        c.drawRoundRect(rect, 4f, 4f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.4f
        c.drawRoundRect(rect, 4f, 4f, stroke)
        c.drawLine(x0 + rw / 2, y0, x0 + rw / 2, y0 + rh, stroke)
        c.drawCircle(x0 + rw / 2, y0 + rh / 2, rh * 0.15f, stroke)
        c.drawRect(x0, y0 + rh * 0.26f, x0 + rw * 0.13f, y0 + rh * 0.74f, stroke)
        c.drawRect(x0 + rw * 0.87f, y0 + rh * 0.26f, x0 + rw, y0 + rh * 0.74f, stroke)

        val dot = kotlin.math.max(2.4f, rh * 0.062f)
        for (p in m.players) {
            if (!p.onPitch) continue
            paint.color = if (p.side == 0) m.home.primary else m.away.primary
            val px = x0 + p.x / 100f * rw
            val py = y0 + p.y / 100f * rh
            rect.set(px - dot, py - dot, px + dot, py + dot)
            c.drawRect(rect, paint)
        }
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(x0 + m.ball.x / 100f * rw, y0 + m.ball.y / 100f * rh, dot * 0.8f, paint)
    }

    private fun drawBanner(c: Canvas, w: Float, h: Float, s: String) {
        label.textSize = h * 0.068f
        val tw = label.measureText(s)
        paint.shader = null
        paint.color = 0xE614171F.toInt()
        rect.set(w / 2 - tw / 2 - 22f, h * 0.40f, w / 2 + tw / 2 + 22f, h * 0.40f + h * 0.098f)
        c.drawRoundRect(rect, 6f, 6f, paint)
        stroke.color = 0xFFF2B544.toInt()
        stroke.strokeWidth = 2.5f
        c.drawRoundRect(rect, 6f, 6f, stroke)
        label.color = 0xFFF7F2E6.toInt()
        c.drawText(s, w / 2, h * 0.40f + h * 0.072f, label)
    }

    private fun tint(color: Int, f: Float): Int {
        val a = (color ushr 24) and 0xFF
        val r = (((color shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((color shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
