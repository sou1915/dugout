package com.dugout.career.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import com.dugout.career.core.Att
import com.dugout.career.core.Club
import com.dugout.career.core.Kits
import com.dugout.career.core.Pos
import com.dugout.career.core.Rng
import com.dugout.career.sim.Act
import com.dugout.career.sim.LivePlayer
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import kotlin.math.cos
import kotlin.math.sin

/**
 * The match, seen from a high camera tilted just enough to show the players
 * as figures rather than discs. The pitch is drawn close to flat — mown bands
 * run straight up the screen and the lines stay parallel — with the far
 * touchline, its hoardings and the dugouts sitting along the top.
 */
class MatchView(ctx: Context, private val m: MatchEngine) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER
    }

    /*
     * Rendered at a modest internal size and scaled up smoothly. That keeps
     * the soft, slightly soft-focus look of an early-2010s phone game without
     * ever turning the players into blocks.
     */
    private var buffer: Bitmap? = null
    private var bufferCanvas: Canvas? = null
    private val blit = Paint().apply { isFilterBitmap = true; isAntiAlias = true; isDither = true }
    private val dst = Rect()

    /** Internal render width. Kept high enough that nothing looks blocky. */
    var pixelWidth = 1280

    private var rw = 1f
    private var rh = 1f
    private val rect = RectF()
    private val path = Path()

    /** 1 = the whole length fits, higher = closer in. */
    var zoom = 2.7f
    var followBall = true

    private var camX = 50f
    private var camY = 50f
    private var unit = 1f          // screen pixels per pitch unit along the length
    private val SQUASH = 0.62f     // how much the width is foreshortened

    private var turf: FloatArray? = null
    private var turfShade: IntArray? = null

    private var crowd: FloatArray? = null
    private var crowdColor: IntArray? = null
    private var ads: Array<String>? = null
    private var adColors: IntArray? = null

    private val GRASS_LIGHT = 0xFF9EBA68.toInt()
    private val GRASS_DARK = 0xFF6E8A2E.toInt()
    private val LINE_WHITE = 0xFFF4F7F0.toInt()

    private val SPONSORS = arrayOf(
        "KOVAX", "AURA BANK", "NORTEL AIR", "VOLTIQ", "MERIDIAN", "FYRE",
        "TESSERA", "HALCYON", "ORBIS", "SANDROC", "VELMONT", "IRONHART",
        "QUANTA", "NIMBUS", "CALDERA", "ZEPHYR", "LUMEN"
    )
    private val AD_COLORS = intArrayOf(
        0xFF1F4FA8.toInt(), 0xFF9A1B2E.toInt(), 0xFF15703F.toInt(), 0xFF5B2D91.toInt(),
        0xFFB4560F.toInt(), 0xFF106A66.toInt(), 0xFF23262F.toInt()
    )
    /** How many cuts the hair routine knows. */
    private val HAIRSTYLES = 8

    /** Boot colours, so a squad is not twenty-two pairs of black boots. */
    private val BOOTS = intArrayOf(
        0xFF15161C.toInt(), 0xFFF2F4F8.toInt(), 0xFFE23A3A.toInt(),
        0xFF2FA8E0.toInt(), 0xFFF2C043.toInt(), 0xFF32C07A.toInt(),
        0xFFE8720C.toInt(), 0xFFBF3FD1.toInt()
    )

    private val HAIR = intArrayOf(
        0xFF120E0B.toInt(), 0xFF2B1C10.toInt(), 0xFF4A3120.toInt(),
        0xFF6E4826.toInt(), 0xFFB9903F.toInt(), 0xFF1C1C1C.toInt()
    )
    private val SKIN = intArrayOf(
        0xFFF0C39C.toInt(), 0xFFD9A377.toInt(), 0xFFB9793F.toInt(),
        0xFF8A5426.toInt(), 0xFF5E3617.toInt()
    )

    /* ------------------------------------------------------- PROJECTION */

    private fun sx(x: Float): Float = rw / 2f + (x - camX) * unit
    private fun sy(y: Float): Float = rh * 0.46f + (y - camY) * unit * SQUASH

    /* ------------------------------------------------------------ DRAW */

    override fun onDraw(c: Canvas) {
        if (width <= 0 || height <= 0) return
        val bw = pixelWidth
        val bh = kotlin.math.max(1, bw * height / width)
        var b = buffer
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            buffer = b
            bufferCanvas = Canvas(b)
        }
        renderScene(bufferCanvas!!, bw.toFloat(), bh.toFloat())
        dst.set(0, 0, width, height)
        c.drawBitmap(b, null, dst, blit)
    }

    private fun renderScene(c: Canvas, w: Float, h: Float) {
        if (w <= 0f || h <= 0f) return
        rw = w; rh = h

        val replaying = applyReplayFrame()

        unit = (w / 100f) * zoom

        if (followBall) {
            camX += (m.ball.x - camX) * 0.09f
            // hold the view a touch nearer than the ball, so the far
            // touchline, its hoardings and the stand stay on screen
            camY += ((m.ball.y - 7f) - camY) * 0.09f
        }
        // never show more than a sliver of grass beyond the touchlines
        val halfX = (w / 2f) / unit
        val halfY = (h * 0.46f) / (unit * SQUASH)
        camX = camX.coerceIn(halfX - 8f, 100f - halfX + 8f)
        camY = camY.coerceIn(halfY - 24f, 100f - halfY + 20f)

        c.save()
        if (m.shake > 0f) {
            c.translate((Math.random().toFloat() - 0.5f) * 6f * m.shake,
                (Math.random().toFloat() - 0.5f) * 4f * m.shake)
        }

        drawGrass(c, w, h)
        drawSurrounds(c, w)
        drawMarkings(c)
        drawGoals(c)
        if (m.scene == Scene.FREEKICK) drawSpray(c)

        // everything on the grass, sorted so the nearer figures overlap
        val figures = ArrayList<LivePlayer>(m.players.size)
        for (p in m.players) if (p.onPitch) figures.add(p)
        figures.sortBy { it.y }
        for (p in figures) drawFigure(c, p, if (p.side == 0) m.home else m.away)

        if (m.refCard > 0) drawReferee(c)
        drawBall(c)
        drawSelector(c)

        m.celebrateKey?.let { k ->
            m.players.firstOrNull { it.key == k }?.let { drawSparkle(c, it) }
        }

        drawHud(c, w, h)

        if (m.flash > 0f) {
            paint.shader = null
            paint.color = ((m.flash * 0.30f * 255).toInt() shl 24) or 0xFFFFFF
            c.drawRect(0f, 0f, w, h, paint)
        }
        m.banner?.let { drawBanner(c, w, h, it) }
        if (replaying) drawReplayFurniture(c, w, h)
        c.restore()
        if (replaying) restoreLiveFrame()
    }

    /* ---------------------------------------------------------- REPLAY */

    /*
     * The engine keeps a rolling history of positions and hands over the last
     * couple of seconds when a goal goes in. Rather than a second draw path,
     * the captured frame is written over the live one, the normal renderer runs
     * exactly as it always does, and the live values go back afterwards. That
     * way the replay gets the same sprites, kits and facings as the match.
     */
    private var saved: FloatArray? = null
    private var savedBall = FloatArray(3)

    private fun applyReplayFrame(): Boolean {
        val rep = m.replay ?: return false
        if (rep.isEmpty()) return false
        val idx = m.replayIndex.coerceIn(0, rep.size - 1)
        val f = rep[idx]
        val next = rep[kotlin.math.min(idx + 1, rep.size - 1)]

        val live = ArrayList<LivePlayer>(22)
        for (p in m.players) if (p.onPitch) live.add(p)
        if (live.size != f.xs.size) return false

        var st = saved
        if (st == null || st.size < live.size * 4) {
            st = FloatArray(live.size * 4); saved = st
        }
        for (i in live.indices) {
            val p = live[i]
            st[i * 4] = p.x; st[i * 4 + 1] = p.y
            st[i * 4 + 2] = p.facing; st[i * 4 + 3] = p.speedNow
            p.x = f.xs[i]; p.y = f.ys[i]
            // facing comes from where he goes next, so the sprite turns properly
            val dx = next.xs[i] - f.xs[i]
            val dy = next.ys[i] - f.ys[i]
            val d = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (d > 0.01f) {
                p.facing = kotlin.math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                p.speedNow = d * 22f
                p.runPhase += d * 3.4f
            } else p.speedNow = 0f
        }
        savedBall[0] = m.ball.x; savedBall[1] = m.ball.y; savedBall[2] = m.ball.height
        m.ball.x = f.ballX; m.ball.y = f.ballY
        return true
    }

    private fun restoreLiveFrame() {
        val st = saved ?: return
        val live = ArrayList<LivePlayer>(22)
        for (p in m.players) if (p.onPitch) live.add(p)
        for (i in live.indices) {
            if (i * 4 + 3 >= st.size) break
            val p = live[i]
            p.x = st[i * 4]; p.y = st[i * 4 + 1]
            p.facing = st[i * 4 + 2]; p.speedNow = st[i * 4 + 3]
        }
        m.ball.x = savedBall[0]; m.ball.y = savedBall[1]; m.ball.height = savedBall[2]
    }

    /** Letterbox bars, a label and a progress line, as a broadcast would cut it. */
    private fun drawReplayFurniture(c: Canvas, w: Float, h: Float) {
        val bar = h * 0.085f
        paint.shader = null
        paint.color = 0xF00A0C12.toInt()
        c.drawRect(0f, 0f, w, bar, paint)
        c.drawRect(0f, h - bar, w, h, paint)

        label.textSize = bar * 0.52f
        label.color = 0xFFF2B544.toInt()
        c.drawText("\u25CF  REPLAY", w * 0.5f, bar * 0.68f, label)

        val rep = m.replay ?: return
        val prog = if (rep.size <= 1) 0f else m.replayIndex.toFloat() / (rep.size - 1)
        paint.color = 0x66FFFFFF
        c.drawRect(w * 0.30f, h - bar * 0.52f, w * 0.70f, h - bar * 0.42f, paint)
        paint.color = 0xFFF2B544.toInt()
        c.drawRect(w * 0.30f, h - bar * 0.52f, w * 0.30f + w * 0.40f * prog, h - bar * 0.42f, paint)
    }

    /* ----------------------------------------------------------- GRASS */

    private fun drawGrass(c: Canvas, w: Float, h: Float) {
        paint.shader = null
        paint.color = GRASS_DARK
        c.drawRect(0f, 0f, w, h, paint)

        // mown bands run up the screen, so they are bands of pitch length
        val bands = 10
        for (i in 0 until bands) {
            if (i % 2 != 0) continue
            paint.color = GRASS_LIGHT
            val x0 = sx(i * 100f / bands - 12f)
            val x1 = sx((i + 1) * 100f / bands - 12f)
            c.drawRect(x0, sy(-30f), x1, sy(130f), paint)
        }

        // texture: the turf is never one flat colour
        if (turf == null) buildTurf()
        val t = turf!!
        val tc = turfShade!!
        val blade = kotlin.math.max(1.6f, unit * 0.13f)
        var i = 0
        while (i < tc.size) {
            paint.color = tc[i]
            c.drawRect(sx(t[i * 2]), sy(t[i * 2 + 1]),
                sx(t[i * 2]) + blade, sy(t[i * 2 + 1]) + blade * 0.7f, paint)
            i++
        }

        // the goalmouths and the centre take a beating over a season
        paint.color = 0x1A6B5A33
        for (gx in floatArrayOf(6f, 94f)) {
            rect.set(sx(gx - 7f), sy(38f), sx(gx + 7f), sy(62f))
            c.drawOval(rect, paint)
        }
        rect.set(sx(43f), sy(43f), sx(57f), sy(57f))
        c.drawOval(rect, paint)
    }

    /** A fixed scatter of blades and patches, so the turf never crawls. */
    private fun buildTurf() {
        val n = 2600
        val pts = FloatArray(n * 2)
        val cols = IntArray(n)
        val r = Rng(m.fixture.id * 7717L + 3)
        for (i in 0 until n) {
            pts[i * 2] = -8f + r.f().toFloat() * 116f
            pts[i * 2 + 1] = -6f + r.f().toFloat() * 112f
            cols[i] = when {
                r.chance(0.34) -> 0x26000000.toInt()          // a shade darker
                r.chance(0.50) -> 0x1FFFFFFF           // a shade lighter
                else -> 0x1A4A7A28
            }
        }
        turf = pts; turfShade = cols
    }

    /* --------------------------------------------------- FAR TOUCHLINE */

    /** Verge, hoardings, dugouts and the stand, all beyond the far line. */
    private fun drawSurrounds(c: Canvas, w: Float) {
        val lineY = sy(0f)
        if (lineY < -40f) return

        val vergeH = unit * SQUASH * 2.6f
        val boardH = unit * SQUASH * 3.6f
        val standTop = lineY - vergeH - boardH - unit * SQUASH * 24f

        paint.shader = null
        // stand
        paint.color = 0xFF6E6A66.toInt()
        c.drawRect(0f, standTop, w, lineY - vergeH - boardH, paint)
        if (crowd == null) buildCrowd(w, standTop, lineY - vergeH - boardH)
        drawCrowd(c)

        // hoardings
        if (ads == null) {
            val r = Rng(m.fixture.id * 8887L + 13)
            ads = Array(7) { SPONSORS[r.i(0, SPONSORS.size - 1)] }
            adColors = IntArray(7) { AD_COLORS[r.i(0, AD_COLORS.size - 1)] }
        }
        val boards = ads!!
        val cols = adColors!!
        val bw = w / boards.size
        for (i in boards.indices) {
            val x0 = i * bw
            paint.color = cols[i]
            c.drawRect(x0 + 1.5f, lineY - vergeH - boardH, x0 + bw - 1.5f, lineY - vergeH, paint)
            label.color = 0xFFFFFFFF.toInt()
            label.textSize = boardH * 0.56f
            c.drawText(boards[i], x0 + bw / 2f, lineY - vergeH - boardH * 0.30f, label)
        }

        // sand-coloured verge between the boards and the line
        paint.color = 0xFFC9BE93.toInt()
        c.drawRect(0f, lineY - vergeH, w, lineY, paint)

        drawDugout(c, sx(34f), lineY - vergeH * 0.15f, m.home)
        drawDugout(c, sx(66f), lineY - vergeH * 0.15f, m.away)
        drawSteward(c, sx(15f), lineY - vergeH * 0.15f)
        drawSteward(c, sx(85f), lineY - vergeH * 0.15f)
    }

    private fun drawDugout(c: Canvas, cx: Float, baseY: Float, club: Club) {
        val dw = unit * 13f
        val dh = unit * SQUASH * 4.4f
        paint.shader = null
        paint.color = 0xFF2B3550.toInt()
        rect.set(cx - dw / 2, baseY - dh, cx + dw / 2, baseY)
        c.drawRoundRect(rect, dh * 0.16f, dh * 0.16f, paint)
        paint.color = 0xFF1A2136.toInt()
        c.drawRect(cx - dw / 2, baseY - dh, cx + dw / 2, baseY - dh * 0.78f, paint)
        // substitutes on the bench
        val n = 5
        for (i in 0 until n) {
            val px = cx - dw / 2 + dw * (i + 0.5f) / n
            paint.color = club.primary
            rect.set(px - dw * 0.055f, baseY - dh * 0.66f, px + dw * 0.055f, baseY - dh * 0.20f)
            c.drawRoundRect(rect, dw * 0.03f, dw * 0.03f, paint)
            paint.color = SKIN[(club.id + i) % SKIN.size]
            c.drawCircle(px, baseY - dh * 0.70f, dw * 0.045f, paint)
        }
    }

    private fun drawSteward(c: Canvas, cx: Float, baseY: Float) {
        val hgt = unit * SQUASH * 3.4f
        paint.shader = null
        paint.color = 0xFFD9E24A.toInt()
        rect.set(cx - hgt * 0.22f, baseY - hgt * 0.72f, cx + hgt * 0.22f, baseY - hgt * 0.22f)
        c.drawRoundRect(rect, hgt * 0.08f, hgt * 0.08f, paint)
        paint.color = 0xFF20242E.toInt()
        c.drawRect(cx - hgt * 0.18f, baseY - hgt * 0.24f, cx + hgt * 0.18f, baseY, paint)
        paint.color = SKIN[1]
        c.drawCircle(cx, baseY - hgt * 0.82f, hgt * 0.16f, paint)
    }

    private fun buildCrowd(w: Float, top: Float, bottom: Float) {
        val n = 1400
        val xs = FloatArray(n * 2)
        val cs = IntArray(n)
        val r = Rng(m.fixture.id * 31L + 7)
        for (i in 0 until n) {
            xs[i * 2] = r.f().toFloat() * w
            xs[i * 2 + 1] = top + r.f().toFloat() * (bottom - top)
            cs[i] = when {
                r.chance(0.40) -> m.home.primary
                r.chance(0.50) -> m.away.primary
                r.chance(0.5) -> 0xFF8C8781.toInt()
                else -> 0xFF544F4B.toInt()
            }
        }
        crowd = xs; crowdColor = cs
    }

    private fun drawCrowd(c: Canvas) {
        val xs = crowd ?: return
        val cs = crowdColor ?: return
        paint.shader = null
        val s = kotlin.math.max(2.4f, unit * 0.28f)
        for (i in cs.indices) {
            paint.color = cs[i]
            c.drawRect(xs[i * 2], xs[i * 2 + 1], xs[i * 2] + s, xs[i * 2 + 1] + s, paint)
        }
    }

    /* -------------------------------------------------------- MARKINGS */

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        c.drawLine(sx(x1), sy(y1), sx(x2), sy(y2), stroke)
    }

    private fun drawMarkings(c: Canvas) {
        stroke.color = LINE_WHITE
        stroke.strokeWidth = kotlin.math.max(1.6f, unit * 0.30f)

        line(c, 0f, 0f, 100f, 0f)
        line(c, 0f, 100f, 100f, 100f)
        line(c, 0f, 0f, 0f, 100f)
        line(c, 100f, 0f, 100f, 100f)
        line(c, 50f, 0f, 50f, 100f)

        // centre circle, an ellipse once the width is squashed
        rect.set(sx(50f - 9.2f), sy(50f - 15f), sx(50f + 9.2f), sy(50f + 15f))
        c.drawOval(rect, stroke)
        paint.shader = null
        paint.color = LINE_WHITE
        c.drawCircle(sx(50f), sy(50f), kotlin.math.max(1.8f, unit * 0.35f), paint)

        for (left in booleanArrayOf(true, false)) {
            val gx = if (left) 0f else 100f
            val bx = if (left) 16.5f else 83.5f
            val s6 = if (left) 5.5f else 94.5f
            line(c, gx, 21f, bx, 21f); line(c, gx, 79f, bx, 79f); line(c, bx, 21f, bx, 79f)
            line(c, gx, 37f, s6, 37f); line(c, gx, 63f, s6, 63f); line(c, s6, 37f, s6, 63f)
            val spot = if (left) 11f else 89f
            c.drawCircle(sx(spot), sy(50f), kotlin.math.max(1.6f, unit * 0.30f), paint)
            // the D on the edge of the box
            rect.set(sx(spot - 9.2f), sy(50f - 15f), sx(spot + 9.2f), sy(50f + 15f))
            c.drawArc(rect, if (left) -58f else 122f, 116f, false, stroke)
        }
    }

    private fun drawGoals(c: Canvas) {
        paint.shader = null
        for (left in booleanArrayOf(true, false)) {
            val gx = if (left) 0f else 100f
            val back = if (left) -4.6f else 104.6f
            val l = kotlin.math.min(sx(gx), sx(back))
            val rr = kotlin.math.max(sx(gx), sx(back))
            val t = sy(42f)
            val b = sy(58f)

            // the mouth behind the line, in shade
            paint.color = 0x33101828
            c.drawRect(l, t, rr, b, paint)

            // netting: a mesh rather than a flat wash
            stroke.color = 0x8CFFFFFF.toInt()
            stroke.strokeWidth = kotlin.math.max(0.9f, unit * 0.045f)
            val step = kotlin.math.max(3f, unit * 0.34f)
            var x = l
            while (x <= rr) { c.drawLine(x, t, x, b, stroke); x += step }
            var y = t
            while (y <= b) { c.drawLine(l, y, rr, y, stroke); y += step }

            // frame
            stroke.color = 0xFFFFFFFF.toInt()
            stroke.strokeWidth = kotlin.math.max(2.2f, unit * 0.34f)
            c.drawLine(sx(gx), t, sx(gx), b, stroke)
            c.drawLine(l, t, rr, t, stroke)
            c.drawLine(l, b, rr, b, stroke)
        }
        drawCornerFlags(c)
    }

    private fun drawCornerFlags(c: Canvas) {
        paint.shader = null
        val hgt = unit * 1.5f
        for (fx in floatArrayOf(0f, 100f)) {
            for (fy in floatArrayOf(0f, 100f)) {
                val px = sx(fx)
                val py = sy(fy)
                stroke.color = 0xFFF0F0F0.toInt()
                stroke.strokeWidth = kotlin.math.max(1.4f, unit * 0.10f)
                c.drawLine(px, py, px, py - hgt, stroke)
                paint.color = 0xFFE8B23A.toInt()
                path.reset()
                path.moveTo(px, py - hgt)
                path.lineTo(px + hgt * 0.52f, py - hgt * 0.80f)
                path.lineTo(px, py - hgt * 0.60f)
                path.close()
                c.drawPath(path, paint)
            }
        }
    }

    /** The referee's vanishing spray: the spot and the line for the wall. */
    private fun drawSpray(c: Canvas) {
        paint.shader = null
        paint.color = 0xE6FFFFFF.toInt()
        val r = Rng(1234)
        for (i in 0 until 60) {
            val a = r.f() * Math.PI * 2
            val rad = r.f().toFloat() * 1.5f
            c.drawCircle(sx(m.freeKickX + (cos(a) * rad).toFloat()),
                sy(m.freeKickY + (sin(a) * rad).toFloat()),
                kotlin.math.max(0.8f, unit * 0.06f), paint)
        }
        stroke.color = 0xE6FFFFFF.toInt()
        stroke.strokeWidth = kotlin.math.max(1.4f, unit * 0.16f)
        val half = m.wallCount * 1.2f
        c.drawLine(sx(m.wallX - half), sy(m.wallY - half * 1.6f),
            sx(m.wallX + half), sy(m.wallY + half * 1.6f), stroke)
    }

    /* --------------------------------------------------------- FIGURES */

    /**
     * A footballer as the old handheld games drew him: a big head so he reads
     * at a glance, a clear block of shirt, separate shorts, bare legs into
     * coloured socks, and small dark boots. Everything is sized off one unit
     * so the whole figure scales together.
     */
    private fun drawFigure(c: Canvas, p: LivePlayer, club: Club) {
        val cx = sx(p.x)
        val cy = sy(p.y)
        // Taller again, and no longer eleven copies of one man. Height and
        // build vary per player and follow his strength, so a centre half is
        // visibly a bigger unit than a winger, and the smaller details --
        // sleeve length, how far the socks are pulled up, boot colour -- are
        // spread across the squad so no two look quite alike.
        val idv = p.ref.id
        val heightF = 0.94f + ((idv * 7) % 13) * 0.011f +
            ((p.ref.att[Att.STR] - 60) * 0.0016f)
        val u = unit * 1.02f * heightF.coerceIn(0.90f, 1.12f)
        val buildF = (0.93f + ((idv * 5) % 11) * 0.013f +
            (p.ref.att[Att.STR] - 60) * 0.0022f).coerceIn(0.88f, 1.14f)
        val skin = SKIN[idv % SKIN.size]
        val hair = HAIR[(idv / 3) % HAIR.size]
        val style = (idv / 7) % HAIRSTYLES
        val longSleeves = (idv % 5) == 0
        val socksLow = (idv % 4) == 1
        val bootCol = BOOTS[(idv / 2) % BOOTS.size]
        val shorts = shortsFor(club)
        val socks = club.secondary

        shadow(c, cx, cy, u)

        when (p.action) {
            Act.DOWN -> { prone(c, cx, cy, u, club, skin, hair); return }
            Act.TACKLE -> { sliding(c, cx, cy, u, p, club, skin, hair, socks); return }
            Act.DIVE -> { diving(c, cx, cy, u, p, club, skin, hair, socks); return }
        }
        // not every goal should look the same: a third of them go down on a knee
        if (p.action == Act.CELEBRATE && p.ref.id % 3 == 2) {
            kneeSlide(c, cx, cy, u, p, club, skin, hair, socks, style)
            return
        }

        // Eight compass facings. 0 is straight away from the camera, 4 is
        // straight toward it; the odd numbers are the diagonals.
        val deg = ((Math.toDegrees(p.facing.toDouble()) + 450.0) % 360.0).toFloat()
        val dir = (((deg + 22.5f) / 45f).toInt()) % 8
        val towardCamera = dir in 3..5
        val sideOn = dir == 2 || dir == 6
        val diagonal = dir % 2 == 1
        val faceSign = if (dir in 1..3) 1f else if (dir in 5..7) -1f else 0f
        val bodyW = (if (sideOn) 0.66f else if (diagonal) 0.84f else 1f) * buildF
        val headW = if (sideOn) 0.78f else if (diagonal) 0.90f else 1f
        val legSpread = if (sideOn) 1.02f else if (diagonal) 0.80f else 0.55f
        val lean = faceSign * u * (0.13f + (if (p.speedNow > 1.2f) 0.05f else 0f))

        val running = p.speedNow > 1.2f
        val stride = if (running) sin(p.runPhase.toDouble() * 0.52).toFloat() else 0.16f
        val kicking = p.action == Act.SHOOT || p.action == Act.HEADER
        val kick = if (kicking) (1f - p.actionTime / 0.75f).coerceIn(0f, 1f) else 0f
        val celebrating = p.action == Act.CELEBRATE

        // ---- the ground up: boots, socks, legs -------------------------
        //
        // A proper gait rather than two legs scissoring around a centre line.
        // Each leg runs its own cycle half a turn apart: while one is planted
        // and travelling backwards under the body, the other lifts, bends at
        // the knee and swings through. That is the difference between a man
        // running and a pair of compasses opening and closing.
        val gait = p.runPhase * 0.52f
        val moving = p.speedNow > 0.35f
        val swingAmp = when {
            !moving -> 0.04f
            running -> 0.21f
            else -> 0.13f
        }
        // the body rises and falls twice per stride, which is most of what
        // sells the movement even when the legs are small
        val bob = if (moving) (kotlin.math.abs(cos(gait.toDouble())).toFloat()) * u * 0.13f else 0f
        val hipY = cy - u * 0.82f - bob

        // near leg last, so it overlaps the far one
        for (legIndex in intArrayOf(1, 0)) {
            val near = legIndex == 0
            val ph = gait + legIndex * Math.PI.toFloat()
            val sn = sin(ph.toDouble()).toFloat()
            val cs = cos(ph.toDouble()).toFloat()

            val fx: Float
            val lift: Float
            val bend: Float
            if (kicking) {
                // the striking leg is thrown through; the other plants
                fx = if (near) (0.34f + kick * 1.15f) else -0.30f
                lift = if (near) kick * 0.20f else 0f
                bend = if (near) (1f - kick) * 0.5f else 0.15f
            } else {
                fx = sn * swingAmp
                // the foot only leaves the turf while it is travelling forward
                lift = kotlin.math.max(0f, cs) * (if (running) 0.17f else 0.09f)
                bend = kotlin.math.max(0f, cs)
            }

            val footX = cx + lean + fx * u * legSpread
            val footY = cy - lift * u
            // the knee leads the foot through the swing, which is what stops
            // the leg reading as one stiff bar
            val kneeX = cx + lean * 0.6f + fx * u * 0.46f * legSpread + faceSign * bend * u * 0.10f
            val kneeY = hipY + u * 0.40f - bend * u * 0.07f
            val shade = if (near) 1f else 0.84f

            // thigh, bare
            stroke.color = tint(skin, shade)
            stroke.strokeWidth = u * 0.235f
            c.drawLine(cx + lean * 0.3f + fx * u * 0.14f * legSpread, hipY + u * 0.03f,
                kneeX, kneeY, stroke)
            // knee, just enough to break the straight line of the limb
            paint.shader = null
            paint.color = tint(skin, shade * 0.94f)
            c.drawCircle(kneeX, kneeY, u * 0.115f, paint)
            // sock in club colour, with a turnover band at the top. Some men
            // wear them low, which shows more bare shin.
            val sockTopX = if (socksLow) kneeX + (footX - kneeX) * 0.34f else kneeX
            val sockTopY = if (socksLow) kneeY + (footY - u * 0.10f - kneeY) * 0.34f else kneeY
            if (socksLow) {
                stroke.color = tint(skin, shade)
                stroke.strokeWidth = u * 0.20f
                c.drawLine(kneeX, kneeY, sockTopX, sockTopY, stroke)
            }
            stroke.color = tint(socks, shade)
            stroke.strokeWidth = u * 0.225f
            c.drawLine(sockTopX, sockTopY, footX, footY - u * 0.10f, stroke)
            stroke.color = tint(socks, shade * 0.70f)
            stroke.strokeWidth = u * 0.235f
            c.drawLine(sockTopX, sockTopY + u * 0.02f,
                sockTopX + (footX - sockTopX) * 0.26f,
                sockTopY + (footY - u * 0.10f - sockTopY) * 0.26f, stroke)

            // a small contact shadow that tightens as the boot nears the turf
            if (lift > 0.005f) {
                paint.color = (((0x30 * (1f - lift * 4f).coerceIn(0f, 1f)).toInt()) shl 24)
                rect.set(footX - u * 0.17f, cy - u * 0.05f, footX + u * 0.19f, cy + u * 0.05f)
                c.drawOval(rect, paint)
            }

            // boot: coloured upper, a pale sole and a darker heel
            paint.color = tint(bootCol, shade)
            rect.set(footX - u * 0.19f, footY - u * 0.155f, footX + u * 0.24f, footY - u * 0.01f)
            c.drawRoundRect(rect, u * 0.06f, u * 0.06f, paint)
            paint.color = tint(0xFFE8E4DC.toInt(), shade)
            rect.set(footX - u * 0.19f, footY - u * 0.035f, footX + u * 0.24f, footY + u * 0.012f)
            c.drawRoundRect(rect, u * 0.025f, u * 0.025f, paint)
            paint.color = tint(bootCol, shade * 0.62f)
            c.drawRect(footX - u * 0.19f, footY - u * 0.155f, footX - u * 0.09f, footY - u * 0.02f, paint)
            paint.color = tint(0xFFF4F6FA.toInt(), shade)
            c.drawRect(footX - u * 0.02f, footY - u * 0.118f, footX + u * 0.08f, footY - u * 0.085f, paint)
        }

        // ---- shorts, with a hem and a side flash -----------------------
        paint.shader = null
        val shL = cx + lean * 0.5f - u * 0.42f * bodyW
        val shR = cx + lean * 0.5f + u * 0.42f * bodyW
        litShade(c, shL, hipY - u * 0.17f, shR, hipY + u * 0.24f, shorts, u * 0.09f)
        // the split between the legs, so it does not read as one block
        paint.color = tint(shorts, 0.74f)
        c.drawRect(cx + lean * 0.5f - u * 0.02f, hipY + u * 0.06f,
            cx + lean * 0.5f + u * 0.02f, hipY + u * 0.24f, paint)
        paint.color = tint(club.secondary, 1f)
        c.drawRect(shL, hipY - u * 0.02f, shL + u * 0.055f, hipY + u * 0.18f, paint)

        // ---- shirt -----------------------------------------------------
        val topY = hipY - u * 1.00f
        shirt(c, cx + lean * 0.5f, topY, hipY - u * 0.10f, u * bodyW, club, towardCamera)

        // the number is on his back, so it shows only when he is running away
        if (dir == 0 || dir == 1 || dir == 7) {
            label.color = shirtNumberColour(club)
            label.textSize = u * 0.44f
            c.drawText(p.shirt.toString(), cx + lean * 0.5f, topY + u * 0.66f, label)
        }

        // ---- arms: sleeve, then bare forearm, then a hand --------------
        val sleeveCol = sleeveFor(club)
        if (celebrating && p.ref.id % 3 == 1) {
            // arms straight out, aeroplane
            armWide(c, cx - u * 0.36f * bodyW, topY + u * 0.20f, -1f, u, sleeveCol, skin)
            armWide(c, cx + u * 0.36f * bodyW, topY + u * 0.20f, 1f, u, sleeveCol, skin)
        } else if (celebrating) {
            armRaised(c, cx - u * 0.36f * bodyW, topY + u * 0.16f, -1f, u, sleeveCol, skin)
            armRaised(c, cx + u * 0.36f * bodyW, topY + u * 0.16f, 1f, u, sleeveCol, skin)
        } else {
            // an arm swings against the leg on the same side, which is what the
            // body actually does and what stops the run looking mechanical
            val armSwing = sin(gait.toDouble()).toFloat() * (if (running) 1f else 0.55f)
            if (!sideOn) armDown(c, cx + lean * 0.5f, topY, u, bodyW, 1f, -armSwing,
                sleeveCol, skin, longSleeves)
            armDown(c, cx + lean * 0.5f, topY, u, bodyW, -1f, armSwing,
                sleeveCol, skin, longSleeves)
        }

        // ---- head, deliberately large so he reads from a distance ------
        head(c, cx + lean * 0.8f, topY - u * 0.46f, u * 0.46f, skin, hair, p.facing, headW, style)

        if (p.injured) {
            paint.shader = null
            paint.color = Theme.RED
            c.drawCircle(cx + u * 0.52f, topY - u * 0.62f, u * 0.16f, paint)
        }
    }

    /** Sleeves are often a contrast on a real shirt; it also separates the arms. */
    private fun sleeveFor(club: Club): Int {
        val p = club.primary
        val lum = (((p shr 16) and 0xFF) * 0.30f + ((p shr 8) and 0xFF) * 0.59f + ((p and 0xFF)) * 0.11f)
        return when (club.kitPattern) {
            Kits.STRIPES, Kits.HOOPS -> tint(p, 0.88f)
            Kits.HALVES -> club.secondary
            else -> if (lum < 110f) tint(p, 1.25f) else tint(p, 0.80f)
        }
    }

    /** Upper arm in the sleeve colour, forearm bare, then a hand on the end. */
    private fun armDown(c: Canvas, cx: Float, topY: Float, u: Float, bodyW: Float,
                        side: Float, swing: Float, sleeve: Int, skin: Int,
                        longSleeve: Boolean = false) {
        val shX = cx + side * u * 0.40f * bodyW
        val shY = topY + u * 0.18f
        // the elbow stays close in; the hand carries most of the swing, and the
        // forearm folds up a little as it comes forward
        val fold = kotlin.math.max(0f, swing) * u * 0.10f
        val sleeveEnd = if (longSleeve) 0.86f else 0.42f
        val elX = cx + side * u * 0.46f * bodyW + swing * u * 0.10f
        val elY = topY + u * 0.50f
        val haX = cx + side * u * 0.44f * bodyW + swing * u * 0.30f
        val haY = topY + u * 0.76f - fold
        // the sleeve runs a share of the way to the hand, the rest is forearm
        val cuffX = shX + (haX - shX) * sleeveEnd
        val cuffY = shY + (haY - shY) * sleeveEnd
        stroke.strokeWidth = u * 0.155f
        stroke.color = sleeve
        c.drawLine(shX, shY, cuffX, cuffY, stroke)
        stroke.color = skin
        stroke.strokeWidth = u * 0.13f
        c.drawLine(cuffX, cuffY, haX, haY, stroke)
        paint.shader = null
        paint.color = skin
        c.drawCircle(haX, haY, u * 0.095f, paint)
        // a knuckle line, which at this size is only a darker pip
        paint.color = tint(skin, 0.82f)
        c.drawCircle(haX + side * u * 0.03f, haY + u * 0.03f, u * 0.04f, paint)
    }

    private fun armWide(c: Canvas, shX: Float, shY: Float, side: Float, u: Float,
                        sleeve: Int, skin: Int) {
        val elX = shX + side * u * 0.40f
        val elY = shY - u * 0.08f
        val haX = shX + side * u * 0.78f
        val haY = shY - u * 0.14f
        stroke.strokeWidth = u * 0.155f
        stroke.color = sleeve
        c.drawLine(shX, shY, elX, elY, stroke)
        stroke.color = skin
        stroke.strokeWidth = u * 0.13f
        c.drawLine(elX, elY, haX, haY, stroke)
        paint.shader = null
        paint.color = skin
        c.drawCircle(haX, haY, u * 0.10f, paint)
    }

    /** Down on one knee with both arms up, sliding across the grass. */
    private fun kneeSlide(c: Canvas, cx: Float, cy: Float, u: Float, p: LivePlayer,
                          club: Club, skin: Int, hair: Int, socks: Int, style: Int) {
        val d = if (cos(p.facing.toDouble()) >= 0) 1f else -1f
        val hipY = cy - u * 0.46f
        // the trailing leg folded under him, the leading leg stretched out
        stroke.strokeWidth = u * 0.22f
        stroke.color = skin
        c.drawLine(cx, hipY + u * 0.06f, cx - d * u * 0.42f, hipY + u * 0.34f, stroke)
        stroke.color = socks
        c.drawLine(cx - d * u * 0.42f, hipY + u * 0.34f, cx + d * u * 0.10f, hipY + u * 0.46f, stroke)
        stroke.color = skin
        c.drawLine(cx, hipY + u * 0.06f, cx + d * u * 0.52f, hipY + u * 0.22f, stroke)
        stroke.color = socks
        c.drawLine(cx + d * u * 0.52f, hipY + u * 0.22f, cx + d * u * 0.92f, hipY + u * 0.42f, stroke)
        paint.shader = null
        paint.color = 0xFF15161C.toInt()
        rect.set(cx + d * u * 0.86f - u * 0.10f, hipY + u * 0.34f,
            cx + d * u * 0.86f + u * 0.16f, hipY + u * 0.48f)
        c.drawRoundRect(rect, u * 0.05f, u * 0.05f, paint)

        // a spray of turf coming off the slide
        paint.color = 0x9958761F.toInt()
        for (i in 0 until 6) {
            val fx = cx - d * (u * 0.5f + i * u * 0.16f)
            c.drawCircle(fx, hipY + u * 0.46f - i * u * 0.03f, u * (0.07f - i * 0.008f), paint)
        }

        litShade(c, cx - u * 0.40f, hipY - u * 0.16f, cx + u * 0.40f, hipY + u * 0.20f,
            shortsFor(club), u * 0.09f)
        val topY = hipY - u * 1.00f
        shirt(c, cx, topY, hipY - u * 0.10f, u, club, true)
        val sleeveCol = sleeveFor(club)
        armRaised(c, cx - u * 0.34f, topY + u * 0.16f, -1f, u, sleeveCol, skin)
        armRaised(c, cx + u * 0.34f, topY + u * 0.16f, 1f, u, sleeveCol, skin)
        head(c, cx, topY - u * 0.42f, u * 0.40f, skin, hair, (Math.PI / 2).toFloat(), 1f, style)
    }

    private fun armRaised(c: Canvas, shX: Float, shY: Float, side: Float, u: Float,
                          sleeve: Int, skin: Int) {
        val elX = shX + side * u * 0.26f
        val elY = shY - u * 0.34f
        val haX = shX + side * u * 0.30f
        val haY = shY - u * 0.72f
        stroke.strokeWidth = u * 0.155f
        stroke.color = sleeve
        c.drawLine(shX, shY, elX, elY, stroke)
        stroke.color = skin
        stroke.strokeWidth = u * 0.13f
        c.drawLine(elX, elY, haX, haY, stroke)
        paint.shader = null
        paint.color = skin
        c.drawCircle(haX, haY, u * 0.10f, paint)
    }

    /** Shorts read best as a clearly different tone from the shirt. */
    /** A number has to sit legibly on whatever the shirt happens to be. */
    private fun shirtNumberColour(club: Club): Int {
        val p = club.primary
        val lum = ((p shr 16 and 0xFF) * 0.30f + (p shr 8 and 0xFF) * 0.59f + (p and 0xFF) * 0.11f)
        return if (lum > 140f) 0xFF1A1D26.toInt() else 0xFFF2F4F8.toInt()
    }

    private fun shortsFor(club: Club): Int {
        val p = club.primary
        val lum = (((p shr 16) and 0xFF) * 0.30f + ((p shr 8) and 0xFF) * 0.59f + (p and 0xFF) * 0.11f)
        // a dark shirt gets pale shorts and the other way round, so they separate
        return if (lum < 110f) tint(club.secondary, 0.92f) else tint(p, 0.42f)
    }

    /** One small round shadow, baked, sitting under the boots. */
    /**
     * Three stacked ellipses rather than one flat disc. The outer rings are
     * nearly transparent, so the edge falls away instead of stopping dead —
     * a baked soft shadow, which is how these games always did it.
     */
    private fun shadow(c: Canvas, cx: Float, cy: Float, u: Float) {
        paint.shader = null
        paint.color = 0x14000000
        rect.set(cx - u * 0.60f, cy - u * 0.20f, cx + u * 0.60f, cy + u * 0.20f)
        c.drawOval(rect, paint)
        paint.color = 0x1F000000
        rect.set(cx - u * 0.50f, cy - u * 0.165f, cx + u * 0.50f, cy + u * 0.165f)
        c.drawOval(rect, paint)
        paint.color = 0x33000000
        rect.set(cx - u * 0.38f, cy - u * 0.125f, cx + u * 0.38f, cy + u * 0.125f)
        c.drawOval(rect, paint)
    }

    private fun legs(c: Canvas, cx: Float, hipY: Float, footY: Float, u: Float,
                     skin: Int, socks: Int, swingA: Float, swingB: Float) {
        for (sw in floatArrayOf(swingA, swingB)) {
            val kneeX = cx + sw * u * 0.30f
            val footX = cx + sw * u * 0.56f
            val fy = footY - kotlin.math.abs(sw) * u * 0.14f
            stroke.color = skin
            stroke.strokeWidth = u * 0.26f
            c.drawLine(cx + sw * u * 0.10f, hipY + u * 0.16f, kneeX, hipY + u * 0.58f, stroke)
            stroke.color = socks
            c.drawLine(kneeX, hipY + u * 0.58f, footX, fy - u * 0.10f, stroke)
            paint.shader = null
            paint.color = 0xFF15171E.toInt()
            rect.set(footX - u * 0.22f, fy - u * 0.16f, footX + u * 0.26f, fy + u * 0.02f)
            c.drawRoundRect(rect, u * 0.07f, u * 0.07f, paint)
        }
    }

    /**
     * Flat colour with a single soft bake along the bottom edge. No directional
     * light, no banding: the shading is painted into the sprite, which is how
     * these games always did it.
     */
    private fun litShade(c: Canvas, l: Float, t: Float, r: Float, b: Float, base: Int, round: Float) {
        rect.set(l, t, r, b)
        paint.color = base
        c.drawRoundRect(rect, round, round, paint)
        paint.color = tint(base, 0.86f)
        rect.set(l, t + (b - t) * 0.66f, r, b)
        c.drawRoundRect(rect, round, round, paint)
        rect.set(l, t, r, b)
    }

    private fun shirt(c: Canvas, cx: Float, top: Float, bottom: Float, u: Float,
                      club: Club, towardCamera: Boolean) {
        rect.set(cx - u * 0.47f, top, cx + u * 0.47f, bottom)
        val saved = c.save()
        path.reset()
        path.addRoundRect(rect, u * 0.14f, u * 0.14f, Path.Direction.CW)
        c.clipPath(path)
        paint.shader = null
        litShade(c, rect.left, rect.top, rect.right, rect.bottom, club.primary, u * 0.14f)
        rect.set(cx - u * 0.47f, top, cx + u * 0.47f, bottom)
        paint.color = club.secondary
        when (club.kitPattern) {
            Kits.STRIPES -> {
                var x = rect.left; var i = 0
                while (x < rect.right) {
                    if (i % 2 == 0) c.drawRect(x, rect.top, x + u * 0.15f, rect.bottom, paint)
                    x += u * 0.15f; i++
                }
            }
            Kits.HOOPS -> {
                var y = rect.top; var i = 0
                while (y < rect.bottom) {
                    if (i % 2 == 0) c.drawRect(rect.left, y, rect.right, y + u * 0.17f, paint)
                    y += u * 0.17f; i++
                }
            }
            Kits.SASH -> {
                stroke.color = club.secondary
                stroke.strokeWidth = u * 0.26f
                c.drawLine(rect.left, rect.bottom, rect.right, rect.top, stroke)
            }
            Kits.HALVES -> c.drawRect(cx, rect.top, rect.right, rect.bottom, paint)
            Kits.BAND -> c.drawRect(rect.left, top + u * 0.34f, rect.right, top + u * 0.52f, paint)
        }

        // shoulders catch a little more light than the belly
        paint.color = 0x1AFFFFFF
        c.drawRect(rect.left, rect.top, rect.right, rect.top + u * 0.16f, paint)

        // a collar, and on the chest a small crest patch, both of which are
        // most of what tells you this is a football shirt at this size
        paint.color = tint(club.secondary, 0.95f)
        if (towardCamera) {
            rect.set(cx - u * 0.17f, top - u * 0.02f, cx + u * 0.17f, top + u * 0.10f)
            c.drawRoundRect(rect, u * 0.05f, u * 0.05f, paint)
            paint.color = tint(club.primary, 0.62f)
            rect.set(cx - u * 0.09f, top, cx + u * 0.09f, top + u * 0.07f)
            c.drawRoundRect(rect, u * 0.03f, u * 0.03f, paint)
            // crest, high on the left of his chest
            paint.color = tint(club.secondary, 1.05f)
            rect.set(cx + u * 0.13f, top + u * 0.20f, cx + u * 0.27f, top + u * 0.38f)
            c.drawRoundRect(rect, u * 0.04f, u * 0.04f, paint)
        } else {
            // from behind, the collar is a plain band across the shoulders
            rect.set(cx - u * 0.18f, top - u * 0.01f, cx + u * 0.18f, top + u * 0.08f)
            c.drawRoundRect(rect, u * 0.04f, u * 0.04f, paint)
        }
        // cuffs, where the sleeve ends
        paint.color = tint(club.secondary, 0.95f)
        c.drawRect(rect.left, top + u * 0.30f, cx - u * 0.38f, top + u * 0.36f, paint)
        c.drawRect(cx + u * 0.38f, top + u * 0.30f, cx + u * 0.47f, top + u * 0.36f, paint)
        c.restoreToCount(saved)
    }

    private fun arms(c: Canvas, cx: Float, shoulderY: Float, u: Float,
                     sleeve: Int, skin: Int, up: Boolean, swing: Float) {
        stroke.strokeWidth = u * 0.20f
        stroke.color = sleeve
        paint.shader = null
        if (up) {
            c.drawLine(cx - u * 0.42f, shoulderY, cx - u * 0.76f, shoulderY - u * 0.70f, stroke)
            c.drawLine(cx + u * 0.42f, shoulderY, cx + u * 0.76f, shoulderY - u * 0.70f, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.76f, shoulderY - u * 0.70f, u * 0.14f, paint)
            c.drawCircle(cx + u * 0.76f, shoulderY - u * 0.70f, u * 0.14f, paint)
        } else {
            val ly = shoulderY + u * 0.58f
            c.drawLine(cx - u * 0.40f, shoulderY, cx - u * 0.56f - swing * u * 0.14f, ly, stroke)
            c.drawLine(cx + u * 0.40f, shoulderY, cx + u * 0.56f + swing * u * 0.14f, ly, stroke)
            paint.color = skin
            c.drawCircle(cx - u * 0.56f - swing * u * 0.14f, ly, u * 0.13f, paint)
            c.drawCircle(cx + u * 0.56f + swing * u * 0.14f, ly, u * 0.13f, paint)
        }
    }

    private fun head(c: Canvas, cx: Float, cy: Float, r: Float, skin: Int, hair: Int,
                     facing: Float, widthF: Float = 1f, style: Int = 0) {
        val rx = r * widthF
        paint.shader = null
        // neck
        paint.color = tint(skin, 0.86f)
        rect.set(cx - rx * 0.30f, cy + r * 0.52f, cx + rx * 0.30f, cy + r * 0.98f)
        c.drawRect(rect, paint)

        // an ellipse, not a circle: side-on the skull is seen edge-on and has
        // to narrow with the shoulders or the turn does not read
        paint.color = skin
        rect.set(cx - rx, cy - r, cx + rx, cy + r)
        c.drawOval(rect, paint)
        paint.color = tint(skin, 0.88f)
        val sv0 = c.save()
        path.reset()
        rect.set(cx - rx, cy - r, cx + rx, cy + r)
        path.addOval(rect, Path.Direction.CW)
        c.clipPath(path)
        rect.set(cx - rx, cy + r * 0.46f, cx + rx, cy + r)
        c.drawRect(rect, paint)
        c.restoreToCount(sv0)

        val deg = ((Math.toDegrees(facing.toDouble()) + 450) % 360).toFloat()
        val backToUs = deg < 60f || deg >= 300f
        val facingUs = deg in 120f..240f

        // ---- ears, which only show once he is not square to the camera ----
        if (!backToUs) {
            paint.color = tint(skin, 0.90f)
            if (facingUs) {
                c.drawCircle(cx - rx * 0.96f, cy + r * 0.06f, r * 0.16f, paint)
                c.drawCircle(cx + rx * 0.96f, cy + r * 0.06f, r * 0.16f, paint)
            } else {
                val d = if (deg < 180f) -1f else 1f
                c.drawCircle(cx + d * rx * 0.55f, cy + r * 0.06f, r * 0.17f, paint)
            }
        }

        // ---- face -------------------------------------------------------
        //
        // Bigger and higher-contrast than before. At this size a one-pixel dot
        // disappears into the antialiasing, so the eyes are whites with a dark
        // pupil, the nose is a shaded wedge and the mouth is a real mark.
        if (facingUs) {
            val eyeY = cy + r * 0.02f
            val eyeDx = rx * 0.36f
            // whites first, then the pupil, so the eye reads at a glance
            paint.color = 0xFFF6F1EA.toInt()
            rect.set(cx - eyeDx - rx * 0.19f, eyeY - r * 0.14f, cx - eyeDx + rx * 0.19f, eyeY + r * 0.14f)
            c.drawOval(rect, paint)
            rect.set(cx + eyeDx - rx * 0.19f, eyeY - r * 0.14f, cx + eyeDx + rx * 0.19f, eyeY + r * 0.14f)
            c.drawOval(rect, paint)
            paint.color = 0xFF1A1410.toInt()
            c.drawCircle(cx - eyeDx, eyeY + r * 0.01f, r * 0.105f, paint)
            c.drawCircle(cx + eyeDx, eyeY + r * 0.01f, r * 0.105f, paint)

            // brows, in the hair colour, carrying the expression
            paint.color = tint(hair, 1.05f)
            rect.set(cx - eyeDx - rx * 0.24f, cy - r * 0.34f, cx - eyeDx + rx * 0.20f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
            rect.set(cx + eyeDx - rx * 0.20f, cy - r * 0.34f, cx + eyeDx + rx * 0.24f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)

            // nose: a shaded wedge down the centre with a lit edge
            paint.color = tint(skin, 0.80f)
            rect.set(cx - rx * 0.10f, cy + r * 0.10f, cx + rx * 0.11f, cy + r * 0.40f)
            c.drawRoundRect(rect, r * 0.07f, r * 0.07f, paint)
            paint.color = tint(skin, 1.10f)
            c.drawRect(cx - rx * 0.10f, cy + r * 0.10f, cx - rx * 0.04f, cy + r * 0.34f, paint)

            // mouth
            paint.color = tint(skin, 0.58f)
            rect.set(cx - rx * 0.24f, cy + r * 0.54f, cx + rx * 0.24f, cy + r * 0.66f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
        } else if (!backToUs) {
            // three-quarter or profile: one eye, the brow, and the nose in relief
            val d = if (deg < 180f) -1f else 1f
            val ex = cx - d * rx * 0.30f
            paint.color = 0xFFF6F1EA.toInt()
            rect.set(ex - rx * 0.17f, cy - r * 0.12f, ex + rx * 0.17f, cy + r * 0.16f)
            c.drawOval(rect, paint)
            paint.color = 0xFF1A1410.toInt()
            c.drawCircle(ex - d * rx * 0.03f, cy + r * 0.03f, r * 0.10f, paint)
            paint.color = tint(hair, 1.05f)
            rect.set(ex - rx * 0.26f, cy - r * 0.34f, ex + rx * 0.20f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
            // the nose breaks the silhouette on the side he is facing
            paint.color = tint(skin, 1.06f)
            c.drawCircle(cx - d * rx * 0.82f, cy + r * 0.24f, r * 0.15f, paint)
            paint.color = tint(skin, 0.76f)
            c.drawCircle(cx - d * rx * 0.66f, cy + r * 0.30f, r * 0.10f, paint)
            paint.color = tint(skin, 0.58f)
            rect.set(cx - d * rx * 0.60f, cy + r * 0.54f, cx - d * rx * 0.16f, cy + r * 0.64f)
            c.drawRoundRect(rect, r * 0.05f, r * 0.05f, paint)
        }

        // ---- hair, clipped to the skull, one of several cuts -------------
        paint.color = hair
        val saved = c.save()
        path.reset()
        rect.set(cx - rx * 1.06f, cy - r * 1.08f, cx + rx * 1.06f, cy + r * 1.02f)
        path.addOval(rect, Path.Direction.CW)
        c.clipPath(path)
        drawHair(c, cx, cy, rx, r, hair, style, backToUs, facingUs, deg)
        c.restoreToCount(saved)
    }

    /**
     * A handful of cuts so a team is not eleven identical men. Each is drawn
     * inside the skull ellipse, so they all sit correctly however he is turned.
     */
    private fun drawHair(c: Canvas, cx: Float, cy: Float, rx: Float, r: Float,
                         hair: Int, style: Int, backToUs: Boolean, facingUs: Boolean, deg: Float) {
        paint.shader = null
        paint.color = hair
        val d = if (deg < 180f) -1f else 1f
        // the cap of hair every style starts from, low at the back, higher in front
        fun cap(frontDrop: Float) {
            if (backToUs) {
                rect.set(cx - rx, cy - r, cx + rx, cy + r * 0.72f)
                c.drawOval(rect, paint)
            } else if (facingUs) {
                c.drawRect(cx - rx, cy - r, cx + rx, cy - r * frontDrop, paint)
            } else {
                c.drawRect(cx + d * rx * 0.02f, cy - r, cx + d * rx * 1.1f, cy + r * 0.34f, paint)
                c.drawRect(cx - rx, cy - r, cx + rx, cy - r * frontDrop, paint)
            }
        }
        when (style) {
            0 -> cap(0.20f)                                   // short back and sides
            1 -> {                                            // side parting
                cap(0.26f)
                if (!backToUs) {
                    paint.color = tint(hair, 0.72f)
                    c.drawRect(cx + d * rx * 0.10f, cy - r, cx + d * rx * 0.20f, cy - r * 0.24f, paint)
                }
            }
            2 -> {                                            // buzz cut, tight to the skull
                paint.color = tint(hair, 1.18f)
                cap(0.44f)
            }
            3 -> {                                            // full curls, sits proud
                rect.set(cx - rx * 1.05f, cy - r * 1.16f, cx + rx * 1.05f, cy + r * 0.30f)
                c.drawOval(rect, paint)
                paint.color = tint(hair, 1.22f)
                c.drawCircle(cx - rx * 0.44f, cy - r * 0.82f, r * 0.26f, paint)
                c.drawCircle(cx + rx * 0.40f, cy - r * 0.88f, r * 0.22f, paint)
                c.drawCircle(cx + rx * 0.04f, cy - r * 1.00f, r * 0.24f, paint)
            }
            4 -> {                                            // long, over the ears
                cap(0.22f)
                rect.set(cx - rx * 1.02f, cy - r * 0.60f, cx - rx * 0.52f, cy + r * 0.60f)
                c.drawRoundRect(rect, r * 0.12f, r * 0.12f, paint)
                rect.set(cx + rx * 0.52f, cy - r * 0.60f, cx + rx * 1.02f, cy + r * 0.60f)
                c.drawRoundRect(rect, r * 0.12f, r * 0.12f, paint)
            }
            5 -> {                                            // receding at the temples
                if (facingUs) {
                    c.drawRect(cx - rx * 0.62f, cy - r, cx + rx * 0.62f, cy - r * 0.34f, paint)
                    c.drawRect(cx - rx, cy - r, cx + rx, cy - r * 0.76f, paint)
                } else cap(0.34f)
            }
            6 -> {                                            // topknot
                cap(0.24f)
                c.drawCircle(cx - d * rx * 0.12f, cy - r * 1.02f, r * 0.26f, paint)
            }
            else -> {                                         // headband over a short cut
                cap(0.22f)
                paint.color = 0xFFF2F4F8.toInt()
                c.drawRect(cx - rx, cy - r * 0.50f, cx + rx, cy - r * 0.30f, paint)
            }
        }
    }

    private fun sliding(c: Canvas, cx: Float, cy: Float, u: Float, p: LivePlayer,
                        club: Club, skin: Int, hair: Int, socks: Int) {
        val d = if (cos(p.actionDir.toDouble()) >= 0) 1f else -1f
        val by = cy - u * 0.34f
        stroke.strokeWidth = u * 0.24f
        stroke.color = socks
        c.drawLine(cx, by, cx + d * u * 1.15f, by + u * 0.18f, stroke)
        stroke.color = skin
        c.drawLine(cx - d * u * 0.18f, by + u * 0.10f, cx + d * u * 0.48f, by + u * 0.38f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx - d * u * 0.50f - u * 0.20f, by - u * 0.26f, cx - d * u * 0.08f + u * 0.20f, by + u * 0.26f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx - d * u * 1.10f, by - u * 0.36f, cx - d * u * 0.40f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        paint.color = skin
        c.drawCircle(cx - d * u * 1.38f, by - u * 0.22f, u * 0.32f, paint)
        paint.color = hair
        c.drawCircle(cx - d * u * 1.44f, by - u * 0.32f, u * 0.24f, paint)
    }

    private fun diving(c: Canvas, cx: Float, cy: Float, u: Float, p: LivePlayer,
                       club: Club, skin: Int, hair: Int, socks: Int) {
        val d = if (p.actionDir < 0) -1f else 1f
        val by = cy - u * 0.55f
        stroke.strokeWidth = u * 0.26f
        stroke.color = socks
        c.drawLine(cx - d * u * 0.25f, by + u * 0.18f, cx - d * u * 1.20f, by + u * 0.42f, stroke)
        c.drawLine(cx - d * u * 0.25f, by - u * 0.08f, cx - d * u * 1.10f, by - u * 0.04f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx - d * u * 0.56f - u * 0.18f, by - u * 0.28f, cx - d * u * 0.14f + u * 0.18f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx + d * u * 0.08f, by - u * 0.40f, cx + d * u * 0.86f, by + u * 0.32f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        stroke.color = club.primary
        stroke.strokeWidth = u * 0.20f
        c.drawLine(cx + d * u * 0.78f, by - u * 0.16f, cx + d * u * 1.65f, by - u * 0.48f, stroke)
        c.drawLine(cx + d * u * 0.78f, by + u * 0.14f, cx + d * u * 1.60f, by - u * 0.16f, stroke)
        paint.color = club.secondary
        c.drawCircle(cx + d * u * 1.72f, by - u * 0.50f, u * 0.18f, paint)
        c.drawCircle(cx + d * u * 1.68f, by - u * 0.18f, u * 0.18f, paint)
        paint.color = skin
        c.drawCircle(cx + d * u * 1.02f, by - u * 0.52f, u * 0.30f, paint)
        paint.color = hair
        c.drawCircle(cx + d * u * 0.96f, by - u * 0.60f, u * 0.23f, paint)
    }

    private fun prone(c: Canvas, cx: Float, cy: Float, u: Float, club: Club, skin: Int, hair: Int) {
        val by = cy - u * 0.22f
        stroke.strokeWidth = u * 0.22f
        stroke.color = skin
        c.drawLine(cx + u * 0.25f, by + u * 0.10f, cx + u * 1.05f, by + u * 0.26f, stroke)
        c.drawLine(cx + u * 0.25f, by - u * 0.12f, cx + u * 1.00f, by - u * 0.24f, stroke)
        paint.shader = null
        paint.color = tint(club.primary, 0.55f)
        rect.set(cx, by - u * 0.26f, cx + u * 0.40f, by + u * 0.26f)
        c.drawRoundRect(rect, u * 0.10f, u * 0.10f, paint)
        paint.color = club.primary
        rect.set(cx - u * 0.75f, by - u * 0.32f, cx + u * 0.04f, by + u * 0.30f)
        c.drawRoundRect(rect, u * 0.14f, u * 0.14f, paint)
        paint.color = skin
        c.drawCircle(cx - u * 1.05f, by - u * 0.08f, u * 0.30f, paint)
        paint.color = hair
        c.drawCircle(cx - u * 1.12f, by - u * 0.16f, u * 0.23f, paint)
    }

    /** The official, in yellow, with the card held up. */
    private fun drawReferee(c: Canvas) {
        val cx = sx(m.refX)
        val cy = sy(m.refY)
        val u = unit * 0.92f
        shadow(c, cx, cy, u)
        val hipY = cy - u * 0.92f
        legs(c, cx, hipY, cy, u, SKIN[2], 0xFF15171E.toInt(), -0.2f, 0.2f)
        paint.shader = null
        litShade(c, cx - u * 0.44f, hipY - u * 0.14f, cx + u * 0.44f, hipY + u * 0.30f, 0xFF14161D.toInt(), u * 0.10f)
        val topY = hipY - u * 1.10f
        litShade(c, cx - u * 0.47f, topY, cx + u * 0.47f, hipY - u * 0.08f, 0xFF1C1F28.toInt(), u * 0.14f)
        // one arm raised, holding the card
        stroke.color = 0xFF1C1F28.toInt()
        stroke.strokeWidth = u * 0.20f
        c.drawLine(cx + u * 0.40f, topY + u * 0.18f, cx + u * 0.78f, topY - u * 0.72f, stroke)
        stroke.color = 0xFF1C1F28.toInt()
        c.drawLine(cx - u * 0.40f, topY + u * 0.18f, cx - u * 0.56f, topY + u * 0.76f, stroke)
        paint.color = if (m.refCard == 2) 0xFFE03434.toInt() else 0xFFF2C94C.toInt()
        rect.set(cx + u * 0.60f, topY - u * 1.16f, cx + u * 0.98f, topY - u * 0.62f)
        c.drawRoundRect(rect, u * 0.05f, u * 0.05f, paint)
        head(c, cx, topY - u * 0.38f, u * 0.36f, SKIN[2], HAIR[0], 0f)
    }

    private fun drawBall(c: Canvas) {
        val bx = sx(m.ball.x)
        val by = sy(m.ball.y)
        val u = unit * 0.92f
        val lift = m.ball.height * u * 0.55f
        val air = (m.ball.height / 3f).coerceIn(0f, 1f)
        paint.shader = null

        // the shadow stays on the grass and spreads as the ball climbs
        val sw = u * (0.22f + air * 0.10f)
        paint.color = if (air > 0.02f) 0x33000000 else 0x4D000000
        rect.set(bx - sw, by - sw * 0.42f, bx + sw, by + sw * 0.42f)
        c.drawOval(rect, paint)

        val r = u * (0.21f + air * 0.05f)
        val cyB = by - lift - u * 0.12f
        paint.color = 0xFFF6F6F6.toInt()
        c.drawCircle(bx, cyB, r, paint)
        paint.color = 0xFFD8D8D8.toInt()
        c.drawCircle(bx + r * 0.26f, cyB + r * 0.22f, r * 0.66f, paint)
        // two panels that turn with the spin, so the roll is visible
        paint.color = 0xFF23262F.toInt()
        val a1 = m.ball.spin
        c.drawCircle(bx + (cos(a1.toDouble()) * r * 0.42).toFloat(),
            cyB + (sin(a1.toDouble()) * r * 0.42).toFloat(), r * 0.26f, paint)
        val a2 = m.ball.spin + 2.3f
        c.drawCircle(bx + (cos(a2.toDouble()) * r * 0.46).toFloat(),
            cyB + (sin(a2.toDouble()) * r * 0.46).toFloat(), r * 0.18f, paint)
    }

    /** The green wedge over whoever has the ball. */
    private fun drawSelector(c: Canvas) {
        val h = m.ball.holder ?: return
        val p = m.players.firstOrNull { it.key == h } ?: return
        val cx = sx(p.x)
        val topY = sy(p.y) - unit * 0.92f * 2.6f
        val s = unit * 0.62f
        paint.shader = null
        paint.color = if (p.side == 0) 0xFF3FCF4A.toInt() else 0xFFF2B544.toInt()
        path.reset()
        path.moveTo(cx - s, topY - s * 0.9f)
        path.lineTo(cx + s, topY - s * 0.9f)
        path.lineTo(cx, topY)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawSparkle(c: Canvas, p: LivePlayer) {
        val cx = sx(p.x); val cy = sy(p.y) - unit
        val t = m.celebrateTime
        stroke.color = ((((1f - t / 2.4f).coerceIn(0f, 1f) * 255).toInt()) shl 24) or 0xFBBF24
        stroke.strokeWidth = 2.4f
        for (i in 0 until 10) {
            val a = (i / 10f) * Math.PI * 2 + t
            val rr = unit * 1.2f + t * unit * 2.4f
            c.drawLine(cx + (cos(a) * rr * 0.5).toFloat(), cy + (sin(a) * rr * 0.5).toFloat(),
                cx + (cos(a) * rr).toFloat(), cy + (sin(a) * rr).toFloat(), stroke)
        }
    }

    /* -------------------------------------------------------------- HUD */

    /** The scoreboard, the radar and the two name plates, as the reference has them. */
    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val pad = h * 0.026f
        val boxH = h * 0.076f
        paint.shader = null

        // one scoreboard, top left: clock then the two short names and the score
        val mins = kotlin.math.min(m.clock.toInt(), 90)
        val clock = String.format("%02d:%02d", mins, ((m.clock - mins) * 60).toInt())
        val line = "$clock   ${m.home.shortName} ${m.score[0]}-${m.score[1]} ${m.away.shortName}"
        label.textSize = boxH * 0.48f
        val scoreW = label.measureText(line) + boxH * 0.9f
        hudBox(c, pad, pad, pad + scoreW, pad + boxH)
        label.color = 0xFFFFFFFF.toInt()
        c.drawText(line, pad + scoreW / 2f, pad + boxH * 0.66f, label)

        // radar, bottom centre
        drawRadar(c, w, h, pad)

        // a name plate in each bottom corner, with a stamina bar
        val homeMan = m.onPitch(0).maxByOrNull { it.minutes }
        val awayMan = m.onPitch(1).maxByOrNull { it.minutes }
        val holder = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
        val leftMan = if (holder != null && holder.side == 0) holder else homeMan
        val rightMan = if (holder != null && holder.side == 1) holder else awayMan
        val plateW = w * 0.26f
        leftMan?.let { namePlate(c, pad, h - pad - boxH, plateW, boxH, it, m.home, false) }
        rightMan?.let { namePlate(c, w - pad - plateW, h - pad - boxH, plateW, boxH, it, m.away, true) }
    }

    private fun namePlate(
        c: Canvas, x: Float, y: Float, w: Float, hgt: Float,
        p: LivePlayer, club: Club, alignRight: Boolean
    ) {
        hudBox(c, x, y, x + w, y + hgt)
        // a flash of the club's colour on the outer edge
        paint.shader = null
        paint.color = club.primary
        val tabW = hgt * 0.26f
        if (alignRight) c.drawRect(x + w - tabW, y + 2f, x + w - 2f, y + hgt - 2f, paint)
        else c.drawRect(x + 2f, y + 2f, x + tabW, y + hgt - 2f, paint)

        label.textSize = hgt * 0.40f
        label.color = 0xFFFFFFFF.toInt()
        val text = "${p.shirt}  ${p.fullName.uppercase()}"
        c.drawText(text, x + w / 2f, y + hgt * 0.46f, label)

        // stamina
        val barX = x + tabW + hgt * 0.20f
        val barW = w - tabW * 2 - hgt * 0.40f
        val barY = y + hgt * 0.64f
        val barH = hgt * 0.16f
        paint.color = 0xFF2A2F3E.toInt()
        rect.set(barX, barY, barX + barW, barY + barH)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, paint)
        val f = (p.fitness / 100.0).toFloat().coerceIn(0f, 1f)
        paint.color = when {
            f > 0.7f -> 0xFF4ADE80.toInt(); f > 0.45f -> 0xFFFBBF24.toInt(); else -> 0xFFF87171.toInt()
        }
        rect.set(barX, barY, barX + barW * f, barY + barH)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, paint)
    }

    private fun hudBox(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        paint.color = 0xE014171F.toInt()
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.6f
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, stroke)
    }

    private fun miniCrest(c: Canvas, cx: Float, cy: Float, r: Float, club: Club) {
        paint.shader = null
        paint.color = club.primary
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawRoundRect(rect, r * 0.28f, r * 0.28f, paint)
        paint.color = club.secondary
        c.drawRect(cx - r * 0.22f, cy - r, cx + r * 0.22f, cy + r, paint)
    }

    private fun drawRadar(c: Canvas, w: Float, h: Float, pad: Float) {
        val rw = w * 0.22f
        val rh = rw * 0.64f
        val x0 = (w - rw) / 2f
        val y0 = h - pad - rh
        paint.shader = null
        paint.color = 0xCC1D5B33.toInt()
        rect.set(x0, y0, x0 + rw, y0 + rh)
        c.drawRoundRect(rect, 4f, 4f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.4f
        c.drawRoundRect(rect, 4f, 4f, stroke)
        c.drawLine(x0 + rw / 2, y0, x0 + rw / 2, y0 + rh, stroke)
        c.drawCircle(x0 + rw / 2, y0 + rh / 2, rh * 0.15f, stroke)
        c.drawRect(x0, y0 + rh * 0.26f, x0 + rw * 0.13f, y0 + rh * 0.74f, stroke)
        c.drawRect(x0 + rw * 0.87f, y0 + rh * 0.26f, x0 + rw, y0 + rh * 0.74f, stroke)

        val dot = kotlin.math.max(2.4f, rh * 0.062f)
        for (p in m.players) {
            if (!p.onPitch) continue
            paint.color = if (p.side == 0) m.home.primary else m.away.primary
            val px = x0 + p.x / 100f * rw
            val py = y0 + p.y / 100f * rh
            rect.set(px - dot, py - dot, px + dot, py + dot)
            c.drawRect(rect, paint)
        }
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(x0 + m.ball.x / 100f * rw, y0 + m.ball.y / 100f * rh, dot * 0.8f, paint)
    }

    private fun drawBanner(c: Canvas, w: Float, h: Float, s: String) {
        label.textSize = h * 0.068f
        val tw = label.measureText(s)
        paint.shader = null
        paint.color = 0xE614171F.toInt()
        rect.set(w / 2 - tw / 2 - 22f, h * 0.40f, w / 2 + tw / 2 + 22f, h * 0.40f + h * 0.098f)
        c.drawRoundRect(rect, 6f, 6f, paint)
        stroke.color = 0xFFF2B544.toInt()
        stroke.strokeWidth = 2.5f
        c.drawRoundRect(rect, 6f, 6f, stroke)
        label.color = 0xFFF7F2E6.toInt()
        c.drawText(s, w / 2, h * 0.40f + h * 0.072f, label)
    }

    private fun tint(color: Int, f: Float): Int {
        val a = (color ushr 24) and 0xFF
        val r = (((color shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((color shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
