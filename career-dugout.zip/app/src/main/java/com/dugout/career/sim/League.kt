package com.dugout.career.sim

import com.dugout.career.core.*
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ---------------------------------------------------------------- FIXTURE */

class Fixture(
    val id: Int,
    val comp: Int,          // Comp.LEAGUE / CUP / CONTI
    val divisionId: Int,    // -1 for cups
    val round: Int,
    val week: Int,
    val homeId: Int,
    val awayId: Int
) {
    var played = false
    var homeGoals = 0
    var awayGoals = 0
    var attendance = 0
    var penalties = false
    var winnerId = -1

    val tieIndex: Int get() = round
}

object Comp {
    const val LEAGUE = 0
    const val CUP = 1
    const val CONTI = 2
    fun label(c: Int) = when (c) { CUP -> "National Cup"; CONTI -> "Continental Cup"; else -> "League" }
}

class CupTie(val homeId: Int, val awayId: Int) {
    var played = false
    var homeGoals = 0
    var awayGoals = 0
    var winnerId = -1
}

class CupRound(val name: String, val week: Int) {
    val ties = ArrayList<CupTie>(32)
}

class Cup(val name: String) {
    val rounds = ArrayList<CupRound>(7)
    var winnerId = -1
    var finished = false
}

/* ---------------------------------------------------------------- RESULTS */

class MatchResult(
    val homeGoals: Int,
    val awayGoals: Int,
    val homeXg: Double,
    val awayXg: Double
) {
    val scorersHome = ArrayList<Int>(4)
    val scorersAway = ArrayList<Int>(4)
}

/* ----------------------------------------------------------------- LEAGUE */

class Season(val world: World) {

    val fixtures = ArrayList<Fixture>(1600)
    var cup: Cup = Cup("National Cup")
    var conti: Cup = Cup("Continental Cup")
    private var nextFixtureId = 1

    companion object {
        const val LAST_WEEK = 38
        private val CUP_WEEKS = intArrayOf(4, 9, 14, 20, 26, 32, 37)
        private val CONTI_WEEKS = intArrayOf(7, 12, 18, 24, 30, 36)
    }

    /* ------------------------------------------------------- CALENDAR */

    fun buildCalendar() {
        fixtures.clear()
        nextFixtureId = 1
        val rng = Rng(world.seed + world.season * 7919L)

        for (div in world.divisions) {
            roundRobin(rng, div.clubIds, div.id)
        }

        cup = Cup("National Cup")
        seedCup(rng)

        conti = Cup("Continental Cup")
        seedConti(rng)

        world.week = 1
    }

    /** Double round robin using the circle method: 20 clubs -> 38 weeks. */
    private fun roundRobin(rng: Rng, clubIds: List<Int>, divisionId: Int) {
        val ids = rng.shuffle(clubIds)
        val n = ids.size
        val arr = ids.toMutableList()
        val firstHalf = ArrayList<Pair<Int, Int>>(n * n)
        val rounds = ArrayList<List<Pair<Int, Int>>>(n - 1)

        for (r in 0 until n - 1) {
            val pairs = ArrayList<Pair<Int, Int>>(n / 2)
            for (k in 0 until n / 2) {
                val a = arr[k]; val b = arr[n - 1 - k]
                pairs.add(if (r % 2 == 0) Pair(a, b) else Pair(b, a))
            }
            rounds.add(pairs)
            val last = arr.removeAt(arr.size - 1)
            arr.add(1, last)
        }

        for (r in rounds.indices) {
            for (p in rounds[r]) {
                fixtures.add(Fixture(nextFixtureId++, Comp.LEAGUE, divisionId, r + 1, r + 1, p.first, p.second))
            }
        }
        for (r in rounds.indices) {
            val wk = n - 1 + r + 1
            for (p in rounds[r]) {
                fixtures.add(Fixture(nextFixtureId++, Comp.LEAGUE, divisionId, wk, wk, p.second, p.first))
            }
        }
        firstHalf.clear()
    }

    private fun seedCup(rng: Rng) {
        val all = ArrayList<Int>(96)
        for (d in world.divisions) all.addAll(d.clubIds)
        val shuffled = rng.shuffle(all)
        // pad to a power of two with byes
        var size = 1
        while (size < shuffled.size) size = size shl 1
        val padded = ArrayList<Int>(size)
        padded.addAll(shuffled)
        while (padded.size < size) padded.add(-1)

        val round = CupRound(roundName(size), CUP_WEEKS[0])
        var i = 0
        while (i < padded.size) {
            val tie = CupTie(padded[i], padded[i + 1])
            if (tie.homeId < 0 || tie.awayId < 0) {
                tie.played = true
                tie.winnerId = if (tie.homeId >= 0) tie.homeId else tie.awayId
            }
            round.ties.add(tie)
            i += 2
        }
        cup.rounds.add(round)
        spawnCupFixtures(cup, 0, Comp.CUP)
    }

    private fun seedConti(rng: Rng) {
        // the strongest domestic sides plus the best foreign clubs
        val domestic = world.divisions[0].clubIds
            .mapNotNull { world.club(it) }
            .sortedByDescending { it.reputation }
            .take(8).map { it.id }
        val foreign = world.foreignClubIds
            .mapNotNull { world.club(it) }
            .sortedByDescending { it.reputation }
            .take(8).map { it.id }
        val ids = rng.shuffle(domestic + foreign)

        val round = CupRound("Round of 16", CONTI_WEEKS[0])
        var i = 0
        while (i < ids.size) { round.ties.add(CupTie(ids[i], ids[i + 1])); i += 2 }
        conti.rounds.add(round)
        spawnCupFixtures(conti, 0, Comp.CONTI)
    }

    private fun roundName(entrants: Int): String = when (entrants) {
        2 -> "Final"; 4 -> "Semi-Final"; 8 -> "Quarter-Final"
        16 -> "Round of 16"; 32 -> "Round of 32"; 64 -> "Round of 64"
        else -> "Round of $entrants"
    }

    private fun spawnCupFixtures(c: Cup, roundIdx: Int, compType: Int) {
        val r = c.rounds[roundIdx]
        for (i in r.ties.indices) {
            val t = r.ties[i]
            if (t.played) continue
            fixtures.add(Fixture(nextFixtureId++, compType, -1, i, r.week, t.homeId, t.awayId))
        }
    }

    fun advanceCup(c: Cup, compType: Int) {
        if (c.finished) return
        val idx = c.rounds.size - 1
        val r = c.rounds[idx]
        if (r.ties.any { !it.played }) return

        val winners = r.ties.mapNotNull { if (it.winnerId >= 0) it.winnerId else null }
        if (winners.size <= 1) {
            c.finished = true
            c.winnerId = winners.firstOrNull() ?: -1
            world.club(c.winnerId)?.honours?.add("${c.name} (S${world.season})")
            return
        }
        val rng = Rng(world.seed + world.season * 131L + idx * 977L)
        val sh = rng.shuffle(winners)
        val weeks = if (compType == Comp.CUP) CUP_WEEKS else CONTI_WEEKS
        val nextIdx = idx + 1
        val round = CupRound(roundName(sh.size), weeks[min(nextIdx, weeks.size - 1)])
        var i = 0
        while (i + 1 < sh.size) { round.ties.add(CupTie(sh[i], sh[i + 1])); i += 2 }
        c.rounds.add(round)
        spawnCupFixtures(c, nextIdx, compType)
    }

    /* --------------------------------------------------------- TABLES */

    fun table(divisionId: Int): List<Club> {
        val div = world.division(divisionId) ?: return emptyList()
        return div.clubIds.mapNotNull { world.club(it) }.sortedWith(
            compareByDescending<Club> { it.points }
                .thenByDescending { it.goalDiff }
                .thenByDescending { it.goalsFor }
                .thenBy { it.name }
        )
    }

    fun position(clubId: Int): Int {
        val c = world.club(clubId) ?: return 0
        if (c.divisionId < 0) return 0
        return table(c.divisionId).indexOfFirst { it.id == clubId } + 1
    }

    fun topScorers(divisionId: Int, n: Int): List<Player> {
        val ids: Set<Int> = if (divisionId < 0) world.clubs.map { it.id }.toSet()
        else (world.division(divisionId)?.clubIds ?: emptyList()).toSet()
        return world.players.values
            .filter { it.clubId in ids && it.goals > 0 }
            .sortedWith(compareByDescending<Player> { it.goals }.thenByDescending { it.assists })
            .take(n)
    }

    fun topRated(divisionId: Int, n: Int): List<Player> {
        val ids: Set<Int> = if (divisionId < 0) world.clubs.map { it.id }.toSet()
        else (world.division(divisionId)?.clubIds ?: emptyList()).toSet()
        return world.players.values
            .filter { it.clubId in ids && it.ratingN >= 8 }
            .sortedByDescending { it.avgRating }
            .take(n)
    }

    /* ----------------------------------------------------- QUICK SIM */

    /** Poisson scoreline from the same ratings the live engine uses. */
    fun quickSim(fx: Fixture, rng: Rng): MatchResult {
        val h = world.club(fx.homeId) ?: return MatchResult(0, 0, 0.0, 0.0)
        val a = world.club(fx.awayId) ?: return MatchResult(0, 0, 0.0, 0.0)
        if (h.tactics.lineup.all { it < 0 }) world.autoPickSquad(h)
        if (a.tactics.lineup.all { it < 0 }) world.autoPickSquad(a)

        val hr = world.teamRating(h, true)
        val ar = world.teamRating(a, false)
        val hx = expectedGoals(hr, ar)
        val ax = expectedGoals(ar, hr)
        val hg = poisson(hx, rng)
        val ag = poisson(ax, rng)

        val res = MatchResult(hg, ag, hx, ax)
        assignGoals(h, hg, res.scorersHome, rng)
        assignGoals(a, ag, res.scorersAway, rng)
        applyLoad(h, rng, hg, ag)
        applyLoad(a, rng, ag, hg)
        return res
    }

    private fun expectedGoals(att: World.TeamRating, def: World.TeamRating): Double {
        val gap = att.attack - def.defence
        return (1.40 * exp(gap / 22.0)).coerceIn(0.15, 4.6)
    }

    private fun poisson(lambda: Double, rng: Rng): Int {
        val l = exp(-lambda)
        var k = 0
        var p = 1.0
        do { k++; p *= rng.f() } while (p > l && k < 12)
        return k - 1
    }

    private fun assignGoals(c: Club, goals: Int, out: MutableList<Int>, rng: Rng) {
        if (goals <= 0) return
        val xi = c.tactics.lineup.map { world.player(it) }.filterNotNull()
        if (xi.isEmpty()) return
        val weights = DoubleArray(xi.size)
        for (i in xi.indices) {
            val p = xi[i]
            val base = when (Pos.group(p.pos)) { 3 -> 10.0; 2 -> 4.0; 1 -> 1.1; else -> 0.05 }
            weights[i] = base * (0.5 + p.att[Att.FIN] / 100.0) * (0.7 + p.form / 20.0)
        }
        repeat(goals) {
            val scorer = weightedPick(xi, weights, rng) ?: return@repeat
            scorer.goals++; scorer.cGoals++
            out.add(scorer.id)
            if (rng.chance(0.70)) {
                val others = xi.filter { it.id != scorer.id }
                if (others.isNotEmpty()) {
                    val aw = DoubleArray(others.size)
                    for (i in others.indices) {
                        val g = Pos.group(others[i].pos)
                        aw[i] = (if (g == 2) 6.0 else if (g == 3) 4.0 else 1.5) *
                                (0.5 + others[i].att[Att.PAS] / 100.0)
                    }
                    weightedPick(others, aw, rng)?.let { it.assists++; it.cAssists++ }
                }
            }
        }
    }

    private fun weightedPick(list: List<Player>, weights: DoubleArray, rng: Rng): Player? {
        var tot = 0.0
        for (w in weights) tot += w
        if (tot <= 0.0) return list.firstOrNull()
        var r = rng.f() * tot
        for (i in list.indices) { r -= weights[i]; if (r <= 0) return list[i] }
        return list.lastOrNull()
    }

    /** Fitness, sharpness, ratings, cards and injuries after a simulated match. */
    private fun applyLoad(c: Club, rng: Rng, gf: Int, ga: Int) {
        val xi = c.tactics.lineup.map { world.player(it) }.filterNotNull()
        val bench = c.tactics.bench.map { world.player(it) }.filterNotNull()
        val onPitch = HashSet<Int>()

        for (p in xi) {
            onPitch.add(p.id)
            val mins = if (rng.chance(0.22)) rng.i(45, 85) else 90
            p.apps++; p.cApps++; p.minutes += mins

            val drain = (mins / 90.0) * (16.0 + (100 - p.att[Att.STA]) * 0.16) *
                    (if (p.hasTrait(Traits.ENGINE)) 0.75 else 1.0)
            p.fitness = max(18.0, p.fitness - drain)
            p.sharpness = min(100.0, p.sharpness + 6)

            var r = 6.30 + (p.effective(p.pos) - 62.0) / 16.0 + (rng.f() - 0.5) * 1.3
            if (p.hasTrait(Traits.CONSISTENT)) r = 6.2 + (r - 6.2) * 0.75
            r = r.coerceIn(4.0, 9.8)
            p.ratingSum += r; p.ratingN++
            p.form = p.form * 0.72 + r * 0.28

            val cardP = 0.075 *
                    (when (c.tactics.tackling) { 2 -> 1.6; 0 -> 0.6; else -> 1.0 }) *
                    (if (p.hasTrait(Traits.HOTHEAD)) 1.9 else 1.0) *
                    (if (Pos.group(p.pos) == 1) 1.4 else 1.0)
            if (rng.chance(cardP)) {
                p.yellowSeason++
                if (p.yellowSeason % 5 == 0) p.suspended = 1
                if (rng.chance(0.06)) { p.redSeason++; p.suspended = 2 }
            }

            val injP = 0.028 * (if (p.fitness < 55) 2.1 else 1.0) *
                    (if (p.hasTrait(Traits.GLASS)) 2.2 else 1.0) *
                    (if (p.age > 31) 1.3 else 1.0)
            if (rng.chance(injP)) {
                val wks = if (rng.chance(0.60)) rng.i(1, 3) else if (rng.chance(0.75)) rng.i(4, 9) else rng.i(10, 26)
                p.injuryWeeks = wks
                p.injuryType = injuryName(wks, rng)
            }
            if (p.pos == Pos.GK && ga == 0) p.cleanSheets++
        }

        for (i in bench.indices) {
            val p = bench[i]
            if (i < 3 && rng.chance(0.45)) {
                p.apps++; p.cApps++
                p.fitness = max(25.0, p.fitness - 8)
                p.sharpness = min(100.0, p.sharpness + 4)
                onPitch.add(p.id)
            } else {
                p.sharpness = max(30.0, p.sharpness - 2)
            }
        }
        for (id in c.squad) {
            val p = world.player(id) ?: continue
            if (!onPitch.contains(p.id)) p.sharpness = max(25.0, p.sharpness - 3)
        }
    }

    fun injuryName(weeks: Int, rng: Rng): String = when {
        weeks <= 1 -> rng.pick(arrayOf("Knock", "Dead leg", "Bruised ribs", "Tight groin"))
        weeks <= 3 -> rng.pick(arrayOf("Strained hamstring", "Tight calf", "Sprained ankle", "Groin strain"))
        weeks <= 9 -> rng.pick(arrayOf("Torn hamstring", "Ankle ligament damage", "Hip flexor tear", "Broken nose"))
        else -> rng.pick(arrayOf("Cruciate ligament damage", "Broken metatarsal", "Achilles tear", "Fractured fibula"))
    }

    /* ------------------------------------------------------- RESULTS */

    fun applyResult(fx: Fixture, hg: Int, ag: Int) {
        fx.played = true; fx.homeGoals = hg; fx.awayGoals = ag
        val h = world.club(fx.homeId) ?: return
        val a = world.club(fx.awayId) ?: return

        if (fx.comp == Comp.LEAGUE) {
            h.record(hg, ag); a.record(ag, hg)
        } else {
            val c = if (fx.comp == Comp.CUP) cup else conti
            val roundIdx = c.rounds.size - 1
            var tie: CupTie? = null
            for (r in c.rounds) for (t in r.ties)
                if (!t.played && t.homeId == fx.homeId && t.awayId == fx.awayId) { tie = t; break }
            val winner = when {
                hg > ag -> h.id
                ag > hg -> a.id
                else -> { fx.penalties = true; if (Rng(world.seed + fx.id * 31L).chance(0.5)) h.id else a.id }
            }
            fx.winnerId = winner
            tie?.let { it.played = true; it.homeGoals = hg; it.awayGoals = ag; it.winnerId = winner }
            h.form.add(0, if (winner == h.id) 'W' else if (hg == ag) 'D' else 'L')
            a.form.add(0, if (winner == a.id) 'W' else if (hg == ag) 'D' else 'L')
            while (h.form.size > 6) h.form.removeAt(h.form.size - 1)
            while (a.form.size > 6) a.form.removeAt(a.form.size - 1)
        }

        // morale
        applyMorale(h, hg - ag)
        applyMorale(a, ag - hg)

        // gate receipts
        val att = min(h.capacity, (h.capacity * (0.50 + h.reputation / 200.0 + h.morale / 400.0)).roundToInt())
        fx.attendance = att
        val ticket = when (h.tier) { 1 -> 38; 2 -> 22; 3 -> 13; 4 -> 8; else -> 5 }
        h.balance += att.toLong() * ticket
    }

    private fun applyMorale(c: Club, diff: Int) {
        val d = when { diff > 1 -> 5.0; diff == 1 -> 3.0; diff == 0 -> 0.0; diff == -1 -> -3.0; else -> -6.0 }
        c.morale = (c.morale + d).coerceIn(15.0, 98.0)
        for (id in c.squad) {
            val p = world.player(id) ?: continue
            p.morale = (p.morale + if (diff > 0) 3.0 else if (diff == 0) 0.0 else -3.0).coerceIn(10.0, 99.0)
        }
    }

    /* ------------------------------------------------------ SCHEDULE */

    fun fixturesForWeek(week: Int): List<Fixture> = fixtures.filter { it.week == week && !it.played }

    fun userFixture(week: Int): Fixture? {
        val u = world.userClubId
        return fixtures.firstOrNull { it.week == week && !it.played && (it.homeId == u || it.awayId == u) }
    }

    fun nextUserFixture(): Fixture? {
        val u = world.userClubId
        return fixtures.filter { !it.played && (it.homeId == u || it.awayId == u) }.minByOrNull { it.week }
    }

    fun userFixtures(): List<Fixture> {
        val u = world.userClubId
        return fixtures.filter { it.homeId == u || it.awayId == u }.sortedBy { it.week }
    }

    /** Plays every other fixture in the week. */
    fun simWeek(week: Int, skipFixtureId: Int) {
        val rng = Rng(world.seed + world.season * 313L + week * 7717L)
        for (fx in fixturesForWeek(week)) {
            if (fx.id == skipFixtureId) continue
            val res = quickSim(fx, rng)
            applyResult(fx, res.homeGoals, res.awayGoals)
        }
        advanceCup(cup, Comp.CUP)
        advanceCup(conti, Comp.CONTI)
    }

    val seasonOver: Boolean get() = world.week > LAST_WEEK

    /* -------------------------------------------------- SEASON ROLL */

    class SeasonReport {
        val champions = ArrayList<Pair<String, Club>>(4)
        val promoted = ArrayList<Club>(9)
        val relegated = ArrayList<Club>(9)
        var playerOfSeason: Player? = null
        var goldenBoot: Player? = null
        var youngPlayer: Player? = null
        var cupWinner: Club? = null
        var contiWinner: Club? = null
    }

    fun endSeason(): SeasonReport {
        val rep = SeasonReport()

        for (div in world.divisions) {
            val tbl = table(div.id)
            if (tbl.isEmpty()) continue
            val champ = tbl[0]
            champ.honours.add("${div.name} (S${world.season})")
            rep.champions.add(Pair(div.name, champ))
            for (i in tbl.indices) {
                val prize = (div.prize * (1.0 - i.toDouble() / (tbl.size + 4))).toLong()
                tbl[i].balance += prize + div.tv
            }
        }

        // promotion and relegation
        val moves = ArrayList<Pair<Club, Int>>(18)
        for (d in 0 until world.divisions.size - 1) {
            val upper = world.divisions[d]
            val lower = world.divisions[d + 1]
            val lowerTbl = table(lower.id)
            val upperTbl = table(upper.id)
            val up = lowerTbl.take(lower.promoted)
            val down = upperTbl.takeLast(upper.relegated)
            for (c in up) { moves.add(Pair(c, upper.id)); rep.promoted.add(c) }
            for (c in down) { moves.add(Pair(c, lower.id)); rep.relegated.add(c) }
        }
        for ((c, _) in moves) world.division(c.divisionId)?.clubIds?.remove(c.id)
        for ((c, target) in moves) {
            world.division(target)?.clubIds?.add(c.id)
            c.divisionId = target
            c.tier = world.division(target)?.tier ?: c.tier
        }

        rep.playerOfSeason = topRated(-1, 1).firstOrNull()
        rep.goldenBoot = topScorers(0, 1).firstOrNull()
        rep.youngPlayer = world.players.values
            .filter { it.age <= 21 && it.ratingN >= 8 }
            .maxByOrNull { it.avgRating }
        rep.cupWinner = world.club(cup.winnerId)
        rep.contiWinner = world.club(conti.winnerId)
        rep.playerOfSeason?.let { it.cTrophies++ }
        return rep
    }

    /** Ageing, development, contracts, retirements and squad top-ups. */
    fun rolloverPlayers(): List<Player> {
        val rng = Rng(world.seed + world.season * 4441L)
        val retired = ArrayList<Player>(64)
        val expiring = ArrayList<Player>(256)

        for (p in world.players.values) {
            p.age++
            val ovr = p.overall()
            val gap = p.potential - ovr
            val playFactor = min(1.4, 0.35 + p.minutes / 1800.0)

            var delta = when {
                p.age <= 21 -> (2.4 + gap * 0.16) * playFactor
                p.age <= 25 -> (1.3 + gap * 0.11) * playFactor
                p.age <= 28 -> (0.35 + gap * 0.05) * playFactor
                p.age <= 31 -> -0.6
                p.age <= 34 -> -1.9
                else -> -3.4
            }
            if (p.hasTrait(Traits.WONDERKID)) delta *= 1.45
            if (p.hasTrait(Traits.LATE_BLOOM) && p.age in 26..30) delta += 0.9
            delta *= 0.7 + rng.f() * 0.6

            val w = Weights.of(p.pos)
            for (a in 0 until Att.COUNT) {
                val imp = if (w[a] > 0) w[a] else 0.02
                val d = delta * (0.4 + imp * 2.4)
                p.att[a] = (p.att[a] + d).roundToInt().coerceIn(4, 99)
            }
            p.capToPotential()

            val club = world.club(p.clubId)
            p.seasons.add(
                SeasonLine(
                    world.season, club?.name ?: "Free Agent",
                    world.division(club?.divisionId ?: -1)?.shortName ?: "-",
                    p.apps, p.goals, p.assists, p.avgRating
                )
            )
            while (p.seasons.size > 14) p.seasons.removeAt(0)

            p.apps = 0; p.goals = 0; p.assists = 0; p.cleanSheets = 0
            p.motm = 0; p.minutes = 0; p.ratingSum = 0.0; p.ratingN = 0
            p.yellowSeason = 0; p.redSeason = 0; p.suspended = 0
            p.fitness = 100.0; p.sharpness = 60.0; p.injuryWeeks = 0; p.injuryType = null
            p.contractYears--

            if (p.age >= 34 && rng.chance(0.28 + (p.age - 34) * 0.20)) retired.add(p)
            else if (p.contractYears <= 0) expiring.add(p)
        }

        for (p in retired) {
            world.club(p.clubId)?.squad?.remove(p.id)
            world.players.remove(p.id)
        }

        for (p in expiring) {
            val c = world.club(p.clubId) ?: continue
            val ranked = world.squadOf(c).sortedByDescending { it.overall() }
            val rank = ranked.indexOfFirst { it.id == p.id }
            val keep = rank in 0..19 && c.squad.size <= 28 && p.age < 35
            if (keep) {
                p.contractYears = rng.i(2, 4)
                p.wage = (p.expectedWage() * (1.0 + rng.f() * 0.18)).roundToInt()
            } else {
                c.squad.remove(p.id)
                p.clubId = -1
                p.contractYears = 0
            }
        }

        // squad caps and top-ups
        for (c in world.clubs) {
            while (c.squad.size > 30) {
                val worst = world.squadOf(c).minByOrNull { it.overall() } ?: break
                c.squad.remove(worst.id)
                worst.clubId = -1
            }
            if (c.isUser) continue
            var guard = 0
            while (c.squad.size < 22 && guard++ < 14) {
                val fa = world.players.values.filter { it.clubId < 0 }.maxByOrNull { it.overall() }
                if (fa != null) {
                    fa.clubId = c.id; fa.contractYears = rng.i(1, 3); fa.wage = fa.expectedWage()
                    c.squad.add(fa.id)
                } else {
                    val base = when (c.tier) { 1 -> 72; 2 -> 63; 3 -> 55; 4 -> 47; else -> 40 }
                    val np = world.makePlayer(
                        rng, rng.i(0, Pos.COUNT - 1), rng.i(17, 24),
                        rng.norm(base.toDouble(), 5.0, 20, 90), rng.pick(Names.NATIONS),
                        world.potentialCapFor(c.tier, c.divisionId)
                    )
                    np.clubId = c.id
                    world.players[np.id] = np
                    c.squad.add(np.id)
                }
            }
        }
        // Players nobody wants drift out of the professional game.
        val freeAgents = world.players.values.filter { it.clubId < 0 }
        for (p in freeAgents) {
            val hopeless = p.age >= 24 && p.overall() < 45
            val tooOld = p.age >= 33
            if (hopeless || tooOld) world.players.remove(p.id)
        }
        // Keep only the best 240 unattached players so the pool stays useful.
        val remaining = world.players.values.filter { it.clubId < 0 }.sortedByDescending { it.overall() }
        for (i in 240 until remaining.size) world.players.remove(remaining[i].id)

        // Youth coming through at every club, not just the player's.
        for (c in world.clubs) {
            if (c.isUser || c.squad.size >= 24) continue
            val n = rng.i(1, 3)
            repeat(n) {
                if (c.squad.size >= 24) return@repeat
                val quality = 30.0 + c.reputation * 0.35
                val kid = world.makePlayer(
                    rng, rng.i(0, Pos.COUNT - 1), rng.i(16, 18),
                    rng.norm(quality * 0.62, 6.0, 16, 62), rng.pick(Names.NATIONS),
                    world.potentialCapFor(c.tier, c.divisionId)
                )
                kid.clubId = c.id; kid.wage = 500; kid.contractYears = 3; kid.squadStatus = 4
                world.players[kid.id] = kid
                c.squad.add(kid.id)
            }
        }

        // Trim AI squads back to a working size, weakest first.
        for (c in world.clubs) {
            if (c.isUser) continue
            while (c.squad.size > 26) {
                val worst = world.squadOf(c).minByOrNull { it.overall() + it.potential * 0.35 } ?: break
                c.squad.remove(worst.id)
                worst.clubId = -1
            }
        }

        return retired
    }

    /**
     * Clubs cannot carry a wage bill their income will not cover. The ones that
     * do move players on until the books balance.
     */
    fun enforceWageBudgets() {
        for (c in world.clubs) {
            if (c.isUser) continue
            var guard = 0
            while (world.wageBill(c) > c.wageBudget * 1.15 && c.squad.size > 18 && guard++ < 12) {
                val earner = world.squadOf(c).maxByOrNull { it.wage } ?: break
                val buyer = world.clubs.firstOrNull {
                    it.id != c.id && !it.isUser && it.squad.size < 28 &&
                            world.wageBill(it) + earner.wage < it.wageBudget
                }
                c.squad.remove(earner.id)
                if (buyer != null) {
                    buyer.squad.add(earner.id); earner.clubId = buyer.id
                    c.balance += earner.value() / 2
                    buyer.balance -= earner.value() / 2
                } else {
                    earner.clubId = -1
                }
            }
            world.autoPickSquad(c)
        }
    }

    fun newSeason() {
        world.season++
        world.week = 1
        for (c in world.clubs) {
            c.resetSeason()
            val target = when (c.tier) { 1 -> 78.0; 2 -> 58.0; 3 -> 40.0; else -> 26.0 }
            c.reputation = (c.reputation * 0.88 + target * 0.12).roundToInt().coerceIn(6, 99)
            world.recalcBudgets(c)
        }
        enforceWageBudgets()
        for (c in world.clubs) world.autoPickSquad(c)
        buildCalendar()
    }
}
