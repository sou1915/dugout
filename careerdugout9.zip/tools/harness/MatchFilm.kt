import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.core.Pos
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * LOOK AT THE MATCH.
 *
 * Every figure this harness suite produces is an aggregate over thousands of
 * matches — goals per game, mean pass length, median shot distance. All of it
 * can be correct while the thing on the screen still looks wrong, and that is
 * exactly what happened: measurement after measurement moved into range and the
 * report from the device stayed "nothing changed".
 *
 * The brief's first rule is "render PNGs and measure them". The numeric half of
 * that was done to death and the visual half was never done at all. This writes
 * a strip of frames from one match so a human — or the model — can see what a
 * player sees, and prints what is in each frame beside it.
 *
 *   java -cp build/h.jar MatchFilmKt [frames] [everyNthFrame] [seed]
 */
fun main(args: Array<String>) {
    val shots = args.firstOrNull()?.toIntOrNull() ?: 12
    val every = args.getOrNull(1)?.toIntOrNull() ?: 240
    val seed = args.getOrNull(2)?.toLongOrNull() ?: 20260727L

    val m = newEngine(seed)
    m.replaysEnabled = false
    m.start()

    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val v = MatchView(android.content.Context(), m)

    // the camera cut is gated on the wall clock and a harness renders far
    // faster than real time, so pin it to the broadcast view — otherwise every
    // frame here is the top-down board and we learn nothing about the picture
    // the player actually watches
    val closeField = MatchView::class.java.getDeclaredField("closeUp")
    closeField.isAccessible = true

    File("out/film").mkdirs()
    println("=== a match, frame by frame ===")
    println(String.format("%-6s %-6s %-9s %-22s %s", "file", "min", "score", "ball", "what is happening"))

    var frame = 0
    var taken = 0
    var guard = 0
    while (!m.finished && taken < shots && guard++ < 300_000) {
        m.update(1f / 36f)
        if (m.finished) break
        frame++
        closeField.setFloat(v, 1f)
        v.renderAt(c, W, H)
        if (frame % every != 0) continue

        taken++
        val name = String.format("out/film/%02d.png", taken)
        ImageIO.write(bmp.image, "png", File(name))

        val on = m.players.filter { it.onPitch && it.pos != Pos.GK }
        val moving = on.count { it.speedNow > 0.5f }
        val near = on.count {
            Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(),
                       ((it.y - m.ball.y) * 0.68).toDouble()) < 15.0
        }
        val holder = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
        val acts = on.filter { it.action != 0 }.map { it.action }
        println(String.format("%-6d %-6.0f %-9s %-22s moving %2d/20, within 15 m %2d, acts %s",
            taken, m.clock, "${m.score[0]}-${m.score[1]}",
            String.format("(%.0f,%.0f) %s", m.ball.x, m.ball.y,
                holder?.name?.take(10) ?: "loose"),
            moving, near, if (acts.isEmpty()) "-" else acts.toString()))
    }
    println()
    println("written to out/film/. Look at them before changing anything else.")
}
