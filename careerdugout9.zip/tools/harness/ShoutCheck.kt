import com.dugout.career.core.Pos
import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Does a touchline shout actually change anything on the pitch?
 *
 * Reported from the device: "players don't seem to apply what I command on the
 * shout button or dugout changes". The shouts mutate `club.tactics`, and
 * `updateTargets` reads that live, so in principle they must — but "in
 * principle" is what this project measures instead of trusting.
 *
 * Each shout is applied MID-MATCH, after the shape has settled, and the side's
 * geometry is measured before and after: how far up the pitch they stand, how
 * wide, and how close to the ball they press. A shout that moves nothing is a
 * button that lies to the manager.
 */
private fun geometry(m: MatchEngine, side: Int): Triple<Double, Double, Double> {
    val on = m.players.filter { it.onPitch && it.side == side && it.pos != Pos.GK }
    if (on.isEmpty()) return Triple(0.0, 0.0, 0.0)
    // how far up the pitch, in the direction this side attacks
    val up = on.map { if (side == 0) it.x.toDouble() else 100.0 - it.x }.average()
    val wide = (on.maxOf { it.y } - on.minOf { it.y }) * 0.68
    val toBall = on.map {
        Math.hypot(((it.x - m.ball.x) * 1.05).toDouble(), ((it.y - m.ball.y) * 0.68).toDouble())
    }.average()
    return Triple(up, wide, toBall)
}

private fun settle(m: MatchEngine, frames: Int) {
    var g = 0
    repeat(frames) {
        if (m.finished) return
        m.update(1f / 36f)
        m.sound.clear()
        g++
    }
}

fun main(args: Array<String>) {
    val samples = args.firstOrNull()?.toIntOrNull() ?: 12
    val world = World.build(20260727L)
    val season = Season(world); season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }

    data class Shout(val name: String, val apply: (com.dugout.career.core.Tactics) -> Unit)
    val shouts = listOf(
        // the control: say NOTHING. Without this row every shout is credited
        // with whatever the shape does on its own over the same window, and
        // "Get it wide" appeared to make the side narrower.
        Shout("(say nothing)") { },
        Shout("Push them forward") { t -> if (t.mentality < 4) t.mentality++; if (t.line < 2) t.line++ },
        Shout("Tighten up") { t -> if (t.mentality > 0) t.mentality--; if (t.line > 0) t.line--; t.tackling = 0 },
        Shout("Get it wide") { t -> t.width = 2; t.focus = 3 },
        Shout("Through the middle") { t -> t.width = 0; t.focus = 1 },
        Shout("Press them") { t -> t.press = 2 },
        Shout("Throw everyone up") { t -> t.mentality = 4; t.line = 2; t.press = 2; t.counter = false }
    )

    println("=== what a shout moves, averaged over $samples matches ===")
    println(String.format("%-22s %14s %14s %14s", "shout", "up the pitch", "width", "distance to ball"))

    for (sh in shouts) {
        var dUp = 0.0; var dWide = 0.0; var dBall = 0.0; var n = 0
        for (i in 0 until samples) {
            val m = MatchEngine(world, season, league[i % league.size])
            m.replaysEnabled = false
            m.start()
            settle(m, 900)
            if (m.finished) continue
            // a fresh copy of the tactics for every trial, so shouts do not stack
            val club = m.home
            val before = geometry(m, 0)
            sh.apply(club.tactics)
            settle(m, 400)
            if (m.finished) continue
            val after = geometry(m, 0)
            dUp += after.first - before.first
            dWide += after.second - before.second
            dBall += after.third - before.third
            n++
        }
        if (n == 0) { println("${sh.name}: no samples"); continue }
        println(String.format("%-22s %+13.2f %+13.2f m %+13.2f m",
            sh.name, dUp / n, dWide / n, dBall / n))
    }
    println()
    println("units up the pitch are pitch units (1.05 m); a shout that reads 0.00")
    println("everywhere did nothing at all.")
}
