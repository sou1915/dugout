import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * How much of a match is a named moment, and which moments never happen?
 *
 * Reported from the device, twice: "there's no scenes for nothing, the match
 * doesn't feel alive -- no red/yellow card scene, penalty scene, corner scene".
 *
 * Two separate faults sit behind that. Scene.LABEL was written when set pieces
 * were and then never referenced anywhere in the app, so a corner, a throw-in
 * and a goal kick all played out with nothing on screen naming them. And a
 * booking had no scene at all: the referee and his card were drawn for 2.6 s
 * while play carried on around them and the free kick scene overwrote the
 * moment a tick later.
 *
 * This counts every scene a match reaches, how long each holds, and what share
 * of the match is a named moment rather than unbroken play.
 */
fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    if (args.getOrNull(1) == "off") MatchEngine.SCENE_AI = false
    println("scene behaviour: ${if (MatchEngine.SCENE_AI) "ON" else "off"}")
    val count = LongArray(Scene.LABEL.size)
    val held = DoubleArray(Scene.LABEL.size)
    var frames = 0L
    var scened = 0L
    var liveSpeed = 0.0; var liveN = 0L
    var deadSpeed = 0.0; var deadN = 0L

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        var prev = Scene.NONE
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(1f / 36f)
            m.sound.clear()
            frames++
            val sc = m.scene
            // how fast are the players moving with the ball dead versus live?
            // a stoppage everybody sprints through is not a stoppage
            val sp = m.players.filter { it.onPitch }.map { it.speedNow.toDouble() }.average()
            if (sc != Scene.NONE && m.sceneTime > 0f) { deadSpeed += sp; deadN++ }
            else { liveSpeed += sp; liveN++ }
            if (sc != Scene.NONE && m.sceneTime > 0f) {
                scened++
                held[sc] += 1.0 / 36.0
                if (sc != prev) count[sc]++
            }
            prev = if (m.sceneTime > 0f) sc else Scene.NONE
        }
    }

    val mm = matches.toDouble()
    println("=== named moments, $matches matches ===")
    println(String.format("%-16s %12s %14s", "scene", "a match", "seconds shown"))
    for (i in Scene.LABEL.indices) {
        if (i == Scene.NONE) continue
        val name = Scene.LABEL[i].ifEmpty { "#$i" }
        println(String.format("%-16s %12.1f %13.1f s", name, count[i] / mm, held[i] / mm))
    }
    println()
    println(String.format("a named moment is on screen for %.1f%% of the match",
        100.0 * scened / maxOf(1L, frames)))
    println(String.format("mean player speed   in play %.2f   at a stoppage %.2f units/s",
        liveSpeed / maxOf(1L, liveN), deadSpeed / maxOf(1L, deadN)))
    println()
    println("a scene reading 0.0 a match is one the engine can never reach, and")
    println("no amount of drawing will make it visible.")
}
