import android.graphics.Bitmap
import android.graphics.Canvas
import com.dugout.career.sim.Scene
import com.dugout.career.ui.MatchView
import java.io.File
import javax.imageio.ImageIO

/**
 * Photograph one of each named moment.
 *
 * SceneCheck counts scenes; it cannot say whether anything is drawn for them.
 * The captions were authored and never referenced for months, which counting
 * would never have caught. This waits for each scene in turn and writes the
 * frame, so "there is a corner scene" is a picture rather than a number.
 */
fun main(args: Array<String>) {
    val seed = args.firstOrNull()?.toLongOrNull() ?: 20260727L
    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val closeField = MatchView::class.java.getDeclaredField("closeUp")
    closeField.isAccessible = true

    File("out/scenes").mkdirs()
    val want = listOf(Scene.CORNER, Scene.FREEKICK, Scene.THROW_IN,
                      Scene.GOAL_KICK, Scene.SUBSTITUTION, Scene.CARD, Scene.PENALTY)
    val got = HashSet<Int>()
    println("=== one frame of each named moment ===")

    var match = 0
    // a penalty is 0.2 a match, so a full sweep for one costs more than it is
    // worth here; PenaltyCheck already covers that routine
    val limit = args.getOrNull(1)?.toIntOrNull() ?: 6
    while (got.size < want.size && match < limit) {
        val m = newEngine(seed + match * 7919L)
        m.replaysEnabled = false
        m.start()
        val v = MatchView(android.content.Context(), m)
        var guard = 0
        while (!m.finished && got.size < want.size && guard++ < 900_000) {
            m.update(1f / 36f)
            m.sound.clear()
            val sc = m.scene
            /*
             * Rendering every frame of a match costs more than simulating it,
             * and a match is now 3.4x longer in real time, so a full-render
             * sweep does not finish. The camera only needs to be roughly on the
             * ball when the shutter falls, so it is eased on every third frame
             * and on every frame once a scene is up.
             */
            val live = sc != Scene.NONE && m.sceneTime > 0f
            if (live || guard % 3 == 0) {
                closeField.setFloat(v, 1f)
                v.renderAt(c, W, H)
            }
            // caught mid-scene, so the caption is at full opacity
            if (sc in want && sc !in got && m.sceneTime > 0.9f) {
                got.add(sc)
                val name = Scene.LABEL[sc].replace(' ', '-').lowercase()
                val f = "out/scenes/$name.png"
                ImageIO.write(bmp.image, "png", File(f))
                println(String.format("  %-14s %-28s min %.0f", Scene.LABEL[sc], f, m.clock))
            }
        }
        match++
    }
    for (sc in want) if (sc !in got) println("  ${Scene.LABEL[sc]}: NEVER REACHED")
    println()
    println("written to out/scenes/.")
}
