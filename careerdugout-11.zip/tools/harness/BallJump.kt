import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season
fun main() {
    val w = World.build(20260727L); val s = Season(w); s.buildCalendar()
    val lg = s.fixtures.filter { it.comp == 0 }
    var jumps = 0; var big = 0; var matches = 0; var frames = 0
    for (i in 0 until 20) {
        val m = MatchEngine(w, s, lg[i]); m.replaysEnabled = false; m.start()
        var px = m.ball.x; var py = m.ball.y; var g = 0
        while (!m.finished && g++ < 300_000) {
            m.update(1f/36f); if (m.finished) break
            val d = Math.hypot(((m.ball.x-px)*1.05).toDouble(), ((m.ball.y-py)*0.68).toDouble())
            px = m.ball.x; py = m.ball.y; frames++
            if (d > 3.0) jumps++          // over 3 m in one frame = a visible jump
            if (d > 8.0) big++            // over 8 m = the ball is somewhere else
        }
        matches++
    }
    println("=== ball teleports, $matches matches, $frames frames ===")
    println(String.format("jumps over 3 m in one frame   %d  (%.1f a match)", jumps, jumps.toDouble()/matches))
    println(String.format("jumps over 8 m in one frame   %d  (%.1f a match)", big, big.toDouble()/matches))
    println("a real ball never jumps; every one of these is the ball vanishing")
    println("from one place and appearing in another, on screen.")
}
