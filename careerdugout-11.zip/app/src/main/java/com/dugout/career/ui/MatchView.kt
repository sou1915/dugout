package com.dugout.career.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import com.dugout.career.core.Att
import com.dugout.career.core.Club
import com.dugout.career.core.Kits
import com.dugout.career.core.Pos
import com.dugout.career.core.Rng
import com.dugout.career.sim.Act
import com.dugout.career.sim.LivePlayer
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene
import kotlin.math.cos
import kotlin.math.sin

/**
 * The decision to cut between the board view and the broadcast camera.
 *
 * THE BROADCAST CAMERA WAS NEVER REACHED. Measured over 40 matches, `closeUp`
 * — nought on the board, one on the broadcast camera — never once got above
 * 0.22. Every perspective frame, the pan fixed last session, the whole of
 * BroadcastRenderer: none of it was ever seen in a live match. It had been
 * measured only by harnesses that pin `closeUp` by reflection, so the thing
 * nobody had measured was whether the view is ever arrived at on its own.
 *
 * The cause was that "which camera are we on" was inferred from the eased
 * value rather than remembered. The renderer decided to cut in, reset the
 * hold clock, and eased `closeUp` from 0 to 0.22 — one frame's worth. On the
 * next frame `closeUp > 0.5f` was still false, so the rule read "we are on the
 * board", and `heldFor` had just been reset to nothing, so the board's minimum
 * hold applied and pinned it there. It eased back out, and three seconds later
 * did exactly the same thing again: 33 aborted cuts a match, the picture
 * twitching a fifth of the way toward a camera it never arrived at.
 *
 * So the camera we are on is now a boolean, set at the moment of the cut. The
 * eased value follows it and is never asked what it means. The hysteresis is
 * then correct by construction as well — it used to test `closeUp > 0f` for
 * "already close", which is really "has ever been close", since the ease-out
 * needs some 1,700 frames to reach a true zero.
 *
 * [heldFor] is seconds since the last cut. The renderer takes it off the wall
 * clock, which is why nothing off-device can measure this by rendering frames
 * as fast as it can: four thousand frames go by in about two seconds of real
 * time, the hold never expires and the picture never leaves the board. A
 * harness must pass a clock that advances with the frames instead, which is
 * what a device at a steady frame rate gives it anyway.
 */
object CameraCut {
    /** Danger at which the camera comes in, and the lower level it goes back out at. */
    const val CUT_IN = 0.58f
    const val CUT_OUT = 0.22f

    /** Shortest time either camera is held before another cut is allowed. */
    const val HOLD_CLOSE = 4.5f
    const val HOLD_BOARD = 3.0f

    fun minHold(isClose: Boolean): Float = if (isClose) HOLD_CLOSE else HOLD_BOARD

    /**
     * Hysteresis on the camera we are actually on: come in at CUT_IN, and once
     * in, stay in until danger falls below CUT_OUT. Whichever camera has just
     * been taken is held for its minimum time whatever danger does, because a
     * director does not cut back and forth every two seconds.
     */
    fun wantClose(isClose: Boolean, danger: Float, heldFor: Float): Boolean {
        if (heldFor < minHold(isClose)) return isClose
        return danger >= CUT_IN || (isClose && danger >= CUT_OUT)
    }

    /** Eases toward the chosen camera: quicker in than out, so the cut reads. */
    fun ease(closeUp: Float, wantClose: Boolean): Float =
        closeUp + ((if (wantClose) 1f else 0f) - closeUp) * (if (wantClose) 0.22f else 0.06f)
}

/**
 * The match, seen from a high camera tilted just enough to show the players
 * as figures rather than discs. The pitch is drawn close to flat — mown bands
 * run straight up the screen and the lines stay parallel — with the far
 * touchline, its hoardings and the dugouts sitting along the top.
 */
class MatchView(ctx: Context, private val m: MatchEngine) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Theme.DISPLAY; textAlign = Paint.Align.CENTER
    }

    /*
     * Rendered at a modest internal size and scaled up smoothly. That keeps
     * the soft, slightly soft-focus look of an early-2010s phone game without
     * ever turning the players into blocks.
     */
    private var buffer: Bitmap? = null
    private var bufferCanvas: Canvas? = null
    private val blit = Paint().apply { isFilterBitmap = true; isAntiAlias = true; isDither = true }
    private val dst = Rect()

    /** Internal render width. Kept high enough that nothing looks blocky. */
    var pixelWidth = 1280

    private var rw = 1f
    private var rh = 1f
    private val rect = RectF()
    private val path = Path()

    /** 1 = the whole length fits, higher = closer in. */
    var zoom = 2.7f
    var followBall = true

    /**
     * How far into the broadcast camera we are, 0 on the board and 1 close up.
     * Held between frames so the move in and out is smooth.
     */
    /*
     * The camera behaves like a man on a tripod rather than a magnet stuck to
     * the ball.
     *
     * It used to chase the ball with a plain lerp, which measured out at fifteen
     * metres a second on average and peaked over two hundred when the ball was
     * repositioned for a restart. Three things fix that: a dead zone so small
     * movements near the middle of frame are ignored entirely, a cap on how fast
     * it may pan, and a limit on how fast that pan speed may change, so it eases
     * into a move and out of it instead of snapping.
     */
    private var camStepX = 0f
    private var camStepY = 0f

    /** Units either side of centre the ball may drift before the camera follows. */
    /*
     * These were tuned to cure a camera that swept past too fast, and they
     * over-corrected badly enough to break the shot.
     *
     * The reasoning recorded here was that the camera "peaked at 8.6 pitch
     * units a second against players who move at under three". Players do move
     * at under three units a second — but the camera does not follow players,
     * it follows the BALL, and a struck ball travels at up to forty. The old
     * ceiling of 0.13 units a frame is 4.7 units a second, so the camera could
     * not keep up with a firm pass, never mind a shot.
     *
     * Measured on two worlds with CamFollow: the ball was off the edge of the
     * broadcast picture 47% and 41% of the time, more than half a pitch away
     * from the camera centre at worst. Half the match was being played off
     * screen.
     *
     * (The old comment's arithmetic was also wrong: 0.13 units a frame at 36
     * frames a second is about 4.9 m/s, not the nine metres a second it
     * claimed.)
     *
     * So: a much higher ceiling, a smaller dead zone and a quicker response,
     * while keeping the easing that made the movement smooth in the first
     * place. The dead zone is what stops the camera fidgeting around a ball
     * that is barely moving; the easing is what stops it snapping. Neither
     * needed the ceiling to be this low.
     */
    private val PAN_DEAD = 3.5f

    /** Fastest pan, in pitch units per frame. About 30 units a second. */
    private val PAN_MAX = 0.85f

    /** How quickly the pan speed itself may change. */
    private val PAN_EASE = 0.16f

    private var closeUp = 0f

    /** True while the board view is being drawn, so the HUD can drop the radar. */
    private var onBoard = false

    private var lastCutAt = 0L

    /**
     * Which camera we are on. Remembered rather than read back off [closeUp],
     * because [closeUp] is only easing toward it — inferring the one from the
     * other is what stopped the close camera ever being reached. See CameraCut.
     */
    private var onCloseCamera = false

    /** The zoom the board view sits at, which the close view grows out of. */
    private val BOARD_ZOOM = 1.05f

    /** Broadcast framing at the moment of the cut, and once settled. */
    private val BROADCAST_WIDE = 0.26f
    /*
     * Widened from 0.72. The close view was framed tightly enough on the ball
     * that team shape was unreadable — and a manager who cannot see the shape
     * cannot see that a shout worked, which is measured: a shout moves the side
     * up to fifteen metres up the pitch and none of it was visible. The games
     * this is aiming at showed a third to a half of the pitch at once, so a
     * move could be read before it arrived.
     */
    private val BROADCAST_CLOSE = 0.56f

    /**
     * Referee height, derived rather than guessed.
     *
     * The broadcast renderer draws a player at figureScale 1.25 against a 1.80 m
     * reference, so 2.25 m, which on the width axis is 2.25 * 100/68 = 3.31
     * pitch units. The referee below is assembled to 2.76 of these units from
     * boots to the top of his head, so one unit has to be 3.31 / 2.76 of a pitch
     * unit for the two men to stand the same height.
     */
    private val REF_SCALE = 3.31f / 2.76f

    private var camX = 50f
    private var camY = 50f
    private var unit = 1f          // screen pixels per pitch unit along the length
    private val SQUASH = 0.62f     // how much the width is foreshortened

    private var turf: FloatArray? = null
    private var turfShade: IntArray? = null

    private var crowd: FloatArray? = null
    private var crowdColor: IntArray? = null
    private var ads: Array<String>? = null
    private var adColors: IntArray? = null

    private val GRASS_LIGHT = 0xFF9EBA68.toInt()
    private val GRASS_DARK = 0xFF6E8A2E.toInt()
    private val LINE_WHITE = 0xFFF4F7F0.toInt()

    private val SPONSORS = arrayOf(
        "KOVAX", "AURA BANK", "NORTEL AIR", "VOLTIQ", "MERIDIAN", "FYRE",
        "TESSERA", "HALCYON", "ORBIS", "SANDROC", "VELMONT", "IRONHART",
        "QUANTA", "NIMBUS", "CALDERA", "ZEPHYR", "LUMEN"
    )
    private val AD_COLORS = intArrayOf(
        0xFF1F4FA8.toInt(), 0xFF9A1B2E.toInt(), 0xFF15703F.toInt(), 0xFF5B2D91.toInt(),
        0xFFB4560F.toInt(), 0xFF106A66.toInt(), 0xFF23262F.toInt()
    )
    /** How many cuts the hair routine knows. */
    private val HAIRSTYLES = 8

    /** Boot colours, so a squad is not twenty-two pairs of black boots. */
    private val BOOTS = intArrayOf(
        0xFF15161C.toInt(), 0xFFF2F4F8.toInt(), 0xFFE23A3A.toInt(),
        0xFF2FA8E0.toInt(), 0xFFF2C043.toInt(), 0xFF32C07A.toInt(),
        0xFFE8720C.toInt(), 0xFFBF3FD1.toInt()
    )

    private val HAIR = intArrayOf(
        0xFF120E0B.toInt(), 0xFF2B1C10.toInt(), 0xFF4A3120.toInt(),
        0xFF6E4826.toInt(), 0xFFB9903F.toInt(), 0xFF1C1C1C.toInt()
    )
    private val SKIN = intArrayOf(
        0xFFF0C39C.toInt(), 0xFFD9A377.toInt(), 0xFFB9793F.toInt(),
        0xFF8A5426.toInt(), 0xFF5E3617.toInt()
    )

    /* ------------------------------------------------------- PROJECTION */

    /**
     * How big something at pitch depth [y] should be drawn.
     *
     * The camera sits behind the near touchline, so a man on the far side is
     * further from the lens and has to come out smaller. Everything was drawn
     * at one size whatever its depth, which is what made the pitch read flat:
     * in a broadcast picture a far side player is noticeably smaller than one
     * in the foreground. A pinhole falls off as one over the distance, so this
     * is that, normalised to one on the halfway line.
     *
     * y = 0 is the far touchline and y = 100 the near one.
     */
    /**
     * Moves one camera axis toward [target], respecting the dead zone, the speed
     * cap and the acceleration limit. Returns the new position.
     */
    private fun panAxis(target: Float, pos: Float, step: Float): FloatArray {
        val err = target - pos
        val over = kotlin.math.abs(err) - PAN_DEAD
        val drive = if (over <= 0f) 0f else kotlin.math.sign(err) * over
        // Gain raised with the ceiling: at the old 0.050 the camera needed an
        // error of seventeen units before it even asked for full speed.
        val wanted = (drive * 0.085f).coerceIn(-PAN_MAX, PAN_MAX)
        val newStep = step + (wanted - step) * PAN_EASE
        return floatArrayOf(pos + newStep, newStep)
    }

    private fun sx(x: Float): Float = rw / 2f + (x - camX) * unit
    private fun sy(y: Float): Float = rh * 0.46f + (y - camY) * unit * SQUASH

    /* --------------------------------------------------- BROADCAST VIEW */

    /*
     * The close view is drawn by BroadcastRenderer.kt, a perspective renderer
     * written against a fixed interface. This is the adapter: it turns the
     * engine's live players into that interface's types and hands them over.
     *
     * Two mappings are not one to one and are easy to get wrong:
     *
     *  - Kit pattern. Ours is PLAIN 0, STRIPES 1, HOOPS 2, SASH 3, HALVES 4,
     *    BAND 5. The renderer takes 0 solid, 1 vertical stripes, 2 sash,
     *    3 hoops. So hoops and sash swap places, and halves and band have no
     *    equivalent and fall back to something close.
     *  - Zoom. Ours is 2.7 for the normal close framing; the renderer calls
     *    that 1.0 and 0.2 for the whole pitch. So theirs is roughly ours / 2.7.
     */
    private val rPlayers = ArrayList<RPlayer>(22)

    private fun kitPatternFor(pattern: Int): Int = when (pattern) {
        Kits.STRIPES -> 1
        Kits.SASH -> 2
        Kits.HOOPS, Kits.BAND -> 3
        else -> 0                      // PLAIN and HALVES
    }

    private fun rKit(club: Club) =
        RKit(club.primary, club.secondary, kitPatternFor(club.kitPattern))

    /**
     * The broadcast renderer's own framing, kept separate from [zoom] so the
     * board view's easing maths is untouched.
     *
     * Measured against the reference stills: at 1.0 the grass fills 70% of the
     * frame and the stand is off screen entirely; at 0.35 it is 45% and the
     * stand dominates. 0.72 puts the far touchline, its hoardings and a band of
     * crowd along the top, which is what the goalmouth reference looks like.
     * The cut in from the board eases between the two, so the camera appears to
     * fly down into the ground rather than snapping.
     */
    private var broadcastFrame = BROADCAST_WIDE

    private fun broadcastZoom(): Float = broadcastFrame

    private fun drawBroadcastScene(c: Canvas, w: Float, h: Float) {
        rPlayers.clear()
        for (p in m.players) {
            if (!p.onPitch) continue
            rPlayers.add(
                RPlayer(
                    x = p.x, y = p.y,
                    facing = p.facing,
                    speed = p.speedNow,
                    runPhase = p.runPhase,
                    side = p.side,
                    isKeeper = p.pos == Pos.GK,
                    shirt = p.shirt,
                    seed = p.ref.id,
                    isCaptain = p.ref.id == (if (p.side == 0) m.home else m.away).tactics.captain,
                    // The engine has always worked out what each man is doing.
                    // Until now this is where it was thrown away, and every
                    // figure was drawn running whatever it was actually doing.
                    action = p.action,
                    actionTime = p.actionTime
                )
            )
        }
        val b = RBall(m.ball.x, m.ball.y, m.ball.height, m.ball.spin)
        drawBroadcast(
            c, w, h, rPlayers, b,
            rKit(m.home), rKit(m.away),
            camX, camY, broadcastZoom()
        )
    }

    /** Screen x of a pitch point, through the broadcast camera. */
    /** Current camera x, exposed for the performance harness. */
    fun cameraX(): Float = camX

    private fun bx(x: Float, y: Float): Float = bProject(x, y)[0]

    /** Screen y of a pitch point, through the broadcast camera. */
    private fun by(x: Float, y: Float, heightUnits: Float = 0f): Float =
        bProject(x, y, heightUnits)[1]

    /** Pixels per pitch unit at that depth, for sizing an overlay. */
    private fun bs(x: Float, y: Float): Float = bProject(x, y)[2]

    /** Where a pitch point lands on screen in the broadcast view. */
    private fun bProject(x: Float, y: Float, heightUnits: Float = 0f): FloatArray =
        broadcastProject(rw, rh, camX, camY, broadcastZoom(), x, y, heightUnits)

    /* ------------------------------------------------------- BOARD VIEW */

    /**
     * The whole pitch from directly above, players as counters.
     *
     * Most of a football match is not a chance, and watching twenty two sprites
     * jog through midfield tells you nothing you cannot read better from a
     * board. This is that board: flat, unsquashed, whole pitch on screen, one
     * disc a man. When the ball reaches the final third the view drops into the
     * broadcast camera and the players become players again.
     */
    private fun drawBoard(c: Canvas, w: Float, h: Float) {
        paint.shader = null

        // the table the game is played on
        paint.color = 0xFF0A0906.toInt()
        c.drawRect(0f, 0f, w, h, paint)

        // the pitch, sized to fit with a margin, and the right way round
        val margin = h * 0.07f
        val ph = h - margin * 2f
        val pw = ph * (105f / 68f)
        val px = (w - pw) / 2f
        val py = margin
        boardX = px; boardY = py; boardW = pw; boardH = ph

        // felt, with the mown bands still visible because they read well
        for (i in 0 until 10) {
            paint.color = if (i % 2 == 0) 0xFF4C7A34.toInt() else 0xFF447030.toInt()
            c.drawRect(px + pw * i / 10f, py, px + pw * (i + 1) / 10f, py + ph, paint)
        }

        // markings
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = maxOf(1.4f, ph * 0.0045f)
        paint.color = 0xC8FFFFFF.toInt()
        c.drawRect(px, py, px + pw, py + ph, paint)
        c.drawLine(px + pw / 2f, py, px + pw / 2f, py + ph, paint)
        c.drawCircle(px + pw / 2f, py + ph / 2f, ph * 0.135f, paint)
        for (side in 0..1) {
            val x0 = if (side == 0) px else px + pw - pw * 0.157f
            rect.set(x0, py + ph * 0.21f, x0 + pw * 0.157f, py + ph * 0.79f)
            c.drawRect(rect, paint)
            val g0 = if (side == 0) px else px + pw - pw * 0.055f
            rect.set(g0, py + ph * 0.37f, g0 + pw * 0.055f, py + ph * 0.63f)
            c.drawRect(rect, paint)
        }
        paint.style = Paint.Style.FILL
        c.drawCircle(px + pw / 2f, py + ph / 2f, ph * 0.008f, paint)

        // the counters
        val r = ph * 0.026f
        for (p in m.players) {
            if (!p.onPitch) continue
            val club = if (p.side == 0) m.home else m.away
            val cx = px + (p.x / 100f) * pw
            val cy = py + (p.y / 100f) * ph

            // a disc sitting on the felt, with the shadow a real counter casts
            paint.color = 0x40000000
            c.drawOval(cx - r * 1.05f, cy - r * 0.75f + r * 0.5f,
                cx + r * 1.05f, cy + r * 0.95f + r * 0.5f, paint)

            paint.color = tint(club.primary, 0.72f)
            c.drawCircle(cx, cy, r, paint)
            paint.color = club.primary
            c.drawCircle(cx, cy - r * 0.08f, r * 0.88f, paint)
            // the little rim of light a plastic counter picks up
            paint.color = 0x33FFFFFF
            c.drawCircle(cx - r * 0.28f, cy - r * 0.34f, r * 0.30f, paint)

            if (p.pos == Pos.GK) {
                paint.color = 0xFFF2C94C.toInt()
                c.drawCircle(cx, cy - r * 0.08f, r * 0.42f, paint)
            } else {
                label.textSize = r * 1.16f
                label.color = shirtNumberColour(club)
                c.drawText(p.shirt.toString(), cx, cy + r * 0.36f, label)
            }

            // the man in possession is ringed, so the eye can follow the ball
            if (p.key == m.ball.holder) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = r * 0.22f
                paint.color = 0xFFF4D06A.toInt()
                c.drawCircle(cx, cy, r * 1.42f, paint)
                paint.style = Paint.Style.FILL
            }
        }

        // the ball
        val bx = px + (m.ball.x / 100f) * pw
        val by = py + (m.ball.y / 100f) * ph
        paint.color = 0x50000000
        c.drawCircle(bx + r * 0.18f, by + r * 0.26f, r * 0.40f, paint)
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(bx, by, r * 0.36f, paint)
        paint.color = 0xFF2A2A2A.toInt()
        c.drawCircle(bx, by, r * 0.13f, paint)
    }

    private var boardX = 0f
    private var boardY = 0f
    private var boardW = 0f
    private var boardH = 0f

    /*
     * The flat renderer that used to draw the close-up view has been removed.
     * BroadcastRenderer.kt draws it in true perspective now, and drawPlayer()
     * in that file is where a footballer is drawn.
     *
     * What is left in here is the board view, the overlays that sit on top of
     * the broadcast picture, the HUD, and the replay plumbing. head(), legs(),
     * shadow() and litShade() survive because the referee is still drawn
     * locally; everything else that only served the old flat pitch is gone.
     */

    /* ------------------------------------------------------------ DRAW */

    override fun onDraw(c: Canvas) {
        if (width <= 0 || height <= 0) return
        val bw = pixelWidth
        val bh = kotlin.math.max(1, bw * height / width)
        var b = buffer
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            buffer = b
            bufferCanvas = Canvas(b)
        }
        renderScene(bufferCanvas!!, bw.toFloat(), bh.toFloat())
        dst.set(0, 0, width, height)
        c.drawBitmap(b, null, dst, blit)
    }

    private fun renderScene(c: Canvas, w: Float, h: Float) {
        if (w <= 0f || h <= 0f) return
        rw = w; rh = h

        val replaying = applyReplayFrame()

        // Which of the two views we are in. The engine decides when something
        // is worth watching properly; this only follows it, and eases across so
        // the change reads as a cut to a camera rather than a glitch.
        // A director does not cut back and forth every two seconds. The
        // hysteresis alone was not enough: danger crossed the band constantly
        // and the picture flipped between the two cameras with a median of 2.3
        // seconds between cuts, two in five of them inside two seconds. Once a
        // camera is taken it is held for a minimum time whatever danger does.
        val nowNanos = System.nanoTime()
        if (lastCutAt == 0L) lastCutAt = nowNanos
        val heldFor = (nowNanos - lastCutAt) / 1e9f
        val wantClose = CameraCut.wantClose(onCloseCamera, m.danger, heldFor)
        if (wantClose != onCloseCamera) { onCloseCamera = wantClose; lastCutAt = nowNanos }
        closeUp = CameraCut.ease(closeUp, onCloseCamera)

        if (closeUp < 0.06f) {
            drawBoard(c, w, h)
            // no radar on the board: the whole pitch is already on screen, and
            // a small copy of it sitting in the middle only gets in the way
            onBoard = true
            drawHud(c, w, h)
            onBoard = false
            m.banner?.let { drawBanner(c, w, h, it) }
            if (replaying) restoreLiveFrame()
            return
        }

        // pulling in: the pitch grows into the broadcast camera
        val ease = closeUp * closeUp * (3f - 2f * closeUp)
        unit = (w / 100f) * (BOARD_ZOOM + (zoom - BOARD_ZOOM) * ease)
        broadcastFrame = BROADCAST_WIDE + (BROADCAST_CLOSE - BROADCAST_WIDE) * ease

        if (followBall) {
            // Hold the view a touch nearer than the ball, so the far touchline,
            // its hoardings and the stand stay on screen.
            val px = panAxis(m.ball.x, camX, camStepX)
            camX = px[0]; camStepX = px[1]
            val py = panAxis(m.ball.y - 7f, camY, camStepY)
            camY = py[0]; camStepY = py[1]
        }
        // never show more than a sliver of grass beyond the touchlines
        val halfX = (w / 2f) / unit
        val halfY = (h * 0.46f) / (unit * SQUASH)
        camX = camX.coerceIn(halfX - 8f, 100f - halfX + 8f)
        // Was halfY - 24f. That let the camera drift so far toward the far
        // touchline that a frame with the ball out there was more than half
        // crowd, with the pitch squashed into a strip along the bottom.
        camY = camY.coerceIn(halfY - 8f, 100f - halfY + 20f)

        c.save()
        if (m.shake > 0f) {
            c.translate((Math.random().toFloat() - 0.5f) * 6f * m.shake,
                (Math.random().toFloat() - 0.5f) * 4f * m.shake)
        }

        // The pitch, the stands, every figure and the ball, in perspective.
        // Depth sorting, the goal frames and the keeper strips are all handled
        // inside the broadcast renderer, so none of the old flat drawing runs
        // here any more.
        drawBroadcastScene(c, w, h)

        // Overlays sit on top and are positioned through the broadcast camera's
        // own projection, or they would land where the flat pitch used to be.
        if (m.scene == Scene.FREEKICK) drawSpray(c)
        if (m.scene == Scene.PENALTY) drawPenaltyScene(c)
        if (m.scene == Scene.CORNER) drawCornerScene(c)
        if (m.skill > 0f) drawSkill(c)
        if (m.woodwork > 0f) drawWoodwork(c)
        if (m.refCard > 0) drawReferee(c)
        drawSelector(c)

        m.celebrateKey?.let { k ->
            m.players.firstOrNull { it.key == k }?.let { drawSparkle(c, it) }
        }

        drawHud(c, w, h)

        if (m.flash > 0f) {
            paint.shader = null
            paint.color = ((m.flash * 0.30f * 255).toInt() shl 24) or 0xFFFFFF
            c.drawRect(0f, 0f, w, h, paint)
        }
        m.banner?.let { drawBanner(c, w, h, it) }
        if (replaying) drawReplayFurniture(c, w, h)
        c.restore()
        if (replaying) restoreLiveFrame()
    }

    /**
     * The frame ringing after a shot hits it. A bright bar over the spot that
     * was struck, fading, with a shock ring spreading out from it.
     */
    /** An 0xRRGGBB colour at a given opacity, which is clearer than hand rolled shifts. */
    private fun fade(rgb: Int, alpha: Float): Int =
        ((alpha.coerceIn(0f, 1f) * 255).toInt() shl 24) or (rgb and 0xFFFFFF)

    private fun drawWoodwork(c: Canvas) {
        val t = (m.woodwork / 0.9f).coerceIn(0f, 1f)
        val x = bx(m.woodworkX, m.woodworkY)
        val y = by(m.woodworkX, m.woodworkY)
        paint.shader = null

        // the ring of the impact
        val ringR = unit * (0.6f + (1f - t) * 3.4f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = unit * 0.16f * t
        paint.color = fade(0xF4D06A, t * 0.78f)
        c.drawCircle(x, y, ringR, paint)
        paint.style = Paint.Style.FILL

        // the length of frame that was hit, lit up
        paint.color = fade(0xFFF3C4, t * 0.92f)
        if (m.woodworkBar) {
            rect.set(x - unit * 0.30f, y - unit * 4.6f, x + unit * 0.30f, y + unit * 4.6f)
        } else {
            rect.set(x - unit * 0.34f, y - unit * 0.9f, x + unit * 0.34f, y + unit * 0.9f)
        }
        c.drawRoundRect(rect, unit * 0.16f, unit * 0.16f, paint)

        label.textSize = unit * 1.5f
        label.color = fade(0xF4D06A, t)
        c.drawText(if (m.woodworkBar) "CROSSBAR!" else "OFF THE POST!",
            rw * 0.5f, rh * 0.30f - (1f - t) * unit * 2f, label)
    }

    /** The name of the trick over the man who pulled it off, with a flourish. */
    private fun drawSkill(c: Canvas) {
        val p = m.players.firstOrNull { it.key == m.skillKey && it.onPitch } ?: return
        val t = (m.skill / 0.62f).coerceIn(0f, 1f)
        val x = bx(p.x, p.y)
        val y = by(p.x, p.y, 4.4f) - (1f - t) * unit * 1.6f
        paint.shader = null

        // a ring of sparks turning round his feet
        val spin = (1f - t) * 6.0f
        paint.color = fade(0xF4D06A, t * 0.85f)
        for (i in 0 until 6) {
            val a = spin + i * (Math.PI.toFloat() / 3f)
            val r = unit * (0.9f + (1f - t) * 1.5f)
            c.drawCircle(
                bx(p.x, p.y) + kotlin.math.cos(a.toDouble()).toFloat() * r,
                by(p.x, p.y) + kotlin.math.sin(a.toDouble()).toFloat() * r * 0.55f,
                unit * 0.16f * t, paint
            )
        }

        label.textSize = unit * 1.05f
        label.color = fade(0x0B0A08, t * 0.75f)
        c.drawText(m.skillName, x + unit * 0.10f, y + unit * 0.10f, label)
        label.color = fade(0xF4D06A, t)
        c.drawText(m.skillName, x, y, label)
    }

    /**
     * A corner should look like one from above: the quadrant marked, the flag
     * picked out, and the arc the delivery will take drawn into the six yard
     * box. Until now a corner looked exactly like open play.
     */
    private fun drawCornerScene(c: Canvas) {
        val fx = bx(m.cornerFlagX, m.cornerFlagY)
        val fy = by(m.cornerFlagX, m.cornerFlagY)
        paint.shader = null

        // the quadrant
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = unit * 0.09f
        paint.color = fade(0xFFFFFF, 0.55f)
        rect.set(fx - unit * 1.6f, fy - unit * 1.6f, fx + unit * 1.6f, fy + unit * 1.6f)
        c.drawArc(rect, 0f, 360f, false, paint)

        // a ring round the taker's corner, pulsing
        val pulse = ((m.sceneTime * 1.8f) % 1f)
        paint.strokeWidth = unit * 0.10f
        paint.color = fade(0xF4D06A, (1f - pulse) * 0.75f)
        c.drawCircle(fx, fy, unit * (0.8f + pulse * 2.6f), paint)

        // the flight of the delivery, into the near of the six yard box
        val toX = sx(if (m.cornerFlagX > 50f) 92f else 8f)
        val toY = sy(50f)
        path.reset()
        path.moveTo(fx, fy)
        path.quadTo((fx + toX) / 2f, (fy + toY) / 2f - unit * 5.5f, toX, toY)
        paint.strokeWidth = unit * 0.13f
        paint.color = fade(0xF4D06A, 0.42f)
        c.drawPath(path, paint)
        paint.style = Paint.Style.FILL

        label.textSize = unit * 1.3f
        label.color = fade(0xF4D06A, 1f)
        c.drawText("CORNER", rw * 0.5f, rh * 0.22f, label)
    }

    /** The spot, the arc and a keeper on his line: a penalty should look staged. */
    private fun drawPenaltyScene(c: Canvas) {
        val att = if (m.ball.x > 50f) 0 else 1
        val spotX = if (att == 0) 88f else 12f
        paint.shader = null
        paint.color = 0xE6FFFFFF.toInt()
        val sc = bs(spotX, 50f)
        c.drawCircle(bx(spotX, 50f), by(spotX, 50f), sc * 0.30f, paint)

        // a soft pulse round the spot so the eye goes there
        val pulse = ((m.sceneTime * 2.2f) % 1f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = unit * 0.10f
        paint.color = fade(0xFFFFFF, (1f - pulse) * 0.6f)
        c.drawCircle(bx(spotX, 50f), by(spotX, 50f), sc * (0.5f + pulse * 2.2f), paint)
        paint.style = Paint.Style.FILL

        label.textSize = unit * 1.35f
        label.color = 0xFFF4D06A.toInt()
        c.drawText("PENALTY", rw * 0.5f, rh * 0.22f, label)
    }

    /* ---------------------------------------------------------- REPLAY */

    /*
     * The engine keeps a rolling history of positions and hands over the last
     * couple of seconds when a goal goes in. Rather than a second draw path,
     * the captured frame is written over the live one, the normal renderer runs
     * exactly as it always does, and the live values go back afterwards. That
     * way the replay gets the same sprites, kits and facings as the match.
     */
    private var saved: FloatArray? = null
    private var savedBall = FloatArray(3)

    private fun applyReplayFrame(): Boolean {
        val rep = m.replay ?: return false
        if (rep.isEmpty()) return false
        val idx = m.replayIndex.coerceIn(0, rep.size - 1)
        val f = rep[idx]
        val next = rep[kotlin.math.min(idx + 1, rep.size - 1)]

        val live = ArrayList<LivePlayer>(22)
        for (p in m.players) if (p.onPitch) live.add(p)
        if (live.size != f.xs.size) return false

        var st = saved
        if (st == null || st.size < live.size * 4) {
            st = FloatArray(live.size * 4); saved = st
        }
        for (i in live.indices) {
            val p = live[i]
            st[i * 4] = p.x; st[i * 4 + 1] = p.y
            st[i * 4 + 2] = p.facing; st[i * 4 + 3] = p.speedNow
            p.x = f.xs[i]; p.y = f.ys[i]
            // facing comes from where he goes next, so the sprite turns properly
            val dx = next.xs[i] - f.xs[i]
            val dy = next.ys[i] - f.ys[i]
            val d = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (d > 0.01f) {
                p.facing = kotlin.math.atan2(dy.toDouble(), dx.toDouble()).toFloat()
                p.speedNow = d * 22f
                p.runPhase += d * 3.5f
            } else p.speedNow = 0f
        }
        savedBall[0] = m.ball.x; savedBall[1] = m.ball.y; savedBall[2] = m.ball.height
        m.ball.x = f.ballX; m.ball.y = f.ballY
        return true
    }

    private fun restoreLiveFrame() {
        val st = saved ?: return
        val live = ArrayList<LivePlayer>(22)
        for (p in m.players) if (p.onPitch) live.add(p)
        for (i in live.indices) {
            if (i * 4 + 3 >= st.size) break
            val p = live[i]
            p.x = st[i * 4]; p.y = st[i * 4 + 1]
            p.facing = st[i * 4 + 2]; p.speedNow = st[i * 4 + 3]
        }
        m.ball.x = savedBall[0]; m.ball.y = savedBall[1]; m.ball.height = savedBall[2]
    }

    /** Letterbox bars, a label and a progress line, as a broadcast would cut it. */
    private fun drawReplayFurniture(c: Canvas, w: Float, h: Float) {
        val bar = h * 0.085f
        paint.shader = null
        paint.color = 0xF00A0C12.toInt()
        c.drawRect(0f, 0f, w, bar, paint)
        c.drawRect(0f, h - bar, w, h, paint)

        label.textSize = bar * 0.52f
        label.color = 0xFFF2B544.toInt()
        c.drawText("\u25CF  REPLAY", w * 0.5f, bar * 0.68f, label)

        val rep = m.replay ?: return
        val prog = if (rep.size <= 1) 0f else m.replayIndex.toFloat() / (rep.size - 1)
        paint.color = 0x66FFFFFF
        c.drawRect(w * 0.30f, h - bar * 0.52f, w * 0.70f, h - bar * 0.42f, paint)
        paint.color = 0xFFF2B544.toInt()
        c.drawRect(w * 0.30f, h - bar * 0.52f, w * 0.30f + w * 0.40f * prog, h - bar * 0.42f, paint)
    }

    /* ----------------------------------------------------------- GRASS */

    private fun drawSpray(c: Canvas) {
        paint.shader = null
        paint.color = 0xE6FFFFFF.toInt()
        val r = Rng(1234)
        for (i in 0 until 60) {
            val a = r.f() * Math.PI * 2
            val rad = r.f().toFloat() * 1.5f
            c.drawCircle(sx(m.freeKickX + (cos(a) * rad).toFloat()),
                sy(m.freeKickY + (sin(a) * rad).toFloat()),
                kotlin.math.max(0.8f, unit * 0.06f), paint)
        }
        stroke.color = 0xE6FFFFFF.toInt()
        stroke.strokeWidth = kotlin.math.max(1.4f, unit * 0.16f)
        val half = m.wallCount * 1.2f
        c.drawLine(sx(m.wallX - half), sy(m.wallY - half * 1.6f),
            sx(m.wallX + half), sy(m.wallY + half * 1.6f), stroke)
    }

    /* --------------------------------------------------------- FIGURES */

    /**
     * A footballer as the old handheld games drew him: a big head so he reads
     * at a glance, a clear block of shirt, separate shorts, bare legs into
     * coloured socks, and small dark boots. Everything is sized off one unit
     * so the whole figure scales together.
     */
    private fun shirtNumberColour(club: Club): Int {
        val p = club.primary
        val lum = ((p shr 16 and 0xFF) * 0.30f + (p shr 8 and 0xFF) * 0.59f + (p and 0xFF) * 0.11f)
        return if (lum > 140f) 0xFF1A1D26.toInt() else 0xFFF2F4F8.toInt()
    }

    private fun shadow(c: Canvas, cx: Float, cy: Float, u: Float) {
        paint.shader = null
        paint.color = 0x14000000
        rect.set(cx - u * 0.60f, cy - u * 0.20f, cx + u * 0.60f, cy + u * 0.20f)
        c.drawOval(rect, paint)
        paint.color = 0x1F000000
        rect.set(cx - u * 0.50f, cy - u * 0.165f, cx + u * 0.50f, cy + u * 0.165f)
        c.drawOval(rect, paint)
        paint.color = 0x33000000
        rect.set(cx - u * 0.38f, cy - u * 0.125f, cx + u * 0.38f, cy + u * 0.125f)
        c.drawOval(rect, paint)
    }

    private fun legs(c: Canvas, cx: Float, hipY: Float, footY: Float, u: Float,
                     skin: Int, socks: Int, swingA: Float, swingB: Float) {
        for (sw in floatArrayOf(swingA, swingB)) {
            val kneeX = cx + sw * u * 0.30f
            val footX = cx + sw * u * 0.56f
            val fy = footY - kotlin.math.abs(sw) * u * 0.14f
            stroke.color = skin
            stroke.strokeWidth = u * 0.26f
            c.drawLine(cx + sw * u * 0.10f, hipY + u * 0.16f, kneeX, hipY + u * 0.58f, stroke)
            stroke.color = socks
            c.drawLine(kneeX, hipY + u * 0.58f, footX, fy - u * 0.10f, stroke)
            paint.shader = null
            paint.color = 0xFF15171E.toInt()
            rect.set(footX - u * 0.22f, fy - u * 0.16f, footX + u * 0.26f, fy + u * 0.02f)
            c.drawRoundRect(rect, u * 0.07f, u * 0.07f, paint)
        }
    }

    /**
     * Flat colour with a single soft bake along the bottom edge. No directional
     * light, no banding: the shading is painted into the sprite, which is how
     * these games always did it.
     */
    private fun litShade(c: Canvas, l: Float, t: Float, r: Float, b: Float, base: Int, round: Float) {
        rect.set(l, t, r, b)
        paint.color = base
        c.drawRoundRect(rect, round, round, paint)
        paint.color = tint(base, 0.86f)
        rect.set(l, t + (b - t) * 0.66f, r, b)
        c.drawRoundRect(rect, round, round, paint)
        rect.set(l, t, r, b)
    }

    private fun head(c: Canvas, cx: Float, cy: Float, r: Float, skin: Int, hair: Int,
                     facing: Float, widthF: Float = 1f, style: Int = 0) {
        val rx = r * widthF
        paint.shader = null
        // neck
        paint.color = tint(skin, 0.86f)
        rect.set(cx - rx * 0.30f, cy + r * 0.52f, cx + rx * 0.30f, cy + r * 0.98f)
        c.drawRect(rect, paint)

        // an ellipse, not a circle: side-on the skull is seen edge-on and has
        // to narrow with the shoulders or the turn does not read
        paint.color = skin
        rect.set(cx - rx, cy - r, cx + rx, cy + r)
        c.drawOval(rect, paint)
        paint.color = tint(skin, 0.88f)
        val sv0 = c.save()
        path.reset()
        rect.set(cx - rx, cy - r, cx + rx, cy + r)
        path.addOval(rect, Path.Direction.CW)
        c.clipPath(path)
        rect.set(cx - rx, cy + r * 0.46f, cx + rx, cy + r)
        c.drawRect(rect, paint)
        c.restoreToCount(sv0)

        val deg = ((Math.toDegrees(facing.toDouble()) + 450) % 360).toFloat()
        val backToUs = deg < 60f || deg >= 300f
        val facingUs = deg in 120f..240f

        // ---- ears, which only show once he is not square to the camera ----
        if (!backToUs) {
            paint.color = tint(skin, 0.90f)
            if (facingUs) {
                c.drawCircle(cx - rx * 0.96f, cy + r * 0.06f, r * 0.16f, paint)
                c.drawCircle(cx + rx * 0.96f, cy + r * 0.06f, r * 0.16f, paint)
            } else {
                val d = if (deg < 180f) -1f else 1f
                c.drawCircle(cx + d * rx * 0.55f, cy + r * 0.06f, r * 0.17f, paint)
            }
        }

        // ---- face -------------------------------------------------------
        //
        // Bigger and higher-contrast than before. At this size a one-pixel dot
        // disappears into the antialiasing, so the eyes are whites with a dark
        // pupil, the nose is a shaded wedge and the mouth is a real mark.
        if (facingUs) {
            val eyeY = cy + r * 0.02f
            val eyeDx = rx * 0.36f
            // whites first, then the pupil, so the eye reads at a glance
            paint.color = 0xFFF6F1EA.toInt()
            rect.set(cx - eyeDx - rx * 0.19f, eyeY - r * 0.14f, cx - eyeDx + rx * 0.19f, eyeY + r * 0.14f)
            c.drawOval(rect, paint)
            rect.set(cx + eyeDx - rx * 0.19f, eyeY - r * 0.14f, cx + eyeDx + rx * 0.19f, eyeY + r * 0.14f)
            c.drawOval(rect, paint)
            paint.color = 0xFF1A1410.toInt()
            c.drawCircle(cx - eyeDx, eyeY + r * 0.01f, r * 0.105f, paint)
            c.drawCircle(cx + eyeDx, eyeY + r * 0.01f, r * 0.105f, paint)

            // brows, in the hair colour, carrying the expression
            paint.color = tint(hair, 1.05f)
            rect.set(cx - eyeDx - rx * 0.24f, cy - r * 0.34f, cx - eyeDx + rx * 0.20f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
            rect.set(cx + eyeDx - rx * 0.20f, cy - r * 0.34f, cx + eyeDx + rx * 0.24f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)

            // nose: a shaded wedge down the centre with a lit edge
            paint.color = tint(skin, 0.80f)
            rect.set(cx - rx * 0.10f, cy + r * 0.10f, cx + rx * 0.11f, cy + r * 0.40f)
            c.drawRoundRect(rect, r * 0.07f, r * 0.07f, paint)
            paint.color = tint(skin, 1.10f)
            c.drawRect(cx - rx * 0.10f, cy + r * 0.10f, cx - rx * 0.04f, cy + r * 0.34f, paint)

            // mouth
            paint.color = tint(skin, 0.58f)
            rect.set(cx - rx * 0.24f, cy + r * 0.54f, cx + rx * 0.24f, cy + r * 0.66f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
        } else if (!backToUs) {
            // three-quarter or profile: one eye, the brow, and the nose in relief
            val d = if (deg < 180f) -1f else 1f
            val ex = cx - d * rx * 0.30f
            paint.color = 0xFFF6F1EA.toInt()
            rect.set(ex - rx * 0.17f, cy - r * 0.12f, ex + rx * 0.17f, cy + r * 0.16f)
            c.drawOval(rect, paint)
            paint.color = 0xFF1A1410.toInt()
            c.drawCircle(ex - d * rx * 0.03f, cy + r * 0.03f, r * 0.10f, paint)
            paint.color = tint(hair, 1.05f)
            rect.set(ex - rx * 0.26f, cy - r * 0.34f, ex + rx * 0.20f, cy - r * 0.18f)
            c.drawRoundRect(rect, r * 0.06f, r * 0.06f, paint)
            // the nose breaks the silhouette on the side he is facing
            paint.color = tint(skin, 1.06f)
            c.drawCircle(cx - d * rx * 0.82f, cy + r * 0.24f, r * 0.15f, paint)
            paint.color = tint(skin, 0.76f)
            c.drawCircle(cx - d * rx * 0.66f, cy + r * 0.30f, r * 0.10f, paint)
            paint.color = tint(skin, 0.58f)
            rect.set(cx - d * rx * 0.60f, cy + r * 0.54f, cx - d * rx * 0.16f, cy + r * 0.64f)
            c.drawRoundRect(rect, r * 0.05f, r * 0.05f, paint)
        }

        // ---- hair, clipped to the skull, one of several cuts -------------
        paint.color = hair
        val saved = c.save()
        path.reset()
        rect.set(cx - rx * 1.06f, cy - r * 1.08f, cx + rx * 1.06f, cy + r * 1.02f)
        path.addOval(rect, Path.Direction.CW)
        c.clipPath(path)
        drawHair(c, cx, cy, rx, r, hair, style, backToUs, facingUs, deg)
        c.restoreToCount(saved)
    }

    /**
     * A handful of cuts so a team is not eleven identical men. Each is drawn
     * inside the skull ellipse, so they all sit correctly however he is turned.
     */
    private fun drawHair(c: Canvas, cx: Float, cy: Float, rx: Float, r: Float,
                         hair: Int, style: Int, backToUs: Boolean, facingUs: Boolean, deg: Float) {
        paint.shader = null
        paint.color = hair
        val d = if (deg < 180f) -1f else 1f
        // the cap of hair every style starts from, low at the back, higher in front
        fun cap(frontDrop: Float) {
            if (backToUs) {
                rect.set(cx - rx, cy - r, cx + rx, cy + r * 0.72f)
                c.drawOval(rect, paint)
            } else if (facingUs) {
                c.drawRect(cx - rx, cy - r, cx + rx, cy - r * frontDrop, paint)
            } else {
                c.drawRect(cx + d * rx * 0.02f, cy - r, cx + d * rx * 1.1f, cy + r * 0.34f, paint)
                c.drawRect(cx - rx, cy - r, cx + rx, cy - r * frontDrop, paint)
            }
        }
        when (style) {
            0 -> cap(0.20f)                                   // short back and sides
            1 -> {                                            // side parting
                cap(0.26f)
                if (!backToUs) {
                    paint.color = tint(hair, 0.72f)
                    c.drawRect(cx + d * rx * 0.10f, cy - r, cx + d * rx * 0.20f, cy - r * 0.24f, paint)
                }
            }
            2 -> {                                            // buzz cut, tight to the skull
                paint.color = tint(hair, 1.18f)
                cap(0.44f)
            }
            3 -> {                                            // full curls, sits proud
                rect.set(cx - rx * 1.05f, cy - r * 1.16f, cx + rx * 1.05f, cy + r * 0.30f)
                c.drawOval(rect, paint)
                paint.color = tint(hair, 1.22f)
                c.drawCircle(cx - rx * 0.44f, cy - r * 0.82f, r * 0.26f, paint)
                c.drawCircle(cx + rx * 0.40f, cy - r * 0.88f, r * 0.22f, paint)
                c.drawCircle(cx + rx * 0.04f, cy - r * 1.00f, r * 0.24f, paint)
            }
            4 -> {                                            // long, over the ears
                cap(0.22f)
                rect.set(cx - rx * 1.02f, cy - r * 0.60f, cx - rx * 0.52f, cy + r * 0.60f)
                c.drawRoundRect(rect, r * 0.12f, r * 0.12f, paint)
                rect.set(cx + rx * 0.52f, cy - r * 0.60f, cx + rx * 1.02f, cy + r * 0.60f)
                c.drawRoundRect(rect, r * 0.12f, r * 0.12f, paint)
            }
            5 -> {                                            // receding at the temples
                if (facingUs) {
                    c.drawRect(cx - rx * 0.62f, cy - r, cx + rx * 0.62f, cy - r * 0.34f, paint)
                    c.drawRect(cx - rx, cy - r, cx + rx, cy - r * 0.76f, paint)
                } else cap(0.34f)
            }
            6 -> {                                            // topknot
                cap(0.24f)
                c.drawCircle(cx - d * rx * 0.12f, cy - r * 1.02f, r * 0.26f, paint)
            }
            else -> {                                         // headband over a short cut
                cap(0.22f)
                paint.color = 0xFFF2F4F8.toInt()
                c.drawRect(cx - rx, cy - r * 0.50f, cx + rx, cy - r * 0.30f, paint)
            }
        }
    }

    private fun drawReferee(c: Canvas) {
        val cx = bx(m.refX, m.refY)
        val cy = by(m.refX, m.refY)
        // Sized through the broadcast camera, like everyone else on the pitch.
        // He was drawn at the old flat scale, so he stayed the same size
        // wherever he stood and did not match the players around him.
        val u = bs(m.refX, m.refY) * REF_SCALE
        shadow(c, cx, cy, u)
        val hipY = cy - u * 0.92f
        legs(c, cx, hipY, cy, u, SKIN[2], 0xFF15171E.toInt(), -0.2f, 0.2f)
        paint.shader = null
        litShade(c, cx - u * 0.44f, hipY - u * 0.14f, cx + u * 0.44f, hipY + u * 0.30f, 0xFF14161D.toInt(), u * 0.10f)
        val topY = hipY - u * 1.10f
        litShade(c, cx - u * 0.47f, topY, cx + u * 0.47f, hipY - u * 0.08f, 0xFF1C1F28.toInt(), u * 0.14f)
        // one arm raised, holding the card
        stroke.color = 0xFF1C1F28.toInt()
        stroke.strokeWidth = u * 0.20f
        c.drawLine(cx + u * 0.40f, topY + u * 0.18f, cx + u * 0.78f, topY - u * 0.72f, stroke)
        stroke.color = 0xFF1C1F28.toInt()
        c.drawLine(cx - u * 0.40f, topY + u * 0.18f, cx - u * 0.56f, topY + u * 0.76f, stroke)
        paint.color = if (m.refCard == 2) 0xFFE03434.toInt() else 0xFFF2C94C.toInt()
        rect.set(cx + u * 0.60f, topY - u * 1.16f, cx + u * 0.98f, topY - u * 0.62f)
        c.drawRoundRect(rect, u * 0.05f, u * 0.05f, paint)
        head(c, cx, topY - u * 0.38f, u * 0.36f, SKIN[2], HAIR[0], 0f)
    }

    private fun drawSelector(c: Canvas) {
        val h = m.ball.holder ?: return
        val p = m.players.firstOrNull { it.key == h } ?: return
        // through the broadcast camera, sized by how far away he is, and lifted
        // by a real height above the grass rather than a screen offset
        val cx = bx(p.x, p.y)
        val topY = by(p.x, p.y, 3.4f)
        val s = bs(p.x, p.y) * 0.62f
        paint.shader = null
        paint.color = if (p.side == 0) 0xFF3FCF4A.toInt() else 0xFFF2B544.toInt()
        path.reset()
        path.moveTo(cx - s, topY - s * 0.9f)
        path.lineTo(cx + s, topY - s * 0.9f)
        path.lineTo(cx, topY)
        path.close()
        c.drawPath(path, paint)
    }

    private fun drawSparkle(c: Canvas, p: LivePlayer) {
        val cx = sx(p.x); val cy = sy(p.y) - unit
        val t = m.celebrateTime
        stroke.color = ((((1f - t / 2.4f).coerceIn(0f, 1f) * 255).toInt()) shl 24) or 0xFBBF24
        stroke.strokeWidth = 2.4f
        for (i in 0 until 10) {
            val a = (i / 10f) * Math.PI * 2 + t
            val rr = unit * 1.2f + t * unit * 2.4f
            c.drawLine(cx + (cos(a) * rr * 0.5).toFloat(), cy + (sin(a) * rr * 0.5).toFloat(),
                cx + (cos(a) * rr).toFloat(), cy + (sin(a) * rr).toFloat(), stroke)
        }
    }

    /* -------------------------------------------------------------- HUD */

    /** The scoreboard, the radar and the two name plates, as the reference has them. */
    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val pad = h * 0.026f
        val boxH = h * 0.076f
        paint.shader = null

        // one scoreboard, top left: clock then the two short names and the score
        val mins = kotlin.math.min(m.clock.toInt(), 90)
        val clock = String.format("%02d:%02d", mins, ((m.clock - mins) * 60).toInt())
        val line = "$clock   ${m.home.shortName} ${m.score[0]}-${m.score[1]} ${m.away.shortName}"
        label.textSize = boxH * 0.48f
        val scoreW = label.measureText(line) + boxH * 0.9f
        hudBox(c, pad, pad, pad + scoreW, pad + boxH)
        label.color = 0xFFFFFFFF.toInt()
        c.drawText(line, pad + scoreW / 2f, pad + boxH * 0.66f, label)

        // radar, bottom centre
        if (!onBoard) drawRadar(c, w, h, pad)

        // a name plate in each bottom corner, with a stamina bar
        val homeMan = m.onPitch(0).maxByOrNull { it.minutes }
        val awayMan = m.onPitch(1).maxByOrNull { it.minutes }
        val holder = m.ball.holder?.let { k -> m.players.firstOrNull { it.key == k } }
        val leftMan = if (holder != null && holder.side == 0) holder else homeMan
        val rightMan = if (holder != null && holder.side == 1) holder else awayMan
        val plateW = w * 0.26f
        leftMan?.let { namePlate(c, pad, h - pad - boxH, plateW, boxH, it, m.home, false) }
        rightMan?.let { namePlate(c, w - pad - plateW, h - pad - boxH, plateW, boxH, it, m.away, true) }
    }

    private fun namePlate(
        c: Canvas, x: Float, y: Float, w: Float, hgt: Float,
        p: LivePlayer, club: Club, alignRight: Boolean
    ) {
        hudBox(c, x, y, x + w, y + hgt)
        // a flash of the club's colour on the outer edge
        paint.shader = null
        paint.color = club.primary
        val tabW = hgt * 0.26f
        if (alignRight) c.drawRect(x + w - tabW, y + 2f, x + w - 2f, y + hgt - 2f, paint)
        else c.drawRect(x + 2f, y + 2f, x + tabW, y + hgt - 2f, paint)

        label.textSize = hgt * 0.40f
        label.color = 0xFFFFFFFF.toInt()
        val text = "${p.shirt}  ${p.fullName.uppercase()}"
        c.drawText(text, x + w / 2f, y + hgt * 0.46f, label)

        // stamina
        val barX = x + tabW + hgt * 0.20f
        val barW = w - tabW * 2 - hgt * 0.40f
        val barY = y + hgt * 0.64f
        val barH = hgt * 0.16f
        paint.color = 0xFF2A2F3E.toInt()
        rect.set(barX, barY, barX + barW, barY + barH)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, paint)
        val f = (p.fitness / 100.0).toFloat().coerceIn(0f, 1f)
        paint.color = when {
            f > 0.7f -> 0xFF4ADE80.toInt(); f > 0.45f -> 0xFFFBBF24.toInt(); else -> 0xFFF87171.toInt()
        }
        rect.set(barX, barY, barX + barW * f, barY + barH)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, paint)
    }

    private fun hudBox(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        paint.color = 0xE014171F.toInt()
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.6f
        c.drawRoundRect(rect, (b - t) * 0.16f, (b - t) * 0.16f, stroke)
    }

    private fun drawRadar(c: Canvas, w: Float, h: Float, pad: Float) {
        /*
         * Moved out of the middle of the picture and shrunk.
         *
         * It was 22% of the width and 25% of the height, opaque, and centred
         * along the bottom edge — which is exactly where the ball is. Every
         * frame rendered from a live match had a solid green rectangle sitting
         * on top of the football. No aggregate figure could show this; it took
         * rendering a strip of frames and looking at them, which is the half of
         * "measure, never assert" that had never been done.
         */
        val rw = w * 0.15f
        val rh = rw * 0.64f
        val x0 = w - pad - rw
        val y0 = pad
        paint.shader = null
        paint.color = 0x991D5B33.toInt()
        rect.set(x0, y0, x0 + rw, y0 + rh)
        c.drawRoundRect(rect, 4f, 4f, paint)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = 1.4f
        c.drawRoundRect(rect, 4f, 4f, stroke)
        c.drawLine(x0 + rw / 2, y0, x0 + rw / 2, y0 + rh, stroke)
        c.drawCircle(x0 + rw / 2, y0 + rh / 2, rh * 0.15f, stroke)
        c.drawRect(x0, y0 + rh * 0.26f, x0 + rw * 0.13f, y0 + rh * 0.74f, stroke)
        c.drawRect(x0 + rw * 0.87f, y0 + rh * 0.26f, x0 + rw, y0 + rh * 0.74f, stroke)

        val dot = kotlin.math.max(1.8f, rh * 0.052f)
        for (p in m.players) {
            if (!p.onPitch) continue
            paint.color = if (p.side == 0) m.home.primary else m.away.primary
            val px = x0 + p.x / 100f * rw
            val py = y0 + p.y / 100f * rh
            rect.set(px - dot, py - dot, px + dot, py + dot)
            c.drawRect(rect, paint)
        }
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(x0 + m.ball.x / 100f * rw, y0 + m.ball.y / 100f * rh, dot * 0.8f, paint)
    }

    private fun drawBanner(c: Canvas, w: Float, h: Float, s: String) {
        label.textSize = h * 0.068f
        val tw = label.measureText(s)
        paint.shader = null
        paint.color = 0xE614171F.toInt()
        rect.set(w / 2 - tw / 2 - 22f, h * 0.40f, w / 2 + tw / 2 + 22f, h * 0.40f + h * 0.098f)
        c.drawRoundRect(rect, 6f, 6f, paint)
        stroke.color = 0xFFF2B544.toInt()
        stroke.strokeWidth = 2.5f
        c.drawRoundRect(rect, 6f, 6f, stroke)
        label.color = 0xFFF7F2E6.toInt()
        c.drawText(s, w / 2, h * 0.40f + h * 0.072f, label)
    }

    private fun tint(color: Int, f: Float): Int {
        val a = (color ushr 24) and 0xFF
        val r = (((color shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((color shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}

/** Reads the camera x of a view, for the performance harness only. */
fun probeCamX(v: MatchView): Float = v.cameraX()
