import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine

/**
 * AUDIT HARNESS -- do the players pile up on each other?
 *
 * The owner reports men tangling and bunching into one spot. An earlier check
 * measured SPREAD (mean distance from a side's own centroid) at 18-19 m and I
 * concluded there was no clumping problem. That was the wrong measurement:
 * spread says how stretched a SIDE is, and says nothing about two men standing
 * on the same blade of grass.
 *
 * separate() enforces minGap = 1.15 PITCH UNITS. One x-unit is 1.05 m and one
 * y-unit is 0.68 m, so along y that is 0.78 m -- not the "metre and a half" the
 * comment claims. Two sprites that close are drawn on top of each other. And it
 * is a single pass, so a genuine pile of eight or ten men cannot resolve.
 *
 * Measured here, per frame of open play:
 *   OVERLAP   pairs of men closer than 1.5 m
 *   PILE      the most men found inside a 5 m circle
 *   BASE      how far a man drifts from the station his formation gives him
 */
private class Row(val label: String, val v2: Boolean) {
    var frames = 0L
    var overlaps = 0L
    var pileSum = 0.0
    var pileMax = 0
    var baseSum = 0.0; var baseN = 0L

    fun run(n: Int) {
        MatchEngine.ENGINE_V2 = v2; MatchEngine.ENGINE_V3 = false
        val dt = 1f / 36f
        for (i in 0 until n) {
            val m = newEngine(20260727L + i * 7919L)
            m.replaysEnabled = false; m.start()
            var g = 0
            while (!m.finished && g++ < 900_000) {
                m.update(dt); m.sound.clear()
                if (g % 9 != 0) continue
                val on = m.players.filter { it.onPitch && it.pos != Pos.GK }
                if (on.size < 4) continue
                frames++
                var pairs = 0
                for (a in on.indices) for (b in a + 1 until on.size) {
                    val d = Math.hypot(((on[a].x - on[b].x) * 1.05).toDouble(),
                        ((on[a].y - on[b].y) * 0.68).toDouble())
                    if (d < 1.5) pairs++
                }
                overlaps += pairs
                var best = 0
                for (p in on) {
                    val c = on.count {
                        Math.hypot(((it.x - p.x) * 1.05).toDouble(),
                            ((it.y - p.y) * 0.68).toDouble()) < 5.0
                    }
                    if (c > best) best = c
                }
                pileSum += best
                if (best > pileMax) pileMax = best
                for (p in on) {
                    baseSum += Math.hypot(((p.x - p.baseX) * 1.05).toDouble(),
                        ((p.y - p.baseY) * 0.68).toDouble())
                    baseN++
                }
            }
        }
        MatchEngine.ENGINE_V2 = true
    }

    fun print() {
        println(String.format("%-4s %12.2f %12.2f %10d %12.1f",
            label, overlaps.toDouble() / maxOf(1L, frames),
            pileSum / maxOf(1L, frames), pileMax, baseSum / maxOf(1L, baseN)))
    }
}

fun main(args: Array<String>) {
    val n = args.firstOrNull()?.toIntOrNull() ?: 5
    println("=== do the players pile up? ($n matches each) ===")
    println(String.format("%-4s %12s %12s %10s %12s",
        "", "overlapping", "biggest", "worst", "drift from"))
    println(String.format("%-4s %12s %12s %10s %12s",
        "", "pairs/frame", "pile (5 m)", "pile", "station m"))
    Row("v1", false).also { it.run(n) }.print()
    Row("v2", true).also { it.run(n) }.print()
    println()
    println("Real football: two outfielders inside 1.5 m of each other is a duel,")
    println("so a fraction of a pair per frame. Six or more inside a 5 m circle")
    println("only happens in a box at a corner.")
}
