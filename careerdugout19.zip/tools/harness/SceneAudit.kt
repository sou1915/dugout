import com.dugout.career.core.Pos
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Scene

/**
 * AUDIT HARNESS -- does each named moment actually LOOK like that moment?
 *
 * SceneCheck counts scenes and SceneFilm photographs one of each. Neither says
 * whether the twenty two men on the pitch are arranged the way the caption
 * claims. This samples each scene at the LAST MOMENT BEFORE THE BALL IS PLAYED
 * -- see the note on `sampleAt` below, which is a parameter for good reason --
 * and asks, for each kind, the one or two questions that decide whether it
 * reads:
 *
 *   THROW-IN    is the ball on a touchline, and is anybody near it
 *   GOAL KICK   is the ball in the six yard box, and is it the keeper's
 *   FREE KICK   is there a wall, and is the taker standing over it
 *   CORNER      is the ball on the flag, and is anybody in the box
 *   PENALTY     taker on the spot, keeper on his line, everyone else outside
 *
 * Plus two things that apply to every scene:
 *
 *   SPREAD      the mean distance of an outfielder from his own side's centroid.
 *               A real side in shape is 18-25; a swarm around the ball is under
 *               10. This is the "everybody is in one clump" measurement.
 *   STACKED     another moment (a goal banner, a celebration) is on screen at
 *               the same time as this one, so the viewer is being shown two
 *               things at once.
 */
private class Acc {
    var n = 0L
    var spread = 0.0
    var nearestMate = 0.0
    var ballToMan = 0.0
    var ok = 0L          // scene-specific "this reads correctly"
    var stacked = 0L
    var extra = 0.0      // scene-specific second number

    fun add(spreadV: Double, mate: Double, ball: Double, good: Boolean,
            stack: Boolean, ex: Double) {
        n++; spread += spreadV; nearestMate += mate; ballToMan += ball
        if (good) ok++
        if (stack) stacked++
        extra += ex
    }

    fun row(name: String, okLabel: String, exLabel: String) {
        if (n == 0L) { println(String.format("%-12s  never reached", name)); return }
        println(String.format("%-12s %7d %8.1f %9.1f %9.1f %11.0f%% %9.0f%% %9.2f",
            name, n, spread / n, nearestMate / n, ballToMan / n,
            100.0 * ok / n, 100.0 * stacked / n, extra / n))
    }
}

private fun dist(ax: Float, ay: Float, bx: Float, by: Float) =
    Math.hypot(((ax - bx) * 1.05).toDouble(), ((ay - by) * 0.68).toDouble())

fun main(args: Array<String>) {
    val matches = args.firstOrNull()?.toIntOrNull() ?: 20
    val accs = HashMap<Int, Acc>()
    fun acc(s: Int) = accs.getOrPut(s) { Acc() }

    for (i in 0 until matches) {
        val m = newEngine(20260727L + i * 7919L)
        m.replaysEnabled = false
        m.start()
        val dt = 1f / 36f
        var lastScene = Scene.NONE
        var sceneStartT = 0f
        var sampled = false
        var guard = 0
        while (!m.finished && guard++ < 900_000) {
            m.update(dt)
            m.sound.clear()
            val sc = if (m.sceneTime > 0f) m.scene else Scene.NONE
            if (sc != lastScene) { lastScene = sc; sceneStartT = m.sceneTime; sampled = false }
            /*
             * WHERE THE SHUTTER FALLS, AND WHY IT IS A PARAMETER.
             *
             * The whole point of a restart is that men ARRIVE, so the state
             * that matters is the one play resumes into -- not the midpoint,
             * which marks a throw-in wrong for the crime of still being in
             * progress. That was the first mistake here.
             *
             * The second was overcorrecting to 0.12 of the scene remaining. A
             * set piece is struck at SET_PIECE_TAKE = 0.85 of its hold, leaving
             * 15%, and the next moment correctly replaces the caption at that
             * instant -- so 0.12 samples AFTER the kick has been taken and
             * caught only the free kicks that happened to have no scene follow
             * them. It reported 9 free kicks at 67% where 0.18 reports 59 at
             * 95%. A biased subsample dressed up as a defect.
             *
             * 0.18 is the last moment before the ball is played. It is a
             * property (-DsampleAt=) rather than a constant because the honest
             * thing to do with a sampling instant is sweep it and look at the
             * sensitivity, not pick one and trust it:
             *
             *   sample at   FREE KICK seen   reads correctly
             *      0.12                 9              67%
             *      0.18                59              95%
             *      0.30                59              97%
             *
             * A number that swings that hard on where you put the shutter is
             * telling you about the shutter, not the engine.
             */
            val frac = System.getProperty("sampleAt")?.toFloatOrNull() ?: 0.18f
            if (sc == Scene.NONE || sampled || m.sceneTime > sceneStartT * frac) continue
            sampled = true

            val out = m.players.filter { it.onPitch && it.pos != Pos.GK }
            if (out.isEmpty()) continue

            // spread: mean distance from a side's own centroid, averaged over sides
            var spreadSum = 0.0
            for (side in 0..1) {
                val men = out.filter { it.side == side }
                if (men.isEmpty()) continue
                val cx = men.map { it.x }.average()
                val cy = men.map { it.y }.average()
                spreadSum += men.map {
                    dist(it.x, it.y, cx.toFloat(), cy.toFloat())
                }.average()
            }
            val spread = spreadSum / 2.0

            val mate = out.map { p ->
                out.filter { it.side == p.side && it.key != p.key }
                    .minOfOrNull { dist(p.x, p.y, it.x, it.y) } ?: 0.0
            }.average()

            val ballToMan = m.players.filter { it.onPitch }
                .minOfOrNull { dist(it.x, it.y, m.ball.x, m.ball.y) } ?: 99.0

            /*
             * STACKED must mean "a DIFFERENT moment is on screen", not "a
             * banner is up". A booking sets its own YELLOW CARD banner and a
             * kick-off its own, so counting any banner read 100% for both and
             * called a working scene broken. Only a goal celebration or a
             * replay is unambiguously another moment.
             */
            val stacked = m.celebrationTime > 0f || m.replay != null ||
                (m.banner?.startsWith("GOAL") == true)

            // the attacking side, taken from the flag for a corner and from
            // possession otherwise -- never from ball.x, which lies at a set
            // piece before the ball has been placed
            val att = m.possessionSide
            val def = 1 - att

            var good = false
            var extra = 0.0
            when (m.scene) {
                Scene.THROW_IN -> {
                    val toLine = Math.min(m.ball.y.toDouble(), (100f - m.ball.y).toDouble())
                    good = toLine < 4.0 && ballToMan < 4.0
                    extra = toLine
                }
                Scene.GOAL_KICK -> {
                    val gx = if (m.ball.x < 50f) 0f else 100f
                    val d = dist(m.ball.x, m.ball.y, gx + (if (gx == 0f) 8f else -8f), 50f)
                    val gk = m.players.firstOrNull { it.onPitch && it.pos == Pos.GK &&
                        (if (gx == 0f) it.side == 0 else it.side == 1) }
                    val gkD = if (gk == null) 99.0 else dist(gk.x, gk.y, m.ball.x, m.ball.y)
                    good = d < 12.0 && gkD < 6.0
                    extra = gkD
                }
                Scene.FREEKICK -> {
                    val wall = m.players.count {
                        it.onPitch && it.side == def &&
                            dist(it.x, it.y, m.wallX, m.wallY) < 5.0
                    }
                    good = wall >= 2 && ballToMan < 5.0
                    extra = wall.toDouble()
                }
                Scene.CORNER -> {
                    val inBox = m.players.count {
                        it.onPitch && it.pos != Pos.GK && it.side == att &&
                            (if (m.cornerFlagX > 50f) it.x > 83.5f else it.x < 16.5f) &&
                            it.y > 21f && it.y < 79f
                    }
                    good = inBox >= 3
                    extra = inBox.toDouble()
                }
                Scene.PENALTY -> {
                    val spotX = if (att == 0) 88f else 12f
                    val takerOn = m.players.any { it.onPitch &&
                        dist(it.x, it.y, spotX, 50f) < 4.0 }
                    val gk = m.players.firstOrNull { it.onPitch && it.pos == Pos.GK && it.side == def }
                    val gkOn = gk != null &&
                        dist(gk.x, gk.y, if (att == 0) 99f else 1f, 50f) < 4.0
                    val inBox = m.players.count {
                        it.onPitch && it.pos != Pos.GK &&
                            (if (att == 0) it.x > 83.5f else it.x < 16.5f) &&
                            it.y > 21f && it.y < 79f
                    }
                    good = takerOn && gkOn && inBox <= 2
                    extra = inBox.toDouble()
                }
                else -> { good = ballToMan < 4.0 }
            }
            acc(m.scene).add(spread, mate, ballToMan, good, stacked, extra)
        }
    }

    println("=== does each named moment look like that moment? ($matches matches) ===")
    println()
    println(String.format("%-12s %7s %8s %9s %9s %12s %10s %9s",
        "scene", "seen", "spread", "nearest", "ball to", "READS", "STACKED", "extra"))
    println(String.format("%-12s %7s %8s %9s %9s %12s %10s %9s",
        "", "", "m", "mate m", "man m", "CORRECTLY", "on another", ""))
    val order = listOf(
        Scene.CORNER to Triple("CORNER", "3+ in box", "in box"),
        Scene.FREEKICK to Triple("FREE KICK", "wall + taker", "wall men"),
        Scene.THROW_IN to Triple("THROW-IN", "ball on line", "to line m"),
        Scene.GOAL_KICK to Triple("GOAL KICK", "keeper has it", "keeper m"),
        Scene.PENALTY to Triple("PENALTY", "spot+line+clear", "in box"),
        Scene.CARD to Triple("BOOKING", "someone near", "-"),
        Scene.KICK_OFF to Triple("KICK OFF", "someone near", "-"),
        Scene.SUBSTITUTION to Triple("SUB", "someone near", "-")
    )
    for ((s, t) in order) accs[s]?.row(t.first, t.second, t.third)
        ?: println(String.format("%-12s  never reached", t.first))

    println()
    println("SPREAD is the mean distance of an outfielder from his own side's")
    println("centroid. A side holding its shape reads 18-25 m. Under 10 m is")
    println("twenty two men standing in one clump around the ball.")
    println("STACKED is the share of frames where a goal banner, a celebration or")
    println("a replay was on screen at the same time as this caption.")
}
