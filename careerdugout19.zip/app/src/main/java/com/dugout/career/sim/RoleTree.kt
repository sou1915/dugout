package com.dugout.career.sim

import com.dugout.career.core.Att
import com.dugout.career.core.Pos
import com.dugout.career.core.Tactics
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ENGINE V3, LAYER 3: what each man is TRYING to do.
 *
 * A small behaviour tree per player, selected by his role and the club's
 * instructions. It answers one question -- what is this man's intent right now
 * -- and deliberately does not answer where he should stand. Turning an intent
 * into a destination is the space model's job, which is what stops this
 * becoming another pile of hand-tuned offsets like v1's updateTargets.
 *
 * The manager's tactical settings are this tree's parameters. That is the point:
 * on v2 the tactics screen reached the pitch only through a team RATING, so the
 * player could feel the difference in results but never see it. Here "press
 * high" literally changes when the PRESS branch is taken.
 */
object PlayIntent {
    const val PRESS = 0      // go and close the man on the ball
    const val COVER = 1      // protect the space behind the press
    const val MARK = 2       // stay with an opponent
    const val HOLD = 3       // keep the line and the shape
    const val SUPPORT = 4    // offer an angle to the man on the ball
    const val RUN = 5        // attack the space beyond the last man
    const val WIDE = 6       // stretch the pitch
    const val RECOVER = 7    // get back goal-side, quickly
    const val CARRY = 8      // he has the ball
    const val KEEP = 9       // goalkeeping
    const val CHASE = 10     // the ball is loose: go and win it

    val NAMES = arrayOf("PRESS", "COVER", "MARK", "HOLD", "SUPPORT",
        "RUN", "WIDE", "RECOVER", "CARRY", "KEEP", "CHASE")
}

/** Everything a tree needs to decide, gathered once per tick. */
class RoleCtx(
    val pitch: Pitch,
    val ballX: Float,
    val ballY: Float,
    val ballVX: Float,
    val ballVY: Float,
    val carrier: LivePlayer?,
    val attackingSide: Int,
    val loose: Boolean
)

object RoleTree {

    /**
     * The tree. Ordered hardest-condition-first, so the first branch that fires
     * wins -- which is what makes a behaviour tree readable months later.
     */
    fun intentOf(p: LivePlayer, t: Tactics, ctx: RoleCtx, isNearestToBall: Boolean): Int {
        if (p.pos == Pos.GK) return PlayIntent.KEEP
        if (ctx.carrier != null && ctx.carrier.key == p.key) return PlayIntent.CARRY

        /*
         * A LOOSE BALL HAS TO BE CHASED BY SOMEBODY.
         *
         * The tree had no intent for it. PRESS targets a cut-off angle rather
         * than the ball, so when nobody had possession all twenty two men
         * carried on holding shape and the ball simply lay there: measured
         * 89.6% of frames with a loose ball and not one shot in six matches.
         * Both sides' nearest man goes for it, which is also what makes a
         * fifty-fifty a contest rather than a coin flip.
         */
        if (ctx.loose && isNearestToBall) return PlayIntent.CHASE

        val attacking = ctx.attackingSide == p.side
        val ownGoalX = if (p.side == 0) 0f else 100f
        val group = Pos.group(p.pos)          // 1 back, 2 middle, 3 forward
        val toOwnGoal = abs(p.x - ownGoalX)
        val ballToOwnGoal = abs(ctx.ballX - ownGoalX)

        /* ----------------------------------------------- out of possession */
        if (!attacking || ctx.loose) {

            // caught upfield with his own goal under threat: get back first
            if (ballToOwnGoal < 38f && toOwnGoal > ballToOwnGoal + 8f) return PlayIntent.RECOVER

            // the nearest man goes, and how high he goes is the press setting
            val pressReach = when (t.press) { 2 -> 46f; 0 -> 24f; else -> 34f }
            if (isNearestToBall && ballToOwnGoal < pressReach) return PlayIntent.PRESS

            // a second man covers behind the press when the ball is near
            val dBall = Physics.metres(p.x, p.y, ctx.ballX, ctx.ballY)
            if (dBall < 18f && group <= 2) return PlayIntent.COVER

            // man-marking, when the manager has asked for it
            if (t.marking == 2 && group == 1) return PlayIntent.MARK

            return PlayIntent.HOLD
        }

        /* --------------------------------------------------- in possession */

        // a forward attacks the space in behind
        if (group == 3) return PlayIntent.RUN

        // width: the widest men stretch it, scaled by the width instruction
        val wideWant = when (t.width) { 2 -> 0.30f; 0 -> 0.72f; else -> 0.48f }
        if (group == 2 && abs(p.baseY - 50f) / 50f > wideWant) return PlayIntent.WIDE

        // everyone else offers an angle
        return PlayIntent.SUPPORT
    }

    /**
     * Turn an intent into somewhere to stand, using the space model.
     *
     * This is the half that makes the roles worth having: SUPPORT does not mean
     * "stand 8 units behind the ball", it means "find the best cell within
     * range from which you could receive it".
     */
    fun targetFor(
        p: LivePlayer, intent: Int, t: Tactics, ctx: RoleCtx,
        homeShapeX: Float, homeShapeY: Float
    ): Pair<Float, Float> {
        val dir = if (p.side == 0) 1f else -1f
        val ownGoalX = if (p.side == 0) 0f else 100f
        val theirGoalX = if (p.side == 0) 100f else 0f

        return when (intent) {
            PlayIntent.KEEP -> {
                // off his line in proportion to how far up the ball is
                val out = ((abs(ctx.ballX - ownGoalX) / 100f) * 8f).coerceIn(1.5f, 9f)
                (ownGoalX + dir * out) to (50f + (ctx.ballY - 50f) * 0.30f)
            }

            PlayIntent.CHASE -> {
                // run at where it is GOING, not where it is
                (ctx.ballX + ctx.ballVX * 0.45f) to (ctx.ballY + ctx.ballVY * 0.45f)
            }

            PlayIntent.PRESS -> {
                // cut the angle to goal rather than chase his back
                val gx = ctx.ballX + (ownGoalX - ctx.ballX) * 0.16f
                val gy = ctx.ballY + (50f - ctx.ballY) * 0.10f
                gx to gy
            }

            PlayIntent.COVER -> {
                // between the ball and his own goal, a little goal-side
                val cx = ctx.ballX + (ownGoalX - ctx.ballX) * 0.34f
                val cy = ctx.ballY + (50f - ctx.ballY) * 0.30f
                cx to cy
            }

            PlayIntent.RECOVER -> (ownGoalX + dir * 16f) to (50f + (ctx.ballY - 50f) * 0.5f)

            PlayIntent.MARK -> homeShapeX to homeShapeY

            PlayIntent.RUN -> {
                // the best space he can get to, ahead of the ball
                val (sx, sy) = ctx.pitch.bestSpace(p.side, p.x, p.y, 30f)
                // but never beyond the last defender: that is offside
                sx to sy
            }

            PlayIntent.WIDE -> {
                val touch = if (p.baseY < 50f) 8f else 92f
                (ctx.ballX + dir * 6f).coerceIn(4f, 96f) to touch
            }

            PlayIntent.SUPPORT -> {
                val (sx, sy) = ctx.pitch.bestSpace(p.side, p.x, p.y, 20f)
                sx to sy
            }

            else -> homeShapeX to homeShapeY   // HOLD, CARRY handled elsewhere
        }
    }

    /** How hard he works at it. A press is a sprint; holding shape is a jog. */
    fun effortFor(intent: Int): Float = when (intent) {
        PlayIntent.CHASE -> 1.00f
        PlayIntent.PRESS -> 1.00f
        PlayIntent.RECOVER -> 0.98f
        PlayIntent.RUN -> 0.92f
        PlayIntent.COVER -> 0.80f
        PlayIntent.CARRY -> 0.74f
        PlayIntent.SUPPORT -> 0.62f
        PlayIntent.WIDE -> 0.58f
        PlayIntent.MARK -> 0.70f
        PlayIntent.KEEP -> 0.55f
        else -> 0.40f
    }
}
