# Pixel-art conversion

Reference supplied by the owner: a pixel-art football game — chunky low-res
sprites, hard edges, muted mown pitch, a shallow camera, a centre-pill
scoreboard and a bottom-centre radar.

**Graphics and art style only.** No simulation behaviour was changed by any of
this, and `UiFlow` 33/33 plus an unchanged `BalanceBig` are the proof.

---

## What was done

### 1. The pixel pipeline — the whole look, in two changes

`MatchView` already rendered the scene into an offscreen buffer and scaled it to
the screen. That is exactly the pipeline a pixel-art game wants; it was simply
being used at full resolution with a smooth filter, so the result read as flat
vector shapes.

- `PIXEL_WIDTH = 400` — the buffer is now the game's real resolution.
- The blit is **nearest-neighbour** (`isFilterBitmap = false`), so every source
  pixel becomes a hard square block.

No sprite sheets and no binary assets: the figures are still generated
procedurally from the seed, they are just drawn into a small grid. The
project's no-assets rule is intact.

### 2. The UI is drawn AFTER the upscale

The first rendered frame showed the scoreboard as `YARW 2-0 ULLF` — text
rendered into a 400-pixel buffer and blown up is unreadable. Pixel-art games
render the *world* at low resolution and the *interface* at the screen's own,
because a scoreboard is meant to be read. `drawOverlay` now draws the HUD,
captions and banners onto the full-resolution canvas after the blit.

### 3. Palette and camera

- Mown stripes moved from the arcade greens (`#48B41E` / `#3E9E18`, chosen for
  the J2ME reference) to muted naturals (`#6FA84C` / `#5E9440`). Contrast
  between the bands matters far more once every colour edge is a visible block.
- Camera depression 40° → **27°**. The reference shows the goal frame from the
  side with depth in the net; a flatter camera is most of that difference.

Everything is behind `PIXEL_ART`, `PIXEL_WIDTH` and `PIXEL_TILT`, so the
previous look is one boolean away and the two can be compared side by side.

## What is NOT done

Judged against the reference, honestly:

- **HUD layout is unchanged.** The reference has a centre-pill scoreboard with
  team badges and a three-letter code, nameplates bottom-left and bottom-right
  with stamina bars, and the radar **bottom centre**. This build still has the
  old top-left scoreboard and top-right radar. This is the largest remaining
  gap and it is pure layout work in `drawHud`.
- **Sprites are the existing procedural figures**, not redrawn to pixel-art
  proportions. The reference's characters have big heads, visible hairstyles and
  a distinct outline. `FaceGen` and the figure code already vary hair and skin,
  so this is a proportion and outline job rather than new machinery.
- **No crowd at this angle.** The reference shows stands and a fence behind the
  boundary; at 27° the existing crowd band still leaves the frame.
- **Effects**: the reference has dust puffs on a tackle, motion streaks and
  confetti. None of that exists here.
- `PIXEL_WIDTH = 400` is a first guess. It wants sweeping by eye against the
  reference — 320 is chunkier, 480 finer.
