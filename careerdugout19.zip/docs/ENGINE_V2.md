# Engine v2 — continuous play

The owner's decision, after the audit: replace the match engine. This is the
design and the running state of that work.

Read `AUDIT.md` §8 and the `ContestCheck` / `BallAir` numbers first — they are
why this is happening, and they are the acceptance criteria.

---

## 1. Why the phase engine is being replaced

Not because it produces wrong results. `BalanceBig` over 9,120 matches sits at
2.51 ± 0.03 goals, the league tables are coherent and saves reproduce. It is
being replaced because of what it cannot express, measured:

| | phase engine | real football |
|---|---|---|
| ball in flight | **55.4%** of frames | ~20% |
| ball at a man's feet | **25.7%** | ~60% |
| nearest opponent to the ball | **8.64 m** | 3–5 m |
| opponent within 2 m of the carrier | **8.5%** of carry time | most of it |
| interceptions per match | **0** | ~45 |
| blocked passes per match | **0** | ~15 |
| deflections per match | **0** | many |

Three structural facts produce all of it:

1. **The outcome is rolled before the ball moves.** A defender therefore has no
   mechanism to take the ball; possession changes on a number decided earlier.
2. **A move is a pre-built list of team mates.** The next pass is struck the
   instant the last one lands, so nobody ever has time on the ball — no touch,
   no carry, no holding it up. That is "the ball keeps flying".
3. **A defender in the passing lane is clipped over**, every time, by
   construction (`blockerOnLine` raises the loft). Interception is not a
   possibility that fails; it is not modelled at all.

Eleven of the twenty-two men on the pitch could never touch the ball.

## 2. What v2 is

**Continuous possession.** No pre-rolled outcome, no pre-built sequence. The
ball is a physical object; possession is a consequence of where men are and how
good they are.

Each tick:

1. **Ball.** If loose, integrate velocity under friction, gravity and bounce.
   If held, it sits at the carrier's feet and moves with him.
2. **Loose-ball contest.** Any player inside a control radius may take it,
   contested on pace, anticipation and first touch.
3. **In-flight interception.** A pass is a travelling object. Anyone who gets
   within an interception radius of it may cut it out, on anticipation and
   position. This is where the 45 interceptions a match come from, and it is
   emergent rather than rolled.
4. **The carrier thinks.** He has a decision timer — time on the ball. While it
   runs he can carry, shield, or knock it past a man. When it expires, or
   pressure forces him, he picks: shoot, pass, cross, clear, or keep carrying.
   Options are scored on progress, lane clearance, receiver pressure and his own
   attributes.
5. **Defenders.** The nearest presses the carrier; the rest mark and cover. A
   tackle inside range resolves on attributes into: win the ball, foul, or beat.
6. **Shots and the keeper.** Shot quality from distance, angle, pressure and
   finishing; the keeper saves on his own attributes and position.
7. **Boundaries.** The ball crossing a line feeds the existing scene machinery —
   throw-in, goal kick, corner — which is kept unchanged and already works.

## 3. What is kept

Everything that is not the ball-and-decision core, because it is measured and
correct: scenes and set-piece staging, the arrangement gate, cards, injuries,
substitutions, the replay ring, sound cues, the commentary feed, the danger
model that drives the camera, `Save`'s format, and the entire public surface the
renderer and `Career` read (`ball`, `players`, `score`, `shots`, `xg`, `scene`,
`clock`, `feed`, `events`, …).

The renderer must not need a single change. That is a hard constraint and also
the cheapest possible regression test: if `MatchView` still compiles and
`UiFlow` still passes 33/33, the contract held.

## 4. How it is kept honest

`ENGINE_V2` is a `@JvmField var`, default off until it beats the old core. Both
engines therefore live in the same build and every existing harness can be
pointed at either, which is the control row the harness README demands.

Acceptance, in order:

| harness | v1 | v2 target |
|---|---|---|
| `BalanceBig` (9,120) | 2.51 ± 0.03 | 2.5–2.7, and home/draw/away within a point |
| `BallAir` in flight | 55.4% | under 30% |
| `BallAir` at feet | 25.7% | over 45% |
| `ContestCheck` nearest opponent | 6.81 m | 3–5 m |
| `ContestCheck` interceptions | 0 | 20+ |
| `SceneAudit` | corner 84%, throw-in 100% | no worse |
| `UiFlow` | 33/33 | 33/33 |

Balance is the hard one. An emergent model has no `CHANCE_QUALITY` to turn; it
is tuned through shot selection, conversion and tackle success, and each pass
costs a 9-minute `BalanceBig` run. Expect this to be the bulk of the work.

## 5. Risks, stated up front

- **Balance is not free.** The phase model guaranteed the scoreline distribution
  by construction. v2 has to earn it, and there is no guarantee the first
  parameter set lands in the band.
- **`quickSim` in `League.kt` must still agree.** It generates every match the
  player does not watch. If v2's goal distribution drifts, the league table the
  player sees will not match the football he watched.
- **Reproducibility.** Saves store a seed, not a scoreline. v2 must remain a
  pure function of its RNG streams, which means keeping the `rng` / `physRng` /
  `sfxRng` discipline exactly as it is.
- **Cost.** This is the largest change the project has had. It is staged behind
  a flag precisely so a half-finished v2 cannot break a shipping v1.

## 6. State

- [x] Design agreed, contract mapped
- [x] `ENGINE_V2` flag, both cores in one build
- [x] Ball physics and loose-ball contest
- [x] Carrier decisions and time on the ball
- [x] In-flight interception
- [x] Tackling and fouls
- [x] Shots and keeper
- [ ] **Balance tuning — not done, and it is the whole remaining job**

### Measured, `V2Check`, 20 matches, same seeds both cores

```
          inFlight   at feet     loose   nearest   carrier   goals   shots  tackles  fouls
v1           56.3%     26.3%     17.4%     8.83     13.7%    2.55    26.7     34.9    7.6
v2           23.6%     59.2%     17.2%     8.20     13.3%    2.35    18.8     77.7    3.4
```

**The structural problem is solved.** Ball in flight 56.3% → 23.6%, at a man's
feet 26.3% → 59.2%. That is the whole of "the ball keeps flying", and it is
fixed at the root: the ball is now an object that men hold, carry and lose,
rather than a projectile passed along a pre-built list. Interceptions and
tackles exist and are emergent. `UiFlow` 33/33 — the renderer contract held
without a single change to `MatchView`.

### And the balance is not there yet

`BalanceBig`, 9,120 matches, v2:

```
goals per game     1.91 +/- 0.03      target 2.5 - 2.7   OUTSIDE
home wins          38.0%              target ~45%        OUTSIDE
draws              29.5%              target ~25%
away wins          32.5%              target ~30%
cards per game     0.92               v1 1.71
```

Note the trap, because it caught me: a 20-match `V2Check` read 2.35 goals and
the 9,120-match run reads **1.91**. At 20 matches the standard error is 0.36,
so the small sample was noise and agreed with the band by accident. Nothing
about v2's balance may be believed from anything smaller than `BalanceBig`.

### The two known causes

1. **Not enough shots.** 18.8 against v1's 26.7 and a real ~25. The decision
   model passes when it should shoot: `V2_SHOT_RANGE` and the shoot roll in
   `v2Decide` are too conservative, and possession is turned over too often by
   `V2_TACKLE_RATE` (77.7 tackles a match against a real ~20).

2. **Home advantage has no channel.** This is the important one and it is
   architectural. v1 rolled outcomes from `world.teamRating(club, home)`, which
   bakes the home edge — and the whole tactical model — straight into the
   result. v2 decides from individual player attributes only, so home advantage
   reaches the pitch through nothing at all and home wins fell to 38%. Team
   rating, tactics, morale and the home edge all need an explicit route into
   the v2 decision weights; otherwise the manager's choices stop mattering,
   which for a management game is fatal.

That second point is the risk §5 predicted, arriving on schedule. It is not a
reason to stop, but it is the thing to fix before any of the shot tuning,
because tuning against a model that ignores the manager would be tuning the
wrong thing.

### Next

1. Route team rating, tactics and home advantage into `v2Decide`'s weights and
   into shot quality. Re-measure home/draw/away first.
2. Then tune shot volume and `V2_TACKLE_RATE` for goals, `BalanceBig` each time.
3. `quickSim` in `League.kt` must be re-checked against whatever v2 settles on.
4. Only then consider flipping `ENGINE_V2` to true by default.
