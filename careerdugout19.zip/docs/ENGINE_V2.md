# Engine v2 — continuous play

The owner's decision, after the audit: replace the match engine. This is the
design and the running state of that work.

Read `AUDIT.md` §8 and the `ContestCheck` / `BallAir` numbers first — they are
why this is happening, and they are the acceptance criteria.

---

## 1. Why the phase engine is being replaced

Not because it produces wrong results. `BalanceBig` over 9,120 matches sits at
2.51 ± 0.03 goals, the league tables are coherent and saves reproduce. It is
being replaced because of what it cannot express, measured:

| | phase engine | real football |
|---|---|---|
| ball in flight | **55.4%** of frames | ~20% |
| ball at a man's feet | **25.7%** | ~60% |
| nearest opponent to the ball | **8.64 m** | 3–5 m |
| opponent within 2 m of the carrier | **8.5%** of carry time | most of it |
| interceptions per match | **0** | ~45 |
| blocked passes per match | **0** | ~15 |
| deflections per match | **0** | many |

Three structural facts produce all of it:

1. **The outcome is rolled before the ball moves.** A defender therefore has no
   mechanism to take the ball; possession changes on a number decided earlier.
2. **A move is a pre-built list of team mates.** The next pass is struck the
   instant the last one lands, so nobody ever has time on the ball — no touch,
   no carry, no holding it up. That is "the ball keeps flying".
3. **A defender in the passing lane is clipped over**, every time, by
   construction (`blockerOnLine` raises the loft). Interception is not a
   possibility that fails; it is not modelled at all.

Eleven of the twenty-two men on the pitch could never touch the ball.

## 2. What v2 is

**Continuous possession.** No pre-rolled outcome, no pre-built sequence. The
ball is a physical object; possession is a consequence of where men are and how
good they are.

Each tick:

1. **Ball.** If loose, integrate velocity under friction, gravity and bounce.
   If held, it sits at the carrier's feet and moves with him.
2. **Loose-ball contest.** Any player inside a control radius may take it,
   contested on pace, anticipation and first touch.
3. **In-flight interception.** A pass is a travelling object. Anyone who gets
   within an interception radius of it may cut it out, on anticipation and
   position. This is where the 45 interceptions a match come from, and it is
   emergent rather than rolled.
4. **The carrier thinks.** He has a decision timer — time on the ball. While it
   runs he can carry, shield, or knock it past a man. When it expires, or
   pressure forces him, he picks: shoot, pass, cross, clear, or keep carrying.
   Options are scored on progress, lane clearance, receiver pressure and his own
   attributes.
5. **Defenders.** The nearest presses the carrier; the rest mark and cover. A
   tackle inside range resolves on attributes into: win the ball, foul, or beat.
6. **Shots and the keeper.** Shot quality from distance, angle, pressure and
   finishing; the keeper saves on his own attributes and position.
7. **Boundaries.** The ball crossing a line feeds the existing scene machinery —
   throw-in, goal kick, corner — which is kept unchanged and already works.

## 3. What is kept

Everything that is not the ball-and-decision core, because it is measured and
correct: scenes and set-piece staging, the arrangement gate, cards, injuries,
substitutions, the replay ring, sound cues, the commentary feed, the danger
model that drives the camera, `Save`'s format, and the entire public surface the
renderer and `Career` read (`ball`, `players`, `score`, `shots`, `xg`, `scene`,
`clock`, `feed`, `events`, …).

The renderer must not need a single change. That is a hard constraint and also
the cheapest possible regression test: if `MatchView` still compiles and
`UiFlow` still passes 33/33, the contract held.

## 4. How it is kept honest

`ENGINE_V2` is a `@JvmField var`, default off until it beats the old core. Both
engines therefore live in the same build and every existing harness can be
pointed at either, which is the control row the harness README demands.

Acceptance, in order:

| harness | v1 | v2 target |
|---|---|---|
| `BalanceBig` (9,120) | 2.51 ± 0.03 | 2.5–2.7, and home/draw/away within a point |
| `BallAir` in flight | 55.4% | under 30% |
| `BallAir` at feet | 25.7% | over 45% |
| `ContestCheck` nearest opponent | 6.81 m | 3–5 m |
| `ContestCheck` interceptions | 0 | 20+ |
| `SceneAudit` | corner 84%, throw-in 100% | no worse |
| `UiFlow` | 33/33 | 33/33 |

Balance is the hard one. An emergent model has no `CHANCE_QUALITY` to turn; it
is tuned through shot selection, conversion and tackle success, and each pass
costs a 9-minute `BalanceBig` run. Expect this to be the bulk of the work.

## 5. Risks, stated up front

- **Balance is not free.** The phase model guaranteed the scoreline distribution
  by construction. v2 has to earn it, and there is no guarantee the first
  parameter set lands in the band.
- **`quickSim` in `League.kt` must still agree.** It generates every match the
  player does not watch. If v2's goal distribution drifts, the league table the
  player sees will not match the football he watched.
- **Reproducibility.** Saves store a seed, not a scoreline. v2 must remain a
  pure function of its RNG streams, which means keeping the `rng` / `physRng` /
  `sfxRng` discipline exactly as it is.
- **Cost.** This is the largest change the project has had. It is staged behind
  a flag precisely so a half-finished v2 cannot break a shipping v1.

## 6. State — v2 is ON by default

`BalanceBig`, 9,120 matches, against the v1 figures it replaces:

```
                 v1              v2            target
goals       2.51 +/- 0.03   2.57 +/- 0.03     2.5-2.7
home wins       42.3%           46.0%         ~45%
draws           26.1%           23.5%         ~25%
away wins       31.6%           30.5%         ~30%
cards            1.71            1.03         (deprioritised, see PROJECT_STATE)
```

v2 is inside the band on goals and closer to target on home and away wins.
v1 is closer on draws. `UiFlow` 33/33 with no change to `MatchView`.

### What it was built to fix, and did

```
                        v1        v2      target
ball in flight        55.4%     24.9%     under 30%
ball at a man's feet  25.7%     44.0%     over 45%
carrier pressed       14.0%     17.9%     higher
interceptions             0   emergent    20+
```

The ball is no longer a projectile for most of the match, there is a real
contest for it, and the manager's team rating, tactics and home advantage reach
the pitch through `v2AttackEdge` and `v2ControlEdge`.

Scene fidelity where v2 improved: CORNER **96%** with **6.87** attackers in the
box at the delivery, GOAL KICK **99%**, PENALTY reads correctly.

### KNOWN REGRESSIONS — v2 is not finished

These are worse than v1 and are the next cycle's work. Recorded rather than
glossed, because a handoff that hides them is how this project lost a year to a
confidently wrong comment.

| | v1 | v2 | note |
|---|---|---|---|
| throw-ins per match | 8.0 | **0.6** | the ball barely leaves play sideways |
| THROW-IN reads correctly | 100% | **0%** | ball ends ~8 units off the line |
| FREE KICK reads correctly | 89% | **59%** | |
| BOOKING reads correctly | 94% | **40%** | |
| cards per match | 1.71 | 1.03 | |
| goal kicks per match | 20 | 21 | both far above a real 14 |

The throw-in chain is the big one and it is understood, not mysterious. Play is
scored on progress and centrality so it stays central; targets were clamped
inside the touchlines so the ball could not go out at all; a hurried-clearance
branch and a "a ball going out is going out" rule in `v2LooseBall` lifted it
from 0.0 to 0.6 a match, which is still an eighth of v1. The remaining causes
are that the pass scoring never values a wide ball, and that `v2Resume` hands
the ball to a man who carries it away before the throw-in has been drawn.

`PROJECT_STATE.md` explicitly deprioritises throw-in and card COUNTS as
realism targets the player cannot perceive. It does not excuse the throw-in
scene reading correctly 0% of the time, which is a picture fault.

### Next

1. Throw-in chain: value wide passes, and hold the ball on the line until the
   scene has been drawn.
2. FREE KICK and BOOKING scene fidelity under v2.
3. Cards: `v2Defend`'s foul rate and card chance.
4. Re-check `quickSim` in `League.kt` agrees with v2's distribution.
5. Only then consider deleting v1 — and probably never, because it is the
   control row that made all of this provable.
