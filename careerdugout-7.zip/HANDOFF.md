Continue work on Career Dugout, my Android football management game in Kotlin.
Project zip attached. Read tools/harness/README.md before anything else.

=================== WHAT IT IS ===================
Single player football management sim, landscape phone, Kotlin, minSdk 24.
Everything is generated from a seed at runtime: clubs, players, badges, faces,
kits, crowd noise. There are no binary assets except the launcher icon, and no
real clubs, players or sponsors. Around 17,000 lines.

Source: app/src/main/java/com/dugout/career/
  core/   Names.kt (Rng + name pools for 185 nations), Model.kt (Player, Club,
          Tactics, Presets), World.kt (generation, rivalries), Staff.kt,
          Manager.kt (profile + career record), DressingRoom.kt, Synth.kt
  sim/    MatchEngine.kt (live match), League.kt (fixtures, tables, season roll,
          continental cup), Career.kt (training, finance, transfers, jobs,
          press, loans, player talks), Save.kt
  ui/     Theme.kt (black and gold), Icons.kt, MatchView.kt, BroadcastRenderer.kt
          (perspective camera), FaceGen.kt, MatchAudio.kt
  MainActivity.kt  every screen, built programmatically

=================== HOW TO BUILD AND TEST ===================
There is no Android SDK here. Install a JDK, then kotlinc 2.1.20 from GitHub
releases — Maven Central is NOT reachable from this container.

tools/harness/shim/Android*.kt is a Java2D shim covering android.graphics,
view, widget, app, media, os, text and util. It is enough to compile the WHOLE
app off-device, MainActivity included.

BUILD IN TWO STAGES. The full app compile is about 65 seconds and the harnesses
are about 15, so do not rebuild the app to change a harness:

  # stage 1, only when app source changes
  SRC=app/src/main/java/com/dugout/career
  kotlinc -nowarn $SRC/core/*.kt $SRC/sim/*.kt $SRC/ui/*.kt $SRC/MainActivity.kt \
      tools/harness/shim/Android*.kt -d /tmp/app

  # stage 2, per harness
  kotlinc -nowarn -cp /tmp/app tools/harness/UiFlow.kt -d /tmp/h
  java -Djava.awt.headless=true -cp /tmp/h:/tmp/app:$KOTLIN_HOME/lib/kotlin-stdlib.jar UiFlowKt

Some harnesses need -Xmx3g (FaceUnique compares 32,136 faces pairwise).

Compiling proves type correctness, NOT that anything lays out on a phone.

There are 71 harnesses in tools/harness/. Run before every build:
  UiFlow.kt          builds the REAL MainActivity on the shim and walks every
                     screen. 33 steps, must be 0 crashes
  WorldCheck.kt      club and player name uniqueness, orphans, country shapes
  SaveCheck.kt       round trip, and that older saves still load
  BalanceHarness.kt  goals per game and result split. Args: matches, speed, seed
  ReplayCheck.kt     does a goal replay actually contain the goal

=================== RULE: MEASURE, NEVER ASSERT ===================
Do not claim any visual or physical result you have not measured. Render PNGs
and measure them, or print numbers. This has caught many bugs that reading the
code did not.

MEASUREMENT TRAPS. You will hit these. The last four were found the hard way
and cost most of a session between them:

1. The match camera EASES between two views over frames, held in a `closeUp`
   field on the MatchView instance. A freshly created view starts on the board.
   Any off-device measurement must run ~40 warm-up renders ON THE SAME INSTANCE.
   render(m, warm=40, tune) in Harness.kt does this. Warming a different
   instance does nothing.

2. Do NOT isolate a player by toggling p.onPitch. He reappears on the
   substitutes bench AND the HUD name plates change, so a difference image spans
   the entire frame. Put two players on the pitch in different halves and
   measure each in its own half.

3. BalanceHarness walks the league fixture list in order and the top division
   fills the first 380. So n=380 measures the top flight, n=2400 averages the
   whole pyramid. The 2.5-2.7 target is a top division figure.
   DivisionBalance.kt prints the breakdown.

4. Balance varies world to world. Always test at least three world seeds
   (arg 3): 20260727, 5150, 99001, 777333.

5. Scripted python edits have twice duplicated a whole code block. After any
   scripted edit, grep for duplicate declarations BEFORE compiling.

6. A HARNESS THAT KEEPS CALLING INTO A FINISHED MATCH MEASURES NOTHING.
   MatchEngine.update() returns immediately once `finished` is set. Four
   harnesses had this bug in different forms and all four reported figures that
   were not true of the live game:
     - StickCheck had `if (m.finished) break` at the BOTTOM of its loop, after
       three `continue`s, so any frame with a loose or in-flight ball jumped
       over it. It counted four thousand frames of a frozen match and reported
       the ball airborne 59% of the time. The truth is 17%.
     - CamCheck had no finished check at all.
     - PerfCheck benched 4,000 update calls without restarting, so it was
       timing a no-op. The engine costs 0.06 ms a frame, not the 0.04 it said.
   Put the check at the very top of the loop, or restart the match.

7. ANYTHING THAT MEASURES THE CAMERA MUST FORCE THE CLOSE VIEW. The cut between
   the board and the broadcast camera is gated on a minimum hold measured in
   WALL CLOCK time. A harness renders four thousand frames in about two seconds
   of real time, so the hold never expires, the view stays on the board, and
   camX is never used. Setting m.danger is NOT enough. CamFollow.kt pins
   closeUp by reflection; copy that. A first attempt at this measurement saw
   the camera move on 21 frames out of 400 and nearly concluded the pan was
   dead when it was barely being run.

8. ONE MATCH IS NOT A SAMPLE. A single match yields under 200 frames where a
   player actually has the ball at his feet, so any per-frame possession figure
   swings by a third off one match. Two numbers in the old VERIFIED STATE were
   quoted off one match and were wrong; a "home advantage in derbies" bug was
   diagnosed off 24 derbies and evaporated at 114. Use 20-40 matches for
   anything measured per frame, and say how many you used.

=================== VERIFIED STATE ===================
Measured this session unless marked otherwise. Every per-frame figure states
its sample size, and every harness that prints one now says how many matches
it ran.

world            1,236 clubs, 32,136 players, builds in 650-850 ms
                 60 countries with leagues, 185 nationalities
                 0 duplicate club names, 0 duplicate player names, 0 orphans
save             round trip clean, older saves still load
faces            100% unique across 32,136, closest pair 3 of 10 features
                 apart, assigned in 895 ms
memory           world 20.7 MB, faces 3.7 MB, fixtures 0.1 MB, total 24.6 MB
                 (inherited, not re-measured)
ball             23.0-23.2 m/s mean, 41.9 peak against a modelled ceiling of
                 40.3, max height 5.0 m, airborne 18-19%
                 (40 matches on each of 3 worlds)
passes           24.4-24.7 m mean, 68/19/13 forward/side/back, 192 struck a
                 match (40 matches on each of 3 worlds, ~5,000 passes)
                 real football is 18 m and 45/35/20 — see open problem 2
stickiness       0.37 m from the man in possession (40 matches, 10,394 held
                 frames; inherited, still believed)
movement         standing 12.4% walking 37.7% jogging 31.8% running 14.8%
                 sprinting 3.4% (20 matches, celebration frames excluded;
                 real football is 15/45/25/12/3). The old 13.9/40.0/28.9/
                 14.0/3.3 counted celebrations, which were 26,000 frames of
                 men walking, and is not comparable.
stride           3.18 m a leg cycle against a real 3.0-4.0 (20 matches)
camera           REACHES THE BROADCAST VIEW AT LAST — closeUp peaked at 0.22
                 out of 1.00 before this session and now reaches 1.00.
                 16.3 cuts a match, median 4.8 s apart, none under 3 s,
                 mean spell on the close camera 9.3 s, 69% of the match on it
                 (40 matches, frame clock)
                 ball off screen 3-4%, median lag 6.4-7.6 units, peak pan
                 30.6 units/s (inherited, measured with closeUp pinned)
performance      broadcast worst case together 6.4 ms/frame, engine 0.06 ms
                 (inherited; Java2D software rendering, treat as indicative.
                 NOTE the broadcast camera is now drawn 76% of frames rather
                 than never, so this is the number that matters now)
cosmetic stream  PROVEN cosmetic at last: an sfxRng draw used for nothing
                 leaves ResultFingerprint byte identical. It did NOT before —
                 the same probe moved goals 2.850 -> 2.750. Run
                 ResultFingerprint before and after ANY presentation change.
texture          take-ons 35.1 a match (was 10.3, real ~40), skill moves ~1
                 (was 0.17), headers 5.9 (was 5.4, real ~40 — needs more
                 aerial balls, which is a physics change)
shots            median 27.3 m, median GOAL 26.1 m, 0.0% of goals from the
                 shooter's own half (was 25.9%), 40 matches
shape            block 45.8 m back to front against a real 30-40; width
                 53.5 m and nearest team mate 13.7 m are both fine
                 (20 matches, 11,694 samples) — see open problem 0
balance          top flight 2.65 +/- 0.03 goals over 9,120 matches, 4 worlds
                 x 6 seasons; home 44.1%, draws 23.8%, away 32.1%, cards 1.86.
                 The four worlds are 2.68 / 2.63 / 2.62 / 2.67. Chance quality
                 went 0.099 -> 0.107 to pay for the ball being out of play at
                 set pieces; see MatchEngine.CHANCE_QUALITY for the whole
                 history. The quick sim independently gives 2.61 over 4,000.
poses            all eight actions change the drawn figure: a slide is 2.8x
                 wider than tall, a man on the floor 3.6x, a celebration the
                 only pose taller than a running stride (PoseCheck)
celebration      the mob closes from 20.2 m to 11.8 m over five seconds and
                 the closest two men settle at 1.8 m apart, never inside a
                 2 m circle (40 matches, 117 goals)
UI               UiFlow 33 steps, 0 crashes, including the unemployed path

=================== SYSTEMS THAT EXIST ===================
Match: two presentations. A top-down "button football" board view for ordinary
play, cutting to a perspective broadcast camera when the engine's `danger` value
rises. BroadcastRenderer.kt is a separate perspective renderer written to a
fixed interface (see tools/INTERFACE.md, MEASUREMENTS.txt, AUDIT.txt). Goal
replays, celebrations, walkout, woodwork, penalties, corners, cards, dribbles
with named skill moves, procedural sound.

Career: 60 playable countries grouped by continent, day-by-day between matches
with a briefing, press conferences, board and fan verdict on every signing,
transfers with scouting uncertainty, contracts with appearance fees, goal
bonuses, clean sheet bonuses and release clauses that rivals actually trigger.

Squad: youth academy and development, training focus and intensity, backroom
staff, dressing room hierarchy where mood spreads from the senior players, ten
personalities, LOANS, and individual player conversations.

Manager: profile chosen at setup (age band, tactical school, squad building
philosophy, manner with players) all with real mechanical effects. A career
record of every spell. You can start UNEMPLOYED and work up from the bottom.

=================== WHAT WAS DONE LAST SESSION ===================
The three items started were re-verification, balance and rivalries. Detail,
with the numbers, is in tools/harness/README.md — that file is the real record
and is worth reading before touching any of this.

1. THE BROADCAST CAMERA HAD NEVER BEEN REACHED. closeUp runs 0 on the board to
   1 on the broadcast camera and never got above 0.22 in 40 matches. "Which
   camera are we on" was inferred from the eased value: the renderer cut in,
   reset the hold clock, eased closeUp to 0.22 in one frame, and on the next
   frame closeUp > 0.5f was still false, so the rule read "we are on the board"
   and the board's 3 s hold pinned it there. 33 aborted cuts a match. The
   camera is now a boolean set at the cut. It reaches 1.00, holds 9.3 s spells,
   16.3 cuts a match. The decision lives in CameraCut in MatchView.kt and
   CutCheck CALLS it rather than copying it, which is how the old copy had
   drifted to the wrong thresholds without anyone noticing.

2. PASSES WERE MEASURED ON 14% OF THE PASSES. 24.6 m, not 19.6. See open
   problem 2 — this was not tuned, only measured.

3. BALANCE DID NOT NEED RETUNING. The 2.45/2.52/2.70 spread was sampling
   noise: 400 matches carries +/- 0.16 at 95% on goals per game. Over 9,120
   top-flight matches the figure is 2.58 +/- 0.03 with the four worlds inside
   0.04 of each other, and the lever was left exactly where it was.
   BalanceHarness's tolerance was 2.4-2.8 while it printed a target of 2.5-2.7;
   it now tests what it prints, and states its own interval. BalanceBig.kt is
   the harness to tune against.

4. BALLCHECK'S RESTART FILTER let repositions through and reported a peak of
   181 m/s against a flight model that cannot exceed 40.3. The engine was fine;
   the harness was not. 41.9 m/s on every world once fixed.

5. RIVALRIES NOW COST SOMETHING. See open problem 7.

A change that did NOT work and was reverted: bounding the receiver-lead in
MatchEngine, on the theory that it was dragging the aim point across the pitch
mid-flight. It changed the measured figures by nothing at all.

1. BALANCE DRIFT and 2. REPLAY REGRESSION were the same bug. `holdForGoal` was
   computed once per tick, but stepPhase() calls resolvePhase() itself, so a
   second shot could resolve in the same tick: shot A set pendingGoal with the
   ball in flight, shot B missed and staged a goal kick, and the stale
   pendingGoal was satisfied by that placement. A new harness, GoalPlace.kt,
   measured 113 of 163 goals — 69% — being awarded with the ball nowhere near
   a goal line, far worse than the single case in the old brief. After the fix,
   0 of 159. The chance-quality lever (0.099) was NOT touched; it did not need
   to be.

3. SIXTY LEAGUES AND ALL NATIONALITIES. 185 nations, 60 with leagues. A
   country's shape comes from FOREIGN_SHAPE in World.kt: 21 majors of 3x12,
   38 minors of 1x10, England 5x20. FOREIGN_CODES was APPENDED to, never
   inserted, so old saves still point at the right division. pickNation was
   rewritten (best-of-k draws, k rising with reputation) because the old flat
   threshold had rep-75 clubs signing from Oman and Thailand at 185 nations;
   k=1 at the bottom of the pyramid on purpose, because any widening at all
   made 22 nations vanish from the world entirely. Foreign top-flight quality
   now scales with nation strength, anchored so the original 15 leagues are
   unchanged. Flags are computed from ISO-2 rather than hand-written.

4. LOANS. A loaned player's clubId becomes the BORROWING club and he moves into
   their squad; loanFromId is the only thing that remembers who owns him. That
   is the whole design — selection, tactics, the engine, ratings and morale all
   treat him as one of theirs with no special case. Two things know about it:
   the wage split (Club.loanWageOut holds the parent's residual, and LoanCheck
   asserts the two clubs together always pay exactly one wage) and development
   (applyTraining runs over the squad PLUS loanedOut(c) — before that a loaned
   player stopped developing entirely, measured at +0.00 overall across a
   season against +4.00 for the ones kept in the reserves, making a loan
   strictly worse than doing nothing). Now 21.3 apps and +8.00 on loan against
   17.7 and +3.67 in the reserves.

5. INDIVIDUAL PLAYER CONVERSATIONS. Four things the manager can say, on the
   player card, one per player per week. The design rule is that a talk MUST be
   able to go wrong — one that always helps is a morale button and would make
   the dressing room pointless. Challenging a Temperamental player is net -8
   morale and fails more often than it works; the same words on a Resolute one
   land 94% of the time. Promises are concrete (six starts in ten weeks) so
   they can be broken: kept +13.1, broken -32.9, and Player.brokenPromises makes
   every future promise to that man 28 points less likely to land.

6. RIVALRIES AND DERBIES. Derived from the seed and the finished club list, not
   stored, so old saves load with derbies in them. buildRivalries() runs at the
   end of World.build AND in Save.read — it must be after clubs and divisions
   are read, because buildStructureOnly gives an empty world. Same town, then
   same division and similar standing, then the big club against the next two;
   capped at four and floored at one. The floor matters: without it 40% of
   clubs had no rival at all and the feature was invisible for four hundred of
   them. A derby is fuller, louder and more bad tempered and NOTHING else —
   over 1,800 matches, home wins 45% in derbies against 43% otherwise.

ALSO: THE CONTINENTAL CUP was rebuilt. Qualification was the eight best
   domestic clubs plus .take(8) off an ordered list of foreign first divisions,
   which meant the entrants were ALWAYS eight English clubs plus exactly ESP,
   ITA, GER, FRA, NED, POR, BEL and CRO — the first eight entries of
   FOREIGN_CODES — every season of every career. Places are now allocated to
   countries by nation strength and filled from that country's table, and the
   tournament follows the manager's continent.

ALSO: THE CAMERA WAS BROKEN and this is the one a player would actually have
   seen. The pan ceiling had been lowered to 0.13 units a frame to cure a
   camera that swept past too fast, on the recorded reasoning that it "peaked at
   8.6 pitch units a second against players who move at under three". Players do
   move at under three units a second — but the camera follows the BALL, and a
   struck ball travels at up to forty. 0.13 units a frame is 4.7 units a second.
   With the close view forced, the ball was off the edge of the broadcast
   picture 27.6% and 34.8% of the time on two worlds. Now 4.1% and 3.2%.

=================== OPEN PROBLEMS, IN PRIORITY ORDER ===================

0. MATCH ENGINE V2 IS UNDER WAY. The diagnosis, after five failed local fixes,
   is that pass length, pass direction, shot distance and team shape are all
   emergent side effects of where men happen to stand, because a move is built
   by hopping between whoever is near the ball. The plan: KEEP the outcome
   model (ratings -> phaseGap -> outcome roll -> chance quality; it measures
   correctly and agrees with the quick sim) and REPLACE the spatial layer.
   MatchEngine.SPATIAL_V2 switches between them; EngineCompare.kt runs both
   through every figure at once.
   - step one, walking the BALL rather than the players: KEPT, behind the flag.
     Mean pass 24.9 -> 21.7 m, direction 69/19/12 -> 62/24/14, and balance
     unchanged at 2.63 vs 2.65. The first change in this whole effort that did
     not have to be reverted. Not yet a clean win: own-half goals 0.0 -> 1.5%.
   - step two, players offering support: REVERTED, moved the pass 0.2 m.
   - step three, choosing the receiver at the moment of the pass: REVERTED,
     best pass figure (20.8 m) but direction and median goal both worse.
   WHAT STEPS TWO AND THREE PROVED: the whole move is decided before it is
   played, so support play and just-in-time passing cannot be bolted on. The
   next thing to try is an INCREMENTAL phase — no pre-built sequence at all,
   the move advancing pass by pass and ending when it reaches a shooting
   position or is lost, outcome still drawn from the ratings. That is a real
   rewrite of newPhase and stepPhase and it is the last untried idea.

0c. SHOTS ARE STILL TOO LONG, AND THE LOCAL FIX FOR IT IS BOOBY TRAPPED.
   Goals from the shooter's own half are gone (25.9% -> 0.0%, ShotRange.kt),
   but the median goal is struck from 26 m against a real 11 m. The obvious
   corrections — cancelling out-of-range attacks, and putting a distance curve
   on chance quality — were both tried and both WRECKED the result
   distribution: home wins 49-51% and draws 18-20% against real figures of 45
   and 25. Both are reverted and written up in tools/harness/README.md. The
   measured lesson is that this engine's distribution is far more sensitive to
   how possession changes hands than to how chances are valued; anything
   touching either needs BalanceBig on every single iteration.

   TEAM SHAPE IS WRONG AND THE OBVIOUS FIX BACKFIRES. Measured properly now
   (20 matches, 11,694 samples, and ShapeCheck reports the BLOCK rather than
   counting the man chasing the ball): 45.8 m back to front against a real
   30-40. Width and spacing are fine.
   SHAPE_COMPACT 0.62 -> 0.45 puts the block at 36.5 m and shortens passes from
   24.6 m to 22.5 m — and it puts goals BACK into the shooter's own half,
   because a compact shape lifts the defending line, the offside clamp holds
   attackers behind it, and play moves away from goal. Four variants were tried
   (pushing the block up, making defenders track the ball, keeping attackers
   high) and every one traded the shape against the shooting. All reverted; the
   table is in tools/harness/README.md.
   Shape, the offside clamp and how far a move can reach are ONE mechanism.
   Solve them together or not at all, and check with ShapeCheck AND ShotRange —
   neither alone tells you whether you have won.

0b. THE MATCH NOW HAS POSES AND SCENES, AND NOBODY HAS SEEN THOSE EITHER.
   The set pieces are the big one: corners and free kicks staged their scene
   and then called attemptShot on the same tick, and attemptShot sets a scene
   of its own, so the staged one was painted over before a frame was drawn.
   Corners now reach the screen 8.3 times a match against 4.4, free kicks 6.1
   against 0.1, and Scene.KICK_OFF and Scene.SUBSTITUTION are assigned at all
   for the first time. AliveCensus.kt counts all of it per match.
   STILL SHORT, and left alone deliberately because they are properties of the
   phase model rather than bugs: headers 5.3 a match against a real 40, taking
   a man on 10.3 against 40, throw-ins 8.4 against 40, cards 1.63 against 4,
   and named skill moves 0.17 — that last one is an advertised feature that is
   effectively invisible. Changing any of them means changing what a phase is,
   which moves balance.
   Reported from the device: no card, penalty, dribble, tackle, corner or
   keeper-diving scene, "the match doesn't feel alive". Both causes are fixed
   and both need looking at BY EYE on a phone:
   - every figure was drawn RUNNING whatever it was doing, because RPlayer had
     no action field and the engine's Act was discarded at the boundary. Eight
     poses are now drawn and PoseCheck measures each silhouette.
   - the set-piece overlays (penalty, corner, free kick, card, woodwork, skill
     move) are all drawn only on the broadcast camera, which was never reached.
   Still NOT posed anywhere: the board view draws flat figures and knows
   nothing about actions. If the board view is going to be the default
   presentation, the poses need to reach it too.

1. THE BROADCAST CAMERA IS NOW REACHED, AND NOBODY HAS SEEN IT. Fixed this
   session, and it is the largest untested change in the project: before, the
   game was on the board view for effectively the whole match, and now it is on
   the perspective camera for 69% of it. Every camera figure in the old brief
   was measured with closeUp pinned by reflection, so all of it described a view
   the game could not arrive at on its own. What now needs looking at BY EYE,
   not by harness:
   - does 69% feel right, or should the board view be the default? The lever is
     HOLD_CLOSE (4.5 s), not the danger thresholds — CutCheck sweeps CUT_OUT
     across its whole useful range and only moves the share from 75% to 61%,
     because a 4.5 s minimum spell times the number of times danger crosses
     CUT_IN already fills most of a 113 second match.
   - the broadcast renderer is now drawn 76% of frames rather than never, so
     PerfCheck's 6.4 ms worst case is suddenly the frame budget that matters.
     Re-run it, and run it on a phone if there is any way to.

2. THE PASSING IS LONGER AND MORE DIRECT THAN ANYONE THOUGHT. Measured
   properly: 24.6 m mean and 68/19/13 forward/side/back, against a real 18 m
   and 45/35/20. The old 19.6 m was measured on 14% of the passes, weighted
   toward the opening ball of a move. NOTHING HAS BEEN TUNED ABOUT THIS — it
   moves shape, chance creation and balance together, so it is a design
   decision and not a fix, and it wants deciding before anything else touches
   the engine. The lever is nextMan / the phase sequence in MatchEngine, and
   BalanceBig must be re-run across all four worlds afterwards.

3. NONE OF THIS HAS EVER RUN ON A PHONE. Everything above is measured on a
   Java2D shim on a desktop container. The two crashes that ever shipped were
   both "something that only exists on the has-a-club route, touched on the
   no-club route", and UiFlow now covers that, but layout, touch targets,
   text scaling, memory pressure and real frame timing are all unmeasured.
   The world is 24.6 MB in memory and an Android app is commonly given 128-256
   MB before it is killed, with the UI and bitmaps coming out of the same
   budget. This is the largest unknown in the project.

4. THE SAVE IS 7.94 MB AND GROWING. It was 3.95 MB at 16 countries. Each
   feature added this session put fields on the end of the player row. The
   previously agreed limit was 10 MB. Loans added four fields, talks added one.
   Before adding anything else to Player, work out whether the row can be
   written more tightly, or whether foreign squads can be regenerated from the
   seed rather than stored.

5. LOANS ARE HALF A SYSTEM. What exists: send out, recall with a lock, wage
   split, development, AI clubs doing it to each other, incoming enquiries,
   save round trip. What does not:
   - No loan-back clause, no option to buy, no wage negotiation. The share is
     take it or leave it.
   - The AI never recalls a player, so an AI club that loses three centre backs
     will not pull its own man back.
   - No loan window rules. A loan can be agreed in any week the transfer window
     is open, which is roughly right, but there is no emergency loan and no
     limit on how many a club may have out.
   - The parent club gets no report on how he is doing beyond apps and goals on
     the panel. A scout report from the loan would be the obvious hook into the
     existing scouting system.

6. CONVERSATIONS DO NOT RIPPLE. A talk moves one man's morale and nothing else.
   The dressing room already models influence and mood spreading from the
   senior players, so publicly challenging a talisman ought to move the room,
   and it does not. Also: no conversation about a transfer request, about a
   contract, or after a bad performance, and the press conference system and
   the talk system know nothing about each other.

7. RIVALRIES: MOSTLY DONE, ONE PIECE LEFT. Done this session — the fixture
   list, the league table and a Rivals panel on the club profile all mark them;
   a derby result moves the dressing room half again as far and swings board
   confidence by +4 for a win and -6 for a defeat; selling to a rival costs
   morale and board confidence and says so in the feed. NOT done: the press
   conference system does not know a derby is coming, and the AI does not weigh
   a rival when deciding who to sell to. (The old list named a season preview
   screen as a place to put them. There is no season preview screen — grep
   finds nothing of the sort. If one is wanted it has to be built first.)
   DerbyCheck measures all of the above and must be run at 1,800
   matches — 400 gives only 24 derbies and reported home wins at 58% against
   46%, which is the same mirage that was chased once already.

8. THE CONTINENTAL CUP IS SEEDED ONCE. seedConti runs at buildCalendar. Whether
   the field is correctly re-drawn each season with updated reputations after
   promotions and relegations has NOT been verified — write the harness that
   plays three seasons and prints the entrants each year. Also, qualification
   is on reputation rather than on where a club actually finished, so winning
   your league does not itself get you in.

9. FOREIGN LEAGUES ARE STILL ABSTRACT. Only the home pyramid and the country
   the manager is working in get a full calendar; everything else is simulated
   abstractly. That is deliberate and must stay that way for cost reasons, but
   it means rivalries, derbies and the new continental qualification are all
   computed over clubs whose season is a summary. Check that a derby in an
   abstract league does anything at all, and if it does not, say so on the
   screens rather than implying otherwise.

10. A STRAY EMPTY DIRECTORY named literally `{core,sim,ui}` was in the original
    zip, presumably from a shell glob that never expanded. It has been removed.
    Mentioned only so nobody puts it back.

=================== THINGS THAT HAVE BURNED ME ===================
- Two crashes shipped to the phone were the same shape: something that only
  exists on the "has a club" route, touched on the "no club" route. RUN
  UiFlow.kt — it drives the real Activity through every screen including the
  unemployed path and would have caught both.
- The RNG is a xorshift whose seed is scrambled with a SplitMix64 finalizer.
  Before that, seeding with a small integer gave a near zero FIRST draw, so all
  460 club badges came out with the same shield shape. If you add anything that
  seeds an Rng with a small id and immediately draws, remember why.
- Club and player names, and faces, are uniqueness-checked against registries.
  If you change generation, re-run WorldCheck.kt and FaceUnique.kt.
- Save.kt: new fields go on the END of a row. Inserting one in the middle shifts
  every index after it and silently corrupts traits, personality and career
  statistics on load. Every reader has a length check so older saves still work.
- FOREIGN_CODES is walked in order to lay out the foreign divisions and a
  division id is what a save stores against every club. APPEND, never insert.
- Any change to player generation moves match balance. Re-run BalanceHarness
  across three seeds afterwards, every time.
- A comment can be confidently wrong and cost a year. The camera pan comment
  explained a deliberate decision with reasoning that did not survive being
  read carefully, and the number in it was wrong by a factor of two. When you
  fix something, say what was wrong before AND what the measurement was, so the
  next person can check the reasoning rather than trusting it.

=================== HOW I WANT YOU TO WORK ===================
Measure before you change anything, and measure again after. If a change does
not achieve what you intended, revert it and say so rather than leaving it in.
Tell me plainly when something is not done or not working — I would rather hear
that than a confident summary. If a number looks wrong, suspect the harness
before you suspect the game; four of them were lying last session. State the
sample size for anything measured per frame. Comments in the code should explain
WHY, and especially what was wrong before, so the reasoning is not lost.

Start with re-verifying the numbers in problem 1, because everything else is
decided on the basis of them, then the balance retune, then whichever of loans,
conversations and rivalries you think is worth the most.
