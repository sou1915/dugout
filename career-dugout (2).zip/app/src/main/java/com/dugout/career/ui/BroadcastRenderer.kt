package com.dugout.career.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * BroadcastRenderer — perspective "broadcast camera" for a football match,
 * ISS Pro Evolution / Winning Eleven (PS1) styling. Pure android.graphics.
 *
 * COORDINATE CONTRACT
 *   x 0..100 along the pitch length (105 m), y 0..100 across the width (68 m)
 *   y = 0   FAR touchline (stands, hoardings, dugouts live beyond it)
 *   y = 100 NEAR touchline (camera side)
 *   ball height is in the same units as y (1 unit = 0.68 m)
 *
 * CAMERA MODEL
 *   A real pinhole. World space is METRES, right-handed:
 *     Xm = x/MX  (0..105, along the pitch)
 *     Ym = y/MY  (0..68, across, increasing toward the camera)
 *     Zm = up
 *   The camera sits at (camX in metres, 68 + BACK_M, HEIGHT_M), tilted down by
 *   TILT_DEG, looking in -Ym. Screen position AND scale both fall off as 1/depth,
 *   so the far touchline is genuinely shorter on screen than the near one and
 *   everything that spans depth becomes a trapezoid.
 *
 *   Panning: the camera translates in Xm with camX (a true pan, ratios preserved)
 *   and the principal point is shifted vertically to follow camY (a shift-lens
 *   tilt, which also preserves the convergence ratios). The tilt angle itself is
 *   constant, so the measured geometry does not drift as the camera tracks play.
 */

// ---------------------------------------------------------------------------
// Interface types — fixed, the match engine is written against these.
// ---------------------------------------------------------------------------

class RPlayer(
    val x: Float, val y: Float,      // pitch coords, see above
    val facing: Float,               // radians, 0 = +x, PI/2 = toward camera
    val speed: Float,                // pitch units per second, 0 when still
    val runPhase: Float,             // gait cycle accumulator
    val side: Int,                   // 0 home, 1 away
    val isKeeper: Boolean,
    val shirt: Int,
    val seed: Int                    // stable per player: skin, hair, build
)

class RBall(val x: Float, val y: Float, val height: Float, val spin: Float)

class RKit(val primary: Int, val secondary: Int, val pattern: Int)

// ---------------------------------------------------------------------------
// Camera rig — documented tunables. Defaults are the measured configuration.
// ---------------------------------------------------------------------------

object BroadcastCamera {
    /** Metres the camera sits behind the NEAR touchline. */
    @JvmField var backM = 101.3f
    /** Camera height above the pitch surface, metres. */
    @JvmField var heightM = 42.0f
    /** Fixed downward tilt, degrees. */
    @JvmField var tiltDeg = 22.0f
    /** Focal length in units of screen width, at zoom = 1. */
    @JvmField var focalK = 4.8f
    /** Where the tracked point (camX, camY) sits vertically on screen, 0..1. */
    @JvmField var aimBias = 0.62f
    /**
     * Figure size relative to true metric height. The PS1 originals drew players
     * oversized so they read on a 480i screen; 1.0 is metrically exact.
     * Uniform, so it does not affect the far/near height RATIO.
     */
    @JvmField var figureScale = 1.25f
    /** Minimum on-screen thickness of a painted line, pixels. Applied
     *  symmetrically about the true centreline. */
    @JvmField var minLinePx = 1.7f
    /** Draw the stands / crowd / hoardings. */
    @JvmField var drawStands = true
    /** Draw the goal frames and nets. Off only for isolating painted markings
     *  in the geometry tests — the nets are 3D white and would otherwise be
     *  unprojected as if they were paint on the grass. */
    @JvmField var drawGoals = true
}

// ---------------------------------------------------------------------------
// Metric constants
// ---------------------------------------------------------------------------

private const val MX = 100f / 105f          // metres -> pitch units, along
private const val MY = 100f / 68f           // metres -> pitch units, across
private const val PITCH_L = 105f
private const val PITCH_W = 68f
private const val LINE_W = 0.12f            // painted line width, metres
private const val PEN_DEPTH = 16.5f
private const val PEN_HALF = 40.32f / 2f
private const val GOALA_DEPTH = 5.5f
private const val GOALA_HALF = 18.32f / 2f
private const val PEN_SPOT = 11f
private const val CIRCLE_R = 9.15f
private const val GOAL_HALF = 7.32f / 2f
private const val GOAL_H = 2.44f
private const val CORNER_R = 1f

private const val PLAYER_H = 1.80f          // reference height, metres

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

fun drawBroadcast(
    c: Canvas, w: Float, h: Float,
    players: List<RPlayer>, ball: RBall,
    homeKit: RKit, awayKit: RKit,
    camX: Float, camY: Float, zoom: Float
) {
    val cam = Cam(w, h, camX, camY, zoom)
    val pens = Pens()

    c.save()
    c.clipRect(0f, 0f, w, h)

    drawBackdrop(c, cam, pens)
    drawGrass(c, cam, pens)
    drawMarkings(c, cam, pens)

    val gkHome = keeperKit(homeKit, awayKit)
    val gkAway = keeperKit(awayKit, homeKit)

    // Back-to-front painter's order over everything that stands up off the grass.
    val ents = ArrayList<Ent>(players.size + 3)
    for (p in players) ents.add(Ent(cam.depthAt(p.x / MX, p.y / MY), 1, p))
    if (BroadcastCamera.drawGoals) {
        ents.add(Ent(cam.depthAt(0f, PITCH_W * 0.5f), 0, null))
        ents.add(Ent(cam.depthAt(PITCH_L, PITCH_W * 0.5f), 0, null, atFarGoal = false))
    }
    ents.add(Ent(cam.depthAt(ball.x / MX, ball.y / MY), 2, null))
    ents.sortWith(compareByDescending { it.depth })

    for (e in ents) when (e.kind) {
        0 -> drawGoal(c, cam, pens, if (e.atFarGoal) 0f else PITCH_L)
        1 -> {
            val p = e.player!!
            val kit = if (p.isKeeper) (if (p.side == 0) gkHome else gkAway)
            else (if (p.side == 0) homeKit else awayKit)
            drawShadow(c, cam, pens, p.x / MX, p.y / MY, 1.9f, 0.42f)
            drawPlayer(c, cam, pens, p, kit)
        }
        2 -> drawBall(c, cam, pens, ball)
    }

    c.restore()
}

/** Camera parameters for the off-device harness / geometry tests. */
/**
 * Projects a pitch point to the screen using exactly the camera drawBroadcast
 * uses, so anything drawn over the top — a referee, a selector arrow, a marker
 * on the penalty spot — lands where the pitch actually is.
 *
 * [x] and [y] are pitch units 0..100 as used by RPlayer; [heightUnits] is height
 * off the grass in the same units as y. Returns [screenX, screenY, scale],
 * where scale is pixels per pitch unit of height at that depth: multiply any
 * size you were going to draw by it and the thing sits correctly in depth.
 */
fun broadcastProject(
    w: Float, h: Float, camX: Float, camY: Float, zoom: Float,
    x: Float, y: Float, heightUnits: Float = 0f
): FloatArray {
    val cam = Cam(w, h, camX, camY, zoom)
    val out = FloatArray(3)
    cam.proj(x / MX, y / MY, heightUnits / MY, out)
    // pixels per metre at this depth, converted to pixels per pitch unit of y
    val ppm = cam.f / out[2]
    return floatArrayOf(out[0], out[1], ppm / MY)
}

fun broadcastCameraReport(w: Float, h: Float, camX: Float, camY: Float, zoom: Float): String {
    val cam = Cam(w, h, camX, camY, zoom)
    return "{\"f\":${cam.f},\"px\":${cam.px},\"py\":${cam.py},\"ex\":${cam.ex},\"ey\":${cam.ey}," +
            "\"ez\":${cam.ez},\"sinT\":${cam.sinT},\"cosT\":${cam.cosT},\"w\":$w,\"h\":$h}"
}

// ---------------------------------------------------------------------------
// Projection
// ---------------------------------------------------------------------------

private class Cam(val w: Float, val h: Float, camX: Float, camY: Float, zoom: Float) {
    val sinT: Float
    val cosT: Float
    val ex: Float
    val ey: Float
    val ez: Float
    val f: Float
    val px: Float
    var py: Float
    val t = FloatArray(3)
    private val t2 = FloatArray(3)

    init {
        val th = BroadcastCamera.tiltDeg * 0.01745329f
        sinT = sin(th); cosT = cos(th)
        ex = camX / MX
        ey = PITCH_W + BroadcastCamera.backM
        ez = BroadcastCamera.heightM
        f = BroadcastCamera.focalK * w * max(zoom, 0.02f)
        px = w * 0.5f
        py = 0f
        // Shift-lens: place the tracked ground point at aimBias of the screen height.
        val vy = camY / MY - ey
        val vz = -ez
        val d = -vy * cosT - vz * sinT
        val b = -vy * sinT + vz * cosT
        py = h * BroadcastCamera.aimBias + f * (b / max(d, 1f))
    }

    /** Project a world point in metres. out = [screenX, screenY, depth]. */
    fun proj(xm: Float, ym: Float, zm: Float, out: FloatArray) {
        val vx = xm - ex
        val vy = ym - ey
        val vz = zm - ez
        var d = -vy * cosT - vz * sinT
        if (d < 1f) d = 1f
        val b = -vy * sinT + vz * cosT
        out[0] = px + f * vx / d
        out[1] = py - f * b / d
        out[2] = d
    }

    fun sx(xm: Float, ym: Float, zm: Float): Float { proj(xm, ym, zm, t2); return t2[0] }
    fun sy(xm: Float, ym: Float, zm: Float): Float { proj(xm, ym, zm, t2); return t2[1] }

    fun depthAt(xm: Float, ym: Float): Float {
        val vy = ym - ey
        return max(-vy * cosT + ez * sinT, 1f)
    }

    /** Pixels per metre at a given depth. */
    fun scale(d: Float) = f / d

    /** Screen y of the horizon (depth -> infinity). */
    fun horizonY() = py - f * (sinT / cosT)
}

private class Ent(
    val depth: Float, val kind: Int, val player: RPlayer?, val atFarGoal: Boolean = true
)

// ---------------------------------------------------------------------------
// Paints
// ---------------------------------------------------------------------------

private class Pens {
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    val flat = Paint().apply { style = Paint.Style.FILL }          // aliased, PS1 flavour
    val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT
    }
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    val path = Path()
}

// ---------------------------------------------------------------------------
// Small geometry helpers
// ---------------------------------------------------------------------------

/** Fill a polygon given as world-metre triples (x, y, z). */
private fun poly(c: Canvas, cam: Cam, pts: FloatArray, paint: Paint, path: Path) {
    path.reset()
    var i = 0
    while (i < pts.size) {
        cam.proj(pts[i], pts[i + 1], pts[i + 2], cam.t)
        if (i == 0) path.moveTo(cam.t[0], cam.t[1]) else path.lineTo(cam.t[0], cam.t[1])
        i += 3
    }
    path.close()
    c.drawPath(path, paint)
}

/** Flat quad on the grass. */
private fun groundQuad(
    c: Canvas, cam: Cam, x0: Float, y0: Float, x1: Float, y1: Float,
    x2: Float, y2: Float, x3: Float, y3: Float, paint: Paint, path: Path
) {
    poly(c, cam, floatArrayOf(x0, y0, 0f, x1, y1, 0f, x2, y2, 0f, x3, y3, 0f), paint, path)
}

/**
 * A band on the grass with a guaranteed minimum on-screen thickness.
 * A line running along the pitch is seen almost edge-on, so its true 12 cm width
 * lands well under one pixel at the far touchline and vanishes into the grass.
 * The widening is symmetric about the true centreline, so every measured
 * position, length and radius is unaffected — only the visual weight changes.
 */
private fun band(
    c: Canvas, ax: FloatArray, ay: FloatArray, bx: FloatArray, by: FloatArray,
    n: Int, paint: Paint, path: Path
) {
    val minPx = BroadcastCamera.minLinePx
    for (i in 0 until n) {
        var dx = bx[i] - ax[i]
        var dy = by[i] - ay[i]
        val l = sqrt(dx * dx + dy * dy)
        if (l < minPx) {
            val need = (minPx - l) * 0.5f
            if (l < 1e-5f) { dx = 0f; dy = 1f } else { dx /= l; dy /= l }
            ax[i] -= dx * need; ay[i] -= dy * need
            bx[i] += dx * need; by[i] += dy * need
        }
    }
    path.reset()
    for (i in 0 until n) if (i == 0) path.moveTo(ax[i], ay[i]) else path.lineTo(ax[i], ay[i])
    for (i in n - 1 downTo 0) path.lineTo(bx[i], by[i])
    path.close()
    c.drawPath(path, paint)
}

/**
 * A painted line on the grass, drawn as a projected trapezoid of constant WORLD
 * width — so it narrows with distance exactly like the real thing.
 */
private fun groundLine(
    c: Canvas, cam: Cam, ax: Float, ay: Float, bx: Float, by: Float,
    width: Float, paint: Paint, path: Path
) {
    val dx = bx - ax
    val dy = by - ay
    val len = sqrt(dx * dx + dy * dy)
    if (len < 1e-4f) return
    val nx = -dy / len * width * 0.5f
    val ny = dx / len * width * 0.5f
    val ex = FloatArray(2); val ey = FloatArray(2)
    val gx = FloatArray(2); val gy = FloatArray(2)
    cam.proj(ax + nx, ay + ny, 0f, cam.t); ex[0] = cam.t[0]; ey[0] = cam.t[1]
    cam.proj(bx + nx, by + ny, 0f, cam.t); ex[1] = cam.t[0]; ey[1] = cam.t[1]
    cam.proj(ax - nx, ay - ny, 0f, cam.t); gx[0] = cam.t[0]; gy[0] = cam.t[1]
    cam.proj(bx - nx, by - ny, 0f, cam.t); gx[1] = cam.t[0]; gy[1] = cam.t[1]
    band(c, ex, ey, gx, gy, 2, paint, path)
}

/**
 * Circular arc on the grass as a ring of projected points — a real perspective
 * ellipse, not drawOval.
 */
private fun groundArc(
    c: Canvas, cam: Cam, cx: Float, cy: Float, r: Float,
    a0: Float, a1: Float, width: Float, paint: Paint, path: Path, steps: Int = 48
) {
    val ro = r + width * 0.5f
    val ri = r - width * 0.5f
    val n = steps + 1
    val ex = FloatArray(n); val ey = FloatArray(n)
    val gx = FloatArray(n); val gy = FloatArray(n)
    for (i in 0 until n) {
        val a = a0 + (a1 - a0) * i / steps
        val ca = cos(a); val sa = sin(a)
        cam.proj(cx + ro * ca, cy + ro * sa, 0f, cam.t); ex[i] = cam.t[0]; ey[i] = cam.t[1]
        cam.proj(cx + ri * ca, cy + ri * sa, 0f, cam.t); gx[i] = cam.t[0]; gy[i] = cam.t[1]
    }
    band(c, ex, ey, gx, gy, n, paint, path)
}

/** Renamed from shade() to avoid clashing with Theme.kt's public shade(). */
private fun brShade(col: Int, k: Float): Int {
    val a = Color.alpha(col)
    val r = min(255, (Color.red(col) * k).toInt())
    val g = min(255, (Color.green(col) * k).toInt())
    val b = min(255, (Color.blue(col) * k).toInt())
    return Color.argb(a, r, g, b)
}

private fun hashF(i: Int): Float {
    var x = i * 374761393 + 668265263
    x = (x xor (x shr 13)) * 1274126177
    return ((x xor (x shr 16)) and 0x7FFFFFF) / 134217727f
}

// ---------------------------------------------------------------------------
// Backdrop: sky, stands, crowd, hoardings, dugouts — everything beyond y = 0
// ---------------------------------------------------------------------------

private val SPONSORS = arrayOf(
    "NORVEX", "KALDRA", "DUGOUT", "BELMARA", "TRIVOLT", "OSTRA",
    "FENNIK", "CALDERA", "MERIDIA", "VANTO", "ZEPHYRA", "HALLOW & CO"
)

private fun drawBackdrop(c: Canvas, cam: Cam, pens: Pens) {
    val f = pens.flat
    val path = pens.path

    // Sky / far darkness above the stand roof.
    f.shader = null
    f.color = 0xFF1A2028.toInt()
    c.drawRect(0f, 0f, cam.w, cam.h, f)

    if (!BroadcastCamera.drawStands) return

    val x0 = -40f
    val x1 = PITCH_L + 40f

    // --- Stand: raked seating plane from the front wall back and up ---
    val rows = 30
    val frontY = -7.5f
    val rowDepth = 1.15f
    val rowRise = 0.78f
    val frontZ = 1.6f

    // Solid mass of the stand (so no sky shows through between crowd dots).
    poly(
        c, cam, floatArrayOf(
            x0, frontY, frontZ, x1, frontY, frontZ,
            x1, frontY - rows * rowDepth, frontZ + rows * rowRise,
            x0, frontY - rows * rowDepth, frontZ + rows * rowRise
        ), f.apply { color = 0xFF2E3A46.toInt() }, path
    )

    // Crowd: two-per-row-offset blobs, deterministic from index (no state).
    val step = 0.72f
    val nAcross = ((x1 - x0) / step).toInt()
    for (r in 0 until rows) {
        val ry = frontY - r * rowDepth
        val rz = frontZ + r * rowRise
        // Row shading: darker deep in the stand.
        val k = 0.62f + 0.38f * (1f - r / rows.toFloat())
        for (i in 0 until nAcross) {
            val idx = r * 977 + i * 37
            val hx = hashF(idx)
            val px = x0 + (i + 0.5f + (hx - 0.5f) * 0.35f) * step
            cam.proj(px, ry + (hashF(idx + 5) - 0.5f) * 0.3f, rz, cam.t)
            val sxp = cam.t[0]
            if (sxp < -20f || sxp > cam.w + 20f) continue
            val syp = cam.t[1]
            if (syp > cam.h + 10f) continue
            val s = cam.scale(cam.t[2])
            val bw = 0.42f * s
            val bh = 0.62f * s
            if (bw < 0.6f) continue
            val hue = hashF(idx + 11)
            val body: Int
            val head: Int
            if (hue < 0.42f) {          // home colours in the stand
                body = brShade(0xFFB8452E.toInt(), k * (0.8f + hashF(idx + 3) * 0.4f))
            } else if (hue < 0.66f) {
                body = brShade(0xFF2F3F70.toInt(), k * (0.8f + hashF(idx + 7) * 0.4f))
            } else if (hue < 0.84f) {
                body = brShade(0xFF5A6070.toInt(), k * (0.8f + hashF(idx + 9) * 0.4f))
            } else {
                body = brShade(0xFFC9C3B0.toInt(), k * (0.75f + hashF(idx + 13) * 0.3f))
            }
            head = brShade(
                when ((hashF(idx + 17) * 4f).toInt()) {
                    0 -> 0xFFB88A62.toInt(); 1 -> 0xFF8C5A3A.toInt(); 2 -> 0xFF5B3A24.toInt()
                    else -> 0xFFD8A87C.toInt()
                }, k
            )
            f.color = body
            c.drawRect(sxp - bw * 0.5f, syp - bh, sxp + bw * 0.5f, syp, f)
            f.color = head
            c.drawRect(sxp - bw * 0.3f, syp - bh - bh * 0.42f, sxp + bw * 0.3f, syp - bh * 0.94f, f)
        }
    }

    // Roof lip / upper shadow band.
    poly(
        c, cam, floatArrayOf(
            x0, frontY - rows * rowDepth, frontZ + rows * rowRise,
            x1, frontY - rows * rowDepth, frontZ + rows * rowRise,
            x1, frontY - rows * rowDepth - 6f, frontZ + rows * rowRise + 9f,
            x0, frontY - rows * rowDepth - 6f, frontZ + rows * rowRise + 9f
        ), f.apply { color = 0xFF141A21.toInt() }, path
    )

    // --- Front wall of the stand (in shadow) ---
    poly(
        c, cam, floatArrayOf(
            x0, frontY, 0f, x1, frontY, 0f, x1, frontY, frontZ, x0, frontY, frontZ
        ), f.apply { color = 0xFF232B33.toInt() }, path
    )

    drawDugouts(c, cam, pens)
    drawHoardings(c, cam, pens)
}

private fun drawHoardings(c: Canvas, cam: Cam, pens: Pens) {
    val f = pens.flat
    val path = pens.path
    val yb = -4.2f          // hoardings sit just beyond the far touchline
    val hz = 1.05f
    val pw = 3.6f
    val x0 = -18f
    val n = ((PITCH_L + 36f) / pw).toInt()

    for (i in 0 until n) {
        val ax = x0 + i * pw
        val bx = ax + pw - 0.06f
        val sxa = cam.sx(ax, yb, hz)
        val sxb = cam.sx(bx, yb, hz)
        if (sxb < -30f || sxa > cam.w + 30f) continue

        val dark = (i % 2 == 0)
        f.color = if (dark) 0xFF1E2530.toInt() else 0xFFE8E6DE.toInt()
        poly(c, cam, floatArrayOf(ax, yb, 0f, bx, yb, 0f, bx, yb, hz, ax, yb, hz), f, path)

        // Top rail catches the light.
        f.color = if (dark) 0xFF39414D.toInt() else 0xFFFFFFFF.toInt()
        poly(
            c, cam,
            floatArrayOf(ax, yb, hz, bx, yb, hz, bx, yb, hz - 0.09f, ax, yb, hz - 0.09f), f, path
        )

        // Sponsor name, drawn along the panel.
        val name = SPONSORS[i % SPONSORS.size]
        val topA = cam.sy(ax, yb, hz)
        val botA = cam.sy(ax, yb, 0f)
        val hpx = botA - topA
        if (hpx > 5f) {
            val t = pens.text
            t.color = if (dark) 0xFFF2F2EE.toInt() else 0xFF161C24.toInt()
            t.textSize = hpx * 0.62f
            val cxp = (sxa + sxb) * 0.5f
            val cyp = (topA + botA) * 0.5f + hpx * 0.22f
            val avail = abs(sxb - sxa) * 0.86f
            val wpx = t.measureText(name)
            c.save()
            if (wpx > avail && wpx > 0f) {
                c.scale(avail / wpx, 1f, cxp, cyp)
            }
            c.drawText(name, cxp, cyp, t)
            c.restore()
        }
    }
}

private fun drawDugouts(c: Canvas, cam: Cam, pens: Pens) {
    val f = pens.flat
    val path = pens.path
    for (s in 0..1) {
        val cx = if (s == 0) PITCH_L * 0.5f - 12f else PITCH_L * 0.5f + 4.5f
        val x0 = cx
        val x1 = cx + 7.5f
        val yf = -5.0f
        val yb = -7.2f
        val zt = 2.35f
        // Body
        f.color = 0xFF2A3038.toInt()
        poly(c, cam, floatArrayOf(x0, yf, 0f, x1, yf, 0f, x1, yf, zt * 0.55f, x0, yf, zt * 0.55f), f, path)
        // Seated staff
        for (i in 0 until 5) {
            val px = x0 + 0.9f + i * 1.4f
            cam.proj(px, yb + 0.9f, 0.5f, cam.t)
            val sc = cam.scale(cam.t[2])
            f.color = if (i % 2 == 0) 0xFF1C1C22.toInt() else 0xFF3A3A44.toInt()
            c.drawRect(cam.t[0] - 0.22f * sc, cam.t[1] - 0.85f * sc, cam.t[0] + 0.22f * sc, cam.t[1], f)
            f.color = 0xFFC79A72.toInt()
            c.drawRect(cam.t[0] - 0.14f * sc, cam.t[1] - 1.12f * sc, cam.t[0] + 0.14f * sc, cam.t[1] - 0.88f * sc, f)
        }
        // Roof
        f.color = 0xFF3C4652.toInt()
        poly(c, cam, floatArrayOf(x0 - 0.3f, yf, zt, x1 + 0.3f, yf, zt, x1 + 0.3f, yb, zt + 0.5f, x0 - 0.3f, yb, zt + 0.5f), f, path)
        // Dark mouth under the roof
        f.color = 0xFF11151A.toInt()
        poly(c, cam, floatArrayOf(x0, yf, zt * 0.55f, x1, yf, zt * 0.55f, x1, yf, zt, x0, yf, zt), f, path)
    }
}

// ---------------------------------------------------------------------------
// Grass
// ---------------------------------------------------------------------------

private fun drawGrass(c: Canvas, cam: Cam, pens: Pens) {
    val f = pens.flat
    val path = pens.path
    val ox = 12f     // grass surround beyond the pitch, metres
    val oyFar = 4.0f
    val oyNear = 8f

    val gx0 = -ox
    val gx1 = PITCH_L + ox
    val gy0 = -oyFar
    val gy1 = PITCH_W + oyNear

    f.color = 0xFF5A8135.toInt()
    groundQuad(c, cam, gx0, gy0, gx1, gy0, gx1, gy1, gx0, gy1, f, path)

    // Mow stripes: bands of constant x, so they run "vertically" on screen.
    val stripe = PITCH_L / 20f
    var i = -3
    while (i < 23) {
        val a = i * stripe
        val b = a + stripe
        if (b < gx0 || a > gx1) { i++; continue }
        val aa = max(a, gx0); val bb = min(b, gx1)
        f.color = if (i % 2 == 0) 0xFF62873A.toInt() else 0xFF53792D.toInt()
        groundQuad(c, cam, aa, gy0, bb, gy0, bb, gy1, aa, gy1, f, path)
        i++
    }

    // Slight far-side wash: the far half sits in the stand's light falloff.
    f.color = 0x12000000
    groundQuad(c, cam, gx0, gy0, gx1, gy0, gx1, PITCH_W * 0.42f, gx0, PITCH_W * 0.42f, f, path)
}

// ---------------------------------------------------------------------------
// Pitch markings — every element that spans depth is a projected trapezoid
// ---------------------------------------------------------------------------

private fun drawMarkings(c: Canvas, cam: Cam, pens: Pens) {
    val f = pens.fill
    val path = pens.path
    f.shader = null
    f.color = 0xF0FFFFFF.toInt()

    // Outline
    groundLine(c, cam, 0f, 0f, PITCH_L, 0f, LINE_W, f, path)                 // far touchline
    groundLine(c, cam, 0f, PITCH_W, PITCH_L, PITCH_W, LINE_W, f, path)       // near touchline
    groundLine(c, cam, 0f, 0f, 0f, PITCH_W, LINE_W, f, path)                 // goal lines
    groundLine(c, cam, PITCH_L, 0f, PITCH_L, PITCH_W, LINE_W, f, path)

    // Halfway line
    groundLine(c, cam, PITCH_L * 0.5f, 0f, PITCH_L * 0.5f, PITCH_W, LINE_W, f, path)

    // Centre circle + spot
    groundArc(c, cam, PITCH_L * 0.5f, PITCH_W * 0.5f, CIRCLE_R, 0f, 6.2831855f, LINE_W, f, path, 56)
    groundArc(c, cam, PITCH_L * 0.5f, PITCH_W * 0.5f, 0.11f, 0f, 6.2831855f, 0.22f, f, path, 12)

    for (end in 0..1) {
        val gx = if (end == 0) 0f else PITCH_L
        val s = if (end == 0) 1f else -1f
        val cy = PITCH_W * 0.5f

        // Penalty area
        val pd = gx + s * PEN_DEPTH
        groundLine(c, cam, gx, cy - PEN_HALF, pd, cy - PEN_HALF, LINE_W, f, path)
        groundLine(c, cam, gx, cy + PEN_HALF, pd, cy + PEN_HALF, LINE_W, f, path)
        groundLine(c, cam, pd, cy - PEN_HALF, pd, cy + PEN_HALF, LINE_W, f, path)

        // Goal area
        val gd = gx + s * GOALA_DEPTH
        groundLine(c, cam, gx, cy - GOALA_HALF, gd, cy - GOALA_HALF, LINE_W, f, path)
        groundLine(c, cam, gx, cy + GOALA_HALF, gd, cy + GOALA_HALF, LINE_W, f, path)
        groundLine(c, cam, gd, cy - GOALA_HALF, gd, cy + GOALA_HALF, LINE_W, f, path)

        // Penalty spot
        val spx = gx + s * PEN_SPOT
        groundArc(c, cam, spx, cy, 0.11f, 0f, 6.2831855f, 0.22f, f, path, 12)

        // The D: arc of radius 9.15 about the spot, only outside the box.
        val cosA = (PEN_DEPTH - PEN_SPOT) / CIRCLE_R
        val a = kotlin.math.acos(cosA.toDouble()).toFloat()
        val base = if (end == 0) 0f else 3.14159265f
        groundArc(c, cam, spx, cy, CIRCLE_R, base - a, base + a, LINE_W, f, path, 26)

        // Corner arcs
        groundArc(c, cam, gx, 0f, CORNER_R, if (end == 0) 0f else 1.5707963f,
            if (end == 0) 1.5707963f else 3.14159265f, LINE_W, f, path, 10)
        groundArc(c, cam, gx, PITCH_W, CORNER_R, if (end == 0) -1.5707963f else 3.14159265f,
            if (end == 0) 0f else 4.712389f, LINE_W, f, path, 10)
    }
}

// ---------------------------------------------------------------------------
// Goals
// ---------------------------------------------------------------------------

private fun drawGoal(c: Canvas, cam: Cam, pens: Pens, gx: Float) {
    val f = pens.fill
    val path = pens.path
    val out = if (gx < 1f) -1f else 1f      // direction the net runs, away from the pitch
    val cy = PITCH_W * 0.5f
    val y0 = cy - GOAL_HALF
    val y1 = cy + GOAL_HALF
    val netTop = 1.5f * out                  // net depth at the crossbar
    val netBot = 2.3f * out                  // net depth on the ground
    val post = 0.12f

    // --- Net: mesh lines on the back, sides and roof ---
    val netPaint = pens.line
    netPaint.shader = null
    netPaint.color = 0x66FFFFFF
    netPaint.strokeWidth = max(1f, cam.scale(cam.depthAt(gx, cy)) * 0.02f)

    val mesh = 0.38f
    // Back panel (a slanted plane from top-back to ground-back)
    run {
        var y = y0
        while (y <= y1 + 1e-3f) {
            path.reset()
            cam.proj(gx + netTop, y, GOAL_H, cam.t); path.moveTo(cam.t[0], cam.t[1])
            cam.proj(gx + netBot, y, 0f, cam.t); path.lineTo(cam.t[0], cam.t[1])
            c.drawPath(path, netPaint)
            y += mesh
        }
        var k = 0f
        while (k <= 1.0001f) {
            val xx = gx + netTop + (netBot - netTop) * k
            val zz = GOAL_H * (1f - k)
            path.reset()
            cam.proj(xx, y0, zz, cam.t); path.moveTo(cam.t[0], cam.t[1])
            cam.proj(xx, y1, zz, cam.t); path.lineTo(cam.t[0], cam.t[1])
            c.drawPath(path, netPaint)
            k += mesh / GOAL_H
        }
    }
    // Side panels + roof
    for (side in 0..1) {
        val yy = if (side == 0) y0 else y1
        var k = 0f
        while (k <= 1.0001f) {
            path.reset()
            cam.proj(gx + netTop * k, yy, GOAL_H, cam.t); path.moveTo(cam.t[0], cam.t[1])
            cam.proj(gx + netBot * k, yy, 0f, cam.t); path.lineTo(cam.t[0], cam.t[1])
            c.drawPath(path, netPaint)
            k += mesh / 2.2f
        }
        var z = 0f
        while (z <= GOAL_H) {
            path.reset()
            cam.proj(gx, yy, z, cam.t); path.moveTo(cam.t[0], cam.t[1])
            cam.proj(gx + netBot * (1f - z / GOAL_H) + netTop * (z / GOAL_H), yy, z, cam.t)
            path.lineTo(cam.t[0], cam.t[1])
            c.drawPath(path, netPaint)
            z += mesh
        }
    }
    // Roof mesh
    run {
        var y = y0
        while (y <= y1 + 1e-3f) {
            path.reset()
            cam.proj(gx, y, GOAL_H, cam.t); path.moveTo(cam.t[0], cam.t[1])
            cam.proj(gx + netTop, y, GOAL_H, cam.t); path.lineTo(cam.t[0], cam.t[1])
            c.drawPath(path, netPaint)
            y += mesh
        }
    }

    // --- Frame: posts and crossbar as depth-scaled boxes ---
    f.shader = null
    for (side in 0..1) {
        val yy = if (side == 0) y0 else y1
        f.color = 0xFFFFFFFF.toInt()
        poly(c, cam, floatArrayOf(
            gx - post * 0.5f, yy - post * 0.5f, 0f, gx + post * 0.5f, yy - post * 0.5f, 0f,
            gx + post * 0.5f, yy - post * 0.5f, GOAL_H, gx - post * 0.5f, yy - post * 0.5f, GOAL_H
        ), f, path)
        f.color = 0xFFD2D6DA.toInt()
        poly(c, cam, floatArrayOf(
            gx + post * 0.5f, yy - post * 0.5f, 0f, gx + post * 0.5f, yy + post * 0.5f, 0f,
            gx + post * 0.5f, yy + post * 0.5f, GOAL_H, gx + post * 0.5f, yy - post * 0.5f, GOAL_H
        ), f, path)
    }
    f.color = 0xFFFFFFFF.toInt()
    poly(c, cam, floatArrayOf(
        gx, y0 - post * 0.5f, GOAL_H, gx, y1 + post * 0.5f, GOAL_H,
        gx, y1 + post * 0.5f, GOAL_H - post, gx, y0 - post * 0.5f, GOAL_H - post
    ), f, path)
    f.color = 0xFFE4E8EC.toInt()
    poly(c, cam, floatArrayOf(
        gx, y0 - post * 0.5f, GOAL_H, gx + post * out, y0 - post * 0.5f, GOAL_H,
        gx + post * out, y1 + post * 0.5f, GOAL_H, gx, y1 + post * 0.5f, GOAL_H
    ), f, path)
}

// ---------------------------------------------------------------------------
// Ball
// ---------------------------------------------------------------------------

private fun drawBall(c: Canvas, cam: Cam, pens: Pens, b: RBall) {
    val xm = b.x / MX
    val ym = b.y / MY
    val zm = max(b.height, 0f) / MY
    val f = pens.fill
    f.shader = null

    // Shadow on the grass, thrown along the light direction.
    val sx = xm + zm * 1.35f
    val sy = ym + zm * 0.5f
    val a = (60f * (1f - min(zm / 6f, 0.7f))).toInt()
    f.color = Color.argb(a, 12, 30, 12)
    val path = pens.path
    path.reset()
    for (i in 0 until 10) {
        val t = i / 10f * 6.2831855f
        cam.proj(sx + 0.13f * cos(t), sy + 0.13f * sin(t), 0f, cam.t)
        if (i == 0) path.moveTo(cam.t[0], cam.t[1]) else path.lineTo(cam.t[0], cam.t[1])
    }
    path.close()
    c.drawPath(path, f)

    cam.proj(xm, ym, zm + 0.11f, cam.t)
    val r = max(1.2f, cam.scale(cam.t[2]) * 0.11f)
    f.color = 0xFFFAFAF6.toInt()
    c.drawCircle(cam.t[0], cam.t[1], r, f)
    // Panels
    f.color = 0xFF2A2A2E.toInt()
    val sp = b.spin
    c.drawCircle(cam.t[0] + cos(sp) * r * 0.34f, cam.t[1] + sin(sp) * r * 0.34f, r * 0.30f, f)
    c.drawCircle(cam.t[0] + cos(sp + 2.3f) * r * 0.5f, cam.t[1] + sin(sp + 2.3f) * r * 0.5f, r * 0.18f, f)
    f.color = 0x30000000
    c.drawCircle(cam.t[0] + r * 0.22f, cam.t[1] + r * 0.26f, r * 0.72f, f)
}

// ---------------------------------------------------------------------------
// Shadows
// ---------------------------------------------------------------------------

private const val LIGHT_X = 1.35f      // shadow metres per metre of height
private const val LIGHT_Y = 0.50f

private fun drawShadow(c: Canvas, cam: Cam, pens: Pens, xm: Float, ym: Float, len: Float, wid: Float) {
    val f = pens.flat
    val path = pens.path
    f.shader = null
    f.color = 0x4C0E2410
    val ex = LIGHT_X * len * 0.5f
    val ey = LIGHT_Y * len * 0.5f
    val cx = xm + ex * 0.55f
    val cy = ym + ey * 0.55f
    val ax = ex * 0.95f
    val ay = ey * 0.95f
    val bx = -ay / sqrt(ax * ax + ay * ay + 1e-6f) * wid
    val by = ax / sqrt(ax * ax + ay * ay + 1e-6f) * wid
    path.reset()
    for (i in 0 until 14) {
        val t = i / 14f * 6.2831855f
        val ct = cos(t); val st = sin(t)
        cam.proj(cx + ax * ct + bx * st, cy + ay * ct + by * st, 0f, cam.t)
        if (i == 0) path.moveTo(cam.t[0], cam.t[1]) else path.lineTo(cam.t[0], cam.t[1])
    }
    path.close()
    c.drawPath(path, f)
}

// ---------------------------------------------------------------------------
// Players
// ---------------------------------------------------------------------------

private fun keeperKit(own: RKit, other: RKit): RKit {
    val palette = intArrayOf(
        0xFF2FD07A.toInt(), 0xFFF2E43A.toInt(), 0xFF9B39C9.toInt(),
        0xFFFF7A18.toInt(), 0xFF19C7D6.toInt(), 0xFF1A1A22.toInt()
    )
    var best = palette[0]
    var bestD = -1f
    for (p in palette) {
        val d = min(colDist(p, own.primary), min(colDist(p, other.primary), min(colDist(p, own.secondary), colDist(p, other.secondary))))
        if (d > bestD) { bestD = d; best = p }
    }
    return RKit(best, brShade(best, 0.45f), 0)
}

private fun colDist(a: Int, b: Int): Float {
    val dr = (Color.red(a) - Color.red(b)).toFloat()
    val dg = (Color.green(a) - Color.green(b)).toFloat()
    val db = (Color.blue(a) - Color.blue(b)).toFloat()
    return sqrt(dr * dr * 0.9f + dg * dg * 1.2f + db * db * 0.7f)
}

private val SKIN = intArrayOf(
    0xFFF2C9A0.toInt(), 0xFFD9A578.toInt(), 0xFFB07A4C.toInt(), 0xFF7A4E2E.toInt(), 0xFF4E2F1C.toInt()
)
private val HAIR = intArrayOf(
    0xFF1B1410.toInt(), 0xFF2E1C10.toInt(), 0xFF6B4423.toInt(), 0xFFC9A24B.toInt(), 0xFF8E8E92.toInt()
)

/**
 * Low-poly figure: a skeleton posed in 3D body-local metres, rotated by facing,
 * then projected through the same pinhole as the pitch — so it foreshortens and
 * scales with depth automatically. Proportions are 5 heads tall (head = H/5),
 * hips at 53% of height: small head, long legs.
 */
private fun drawPlayer(c: Canvas, cam: Cam, pens: Pens, p: RPlayer, kit: RKit) {
    val xm = p.x / MX
    val ym = p.y / MY

    // Body direction in METRES. The pitch-unit grid is anisotropic, so a heading
    // has to be converted before it can be used as a world direction.
    var fx = cos(p.facing) / MX
    var fy = sin(p.facing) / MY
    val fl = sqrt(fx * fx + fy * fy)
    fx /= fl; fy /= fl
    val rx = fy      // right-hand perpendicular in the ground plane
    val ry = -fx

    val sd = p.seed
    val k = PLAYER_H * (0.955f + hashF(sd) * 0.09f) / PLAYER_H * BroadcastCamera.figureScale
    val skin = SKIN[(hashF(sd + 31) * SKIN.size).toInt().coerceIn(0, SKIN.size - 1)]
    val hair = HAIR[(hashF(sd + 57) * HAIR.size).toInt().coerceIn(0, HAIR.size - 1)]

    val run = min(abs(p.speed) / 7.5f, 1f)
    val ph = p.runPhase
    val lean = 0.05f + 0.20f * run

    // --- skeleton, body-local metres: u = right, v = forward, z = up ---
    val hipZ = 0.95f * k          // 53% of standing height
    val thigh = 0.46f * k
    val shin = 0.44f * k
    val shoulderZ = 1.40f * k
    val shHalf = 0.21f * k
    val hipHalf = 0.115f * k
    val bodyD = 0.115f * k        // torso half-thickness, front to back
    val upperArm = 0.30f * k
    val foreArm = 0.28f * k
    val headR = 0.16f * k         // head spans 1.46k..1.78k = H/5
    val headZ = 1.62f * k

    val ankU = FloatArray(2); val ankV = FloatArray(2); val ankZ = FloatArray(2)
    val kneeU = FloatArray(2); val kneeV = FloatArray(2); val kneeZ = FloatArray(2)
    val hipU = FloatArray(2)
    var lowest = 1e9f
    for (s in 0..1) {
        val lp = ph + s * 3.14159265f
        val hipA = sin(lp) * (0.22f + 0.62f * run)
        val kneeA = 0.10f + (0.25f + 1.05f * run) * max(0f, -sin(lp - 0.7f))
        val u = (if (s == 0) -hipHalf else hipHalf) * 1.02f
        hipU[s] = u
        val kv = sin(hipA) * thigh
        val kz = hipZ - cos(hipA) * thigh
        kneeU[s] = u; kneeV[s] = kv; kneeZ[s] = kz
        val a2 = hipA - kneeA
        ankU[s] = u
        ankV[s] = kv + sin(a2) * shin
        ankZ[s] = kz - cos(a2) * shin
        if (ankZ[s] < lowest) lowest = ankZ[s]
    }
    val lift = 0.05f * k - lowest      // plant the lower foot on the grass
    val bob = if (run > 0.02f) 0.02f * k * cos(2f * ph) else 0f

    val hndU = FloatArray(2); val hndV = FloatArray(2); val hndZ = FloatArray(2)
    val elbU = FloatArray(2); val elbV = FloatArray(2); val elbZ = FloatArray(2)
    for (s in 0..1) {
        val lp = ph + s * 3.14159265f
        val swing = if (p.isKeeper) 0.7f else -sin(lp) * (0.30f + 0.55f * run)
        val out = if (p.isKeeper) 0.5f else 0.11f + 0.07f * run
        val u = if (s == 0) -shHalf else shHalf
        val eu = u + (if (s == 0) -out else out) * 0.45f
        val ev = sin(swing) * upperArm
        val ez = shoulderZ - cos(swing) * upperArm * 0.98f
        elbU[s] = eu; elbV[s] = ev; elbZ[s] = ez
        val fa = swing + (if (p.isKeeper) 0.35f else 0.55f + 0.5f * run)
        hndU[s] = eu + (if (s == 0) -out else out) * 0.45f
        hndV[s] = ev + sin(fa) * foreArm
        hndZ[s] = ez - cos(fa) * foreArm * 0.92f
    }

    // --- projection of a body-local point, including the forward lean ---
    val tmp = FloatArray(3)
    fun w(u: Float, v: Float, z: Float, o: FloatArray) {
        val dz = z - hipZ
        val vv = v + dz * sin(lean)
        val zz = hipZ + dz * cos(lean)
        cam.proj(xm + rx * u + fx * vv, ym + ry * u + fy * vv, zz + lift + bob, o)
    }

    val pelv = FloatArray(3); w(0f, 0f, hipZ, pelv)
    if (pelv[0] < -160f || pelv[0] > cam.w + 160f) return
    val sc = cam.scale(pelv[2])
    val f = pens.fill
    f.shader = null

    val shirt = kit.primary
    val shirt2 = kit.secondary
    val shorts = if (kit.pattern == 2) kit.primary else kit.secondary
    val socks = kit.primary

    // Which flank is farther from the camera? Larger world y = nearer.
    val farSide = if (ry > 0f) 0 else 1
    val order = intArrayOf(farSide, 1 - farSide)
    // Is the chest or the back turned toward the camera?
    val chestToCam = fy > 0f
    val faceV = if (chestToCam) bodyD else -bodyD

    val a = FloatArray(3); val b = FloatArray(3); val d = FloatArray(3); val e = FloatArray(3)
    val path = pens.path

    // ---- far leg, far arm ----
    drawLeg(c, cam, f, pens, order[0], 0.84f, hipU, kneeU, kneeV, kneeZ, ankU, ankV, ankZ,
        hipZ, k, sc, shorts, socks, fx, fy, ::w, a, b, d)
    drawArm(c, cam, f, order[0], 0.84f, shHalf, shoulderZ, elbU, elbV, elbZ, hndU, hndV, hndZ,
        k, sc, shirt, skin, ::w, a, b, d)

    // ---- torso: an 8-corner box, hulled so it never degenerates edge-on ----
    run {
        val cor = FloatArray(16)
        var n = 0
        for (sgn in intArrayOf(-1, 1)) for (vs in intArrayOf(-1, 1)) {
            w(shHalf * sgn, bodyD * vs, shoulderZ, a); cor[n++] = a[0]; cor[n++] = a[1]
        }
        for (sgn in intArrayOf(-1, 1)) for (vs in intArrayOf(-1, 1)) {
            w(hipHalf * 1.2f * sgn, bodyD * 0.9f * vs, hipZ + 0.05f * k, a); cor[n++] = a[0]; cor[n++] = a[1]
        }
        hull(cor, path)
        f.color = brShade(shirt, 0.86f)
        c.drawPath(path, f)

        // Front (or back) face, carrying the pattern.
        w(-shHalf, faceV, shoulderZ, a); w(shHalf, faceV, shoulderZ, b)
        w(hipHalf * 1.2f, faceV * 0.9f, hipZ + 0.05f * k, d)
        w(-hipHalf * 1.2f, faceV * 0.9f, hipZ + 0.05f * k, e)
        quad(c, f, a, b, d, e, path, shirt)

        when (kit.pattern) {
            1 -> {          // vertical stripes
                for (j in 0 until 5) {
                    if (j % 2 == 0) continue
                    val u0 = -shHalf + j * (2f * shHalf / 5f)
                    val u1 = u0 + 2f * shHalf / 5f
                    w(u0, faceV, shoulderZ, a); w(u1, faceV, shoulderZ, b)
                    w(u1 * 0.58f, faceV * 0.9f, hipZ + 0.05f * k, d)
                    w(u0 * 0.58f, faceV * 0.9f, hipZ + 0.05f * k, e)
                    quad(c, f, a, b, d, e, path, shirt2)
                }
            }
            2 -> {          // sash
                w(-shHalf, faceV, shoulderZ, a); w(-shHalf * 0.3f, faceV, shoulderZ, b)
                w(hipHalf * 1.2f, faceV * 0.9f, hipZ + 0.05f * k, d)
                w(hipHalf * 0.2f, faceV * 0.9f, hipZ + 0.05f * k, e)
                quad(c, f, a, b, d, e, path, shirt2)
            }
            3 -> {          // hoops
                for (q in 0 until 2) {
                    val z0 = shoulderZ - (0.13f + q * 0.19f) * k
                    val z1 = z0 - 0.085f * k
                    w(-shHalf * 0.99f, faceV, z0, a); w(shHalf * 0.99f, faceV, z0, b)
                    w(shHalf * 0.9f, faceV, z1, d); w(-shHalf * 0.9f, faceV, z1, e)
                    quad(c, f, a, b, d, e, path, shirt2)
                }
            }
        }
        // Flat side shading — one plane a shade darker, PS1 vertex-lighting look.
        val su = if (farSide == 0) shHalf else -shHalf
        w(su, -bodyD, shoulderZ, a); w(su, bodyD, shoulderZ, b)
        w(su * 0.55f, bodyD * 0.9f, hipZ + 0.05f * k, d)
        w(su * 0.55f, -bodyD * 0.9f, hipZ + 0.05f * k, e)
        quad(c, f, a, b, d, e, path, 0x22000000)
    }

    // ---- near leg, near arm ----
    drawLeg(c, cam, f, pens, order[1], 1f, hipU, kneeU, kneeV, kneeZ, ankU, ankV, ankZ,
        hipZ, k, sc, shorts, socks, fx, fy, ::w, a, b, d)
    drawArm(c, cam, f, order[1], 1f, shHalf, shoulderZ, elbU, elbV, elbZ, hndU, hndV, hndZ,
        k, sc, shirt, skin, ::w, a, b, d)

    // ---- neck + head ----
    run {
        w(0f, 0.015f * k, shoulderZ, a)
        w(0f, 0.02f * k, headZ, b)
        bone(c, f, a, b, 0.062f * k * sc, 0.085f * k * sc, brShade(skin, 0.84f))
        val hx = b[0]
        val hy = b[1]
        val hr = max(headR * sc, 1.2f)
        f.color = skin
        c.drawCircle(hx, hy, hr, f)
        // Hair: a cap over the crown, dropping further down when facing away.
        f.color = hair
        val backOfHead = !chestToCam
        val hp = pens.path
        hp.reset()
        val drop = if (backOfHead) 0.45f else -0.22f
        for (i in 0..10) {
            val ang = 3.14159265f + 3.14159265f * i / 10f
            val px2 = hx + hr * 1.02f * cos(ang)
            val py2 = hy + hr * 1.02f * sin(ang)
            // The first point has to be a moveTo. Android silently treats a
            // lineTo on a fresh path as starting from (0,0), which would draw a
            // spike from the corner of the screen to every player's head; a
            // strict Path implementation throws instead.
            if (i == 0) hp.moveTo(px2, py2) else hp.lineTo(px2, py2)
        }
        hp.lineTo(hx + hr, hy + hr * drop)
        hp.lineTo(hx + hr * 0.66f, hy - hr * (if (backOfHead) 0.05f else 0.34f))
        hp.lineTo(hx - hr * 0.66f, hy - hr * (if (backOfHead) 0.05f else 0.34f))
        hp.lineTo(hx - hr, hy + hr * drop)
        hp.close()
        c.drawPath(hp, f)
    }
}

private inline fun drawLeg(
    c: Canvas, cam: Cam, f: Paint, pens: Pens, s: Int, dim: Float,
    hipU: FloatArray, kneeU: FloatArray, kneeV: FloatArray, kneeZ: FloatArray,
    ankU: FloatArray, ankV: FloatArray, ankZ: FloatArray,
    hipZ: Float, k: Float, sc: Float, shorts: Int, socks: Int,
    fx: Float, fy: Float, w: (Float, Float, Float, FloatArray) -> Unit,
    a: FloatArray, b: FloatArray, d: FloatArray
) {
    w(hipU[s], 0f, hipZ + 0.04f * k, a)
    w(kneeU[s], kneeV[s], kneeZ[s], b)
    w(ankU[s], ankV[s], ankZ[s], d)
    bone(c, f, a, b, 0.105f * k * sc, 0.078f * k * sc, brShade(shorts, dim * 0.94f))
    bone(c, f, b, d, 0.072f * k * sc, 0.055f * k * sc, brShade(socks, dim))
    // Boot: a wedge along the body's forward direction.
    val toe = FloatArray(3)
    w(ankU[s], ankV[s] + 0.20f * k, ankZ[s] - 0.035f * k, toe)
    bone(c, f, d, toe, 0.062f * k * sc, 0.038f * k * sc, brShade(0xFF16161C.toInt(), dim))
}

private inline fun drawArm(
    c: Canvas, cam: Cam, f: Paint, s: Int, dim: Float, shHalf: Float, shoulderZ: Float,
    elbU: FloatArray, elbV: FloatArray, elbZ: FloatArray,
    hndU: FloatArray, hndV: FloatArray, hndZ: FloatArray,
    k: Float, sc: Float, shirt: Int, skin: Int,
    w: (Float, Float, Float, FloatArray) -> Unit,
    a: FloatArray, b: FloatArray, d: FloatArray
) {
    w(if (s == 0) -shHalf * 0.92f else shHalf * 0.92f, 0f, shoulderZ - 0.02f * k, a)
    w(elbU[s], elbV[s], elbZ[s], b)
    w(hndU[s], hndV[s], hndZ[s], d)
    bone(c, f, a, b, 0.070f * k * sc, 0.052f * k * sc, brShade(shirt, dim * 0.97f))
    bone(c, f, b, d, 0.050f * k * sc, 0.042f * k * sc, brShade(skin, dim))
}

/** Tapered quad between two projected joints. */
private fun bone(c: Canvas, f: Paint, a: FloatArray, b: FloatArray, wa: Float, wb: Float, col: Int) {
    var dx = b[0] - a[0]
    var dy = b[1] - a[1]
    val l = sqrt(dx * dx + dy * dy)
    if (l < 0.0001f) { dx = 0f; dy = 1f } else { dx /= l; dy /= l }
    val nx = -dy
    val ny = dx
    val p = Path()
    p.moveTo(a[0] + nx * wa, a[1] + ny * wa)
    p.lineTo(b[0] + nx * wb, b[1] + ny * wb)
    p.lineTo(b[0] - nx * wb, b[1] - ny * wb)
    p.lineTo(a[0] - nx * wa, a[1] - ny * wa)
    p.close()
    f.color = col
    c.drawPath(p, f)
}

private fun quad(c: Canvas, f: Paint, a: FloatArray, b: FloatArray, d: FloatArray, e: FloatArray,
                 path: Path, col: Int) {
    path.reset()
    path.moveTo(a[0], a[1]); path.lineTo(b[0], b[1]); path.lineTo(d[0], d[1]); path.lineTo(e[0], e[1])
    path.close()
    f.color = col
    c.drawPath(path, f)
}

/** Convex hull (monotone chain) of screen-space points held as x,y pairs. */
private fun hull(pts: FloatArray, out: Path) {
    val n = pts.size / 2
    val idx = IntArray(n) { it }
    // insertion sort by x then y
    for (i in 1 until n) {
        val v = idx[i]; var j = i - 1
        while (j >= 0 && (pts[idx[j] * 2] > pts[v * 2] ||
                    (pts[idx[j] * 2] == pts[v * 2] && pts[idx[j] * 2 + 1] > pts[v * 2 + 1]))) {
            idx[j + 1] = idx[j]; j--
        }
        idx[j + 1] = v
    }
    val h = IntArray(2 * n + 1)
    var m = 0
    for (pass in 0 until 2) {
        val start = m
        val range = if (pass == 0) 0 until n else n - 2 downTo 0
        for (ii in range) {
            val q = idx[ii]
            while (m - start >= 2) {
                val o = h[m - 2]; val p1 = h[m - 1]
                val cr = (pts[p1 * 2] - pts[o * 2]) * (pts[q * 2 + 1] - pts[o * 2 + 1]) -
                        (pts[p1 * 2 + 1] - pts[o * 2 + 1]) * (pts[q * 2] - pts[o * 2])
                if (cr <= 0f) m-- else break
            }
            h[m++] = q
        }
        m--
    }
    m++
    out.reset()
    for (i in 0 until m) {
        val q = h[i]
        if (i == 0) out.moveTo(pts[q * 2], pts[q * 2 + 1]) else out.lineTo(pts[q * 2], pts[q * 2 + 1])
    }
    out.close()
}
