import com.dugout.career.core.World
import com.dugout.career.sim.MatchEngine
import com.dugout.career.sim.Season

/**
 * Plays whole matches through the live engine and reports the distribution.
 * The brief fixes the targets: 2.5-2.7 goals a game and roughly 45/25/30 for
 * home, draw, away. This is the check that any engine edit has to survive.
 */
fun main(args: Array<String>) {
    val count = (args.firstOrNull()?.toIntOrNull()) ?: 400
    val spd = (args.getOrNull(1)?.toFloatOrNull()) ?: 6f
    // second argument picks the world, so world to world variation can be
    // told apart from a real change in the engine
    val worldSeed = args.getOrNull(2)?.toLongOrNull() ?: 20260727L
    val world = World.build(worldSeed)
    val season = Season(world)
    season.buildCalendar()
    val league = season.fixtures.filter { it.comp == 0 }
    println("simulating $count matches through the live engine at speed $spd...")

    var goals = 0
    var homeWins = 0; var draws = 0; var awayWins = 0
    var shots = 0; var onTarget = 0; var cards = 0
    var xgHome = 0.0; var xgAway = 0.0
    var cues = 0
    val t0 = System.nanoTime()

    for (i in 0 until count) {
        val fx = league[i % league.size]
        // a fresh fixture object each time, so a replayed one is not marked played
        val m = MatchEngine(world, season, fx)
        m.speed = spd
        // presentation off: this is a measurement of the simulation, not the show
        m.replaysEnabled = false
        m.start()
        var guard = 0
        while (!m.finished && guard < 200_000) {
            m.update(1f / 30f)
            if (!m.running && !m.finished) m.start()      // step through half time
            cues += m.sound.size
            m.sound.clear()
            guard++
        }
        goals += m.score[0] + m.score[1]
        when {
            m.score[0] > m.score[1] -> homeWins++
            m.score[0] == m.score[1] -> draws++
            else -> awayWins++
        }
        shots += m.shots[0] + m.shots[1]
        onTarget += m.onTarget[0] + m.onTarget[1]
        cards += m.yellows[0] + m.yellows[1] + m.reds[0] + m.reds[1]
        xgHome += m.xg[0]; xgAway += m.xg[1]
    }

    val secs = (System.nanoTime() - t0) / 1e9
    val n = count.toDouble()
    println()
    println(String.format("matches            %d  (in %.1f s)", count, secs))
    println(String.format("goals per game     %.2f      target 2.5 - 2.7", goals / n))
    println(String.format("home wins          %.1f%%     target ~45%%", homeWins * 100 / n))
    println(String.format("draws              %.1f%%     target ~25%%", draws * 100 / n))
    println(String.format("away wins          %.1f%%     target ~30%%", awayWins * 100 / n))
    println()
    println(String.format("shots per game     %.1f", shots / n))
    println(String.format("on target per game %.1f", onTarget / n))
    println(String.format("cards per game     %.2f", cards / n))
    println(String.format("xG per game        %.2f  (actual goals %.2f)", (xgHome + xgAway) / n, goals / n))
    println(String.format("sound cues raised  %.1f per match", cues / n))

    val gpg = goals / n
    val hw = homeWins * 100 / n
    val ok = gpg in 2.4..2.8 && hw in 40.0..50.0
    println()
    println(if (ok) "WITHIN TOLERANCE" else "OUT OF TOLERANCE")
}
